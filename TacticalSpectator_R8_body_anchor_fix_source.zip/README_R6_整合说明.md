# Tactical Spectator R6 源码与验证整合包

此包基于 R5 源码，整合逻辑验证工具，并将 Gradle 项目版本标记更新为 `1.0.0-r6`。不代表新增游戏功能已经实装。

## 环境
- Minecraft 1.20.1 / Forge 47.2.8
- Java 17
- Gradle 8.x（GitHub Actions 使用 8.8）
- TacZ 依赖按项目现有要求安装

## 逻辑验证
在工程根目录执行：
```bash
bash verification/run_checks.sh
bash verification/mutation_check.sh
```
逻辑验证使用手写 API 桩，不替代真实 Forge 编译、运行或游戏内测试。
## 构建
```bash
gradle build --no-daemon
```

## 本版本说明
R6 是源码/验证整合版本；不宣称已修复选区框、死亡观战、平板动画或无信号画面等游戏内问题。


## R7：第一人称观战身体渲染（实验性）

观战镜头跟随目标玩家时，在客户端 AFTER_ENTITIES 阶段额外绘制目标玩家模型，并隐藏头部与帽子层，使观战者能从目标玩家眼睛位置看到头部以下的躯干、手臂和腿部。该实现需要在 Forge 1.20.1 实机验证遮挡、装备层、潜行/游泳姿势及帧同步；当前源码包不代表已通过 Forge 编译或游戏内验证。
