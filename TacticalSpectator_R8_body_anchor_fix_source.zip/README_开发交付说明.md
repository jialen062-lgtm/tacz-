# Tactical Spectator r5 — 开发交付说明

> 基线：`tactical_spectator_source_repair_01.zip`　→　本版本：`1.0.0-r5`
> 目标环境：Minecraft 1.20.1 / Forge 47.2.8 / Java 17 / TaCZ 1.1.8-hotfix2

---

## 0. 先说清楚：哪些做了，哪些没做

**没有生成 JAR。** 交付这一版的沙箱没有网络、没有 Gradle、没有任何 Forge / Minecraft / TaCZ 的 jar，所以：

| 项目 | 状态 |
|---|---|
| 修改真实 Java 源码 | ✅ 完成（见第 5 节文件清单） |
| Forge / Gradle 真实编译 | ❌ **没有做**，没有 JAR |
| 游戏内（客户端 / 专用服务器）测试 | ❌ **没有做** |
| 对“手写 API 桩”做 javac 类型检查 | ✅ 0 error / 0 warning（模组代码） |
| 对“可运行假实现”跑逻辑场景测试 | ✅ 14 组 / 130 项断言全部通过 |
| 变异测试（故意改坏逻辑看测试能否抓到） | ✅ 5 种变异全部被抓到 |
| 资源检查（JSON、贴图引用、UV、语言键、mods.toml 展开后解析） | ✅ 通过 |
| 资源是否打进最终 JAR | ❌ 没有 JAR，无法检查 |

验证工具包（桩、假实现、测试、姿态模拟）单独放在 `tactical_spectator_verification_harness.zip`，解压到工程根目录即可运行；完整的构建 / 验证日志见 `BUILD_LOG.txt`。

“桩 / 假实现”是我按记忆写的 1.20.1 / Forge API 外形，**不是真实 jar**，只能证明：语法正确、我自己各个类之间互相调用一致、状态机 / 持久化 / 网络包编解码的逻辑在我假设的 API 行为下是对的。**它不能证明和真实 Forge 兼容。** 详见 `BUILD_LOG.txt`。

### 你本地怎么构建

1. 安装 **JDK 17** 与 **Gradle 8.1.x**（ForgeGradle 6.0–6.1 需要）。工程里没有 `gradlew`，先在工程根目录执行
   `gradle wrapper --gradle-version 8.1.1`。
2. `gradle.properties` 里的 `org.gradle.java.installations.paths=/opt/jdks/...` 是原生成环境的路径，你的机器上不存在；如果 Gradle 报 toolchain 警告 / 错误，直接删掉这一行。
3. `./gradlew build` → `build/libs/tactical_spectator-1.0.0-r5.jar`（带 reobf）。
4. 运行环境需要同时装 **TaCZ**（mods.toml 已声明为必需依赖，见第 3 节）。
5. 编译出错时，先对照第 6 节“首次编译优先核对的 API 点”。

---

## 1. 已完成功能清单（代码已写，未经游戏内实测）

### 区域与选区
- 原版木棍选区：左键 = 位置 1，右键 = 位置 2；不破坏方块、不触发箱子等交互；提示坐标与体积。
- 边框只在主手 **或** 副手持木棍时显示；收起立即隐藏、**不清除坐标**；再拿起继续显示。
- 边框预览改为**服务端确认后**才显示（`S2CWandSelectionPacket`），被服务端拒绝的点不会出现；切换维度 / 登录时服务端与客户端同时清空。
- `/ts wand`（新增）、`/ts region create|list|delete|resize`、`/ts tablet`；区域名取整行文本，**支持中文和空格**。
- 多区域、唯一 ID、名称 / 所有者 / 维度 / 坐标、SavedData 持久化、允许重叠、体积最小优先、体积相同按稳定 ID。
- 所有者管理自己的区域，OP（权限 2）管理全部。

### 回合
- 每个区域独立回合；进入区域自动参战；多区域同时运行；一个区域全员死亡只结束该区域。
- 死亡 → 淘汰；**复活不恢复存活**；身份绑定“原本所属回合”，与死亡位置无关。
- 下线保留身份；重新连接后恢复状态并同步名单（客户端因此知道自己已淘汰，才能长按 F）。
- 一个玩家同一时刻只会在一个名单里。
- 区域删除 → 回合作废、观战结束、HUD 清空。
- **回合持久化（已实现）**：`RoundStore`（SavedData）随存档保存，服务器重启后淘汰 / 存活身份保留；绑定时清理对应区域已不存在的回合；异常存档去重。
- `/ts round reset <区域>`（新增，所有者或 OP）：手动结束回合，用于“最后的存活者已下线导致回合一直不结束”之类的残留。

### 战术平板与动画
- 长按 F：从背包取出平板（只取出，**不会进入观战**）；短按 F 保留原版副手交换。
- 必须实际手持平板右键才能进入 / 退出观战（服务端校验手持）；右键方块时不再触发方块交互。
- 观战中右键 = 退出（旧版取消了所有交互，导致根本无法右键退出，已修）；长按 F = 退出观战并收回平板（平板换回之前的物品）。
- 平板动画状态机：未持有 / 掏出中 / 持有中 / 收回中；掏出前先“等枪退出视野”再从画面左下方抬起；收回时降到画面下方后才让服务端换回物品；切物品、切槽位、死亡、断线都会复位；动画未结束时忽略右键。
- 持有姿态按参考视频帧校准（见第 4 节）。模型 JSON 的 `firstperson_*` display 已改为单位变换，姿态完全由代码决定。

### 观战
- 淘汰玩家手持平板右键 → 随机选一名**同区域、在线、存活、仍在区域内**的目标。
- A / D 按名单顺序循环；当前目标死亡 / 下线 / 离开区域 → 自动切到名单中的下一位；无可观战目标 → 自动退出并提示。
- 不能观战其他区域、死亡或离线的玩家（服务端权威校验，客户端只发 -1 / 0 / +1 方向）。
- **远距离观战重做**（第 4 节）。
- 退出：恢复本人视角、位置、游戏模式，隐藏 HUD，清理两端状态。

### HUD
- 右上角：当前观战区域全部参战者的皮肤头像 + 绿 / 红圆点，不显示名字；头像失败回退默认皮肤；全员死亡后随回合结束消失。
- 顶部居中：`正在观战（玩家 ID）`，由服务端在每次切换目标时重发，立即更新。
- HUD 只取 `spectateRegion` 对应的回合，不混入其他区域。

### 网络与资源
- 协议版本号 2 → 3（新旧版本在握手阶段就会被拒绝，而不是游戏里解码出错）。
- 包校验：名单条目上限 256（编码截断 / 解码拒绝）、方向规整为 -1/0/1、平板动作白名单 + 冷却、选点范围 + 世界边界、切换 / 切目标冷却。
- 中英文语言文件各 29 键，键集合一致、占位符个数一致。

---

## 2. 已修复 Bug 清单

### 你列出的 14 项

| # | 问题 | 处理 |
|---|---|---|
| 1 | `SpectateService` 远距离目标跟踪限制 | 不再用“是否已被客户端跟踪”当资格；改为锚定观战者 + StartTracking 握手 + 周期重发（第 4 节） |
| 2 | `onDeath()` 依赖死亡位置 | 以已有名单为准；仅当玩家从未被登记且死在区域内才按位置补登记 |
| 3 | `onLogout()` 删除名单 | 不再删除；只做观战善后（先恢复位置 / 模式再保存玩家数据） |
| 4 | 复活后保持淘汰 | 复活不改状态；`Round.revive` 已删除 |
| 5 | 资格检查空对象风险 | `toggle()` / `targets()` / `validate()` 对 server、round、participant、region 全部判空 |
| 6 | `TRACKED_PLAYERS` 清理 | 仅用于“何时下发镜头包”；登出、服务器停止时清理；不再决定资格 |
| 7 | 目标死亡 / 离线自动切换 | 死亡立即切换；离线 / 离开区域最多 5 tick 内切换；顺序取名单中的下一位 |
| 8 | HUD 区域隔离 | `S2CSpectateModePacket` 携带 `regionId`，HUD 只画该区域 |
| 9 | 客户端 / 服务端状态不一致 | 登录重置；每次切换重发；断线清空；回合结束 / 区域删除 / 维度被外部切换都会结束并通知客户端 |
| 10 | 边框只在手持木棍时显示 | 保留并改为服务端确认预览；维度切换清理 |
| 11 | 平板动画未实现 | `TabletAnimator` + `TabletHandRenderer` |
| 12 | 区域 NBT 加载异常 | `Region.fromTag` 返回 null 而非抛异常；`RegionStore` 逐条 try/catch、去重、记录日志；`RoundStore` 同理 |
| 13 | 包大小与参数校验 | 见第 1 节“网络与资源” |
| 14 | 区域删除后的回合 / HUD 清理 | `onRegionDeleted` → 结束回合、停止观战者、给相关玩家发空名单 |

### 额外发现并修复的问题
- 观战中右键无法退出（所有交互被取消）。
- 重新连接后客户端不知道自己已被淘汰 → 无法长按 F 取平板。
- `/ts wand` 命令缺失。
- 中文区域名无法输入（Brigadier `word()` 只允许 ASCII）。
- 普通玩家无法创建区域（原要求权限 1）→ 与“普通玩家管理自己的区域”不符，已放开创建（见第 3 节 3）。
- `mods.toml` 没有声明 TaCZ 依赖。
- 其他模组取消了死亡事件（如图腾）时仍被记为淘汰 → 处理器改为 LOWEST 优先级且不接收已取消事件。
- 手持平板右键方块会打开箱子 / 门，导致没法进入观战。
- 使用原版旁观模式后，数字键 / 滚轮 / 中键会弹出“传送到玩家”菜单，可绕过区域隔离 → 客户端吞掉这些输入，服务端 5 tick 内会把本体拉回目标身边。
- 别的模组取消游戏模式切换时，会出现“普通模式的本体跟着目标走” → 检测到切换失败整体回滚。

---

## 3. 需要你确认的设计决策

1. **观战 = “本体锚定”。** 观战期间观战者被切到旁观模式，并被带到当前目标身边（跨维度也可以）；退出 / 断线 / 回合结束 / 服务器关闭时回到观战前的位置、维度、游戏模式。原点同时写进玩家持久数据，崩溃后下次登录自动恢复。
   这与原“本体留在大厅，只切镜头”的设计不同，原因见第 4 节。**如果你的 NPC 警告模组 / 其他模组会对“旁观模式玩家出现在战场”做出反应，请先在测试服验证。**
2. **平板动画完全自研，不依赖 TaCZ 的任何 API，也不需要 Player Animator。** 我没有 TaCZ 的 jar，没法检查它是否提供“播放普通物品动画”的接口，所以没有假设它存在。代价：枪的“退出视野”动画由 TaCZ 自己处理，我只能用固定的等待时间（`DRAW_DELAY_TICKS = 6`）避免重叠，需要你在游戏里按枪的收枪时长调。Player Animator 只在需要**第三人称**持握姿势时才有必要，本版没做第三人称。
3. **普通玩家可以创建区域**（原来要求权限 1）。公开服务器如果不想放开，把 `TsCommand` 里 `/ts region create` 加回 `.requires(s -> s.hasPermission(1))` 即可。
4. **TaCZ 依赖声明为 `modId="tacz"`, `versionRange="[1.1.8,)"`。** 没有 TaCZ 的 jar，modId 与版本号是按记忆写的，请对照实际 jar 的 `mods.toml` 核对。模组代码里没有任何编译期 TaCZ 引用。
5. **新增了 `/ts wand`、`/ts round reset`**（你的需求列表里有 wand，没有 reset；reset 是因为回合只在“无人存活”时结束，需要给管理员一个出口）。

---

## 4. 两个核心设计的说明

### 远距离观战
`ClientboundSetCameraPacket` 只有在**客户端已经有该实体、并且加载了周围区块**时才生效。旧实现因此把“目标已被跟踪”当成资格，远处目标永远选不上。

新流程（`SpectateService`）：
1. 资格只由服务端回合 / 区域状态决定（同回合、在线、存活、仍在区域内）。
2. 选中目标 → `follow()`：必要时 `teleportTo` 把观战者带到目标身边（旁观模式，不可被攻击 / 不拾取 / 不触发机关），再 `setCamera(target)`，客户端因此自然收到目标实体与周围区块。
3. `StartTracking` 事件触发时再下发镜头包（排在实体添加包之后）；已被跟踪则立即下发。
4. 观战期间每 20 tick 重发一次镜头包（未确认时每 5 tick），自愈“画面停留在旧目标”；本体离目标超过 24 格或维度不同会被拉回。
5. 刻意**不**因为“长时间没收到跟踪事件”而放弃 / 换目标（事件记录可能漂移，那样会把正常工作的镜头误判为失败；已有回归测试 T14）。

### 平板姿态校准
用视频 `Screenrecorder-2026-11-22-00-08-13-77.mp4` 的持有帧反推：平板正面朝向镜头、上边缘向远处倾斜 35°、横向居中、下半部分落在屏幕下沿之外。
`HOLD_Y=-0.308, HOLD_Z=-0.715, HOLD_PITCH=-35°, SCALE=0.85`，用模型实际几何做了离线投影，叠加到视频帧上轮廓基本重合（`verification/tools/sim_hold.png`）。掏出动画：先隐藏等待，再从左下方（`START_DX=-0.30, START_DY=-0.50`，略带侧倾）缓动抬起。
> 你提示词里写的参考视频是 `1000607500.mp4`，实际上传的是 `Screenrecorder-…-77.mp4`（一段对 B 站视频的录屏），我按这个做的。这只是**离线投影**校准，真实游戏里的视野、FOV、光影、TaCZ 手部渲染仍需你实机微调。

---

## 5. 尚未解决 / 未验证的问题

1. **没有真实编译 / 没有 JAR / 没有游戏内测试**（第 0 节）。
2. TaCZ 枪退出动画与平板抬起的衔接只能靠固定延迟，需要实机调 `DRAW_DELAY_TICKS`。TaCZ 在“主手变成非枪物品”时到底怎么画（是否还会残留枪模型）我没验证。
3. 第一人称只画平板，**没有画手臂**（视频里平板是被手托着的）。
4. **没有第三人称持握姿势**（别人看你拿着平板是普通物品姿势）。
5. 回合没有显式的“开始 / 结束”指令，只靠“踏入区域加入、无人存活结束”；离线的存活者会让回合一直开着（用 `/ts round reset` 处理）。
6. `/ts region resize` 不会重新评估已在名单里的玩家。
7. 在高延迟 / 丢包网络下镜头同步的表现未测；周期重发只是兜底。
8. 与光影 / 其他渲染模组、NPC 警告模组的兼容性未测。
9. 木棍选区（服务端 `WandSelections`）仍是内存数据，不随存档保存（符合“预览”性质，登录时清空）。
10. 没有做 Gradle wrapper（沙箱里生成不了 `gradle-wrapper.jar`）。

---

## 6. 首次编译 / 进游戏优先核对

### 编译期最可能需要微调的 API 点（我按 1.20.1 / Forge 47.2.8 记忆写的）
- `ServerPlayer.teleportTo(ServerLevel, double, double, double, float, float)`、`setCamera(Entity)`、`setGameMode(GameType)`（返回 boolean）、`gameMode.getGameModeForPlayer()`、`GameType.byId/getId`
- `MinecraftServer.getTickCount()`、`Entity.getPersistentData()`、`PlayerEvent.StartTracking#getTarget()`
- `RenderHandEvent` 的 `getHand / getItemStack / getPoseStack / getMultiBufferSource / getPackedLight / getPartialTick`
- `ItemRenderer.renderStatic(LivingEntity, ItemStack, ItemDisplayContext, boolean, PoseStack, MultiBufferSource, Level, int, int, int)`
- `InputEvent.MouseScrollingEvent`、`InteractionKeyMappingTriggered#isUseItem/setSwingHand`、`Options.keyHotbarSlots`
- `PlayerInteractEvent.RightClickBlock#setUseBlock(Event.Result)`
- `ClientPacketListener.getPlayerInfo(UUID)`、`PlayerInfo.getProfile()`、`CommandSourceStack.sendSuccess(Supplier<Component>, boolean)`

### 进游戏冒烟清单
1. 专用服务器与客户端都能启动加载（无 ClassNotFound / 客户端类泄漏到服务端）。
2. 木棍选两点 → 边框显示；副手持棍也显示；收起消失；再拿起恢复；换维度后消失。
3. 创建两个区域（一个嵌套在另一个里）→ 站位判定取体积最小者。
4. 区域内死亡（被击退出边界再死）→ 仍是淘汰；复活后不能当存活者。
5. 长按 F 取出平板 → 动画；此时**不会**进入观战；右键才进入；再右键退出。
6. 远处目标：大厅离战场 > 视距时能否正常看到目标、A/D 切换、目标死亡自动切换。
7. 观战中按数字键 / 滚轮不弹出原版旁观菜单；退出后回到观战前位置与游戏模式。
8. 两个区域同时开局，互相看不到对方的玩家 / HUD。
9. 观战者下线再上线、目标下线、区域被删除、服务器重启（回合持久化）。
10. 与 NPC 警告模组同时运行：死亡传送回大厅 + 观战锚定是否冲突。

---

## 7. 调参入口

| 想改什么 | 在哪 |
|---|---|
| 等枪退出视野的时间 / 抬起时间 / 收回时间 | `client/TabletAnimator.java`：`DRAW_DELAY_TICKS / DRAW_TICKS / STOW_TICKS` |
| 平板持有位置、倾角、大小、起始偏移 | `client/TabletHandRenderer.java` 顶部常量 |
| 长按 F 的判定时长 | `client/ClientEvents.java`：`TABLET_HOLD_TICKS`（10 tick = 0.5 s） |
| 观战本体被拉回的距离、镜头重发间隔 | `spectate/SpectateService.java` 顶部常量 |
| 木棍选点最大距离 | `event/WandEvents.java`：`MAX_RANGE` |

---

## 8. 变更文件（相对 `tactical_spectator_source_repair_01.zip`）

**新增**：`round/RoundStore.java`、`net/packet/S2CWandSelectionPacket.java`、`client/TabletAnimator.java`、`client/TabletHandRenderer.java`

**重写 / 大改**：`round/RoundService.java`、`round/Round.java`、`round/Participant.java`、`spectate/SpectateService.java`、`command/TsCommand.java`、`event/GameEvents.java`、`client/ClientEvents.java`、`client/ClientState.java`、`client/ClientRx.java`、`client/HudRenderer.java`、`client/ClientWandEvents.java`、`net/ModNetwork.java`、`net/packet/{S2CRoundUpdate,S2CSpectateMode,C2STabletAction,C2SCycleTarget,C2SWandPoint}Packet.java`

**小改**：`region/Region.java`、`region/RegionStore.java`、`event/WandEvents.java`、`item/TacticalTabletItem.java`（注释）

**资源 / 配置**：`META-INF/mods.toml`（TaCZ 依赖）、`pack.mcmeta`（描述文字）、`lang/en_us.json`、`lang/zh_cn.json`、`models/item/tactical_tablet.json`（第一人称 display 改为单位变换）、`build.gradle`（版本 1.0.0-r5）

**未改**：`TacticalSpectator.java`、`ModItems.java`、`ModCreativeTabs.java`、`region/WandSelections.java`、`client/SelectionBoxRenderer.java`、贴图、`settings.gradle`、`gradle.properties`
