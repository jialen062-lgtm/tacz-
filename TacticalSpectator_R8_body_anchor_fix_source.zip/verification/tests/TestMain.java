package cn.blockforge.generated.tacticalspectator.test;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.client.ClientState;
import cn.blockforge.generated.tacticalspectator.client.TabletAnimator;
import cn.blockforge.generated.tacticalspectator.event.WandEvents;
import cn.blockforge.generated.tacticalspectator.net.packet.*;
import cn.blockforge.generated.tacticalspectator.region.*;
import cn.blockforge.generated.tacticalspectator.round.*;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundSetCameraPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.storage.DimensionDataStorage;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.*;

public class TestMain {
    static int passed = 0, failed = 0;
    static final ResourceLocation OW = new ResourceLocation("minecraft:overworld");

    static void check(boolean ok, String what) {
        if (ok) { passed++; } else { failed++; System.out.println("  FAIL: " + what); }
    }

    // ---- world helpers ----
    static Map<String, CompoundTag> disk = new HashMap<>();
    static MinecraftServer newServer() {
        MinecraftServer s = new MinecraftServer();
        s.levels.put("minecraft:overworld", new ServerLevel("minecraft:overworld", new DimensionDataStorage(disk)));
        s.levels.put("minecraft:the_nether", new ServerLevel("minecraft:the_nether", new DimensionDataStorage(new HashMap<>())));
        return s;
    }
    static MinecraftServer fresh() {
        disk = new HashMap<>();
        RoundService.unbind(); SpectateService.clear(); SimpleChannel.SENT.clear();
        MinecraftServer s = newServer();
        RoundService.bind(s);
        return s;
    }
    static ServerPlayer player(MinecraftServer s, String name, double x, double y, double z) {
        ServerPlayer p = new ServerPlayer(s, name, s.overworld(), x, y, z);
        s.players.add(p);
        return p;
    }
    static Region region(MinecraftServer s, String name, int x0, int y0, int z0, int x1, int y1, int z1) {
        return RegionStore.get(s).create(name, UUID.randomUUID(), "owner", OW, new BlockPos(x0, y0, z0), new BlockPos(x1, y1, z1));
    }
    static void tick(MinecraftServer s, int n) { for (int i = 0; i < n; i++) { s.ticks++; RoundService.onServerTick(s); } }
    static void giveTablet(ServerPlayer p) { p.inv.setItem(0, new ItemStack(ModItems.TACTICAL_TABLET.get())); p.inv.selected = 0; }
    static void die(ServerPlayer p) { RoundService.onDeath(p); p.alive = false; }
    static void respawnAt(ServerPlayer p, double x, double y, double z) { p.alive = true; p.x = x; p.y = y; p.z = z; RoundService.onRespawn(p); }
    static boolean aliveInRound(UUID id) { Round r = RoundService.firstRoundOf(id); return r != null && r.get(id).alive; }
    static List<Object> sentTo(ServerPlayer p, Class<?> type) {
        List<Object> out = new ArrayList<>();
        for (Object[] e : SimpleChannel.SENT) if (e[0] == p && type.isInstance(e[1])) out.add(e[1]);
        return out;
    }
    static S2CSpectateModePacket lastMode(ServerPlayer p) {
        List<Object> l = sentTo(p, S2CSpectateModePacket.class);
        return l.isEmpty() ? null : (S2CSpectateModePacket) l.get(l.size() - 1);
    }

    public static void main(String[] args) {
        t1_joinDeathRespawn();
        t2_multiRegionAndOverlap();
        t3_spectateFlow();
        t4_regionDeletedWhileSpectating();
        t5_persistence();
        t6_crashRecovery();
        t7_nbtRobustness();
        t8_packets();
        t9_wand();
        t10_tabletSwap();
        t11_animator();
        t12_targetLeavesRegion();
        t13_gameModeRefused();
        t14_longSpectateWithoutTrackingEvents();
        System.out.println("\nRESULT: " + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    // ================= tests =================

    static void t1_joinDeathRespawn() {
        System.out.println("[T1] join / death outside region / respawn keeps eliminated");
        MinecraftServer s = fresh();
        Region r1 = region(s, "arena", 0, 0, 0, 99, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10), c = player(s, "C", 30, 10, 10), d = player(s, "D", 500, 64, 500);
        tick(s, 10);
        Round r = RoundService.byRegion(r1.id);
        check(r != null && r.participants.size() == 3, "A,B,C joined the round, D (lobby) did not");
        check(RoundService.firstRoundOf(d.uuid) == null, "D not in any round");
        // knocked out of the region before the death event is processed
        a.x = 150;
        die(a);
        check(RoundService.firstRoundOf(a.uuid) == r, "A keeps original round although death position is outside the region");
        check(RoundService.isEliminated(a.uuid), "A is marked eliminated");
        check(aliveInRound(b.uuid) && aliveInRound(c.uuid), "B, C unaffected");
        // respawn in lobby, then even back inside the region
        respawnAt(a, 500, 64, 500);
        tick(s, 20);
        check(RoundService.isEliminated(a.uuid), "A still eliminated after respawn");
        a.x = 10; a.y = 10; a.z = 10;
        tick(s, 20);
        check(RoundService.isEliminated(a.uuid) && !aliveInRound(a.uuid), "A re-entering the region does not revive A");
        // totem-like: death in lobby with no round and no region -> ignored
        RoundService.onDeath(d);
        check(RoundService.firstRoundOf(d.uuid) == null, "death outside any region/round is ignored");
        // death inside a region before the 10-tick join -> registered then eliminated
        ServerPlayer e = player(s, "E", 40, 10, 10);
        RoundService.onDeath(e);
        check(RoundService.isEliminated(e.uuid), "death inside region with no prior roster entry is registered as eliminated");
    }

    static void t2_multiRegionAndOverlap() {
        System.out.println("[T2] multi-region isolation, overlap, tie-break, per-region round end");
        MinecraftServer s = fresh();
        Region r1 = region(s, "one", 0, 0, 0, 99, 99, 99);
        Region r3 = region(s, "three", 200, 0, 0, 299, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10);
        ServerPlayer e = player(s, "E", 210, 10, 10), f = player(s, "F", 220, 10, 10);
        tick(s, 10);
        check(RoundService.firstRoundOf(a.uuid).regionId == r1.id && RoundService.firstRoundOf(e.uuid).regionId == r3.id, "rounds are per region");
        check(RoundService.byRegion(r1.id).participants.size() == 2 && RoundService.byRegion(r3.id).participants.size() == 2, "rosters not mixed");
        die(e); die(f);
        check(RoundService.byRegion(r3.id) == null, "region 3 round ended after everyone died");
        check(RoundService.byRegion(r1.id) != null && aliveInRound(a.uuid), "region 1 round unaffected");
        // overlap + tie-break
        Region small = region(s, "small", 10, 0, 0, 19, 99, 99);
        Region twin = region(s, "twin", 10, 0, 0, 19, 99, 99);
        RegionStore store = RegionStore.get(s);
        check(store.smallestAt(OW, new BlockPos(15, 10, 10)).id == small.id, "smallest volume wins, equal volume -> lower stable id");
        check(store.smallestAt(OW, new BlockPos(50, 10, 10)).id == r1.id, "falls back to the larger region outside the small one");
        check(store.smallestAt(OW, new BlockPos(500, 10, 10)) == null, "no region outside");
        // alive player walking into a nested smaller region leaves the old roster (never in two rosters)
        a.x = 15;
        tick(s, 10);
        int count = 0;
        for (Region reg : store.all()) { Round rr = RoundService.byRegion(reg.id); if (rr != null && rr.contains(a.uuid)) count++; }
        check(count == 1, "player is in exactly one roster");
    }

    static void t3_spectateFlow() {
        System.out.println("[T3] spectate: eligibility, far targets, cycle, auto-switch, logout/login, round end");
        MinecraftServer s = fresh();
        Region r1 = region(s, "arena", 0, 0, 0, 299, 99, 299);
        Region r3 = region(s, "other", 1000, 0, 0, 1099, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10), c = player(s, "C", 290, 10, 290), d = player(s, "D", 150, 10, 150);
        ServerPlayer x = player(s, "X", 1010, 10, 10);   // other region
        tick(s, 10);
        die(a);
        respawnAt(a, 500, 64, 500);   // lobby, far (>200 blocks) from every target
        a.inv.setItem(0, new ItemStack(Items.SWORD)); a.inv.selected = 0;
        s.ticks += 20;
        check(!SpectateService.toggle(a), "toggle without tablet in hand is refused");
        check(a.messages.contains("ts.spectate.notholding"), "notholding message");
        check(!SpectateService.isActive(a), "no session");
        giveTablet(a);
        s.ticks += 20;
        check(!SpectateService.toggle(b), "alive player cannot spectate");
        b.inv.setItem(0, new ItemStack(ModItems.TACTICAL_TABLET.get())); b.inv.selected = 0;
        s.ticks += 20;
        check(!SpectateService.toggle(b), "alive player holding tablet cannot spectate");
        check(SpectateService.toggle(a), "eliminated player holding tablet starts spectating");
        check(SpectateService.isActive(a), "session active");
        check(a.gameMode.mode == GameType.SPECTATOR, "viewer switched to spectator mode");
        check(a.persistent.contains(SpectateService.ORIGIN_KEY, 10), "origin persisted in player data");
        ServerPlayer t0 = (ServerPlayer) a.camera;
        check(t0 != a && (t0 == b || t0 == c || t0 == d), "camera on an alive player of the same region (never X from another region)");
        check(a.x == t0.x && a.z == t0.z, "far target: viewer body anchored next to the target so the client receives it");
        S2CSpectateModePacket m = lastMode(a);
        check(m != null && m.on && m.target.equals(t0.uuid) && m.regionId == r1.id, "HUD packet carries region + current target");
        // cycle visits all three alive targets, in roster order, wrapping
        Set<UUID> seen = new HashSet<>(); seen.add(t0.uuid);
        ServerPlayer prev = t0;
        for (int i = 0; i < 3; i++) {
            s.ticks += 5;
            SpectateService.cycle(a, 1);
            ServerPlayer cur = (ServerPlayer) a.camera;
            seen.add(cur.uuid);
            check(cur != a, "cycle keeps a target");
            prev = cur;
        }
        check(seen.size() == 3 && !seen.contains(x.uuid) && !seen.contains(a.uuid), "D cycles through exactly B, C, D");
        // cooldown: immediate second cycle ignored
        ServerPlayer before = (ServerPlayer) a.camera;
        SpectateService.cycle(a, 1);
        check(a.camera == before, "cycle spam within cooldown is ignored");
        // invalid direction
        s.ticks += 5; SpectateService.cycle(a, 0);
        check(a.camera == before, "direction 0 ignored");
        // target dies -> auto-switch immediately
        ServerPlayer cur = (ServerPlayer) a.camera;
        die(cur);
        check(a.camera != cur && a.camera != a && aliveInRound(((ServerPlayer) a.camera).uuid), "dead target replaced by another alive target");
        Object lastPacket = null;
        for (Object o : a.connection.sent) if (o instanceof ClientboundSetCameraPacket) lastPacket = o;
        check(lastPacket != null && ((ClientboundSetCameraPacket) lastPacket).entity == a.camera, "the last camera packet points at the current target");
        // target logs out -> switch within 5 ticks, roster identity kept
        ServerPlayer cur2 = (ServerPlayer) a.camera;
        RoundService.onLogout(cur2);
        s.players.remove(cur2);
        tick(s, 5);
        check(a.camera != cur2 && a.camera != a && SpectateService.isActive(a), "logged-out target replaced");
        check(RoundService.firstRoundOf(cur2.uuid) != null && aliveInRound(cur2.uuid), "logged-out alive player keeps roster membership");
        // relog restores state and re-sends the roster
        s.players.add(cur2);
        SimpleChannel.SENT.clear();
        RoundService.onLogin(cur2);
        List<Object> upd = sentTo(cur2, S2CRoundUpdatePacket.class);
        check(!upd.isEmpty() && ((S2CRoundUpdatePacket) upd.get(0)).regionId == r1.id, "login re-sends the round roster to the player");
        // wipe out everybody else -> round ends, viewer restored to lobby + original mode
        for (ServerPlayer p : new ArrayList<>(List.of(b, c, d, cur2))) if (aliveInRound(p.uuid)) die(p);
        check(RoundService.byRegion(r1.id) == null, "round ended when no one is alive");
        check(!SpectateService.isActive(a), "spectating stopped at round end");
        check(a.gameMode.mode == GameType.SURVIVAL && !a.spectator, "original game mode restored");
        check(a.x == 500 && a.y == 64 && a.z == 500, "viewer returned to the exact lobby position");
        check(a.camera == a, "camera back on the viewer");
        check(!a.persistent.contains(SpectateService.ORIGIN_KEY, 10), "persisted origin cleared");
        S2CSpectateModePacket off = lastMode(a);
        check(off != null && !off.on, "client told spectating is off");
        check(RoundService.byRegion(r3.id) != null && aliveInRound(x.uuid), "other region's round untouched by the end of region 1's round");
        // an eliminated player's own death while spectating (e.g. /kill)
        MinecraftServer s2 = fresh();
        region(s2, "arena", 0, 0, 0, 299, 99, 299);
        ServerPlayer a2 = player(s2, "A", 10, 10, 10), b2 = player(s2, "B", 100, 10, 100);
        tick(s2, 10); die(a2); respawnAt(a2, 500, 64, 500); giveTablet(a2); s2.ticks += 20;
        check(SpectateService.toggle(a2), "second world: spectating starts");
        RoundService.onDeath(a2);
        check(!SpectateService.isActive(a2) && a2.gameMode.mode == GameType.SURVIVAL, "viewer death ends the session and restores the game mode");
    }

    static void t4_regionDeletedWhileSpectating() {
        System.out.println("[T4] region deleted while spectating");
        MinecraftServer s = fresh();
        Region r1 = region(s, "arena", 0, 0, 0, 299, 99, 299);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 100, 10, 100);
        tick(s, 10); die(a); respawnAt(a, 500, 64, 500); giveTablet(a); s.ticks += 20;
        SpectateService.toggle(a);
        check(SpectateService.isActive(a), "spectating");
        SimpleChannel.SENT.clear();
        RegionStore.get(s).remove(r1.id);
        RoundService.onRegionDeleted(s, r1.id);
        check(RoundService.byRegion(r1.id) == null && !SpectateService.isActive(a), "round and spectate state cleaned");
        check(a.x == 500 && a.gameMode.mode == GameType.SURVIVAL, "viewer restored");
        boolean cleared = false;
        for (Object o : sentTo(b, S2CRoundUpdatePacket.class)) if (((S2CRoundUpdatePacket) o).entries.isEmpty()) cleared = true;
        check(cleared, "participants got an empty roster (HUD cleared)");
    }

    static void t5_persistence() {
        System.out.println("[T5] round persistence across restart");
        MinecraftServer s = fresh();
        Region r1 = region(s, "arena", 0, 0, 0, 99, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10), c = player(s, "C", 30, 10, 10);
        tick(s, 10); die(a);
        UUID ida = a.uuid, idb = b.uuid, idc = c.uuid;
        // a round for a region that no longer exists must be pruned on bind
        RoundStore rs = RoundStore.get(s);
        Round ghost = new Round(999L); ghost.add(UUID.randomUUID(), "ghost"); rs.rounds.put(999L, ghost); rs.setDirty();
        s.overworld().storage.saveAll();
        // "restart"
        RoundService.unbind(); SpectateService.clear();
        MinecraftServer s2 = newServer();
        RoundService.bind(s2);
        Round r = RoundService.byRegion(r1.id);
        check(r != null && r.participants.size() == 3, "roster restored after restart");
        check(RoundService.isEliminated(ida) && aliveInRound(idb) && aliveInRound(idc), "dead/alive identities restored");
        check(RoundService.byRegion(999L) == null, "round of a deleted region is pruned");
        List<UUID> order = new ArrayList<>(r.participants.keySet());
        check(order.equals(List.of(ida, idb, idc)), "join order preserved");
        // a bind with everyone dead drops the round
        die(b2(s2, idb)); 
    }
    static ServerPlayer b2(MinecraftServer s, UUID id) {
        ServerPlayer p = new ServerPlayer(s, "B", s.overworld(), 20, 10, 10); p.uuid = id; s.players.add(p); return p;
    }

    static void t6_crashRecovery() {
        System.out.println("[T6] crash recovery: anchored viewer restored on next login");
        MinecraftServer s = fresh();
        region(s, "arena", 0, 0, 0, 299, 99, 299);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 200, 10, 200);
        tick(s, 10); die(a); respawnAt(a, 500, 64, 500); giveTablet(a); s.ticks += 20;
        SpectateService.toggle(a);
        check(a.x == 200 && a.gameMode.mode == GameType.SPECTATOR, "viewer anchored at the target (precondition)");
        SpectateService.clear();    // simulates losing in-memory state (crash)
        RoundService.onLogin(a);
        check(a.x == 500 && a.y == 64 && a.z == 500, "position restored from persisted origin");
        check(a.gameMode.mode == GameType.SURVIVAL, "game mode restored from persisted origin");
        check(!a.persistent.contains(SpectateService.ORIGIN_KEY, 10), "origin tag removed after restore");
        // graceful shutdown path
        s.ticks += 20;
        SpectateService.toggle(a);
        SpectateService.stopAll(s);
        check(a.x == 500 && a.gameMode.mode == GameType.SURVIVAL && !SpectateService.isActive(a), "stopAll restores everyone before world save");
        // logout while spectating restores before the data would be saved
        s.ticks += 20;
        SpectateService.toggle(a);
        RoundService.onLogout(a);
        check(a.x == 500 && a.gameMode.mode == GameType.SURVIVAL, "logout while spectating restores position and mode first");
        check(RoundService.isEliminated(a.uuid), "eliminated identity survives logout");
    }

    static void t7_nbtRobustness() {
        System.out.println("[T7] NBT load protection");
        CompoundTag root = new CompoundTag();
        ListTag list = new ListTag();
        CompoundTag good = new Region(5, "good", UUID.randomUUID(), "o", OW, new BlockPos(0, 0, 0), new BlockPos(5, 5, 5)).toTag();
        CompoundTag noName = new CompoundTag(); noName.putLong("id", 6); noName.putString("dim", "minecraft:overworld");
        CompoundTag badDim = new Region(7, "baddim", null, "", OW, new BlockPos(0, 0, 0), new BlockPos(1, 1, 1)).toTag(); badDim.putString("dim", "!!bad dim!!");
        CompoundTag dupId = new Region(5, "dup", null, "", OW, new BlockPos(0, 0, 0), new BlockPos(1, 1, 1)).toTag();
        CompoundTag dupName = new Region(9, "GOOD", null, "", OW, new BlockPos(0, 0, 0), new BlockPos(1, 1, 1)).toTag();
        CompoundTag badOwner = new Region(10, "owner", null, "", OW, new BlockPos(0, 0, 0), new BlockPos(1, 1, 1)).toTag(); badOwner.putString("owner", "not-a-uuid");
        for (CompoundTag t : List.of(good, noName, badDim, dupId, dupName, badOwner)) list.add(t);
        root.put("regions", list);
        root.putLong("nextId", 0);
        RegionStore store = null;
        try { store = RegionStore.load(root); } catch (Throwable t) { check(false, "load threw " + t); return; }
        check(store.all().size() == 2, "only valid, unique regions loaded (got " + store.all().size() + ")");
        check(store.byId(5) != null && store.byId(10) != null && store.byId(10).owner == null, "bad owner uuid tolerated");
        Region created = store.create("fresh", null, "", OW, new BlockPos(0, 0, 0), new BlockPos(1, 1, 1));
        check(created.id > 10, "nextId advances past loaded ids (" + created.id + ")");
        // rounds: a player in two rounds is de-duplicated
        CompoundTag rr = new CompoundTag(); ListTag rl = new ListTag();
        UUID u = UUID.randomUUID();
        Round r1 = new Round(1); r1.add(u, "p"); Round r2 = new Round(2); r2.add(u, "p"); r2.add(UUID.randomUUID(), "q");
        rl.add(r1.toTag()); rl.add(r2.toTag()); rr.put("rounds", rl);
        RoundStore loaded = RoundStore.load(rr);
        int occurrences = 0; for (Round r : loaded.rounds.values()) if (r.contains(u)) occurrences++;
        check(occurrences == 1, "duplicate roster membership removed on load");
    }

    static void t8_packets() {
        System.out.println("[T8] packet codecs / validation");
        FriendlyByteBuf b = new FriendlyByteBuf();
        List<S2CRoundUpdatePacket.Entry> es = new ArrayList<>();
        for (int i = 0; i < 300; i++) es.add(new S2CRoundUpdatePacket.Entry(UUID.randomUUID(), "n" + i, i % 2 == 0));
        S2CRoundUpdatePacket.encode(new S2CRoundUpdatePacket(7, es), b);
        S2CRoundUpdatePacket d = S2CRoundUpdatePacket.decode(b);
        check(d.regionId == 7 && d.entries.size() == S2CRoundUpdatePacket.MAX_ENTRIES, "encode caps entries at MAX_ENTRIES");
        FriendlyByteBuf evil = new FriendlyByteBuf(); evil.writeLong(1); evil.writeVarInt(1_000_000);
        boolean threw = false; try { S2CRoundUpdatePacket.decode(evil); } catch (RuntimeException e) { threw = true; }
        check(threw, "oversized entry count rejected on decode");
        FriendlyByteBuf neg = new FriendlyByteBuf(); neg.writeLong(1); neg.writeVarInt(-5);
        threw = false; try { S2CRoundUpdatePacket.decode(neg); } catch (RuntimeException e) { threw = true; }
        check(threw, "negative entry count rejected");
        // spectate mode
        UUID t = UUID.randomUUID();
        FriendlyByteBuf m1 = new FriendlyByteBuf(); S2CSpectateModePacket.encode(new S2CSpectateModePacket(true, 42, t, "Steve"), m1);
        S2CSpectateModePacket p1 = S2CSpectateModePacket.decode(m1);
        check(p1.on && p1.regionId == 42 && t.equals(p1.target) && p1.targetName.equals("Steve"), "mode packet roundtrip (with target)");
        FriendlyByteBuf m2 = new FriendlyByteBuf(); S2CSpectateModePacket.encode(new S2CSpectateModePacket(false, 0, null, null), m2);
        S2CSpectateModePacket p2 = S2CSpectateModePacket.decode(m2);
        check(!p2.on && p2.target == null && p2.targetName.isEmpty(), "mode packet roundtrip (no target)");
        // cycle clamp
        for (int[] c : new int[][]{{5, 1}, {-3, -1}, {0, 0}, {127, 1}, {-128, -1}}) {
            FriendlyByteBuf cb = new FriendlyByteBuf(); cb.writeByte(c[0]);
            check(C2SCycleTargetPacket.decode(cb).dir == c[1], "cycle dir " + c[0] + " -> " + c[1]);
        }
        // wand selection packet
        FriendlyByteBuf w1 = new FriendlyByteBuf(); S2CWandSelectionPacket.encode(new S2CWandSelectionPacket(OW, new BlockPos(1, 2, 3), null), w1);
        S2CWandSelectionPacket ws = S2CWandSelectionPacket.decode(w1);
        check(OW.equals(ws.dimension) && new BlockPos(1, 2, 3).equals(ws.a) && ws.b == null, "wand selection roundtrip (only point 1)");
        FriendlyByteBuf w2 = new FriendlyByteBuf(); S2CWandSelectionPacket.encode(S2CWandSelectionPacket.empty(), w2);
        check(S2CWandSelectionPacket.decode(w2).dimension == null, "wand selection empty roundtrip");
        FriendlyByteBuf w3 = new FriendlyByteBuf(); C2SWandPointPacket.encode(new C2SWandPointPacket(2, new BlockPos(-5, 70, 9)), w3);
        C2SWandPointPacket wp = C2SWandPointPacket.decode(w3);
        check(wp.point == 2 && wp.pos.equals(new BlockPos(-5, 70, 9)), "wand point roundtrip");
        // tablet action
        FriendlyByteBuf tb = new FriendlyByteBuf(); C2STabletActionPacket.encode(new C2STabletActionPacket(C2STabletActionPacket.STOW), tb);
        check(C2STabletActionPacket.decode(tb).action() == C2STabletActionPacket.STOW, "tablet action roundtrip");
    }

    static void t9_wand() {
        System.out.println("[T9] wand selection (server side)");
        MinecraftServer s = fresh();
        ServerPlayer p = player(s, "W", 0, 64, 0);
        p.inv.setItem(0, new ItemStack(Items.SWORD)); p.inv.selected = 0;
        WandEvents.applyPoint(p, 1, new BlockPos(1, 64, 1));
        check(WandSelections.get(p.uuid) == null, "no wand in hand -> ignored");
        p.inv.setItem(0, new ItemStack(Items.STICK));
        WandEvents.applyPoint(p, 3, new BlockPos(1, 64, 1));
        check(WandSelections.get(p.uuid) == null, "invalid point index ignored");
        WandEvents.applyPoint(p, 1, new BlockPos(500, 64, 500));
        check(WandSelections.get(p.uuid) == null && p.messages.contains("ts.wand.far"), "too-far point rejected with message");
        WandEvents.applyPoint(p, 1, new BlockPos(0, 10000, 0));
        check(WandSelections.get(p.uuid) == null, "out-of-world point rejected");
        SimpleChannel.SENT.clear();
        WandEvents.applyPoint(p, 1, new BlockPos(5, 64, 5));
        WandEvents.applyPoint(p, 2, new BlockPos(9, 70, 9));
        WandSelections.Sel sel = WandSelections.get(p.uuid);
        check(sel != null && sel.a != null && sel.b != null, "both points stored");
        check(p.messages.contains("ts.wand.pos1") && p.messages.contains("ts.wand.pos2") && p.messages.contains("ts.wand.done"), "coordinate + volume messages shown");
        List<Object> sync = sentTo(p, S2CWandSelectionPacket.class);
        check(sync.size() == 2 && ((S2CWandSelectionPacket) sync.get(1)).b != null, "server-confirmed selection sent to client preview");
        WandEvents.applyPoint(p, 2, new BlockPos(9, 70, 9));
        check(sentTo(p, S2CWandSelectionPacket.class).size() == 2, "duplicate point does not resend");
        WandEvents.clearSelection(p);
        check(WandSelections.get(p.uuid) == null && ((S2CWandSelectionPacket) sentTo(p, S2CWandSelectionPacket.class).get(2)).dimension == null, "clear removes server selection and the client preview");
    }

    static void t10_tabletSwap() {
        System.out.println("[T10] tablet equip / stow packet handling");
        MinecraftServer s = fresh();
        region(s, "arena", 0, 0, 0, 99, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10);
        tick(s, 10);
        ItemStack gun = new ItemStack(Items.SWORD), tablet = new ItemStack(ModItems.TACTICAL_TABLET.get());
        a.inv.setItem(0, gun); a.inv.selected = 0; a.inv.setItem(5, tablet);
        a.tickCount = 100;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.EQUIP), () -> new NetworkEvent.Context(a));
        check(a.inv.getSelected() == gun, "alive player cannot pull the tablet out");
        die(a); respawnAt(a, 500, 64, 500);
        a.tickCount = 110;
        C2STabletActionPacket.handle(new C2STabletActionPacket((byte) 99), () -> new NetworkEvent.Context(a));
        check(a.inv.getSelected() == gun, "invalid action byte ignored");
        a.tickCount = 120;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.EQUIP), () -> new NetworkEvent.Context(a));
        check(a.inv.getSelected() == tablet && a.inv.getItem(5) == gun, "eliminated player: tablet swapped into the hand");
        check(!SpectateService.isActive(a), "equipping never starts spectating");
        a.tickCount = 121;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.STOW), () -> new NetworkEvent.Context(a));
        check(a.inv.getSelected() == tablet, "action spam inside the cooldown ignored");
        a.tickCount = 140;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.STOW), () -> new NetworkEvent.Context(a));
        check(a.inv.getSelected() == gun && a.inv.getItem(5) == tablet, "stow swaps the previous item back");
        // no tablet at all
        ServerPlayer c = player(s, "C", 30, 10, 10);
        tick(s, 10); die(c); respawnAt(c, 500, 64, 500);
        c.tickCount = 50;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.EQUIP), () -> new NetworkEvent.Context(c));
        check(c.messages.contains("ts.tablet.missing"), "missing tablet message");
        // exit-spectate action
        a.inv.selected = 5; a.tickCount = 200; s.ticks += 20;
        check(SpectateService.toggle(a), "spectate via tablet (hand slot 5)");
        a.tickCount = 230;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.EXIT_SPECTATE), () -> new NetworkEvent.Context(a));
        check(!SpectateService.isActive(a) && a.gameMode.mode == GameType.SURVIVAL, "EXIT_SPECTATE stops spectating and restores state");
        a.tickCount = 240;
        C2STabletActionPacket.handle(new C2STabletActionPacket(C2STabletActionPacket.EXIT_SPECTATE), () -> new NetworkEvent.Context(a));
        check(true, "exit when not spectating is a harmless no-op");
    }

    static void t11_animator() {
        System.out.println("[T11] client tablet animation state machine");
        TabletAnimator.reset();
        ClientState.clear();
        SimpleChannel.SENT.clear();
        Minecraft mc = new Minecraft();
        mc.player = new LocalPlayer(); mc.player.profile = new GameProfile(UUID.randomUUID(), "me"); mc.level = new ClientLevel();
        ItemStack tablet = new ItemStack(ModItems.TACTICAL_TABLET.get());
        mc.player.inv.setItem(0, new ItemStack(Items.SWORD)); mc.player.inv.selected = 0;
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.NONE && TabletAnimator.visibility(0) == 0f, "NONE while the gun is in hand");
        mc.player.inv.setItem(0, tablet);
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.DRAWING, "DRAWING once the tablet is the main-hand item");
        float last = -1; boolean monotonic = true; int hiddenFrames = 0;
        for (int i = 0; i < TabletAnimator.DRAW_DELAY_TICKS + TabletAnimator.DRAW_TICKS; i++) {
            float v = TabletAnimator.visibility(0.5f);
            if (v < last - 1e-6) monotonic = false;
            if (v <= 0.001f) hiddenFrames++;
            last = v;
            TabletAnimator.tick(mc);
        }
        check(monotonic, "draw visibility never goes backwards");
        check(hiddenFrames >= TabletAnimator.DRAW_DELAY_TICKS - 1, "tablet stays hidden during the gun-exit delay (no overlap)");
        check(TabletAnimator.state() == TabletAnimator.State.HOLDING && TabletAnimator.visibility(0.3f) == 1f, "HOLDING at full visibility");
        TabletAnimator.requestStow();
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.STOWING, "STOWING after a stow request");
        for (int i = 0; i < TabletAnimator.STOW_TICKS; i++) TabletAnimator.tick(mc);
        int stowPackets = 0;
        for (Object[] e : SimpleChannel.SENT) if (e[1] instanceof C2STabletActionPacket p && p.action() == C2STabletActionPacket.STOW) stowPackets++;
        check(stowPackets == 1 && TabletAnimator.visibility(0) == 0f, "exactly one STOW packet after the lowering finished, tablet hidden");
        // server refused: tablet raises again instead of staying invisible
        for (int i = 0; i < 25; i++) TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.DRAWING, "refused stow -> tablet is raised again");
        // item switched away mid-animation -> reset
        mc.player.inv.setItem(0, new ItemStack(Items.SWORD));
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.NONE, "switching the item away resets the animation");
        // slot change restarts the draw
        mc.player.inv.setItem(0, tablet); mc.player.inv.setItem(1, tablet);
        TabletAnimator.tick(mc); for (int i = 0; i < 30; i++) TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.HOLDING, "back to HOLDING");
        mc.player.inv.selected = 1;
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.NONE || TabletAnimator.state() == TabletAnimator.State.DRAWING, "slot change interrupts and restarts");
        // death mid-animation
        mc.player.alive = false; TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.NONE, "death resets the animation");
        // stow requested while spectating waits until spectating ends
        TabletAnimator.reset(); mc.player.alive = true; mc.player.inv.selected = 0;
        TabletAnimator.tick(mc); for (int i = 0; i < 30; i++) TabletAnimator.tick(mc);
        ClientState.applySpectate(true, 1, UUID.randomUUID(), "T");
        TabletAnimator.requestStow(); TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.HOLDING, "stow is deferred while spectating");
        ClientState.applySpectate(false, -1, null, "");
        TabletAnimator.tick(mc);
        check(TabletAnimator.state() == TabletAnimator.State.STOWING, "stow starts right after spectating ends");
        ClientState.clear();
    }

    static void t12_targetLeavesRegion() {
        System.out.println("[T12] target leaves the region / nobody left to watch");
        MinecraftServer s = fresh();
        region(s, "arena", 0, 0, 0, 99, 99, 99);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 20, 10, 10), c = player(s, "C", 30, 10, 10);
        tick(s, 10); die(a); respawnAt(a, 500, 64, 500); giveTablet(a); s.ticks += 20;
        SpectateService.toggle(a);
        ServerPlayer first = (ServerPlayer) a.camera;
        ServerPlayer other = first == b ? c : b;
        first.x = 400;   // walks out of the region (alive, online, but no longer inside)
        tick(s, 5);
        check(a.camera == other && SpectateService.isActive(a), "target that left the region is replaced by one still inside");
        other.x = 400;
        tick(s, 5);
        check(!SpectateService.isActive(a) && a.gameMode.mode == GameType.SPECTATOR == false, "no target inside the region -> spectating stops and state is restored");
        check(a.messages.contains("ts.spectate.unavailable"), "player is told why spectating stopped");
        check(a.x == 500 && a.z == 500, "viewer back at the lobby");
        // admin changes the viewer's game mode while spectating -> treated as external stop, no forced teleport
        first.x = 20; other.x = 30; s.ticks += 20;
        check(SpectateService.toggle(a), "can start again afterwards");
        a.setGameMode(GameType.CREATIVE);
        tick(s, 5);
        check(!SpectateService.isActive(a), "external game-mode change ends the session cleanly");
    }

    static void t13_gameModeRefused() {
        System.out.println("[T13] another mod refuses the game-mode switch");
        MinecraftServer s = fresh();
        region(s, "arena", 0, 0, 0, 299, 99, 299);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 100, 10, 100);
        tick(s, 10); die(a); respawnAt(a, 500, 64, 500); giveTablet(a); s.ticks += 20;
        a.refuseGameMode = true;
        check(!SpectateService.toggle(a), "toggle fails when the game-mode change is refused");
        check(!SpectateService.isActive(a) && a.x == 500 && a.z == 500, "no half-started session, body untouched");
        check(!a.persistent.contains(SpectateService.ORIGIN_KEY, 10), "origin not left behind");
        a.refuseGameMode = false; s.ticks += 20;
        check(SpectateService.toggle(a), "works again once the mode switch is allowed");
    }

    static void t14_longSpectateWithoutTrackingEvents() {
        System.out.println("[T14] long spectate when no StartTracking event was ever recorded");
        MinecraftServer s = fresh();
        region(s, "arena", 0, 0, 0, 299, 99, 299);
        ServerPlayer a = player(s, "A", 10, 10, 10), b = player(s, "B", 250, 10, 250);
        tick(s, 10); die(a); respawnAt(a, 500, 64, 500); giveTablet(a); s.ticks += 20;
        SpectateService.toggle(a);
        ServerPlayer target = (ServerPlayer) a.camera;
        int camPacketsBefore = (int) a.connection.sent.stream().filter(o -> o instanceof ClientboundSetCameraPacket).count();
        tick(s, 600);
        check(SpectateService.isActive(a) && a.camera == target, "still spectating the same target after 600 ticks (no spurious give-up / switch)");
        int camPacketsAfter = (int) a.connection.sent.stream().filter(o -> o instanceof ClientboundSetCameraPacket).count();
        check(camPacketsAfter > camPacketsBefore, "camera is re-asserted periodically (self-healing)");
        check(camPacketsAfter - camPacketsBefore < 60, "re-assert rate stays low (" + (camPacketsAfter - camPacketsBefore) + " packets / 600 ticks)");
        // the StartTracking handshake: pending target gets its camera packet when tracking starts
        SpectateService.stopFor(a, null);
        s.ticks += 20;
        SpectateService.toggle(a);
        ServerPlayer t2 = (ServerPlayer) a.camera;
        SpectateService.onTracking(a, t2, true);
        Object last = null; for (Object o : a.connection.sent) if (o instanceof ClientboundSetCameraPacket) last = o;
        check(last != null && ((ClientboundSetCameraPacket) last).entity == t2, "StartTracking for the target triggers a camera packet");
    }
}
