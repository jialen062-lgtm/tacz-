#!/usr/bin/env bash
# R6 validation: API-stub type check and functional logic tests. Not a real Forge compile.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="${1:-$HERE/../src/main/java}"
if command -v javac >/dev/null 2>&1; then JAVAC=(javac); else JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
find "$SRC" -name '*.java' > "$WORK/src.txt"
echo "== 1. API-stub syntax/type check (not real Forge API)"
find "$HERE/stubs-typecheck" -name '*.java' > "$WORK/stubs.txt"; mkdir -p "$WORK/o1"
set +e
"${JAVAC[@]}" -proc:none -Xlint:all -d "$WORK/o1" @"$WORK/stubs.txt" @"$WORK/src.txt" >"$WORK/typecheck.log" 2>&1
status=$?
set -e
cat "$WORK/typecheck.log" | grep -v "JAVA_TOOL\|stubs-typecheck\|^package \|^ *\^\|serial" || true
if [ "$status" -ne 0 ]; then echo "TYPECHECK FAILED (javac exit $status)"; exit "$status"; fi
echo "Typecheck passed (warnings may remain)."
echo "== 2. Functional logic scenario tests"
find "$HERE/stubs-functional" -name '*.java' > "$WORK/fstubs.txt"; mkdir -p "$WORK/o2"
set +e
"${JAVAC[@]}" -proc:none -d "$WORK/o2" @"$WORK/fstubs.txt" @"$WORK/src.txt" "$HERE/tests/TestMain.java" >"$WORK/functional_compile.log" 2>&1
status=$?
set -e
cat "$WORK/functional_compile.log" | grep -v "JAVA_TOOL\|serial\|warning\|^package \|^ *\^" || true
if [ "$status" -ne 0 ]; then echo "FUNCTIONAL TEST COMPILATION FAILED (javac exit $status)"; cat "$WORK/functional_compile.log"; exit "$status"; fi
java -cp "$WORK/o2" cn.blockforge.generated.tacticalspectator.test.TestMain
