#!/usr/bin/env bash
# 变异测试：把关键逻辑故意改坏，确认 TestMain 能抓到。每一项都应该出现 FAIL。
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="${1:-$HERE/../src/main/java}"
if command -v javac >/dev/null 2>&1; then JAVAC=(javac); else JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
mut() { # 名称 文件(相对 tacticalspectator 包) 旧文本 新文本
  W="$(mktemp -d)"; cp -r "$SRC" "$W/java"
  python3 - "$W/java/cn/blockforge/generated/tacticalspectator/$2" "$3" "$4" <<'PY'
import sys
p,old,new=sys.argv[1:4]
s=open(p,encoding='utf-8').read()
assert old in s, "pattern not found (source changed?)"
open(p,'w',encoding='utf-8').write(s.replace(old,new,1))
PY
  find "$W/java" -name '*.java' > "$W/s.txt"; find "$HERE/stubs-functional" -name '*.java' > "$W/f.txt"; mkdir -p "$W/o"
  "${JAVAC[@]}" -proc:none -d "$W/o" @"$W/f.txt" @"$W/s.txt" "$HERE/tests/TestMain.java" 2>&1 | grep -E "error" | head -3
  echo "--- 变异: $1"; java -cp "$W/o" cn.blockforge.generated.tacticalspectator.test.TestMain 2>&1 | grep -E "FAIL|RESULT" | head -4
  rm -rf "$W"
}
mut "复活后把玩家改回存活" round/RoundService.java "SpectateService.onViewerRespawn(player);" "SpectateService.onViewerRespawn(player); Round rr = firstRoundOf(player.getUUID()); if (rr != null) rr.get(player.getUUID()).alive = true;"
mut "下线时删除名单条目(原版 Bug)" round/RoundService.java "        SpectateService.onLogout(player);
    }" "        SpectateService.onLogout(player); Round rr = firstRoundOf(player.getUUID()); if (rr != null) rr.remove(player.getUUID());
    }"
mut "观战目标不再校验区域范围" spectate/SpectateService.java "if (!region.contains(target.level().dimension().location(), target.blockPosition())) {
                continue;
            }" ""
