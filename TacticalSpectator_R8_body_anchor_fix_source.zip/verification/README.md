# 验证工具包（不是模组的一部分）

用来在**没有 Forge / Minecraft jar** 的环境里检查模组源码。把本目录解压到工程根目录（与 `src/` 同级）后运行：

```bash
./verification/run_checks.sh          # 类型检查 + 14 组逻辑场景测试
./verification/mutation_check.sh      # 变异测试（每一项都应该出现 FAIL）
python3 verification/tools/sim_pose.py [参考画面.png]   # 平板姿态离线投影（需要 Pillow）
```

## 它能证明什么
* `stubs-typecheck/`：按记忆手写的 Minecraft 1.20.1 / Forge 47.2.8 API 外形。`javac` 能对模组代码做完整的语法 + 类型检查。
* `stubs-functional/`：同一批类的“可运行假实现”（NBT、服务器 / 玩家、网络记录、存档读写…）。`tests/TestMain.java` 在上面跑回合 / 观战 / 持久化 / 网络包 / 平板状态机的场景。
* `tools/sim_pose.py`：用模型 JSON 的真实几何做离线投影，验证第一人称平板姿态（`sim_hold.png` 是与参考视频帧的叠加结果）。

## 它不能证明什么
桩和假实现是我对 API 的**记忆**，不是真实 jar。它们不能证明与真实 Forge / Minecraft / TaCZ 兼容，也不能代替游戏内测试。真实编译请用 Gradle（见 `README_开发交付说明.md`）。
