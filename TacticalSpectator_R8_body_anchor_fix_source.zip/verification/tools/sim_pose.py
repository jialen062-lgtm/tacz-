import json, math, sys
import numpy as np
from PIL import Image, ImageDraw

import os
MODEL=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','src','main','resources','assets','tactical_spectator','models','item','tactical_tablet.json')
j=json.load(open(MODEL))
COL={'#0':(30,30,34),'#1':(20,90,80),'#2':(60,60,64),'#3':(90,90,40),'#4':(45,50,45)}

def box_faces(e):
    x0,y0,z0=[v/16-0.5 for v in e['from']]
    x1,y1,z1=[v/16-0.5 for v in e['to']]
    # face -> (verts ccw seen from outside, normal)
    F={
     'south':([(x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)],(0,0,1)),
     'north':([(x1,y0,z0),(x0,y0,z0),(x0,y1,z0),(x1,y1,z0)],(0,0,-1)),
     'east': ([(x1,y0,z1),(x1,y0,z0),(x1,y1,z0),(x1,y1,z1)],(1,0,0)),
     'west': ([(x0,y0,z0),(x0,y0,z1),(x0,y1,z1),(x0,y1,z0)],(-1,0,0)),
     'up':   ([(x0,y1,z1),(x1,y1,z1),(x1,y1,z0),(x0,y1,z0)],(0,1,0)),
     'down': ([(x0,y0,z0),(x1,y0,z0),(x1,y0,z1),(x0,y0,z1)],(0,-1,0)),
    }
    out=[]
    for name,(vs,n) in F.items():
        f=e['faces'].get(name)
        if f is None: continue
        tex=f.get('texture','#0')
        out.append((vs,n,COL.get(tex,(80,80,80))))
    return out

def rotx(d):
    r=math.radians(d); c,s=math.cos(r),math.sin(r)
    return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def rotz(d):
    r=math.radians(d); c,s=math.cos(r),math.sin(r)
    return np.array([[c,-s,0],[s,c,0],[0,0,1]])

def pose_matrix(v, P):
    inv=1-v
    t=np.array([P['x']+P['dx']*inv, P['y']+P['dy']*inv, P['z']+P['dz']*inv])
    R=rotz(P['roll']*inv) @ rotx(P['pitch']+P['dpitch']*inv)
    return t,R*P['s']

def render(P, v, W=540, H=304, fov=70.0):
    t,M=pose_matrix(v,P)
    polys=[]
    for e in j['elements']:
        for vs,n,col in box_faces(e):
            pv=[M@np.array(p)+t for p in vs]
            nrm=rotx(P['pitch']+P['dpitch']*(1-v))@np.array(n)  # approx (rotz ignored for normal sign test below)
            # proper normal via cross product
            a,b,c=pv[0],pv[1],pv[2]
            nn=np.cross(b-a,c-a)
            cen=sum(pv)/4
            if np.dot(nn,-cen)<=0: continue   # facing away from camera (camera at origin)
            polys.append((cen[2],pv,col))
    polys.sort(key=lambda q:q[0])   # most negative z (far) first
    f=1.0/math.tan(math.radians(fov)/2)
    aspect=W/H
    img=Image.new('RGBA',(W,H),(0,0,0,0))
    d=ImageDraw.Draw(img)
    for _,pv,col in polys:
        pts=[]
        ok=True
        for p in pv:
            if p[2]>=-0.05: ok=False;break
            x=(p[0]*f/aspect)/(-p[2]); y=(p[1]*f)/(-p[2])
            pts.append((W/2+x*W/2, H/2-y*H/2))
        if ok: d.polygon(pts,fill=col+(255,),outline=(0,0,0,255))
    return img

# 与 client/TabletHandRenderer.java 顶部常量保持一致
HOLD=dict(x=0.0,y=-0.308,z=-0.715,pitch=-35.0,s=0.85,dx=-0.30,dy=-0.50,dz=0.10,roll=14.0,dpitch=-20.0)
if __name__=='__main__':
    # 用法: python3 sim_pose.py [参考画面.png]   （参考画面 = 游戏画面裁剪，540x304 左右；不给则只输出动画条）
    import sys
    if len(sys.argv)>1:
        src=Image.open(sys.argv[1]).convert('RGBA')
        frame=Image.new('RGBA',(540,304)); frame.paste(src.crop((0,0,min(540,src.width),min(304,src.height))),(0,0))
        over=render(HOLD,1.0)
        out=Image.alpha_composite(frame,Image.blend(Image.new('RGBA',over.size,(0,0,0,0)),over,0.55))
        out.save('sim_hold.png')
    tiles=[]
    for v in [0.0,0.15,0.3,0.5,0.7,0.85,1.0]:
        im=Image.new('RGBA',(540,304),(40,60,40,255)); im.alpha_composite(render(HOLD,v)); tiles.append(im.resize((270,152)))
    sheet=Image.new('RGBA',(270*4,152*2),(0,0,0,255))
    for i,t in enumerate(tiles): sheet.paste(t,((i%4)*270,(i//4)*152))
    sheet.save('sim_anim.png')
    print('ok')
