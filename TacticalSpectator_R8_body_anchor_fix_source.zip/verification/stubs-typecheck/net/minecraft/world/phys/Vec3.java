package net.minecraft.world.phys; public class Vec3 { public static final Vec3 ZERO=null; public double x,y,z; }
