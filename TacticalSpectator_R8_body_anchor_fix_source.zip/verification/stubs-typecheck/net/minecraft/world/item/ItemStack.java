package net.minecraft.world.item; public class ItemStack { public ItemStack(Item i){} public boolean is(Item i){return false;} }
