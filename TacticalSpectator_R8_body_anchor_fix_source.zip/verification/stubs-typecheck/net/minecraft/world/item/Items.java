package net.minecraft.world.item; public class Items { public static final Item STICK=null; }
