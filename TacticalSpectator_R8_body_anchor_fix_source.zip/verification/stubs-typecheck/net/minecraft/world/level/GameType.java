package net.minecraft.world.level; public enum GameType { SURVIVAL, CREATIVE, ADVENTURE, SPECTATOR; public int getId(){return 0;} public static GameType byId(int i){return null;} }
