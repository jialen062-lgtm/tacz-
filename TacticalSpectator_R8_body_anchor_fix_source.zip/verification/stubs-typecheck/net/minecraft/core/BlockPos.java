package net.minecraft.core; public class BlockPos extends Vec3i { public static final BlockPos ZERO=null; public BlockPos(int x,int y,int z){} }
