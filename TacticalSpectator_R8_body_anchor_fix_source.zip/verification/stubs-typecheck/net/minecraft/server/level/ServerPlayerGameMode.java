package net.minecraft.server.level; import net.minecraft.world.level.GameType; public class ServerPlayerGameMode { public GameType getGameModeForPlayer(){return null;} }
