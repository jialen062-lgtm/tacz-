package com.mojang.authlib; import java.util.UUID; public class GameProfile { public GameProfile(UUID id,String name){} public String getName(){return null;} public UUID getId(){return null;} }
