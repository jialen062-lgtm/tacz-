package io.netty.handler.codec; public class DecoderException extends RuntimeException { public DecoderException(String m){super(m);} }
