package com.mojang.blaze3d.platform; public class Window { public int getGuiScaledWidth(){return 0;} }
