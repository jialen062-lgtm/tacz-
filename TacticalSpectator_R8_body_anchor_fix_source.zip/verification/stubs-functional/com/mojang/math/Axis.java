package com.mojang.math; import org.joml.Quaternionf; public interface Axis { Axis XP=null; Axis YP=null; Axis ZP=null; Quaternionf rotationDegrees(float deg); }
