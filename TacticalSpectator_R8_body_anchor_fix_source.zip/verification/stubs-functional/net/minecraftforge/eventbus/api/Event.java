package net.minecraftforge.eventbus.api; public class Event { public enum Result { DENY, DEFAULT, ALLOW } public void setCanceled(boolean b){} public boolean isCanceled(){return false;} }
