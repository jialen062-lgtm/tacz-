package net.minecraft.nbt; import java.util.*;
public class CompoundTag implements Tag { final Map<String,Object> m=new LinkedHashMap<>();
 public void putLong(String k,long v){m.put(k,v);} public long getLong(String k){ return m.get(k) instanceof Long v? v:0; }
 public void putString(String k,String v){m.put(k,v);} public String getString(String k){ return m.get(k) instanceof String v? v:""; }
 public void putInt(String k,int v){m.put(k,v);} public int getInt(String k){ return m.get(k) instanceof Integer v? v:0; }
 public void putBoolean(String k,boolean v){m.put(k,v);} public boolean getBoolean(String k){ return m.get(k) instanceof Boolean v&&v; }
 public void putDouble(String k,double v){m.put(k,v);} public double getDouble(String k){ return m.get(k) instanceof Double v? v:0; }
 public void putFloat(String k,float v){m.put(k,v);} public float getFloat(String k){ return m.get(k) instanceof Float v? v:0; }
 public void putUUID(String k,UUID v){m.put(k,v);} public UUID getUUID(String k){ return (UUID)m.get(k);} public boolean hasUUID(String k){ return m.get(k) instanceof UUID; }
 public Tag put(String k,Tag v){ return (Tag)m.put(k,v);} public ListTag getList(String k,int t){ return m.get(k) instanceof ListTag l? l:new ListTag(); }
 public CompoundTag getCompound(String k){ return m.get(k) instanceof CompoundTag c? c:new CompoundTag(); } public boolean contains(String k,int t){ Object o=m.get(k); return t==10? o instanceof CompoundTag : o!=null; }
 public void remove(String k){m.remove(k);} public int size(){return m.size();} }
