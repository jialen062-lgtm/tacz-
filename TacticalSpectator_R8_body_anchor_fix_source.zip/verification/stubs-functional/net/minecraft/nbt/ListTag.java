package net.minecraft.nbt; import java.util.*;
public class ListTag extends AbstractList<Tag> implements Tag { final List<Tag> l=new ArrayList<>(); public Tag get(int i){return l.get(i);} public int size(){return l.size();} public boolean add(Tag t){return l.add(t);} public CompoundTag getCompound(int i){ Tag t=l.get(i); return t instanceof CompoundTag c? c:new CompoundTag(); } }
