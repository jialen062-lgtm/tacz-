package net.minecraft.core;
public class Vec3i { protected int x,y,z; public Vec3i(int x,int y,int z){this.x=x;this.y=y;this.z=z;} public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;}
 public boolean closerThan(Vec3i v,double d){ double dx=x-v.x,dy=y-v.y,dz=z-v.z; return dx*dx+dy*dy+dz*dz<d*d; }
 @Override public boolean equals(Object o){ return o instanceof Vec3i v && v.x==x&&v.y==y&&v.z==z;} @Override public int hashCode(){return java.util.Objects.hash(x,y,z);} @Override public String toString(){return "("+x+","+y+","+z+")";} }
