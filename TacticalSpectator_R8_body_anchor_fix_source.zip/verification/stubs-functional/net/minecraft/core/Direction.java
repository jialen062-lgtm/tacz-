package net.minecraft.core; public enum Direction { DOWN, UP }
