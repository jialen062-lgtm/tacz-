package net.minecraft.network; import java.io.*; import java.util.UUID; import net.minecraft.core.BlockPos; import net.minecraft.resources.ResourceLocation;
public class FriendlyByteBuf { final ByteArrayOutputStream bo=new ByteArrayOutputStream(); final DataOutputStream o=new DataOutputStream(bo); DataInputStream in;
 DataInputStream i(){ if(in==null) in=new DataInputStream(new ByteArrayInputStream(bo.toByteArray())); return in; } RuntimeException wrap(IOException e){ return new RuntimeException(e); }
 public void writeLong(long v){ try{o.writeLong(v);}catch(IOException e){throw wrap(e);} } public long readLong(){ try{return i().readLong();}catch(IOException e){throw wrap(e);} }
 public FriendlyByteBuf writeVarInt(int v){ try{o.writeInt(v);}catch(IOException e){throw wrap(e);} return this; } public int readVarInt(){ try{return i().readInt();}catch(IOException e){throw wrap(e);} }
 public FriendlyByteBuf writeUUID(UUID u){ writeLong(u.getMostSignificantBits()); writeLong(u.getLeastSignificantBits()); return this; } public UUID readUUID(){ return new UUID(readLong(),readLong()); }
 public FriendlyByteBuf writeUtf(String s,int m){ if(s.length()>m) throw new RuntimeException("too long"); try{o.writeUTF(s);}catch(IOException e){throw wrap(e);} return this; } public String readUtf(int m){ try{return i().readUTF();}catch(IOException e){throw wrap(e);} }
 public void writeBoolean(boolean b){ try{o.writeBoolean(b);}catch(IOException e){throw wrap(e);} } public boolean readBoolean(){ try{return i().readBoolean();}catch(IOException e){throw wrap(e);} }
 public void writeByte(int b){ try{o.writeByte(b);}catch(IOException e){throw wrap(e);} } public byte readByte(){ try{return i().readByte();}catch(IOException e){throw wrap(e);} }
 public FriendlyByteBuf writeBlockPos(BlockPos p){ writeVarInt(p.getX());writeVarInt(p.getY());writeVarInt(p.getZ()); return this; } public BlockPos readBlockPos(){ return new BlockPos(readVarInt(),readVarInt(),readVarInt()); }
 public FriendlyByteBuf writeResourceLocation(ResourceLocation r){ writeUtf(r.toString(),256); return this; } public ResourceLocation readResourceLocation(){ return new ResourceLocation(readUtf(256)); } }
