package net.minecraft.network.chat; public interface Component { static Component translatable(String k,Object... a){ return new Component(){ @Override public String toString(){return k;} }; } }
