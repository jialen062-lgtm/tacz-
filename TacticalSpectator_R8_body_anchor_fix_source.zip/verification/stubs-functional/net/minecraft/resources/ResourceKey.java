package net.minecraft.resources; import net.minecraft.core.Registry;
public class ResourceKey<T> { final ResourceLocation loc; ResourceKey(ResourceLocation l){loc=l;}
 public static <T> ResourceKey<T> create(ResourceKey<? extends Registry<T>> r, ResourceLocation l){ return new ResourceKey<>(l);} public ResourceLocation location(){return loc;}
 @Override public boolean equals(Object o){ return o instanceof ResourceKey<?> k && k.loc.equals(loc);} @Override public int hashCode(){return loc.hashCode();} }
