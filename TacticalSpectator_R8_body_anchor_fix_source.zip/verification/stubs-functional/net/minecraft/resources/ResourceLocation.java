package net.minecraft.resources;
public class ResourceLocation { public final String s;
 public ResourceLocation(String ns,String p){ s=ns+":"+p; } public ResourceLocation(String s){ this.s=s.contains(":")?s:"minecraft:"+s; }
 public static ResourceLocation tryParse(String x){ if(x==null||!x.matches("[a-z0-9_.-]*:?[a-z0-9_./-]+")||x.isEmpty()) return null; return new ResourceLocation(x); }
 @Override public boolean equals(Object o){ return o instanceof ResourceLocation r && r.s.equals(s);} @Override public int hashCode(){return s.hashCode();} @Override public String toString(){return s;} }
