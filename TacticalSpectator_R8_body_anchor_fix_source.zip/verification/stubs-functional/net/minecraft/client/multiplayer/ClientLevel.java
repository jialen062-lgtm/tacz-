package net.minecraft.client.multiplayer; public class ClientLevel extends net.minecraft.world.level.Level { public ClientLevel(){super("minecraft:overworld");} }
