package net.minecraft.client.multiplayer; import com.mojang.authlib.GameProfile; public class PlayerInfo { public GameProfile getProfile(){return null;} }
