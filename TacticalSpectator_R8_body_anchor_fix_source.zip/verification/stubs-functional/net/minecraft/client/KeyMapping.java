package net.minecraft.client; public class KeyMapping { public boolean consumeClick(){return false;} public boolean isDown(){return false;} public void setDown(boolean b){} }
