package net.minecraft.client.renderer; public class RenderType { public static RenderType LINES; }
