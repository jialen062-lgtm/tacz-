package net.minecraft.world.item; import net.minecraft.resources.ResourceKey; public class CreativeModeTabs { public static final ResourceKey<CreativeModeTab> TOOLS_AND_UTILITIES=null; }
