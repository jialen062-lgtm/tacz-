package net.minecraft.world.item; import net.minecraft.world.*; import net.minecraft.world.entity.player.Player; import net.minecraft.world.level.Level;
public class Item { public Item(Properties p){} public static class Properties { public Properties stacksTo(int i){return this;} } public InteractionResultHolder<ItemStack> use(Level l,Player p,InteractionHand h){return null;} }
