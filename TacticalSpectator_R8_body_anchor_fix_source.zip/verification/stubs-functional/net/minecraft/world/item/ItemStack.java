package net.minecraft.world.item; public class ItemStack { public final Item item; public ItemStack(Item i){item=i;} public boolean is(Item i){return item==i;} }
