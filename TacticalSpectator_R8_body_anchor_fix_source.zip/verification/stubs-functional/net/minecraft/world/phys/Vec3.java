package net.minecraft.world.phys; public class Vec3 { public static final Vec3 ZERO=new Vec3(0,0,0); public double x,y,z; public Vec3(double x,double y,double z){this.x=x;this.y=y;this.z=z;} }
