package net.minecraft.world; public class InteractionResultHolder<T> { public static <T> InteractionResultHolder<T> sidedSuccess(T t,boolean b){return null;} }
