package net.minecraft.world.level.storage; import net.minecraft.nbt.CompoundTag; import net.minecraft.world.level.saveddata.SavedData; import java.util.*; import java.util.function.*;
public class DimensionDataStorage { public final Map<String,CompoundTag> disk; final Map<String,SavedData> cache=new HashMap<>(); public DimensionDataStorage(Map<String,CompoundTag> disk){this.disk=disk;}
 @SuppressWarnings("unchecked") public <T extends SavedData> T computeIfAbsent(Function<CompoundTag,T> l,Supplier<T> f,String n){ if(cache.containsKey(n)) return (T)cache.get(n); T t = disk.containsKey(n)? l.apply(disk.get(n)) : f.get(); cache.put(n,t); return t; }
 public void saveAll(){ for(var e: cache.entrySet()) disk.put(e.getKey(), e.getValue().save(new CompoundTag())); } }
