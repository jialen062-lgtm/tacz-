package org.slf4j; public interface Logger { void warn(String m, Object... a); void info(String m, Object... a); void error(String m, Object... a); }
