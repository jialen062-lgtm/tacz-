package org.lwjgl.glfw; public class GLFW { public static final int GLFW_PRESS=1, GLFW_KEY_A=65, GLFW_KEY_D=68; }
