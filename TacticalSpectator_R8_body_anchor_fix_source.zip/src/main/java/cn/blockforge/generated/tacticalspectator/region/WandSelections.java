package cn.blockforge.generated.tacticalspectator.region;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 服务端记录的木棍选区（每位玩家一份，内存数据，不持久化）。
 * 换维度后旧选区自动作废。
 */
public final class WandSelections {

    public static final class Sel {
        public ResourceLocation dim;
        public BlockPos a;
        public BlockPos b;
    }

    private static final Map<UUID, Sel> SELECTIONS = new ConcurrentHashMap<>();

    public static Sel get(UUID player) {
        return SELECTIONS.get(player);
    }

    /**
     * 设置点 1 或点 2。维度变化时清空旧选区。
     *
     * @return true 表示选区发生了实际变化（用于避免重复提示）
     */
    public static boolean setPoint(UUID player, ResourceLocation dim, int point, BlockPos pos) {
        Sel sel = SELECTIONS.computeIfAbsent(player, k -> new Sel());
        if (sel.dim == null || !sel.dim.equals(dim)) {
            sel.dim = dim;
            sel.a = null;
            sel.b = null;
        }
        if (point == 1) {
            if (Objects.equals(sel.a, pos)) {
                return false;
            }
            sel.a = pos;
        } else {
            if (Objects.equals(sel.b, pos)) {
                return false;
            }
            sel.b = pos;
        }
        return true;
    }

    public static void clear(UUID player) {
        SELECTIONS.remove(player);
    }

    public static void clearAll() {
        SELECTIONS.clear();
    }

    private WandSelections() {
    }
}
