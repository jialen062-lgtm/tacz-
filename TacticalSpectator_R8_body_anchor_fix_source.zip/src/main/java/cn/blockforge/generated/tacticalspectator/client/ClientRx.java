package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.List;
import java.util.UUID;

/** S2C packet 的客户端落地点（由 DistExecutor 调用，保证只在客户端加载本类） */
public final class ClientRx {

    public static void applyRoundUpdate(long regionId, List<S2CRoundUpdatePacket.Entry> entries) {
        ClientState.applyRound(regionId, entries);
    }

    public static void applySpectateMode(boolean on, long regionId, UUID target, String targetName) {
        ClientState.applySpectate(on, regionId, target, targetName);
    }

    public static void applyWandSelection(ResourceLocation dim, BlockPos a, BlockPos b) {
        ClientState.applyWandSelection(dim, a, b);
    }

    private ClientRx() {
    }
}
