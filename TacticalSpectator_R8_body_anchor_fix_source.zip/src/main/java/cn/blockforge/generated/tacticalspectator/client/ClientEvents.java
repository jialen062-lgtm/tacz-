package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SCycleTargetPacket;
import cn.blockforge.generated.tacticalspectator.net.packet.C2STabletActionPacket;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * 客户端 tick / 按键：
 *  - 观战中按 A/D 发送切换请求（非观战状态完全不干预）；
 *  - 观战中冻结本体移动输入；观战中的鼠标交互一律取消，唯一例外是手持平板右键 = 退出观战；
 *  - F 短按 = 原版副手交换；长按 = 取出平板（只取出，不会直接进入观战）/ 收回平板并退出观战；
 *  - 平板动画状态机每 tick 推进；断开连接时清空本地状态。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    private static final int TABLET_HOLD_TICKS = 10;
    private static final int EXIT_RESEND_TICKS = 4;
    private static int swapHeldTicks;
    private static int clientTicks;
    private static int lastExitSent = -100;

    @SubscribeEvent
    public static void onKey(InputEvent.Key event) {
        if (event.getAction() != GLFW.GLFW_PRESS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !ClientState.spectating) {
            return;
        }
        if (event.getKey() == GLFW.GLFW_KEY_A) {
            ModNetwork.CHANNEL.sendToServer(new C2SCycleTargetPacket(-1));
        } else if (event.getKey() == GLFW.GLFW_KEY_D) {
            ModNetwork.CHANNEL.sendToServer(new C2SCycleTargetPacket(1));
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        clientTicks++;
        Minecraft mc = Minecraft.getInstance();
        TabletAnimator.tick(mc);
        handleTabletKey(mc);
        if (mc.player == null || !ClientState.spectating) {
            return;
        }
        Options options = mc.options;
        freeze(options.keyUp);
        freeze(options.keyDown);
        freeze(options.keyLeft);
        freeze(options.keyRight);
        freeze(options.keyJump);
        freeze(options.keyShift);
        freeze(options.keySprint);
        // 原版旁观模式的“传送到玩家”菜单由数字键 / 滚轮 / 中键打开，会绕过区域隔离：全部吞掉
        for (KeyMapping hotbar : options.keyHotbarSlots) {
            while (hotbar.consumeClick()) {
                // swallowed
            }
        }
    }

    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        if (ClientState.spectating) {
            event.setCanceled(true);
        }
    }

    private static boolean holdingTablet(LocalPlayer player) {
        return player.getMainHandItem().is(ModItems.TACTICAL_TABLET.get());
    }

    private static void handleTabletKey(Minecraft mc) {
        if (mc.player == null || mc.screen != null || !mc.isWindowActive() || mc.getConnection() == null) {
            swapHeldTicks = 0;
            return;
        }
        boolean holding = holdingTablet(mc.player);
        // 只在与平板有关的状态下接管 F；其他时候完全交还给原版
        if (!ClientState.spectating && !holding && !ClientState.isEliminated(mc.player.getUUID())) {
            swapHeldTicks = 0;
            return;
        }

        KeyMapping swap = mc.options.keySwapOffhand;
        boolean pressed = false;
        while (swap.consumeClick()) {
            pressed = true;
        }
        if (swap.isDown()) {
            if (pressed || swapHeldTicks > 0) {
                if (swapHeldTicks < TABLET_HOLD_TICKS && ++swapHeldTicks == TABLET_HOLD_TICKS) {
                    onLongPress(mc, holding);
                }
            }
            return;
        }
        // 松开：没达到长按时长 = 短按，保留原版“与副手交换”
        if (!ClientState.spectating && (pressed || swapHeldTicks > 0) && swapHeldTicks < TABLET_HOLD_TICKS) {
            mc.getConnection().send(new ServerboundPlayerActionPacket(
                    ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
        }
        swapHeldTicks = 0;
    }

    private static void onLongPress(Minecraft mc, boolean holding) {
        if (ClientState.spectating) {
            // 观战中长按 F：立即退出观战，并开始收回平板（退出后才会播放收回动画）
            ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(C2STabletActionPacket.EXIT_SPECTATE));
            TabletAnimator.requestStow();
        } else if (holding) {
            TabletAnimator.requestStow();
        } else if (ClientState.isEliminated(mc.player.getUUID())) {
            // 只请求取出背包里已有的平板；进入观战只能手持平板右键
            ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(C2STabletActionPacket.EQUIP));
        }
    }

    /**
     * 观战中：取消所有鼠标交互（攻击 / 使用 / 选取），只有手持平板右键会被改发成“退出观战”请求。
     * 未观战但平板还在掏出 / 收回动画中：忽略右键，避免动画未结束就进入观战。
     */
    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        boolean holding = holdingTablet(player);
        if (ClientState.spectating) {
            event.setCanceled(true);
            event.setSwingHand(false);
            if (event.isUseItem() && holding && clientTicks - lastExitSent >= EXIT_RESEND_TICKS) {
                lastExitSent = clientTicks;
                ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(C2STabletActionPacket.EXIT_SPECTATE));
            }
            return;
        }
        if (holding && event.isUseItem() && TabletAnimator.state() != TabletAnimator.State.HOLDING) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    private static void freeze(KeyMapping key) {
        if (key.isDown()) {
            key.setDown(false);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.clear();
        TabletAnimator.reset();
        swapHeldTicks = 0;
    }

    private ClientEvents() {
    }
}
