package cn.blockforge.generated.tacticalspectator.region;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/** 一个长方体区域：独立名称 + 唯一 ID + 所有者 + 维度 + 边界（含端点，方块坐标） */
public final class Region {
    public final long id;
    public final String name;        // 显示名
    public final String lowerName;   // 查询用（忽略大小写）
    public UUID owner;
    public String ownerName;
    public ResourceLocation dimension;
    public int minX, minY, minZ, maxX, maxY, maxZ;

    public Region(long id, String name, UUID owner, String ownerName, ResourceLocation dimension,
                  BlockPos a, BlockPos b) {
        this.id = id;
        this.name = name;
        this.lowerName = name.toLowerCase(java.util.Locale.ROOT);
        this.owner = owner;
        this.ownerName = ownerName;
        this.dimension = dimension;
        setBox(a, b);
    }

    public void setBox(BlockPos a, BlockPos b) {
        minX = Math.min(a.getX(), b.getX());
        minY = Math.min(a.getY(), b.getY());
        minZ = Math.min(a.getZ(), b.getZ());
        maxX = Math.max(a.getX(), b.getX());
        maxY = Math.max(a.getY(), b.getY());
        maxZ = Math.max(a.getZ(), b.getZ());
    }

    public long volume() {
        return (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
    }

    public boolean contains(ResourceLocation dim, BlockPos pos) {
        return dimension.equals(dim)
                && pos.getX() >= minX && pos.getX() <= maxX
                && pos.getY() >= minY && pos.getY() <= maxY
                && pos.getZ() >= minZ && pos.getZ() <= maxZ;
    }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.putLong("id", id);
        tag.putString("name", name);
        tag.putString("owner", owner == null ? "" : owner.toString());
        tag.putString("ownerName", ownerName == null ? "" : ownerName);
        tag.putString("dim", dimension.toString());
        tag.putInt("minX", minX);
        tag.putInt("minY", minY);
        tag.putInt("minZ", minZ);
        tag.putInt("maxX", maxX);
        tag.putInt("maxY", maxY);
        tag.putInt("maxZ", maxZ);
        return tag;
    }

    /**
     * 从 NBT 读取区域；数据不完整（缺名称、维度非法等）时返回 null，由调用方跳过并记录日志，
     * 不让一个坏条目拖垮整个存档的加载。
     */
    public static Region fromTag(CompoundTag tag) {
        String name = tag.getString("name");
        if (name.isBlank()) {
            return null;
        }
        ResourceLocation dimension = ResourceLocation.tryParse(tag.getString("dim"));
        if (dimension == null) {
            return null;
        }
        String ownerStr = tag.getString("owner");
        UUID owner;
        try {
            owner = ownerStr.isEmpty() ? null : UUID.fromString(ownerStr);
        } catch (IllegalArgumentException e) {
            owner = null;
        }
        return new Region(
                tag.getLong("id"),
                name,
                owner,
                tag.getString("ownerName"),
                dimension,
                new BlockPos(tag.getInt("minX"), tag.getInt("minY"), tag.getInt("minZ")),
                new BlockPos(tag.getInt("maxX"), tag.getInt("maxY"), tag.getInt("maxZ")));
    }
}
