package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.client.ClientRx;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 服务端确认后的木棍选区（用于客户端边框预览）。
 * 客户端不再自己“猜”选区：服务端拒绝的选点（太远等）不会出现在预览里，
 * 切换维度 / 重新登录后服务端发送空选区，预览随之清除。
 */
public final class S2CWandSelectionPacket {
    /** 维度为 null 表示没有选区 */
    public final ResourceLocation dimension;
    public final BlockPos a;
    public final BlockPos b;

    public S2CWandSelectionPacket(ResourceLocation dimension, BlockPos a, BlockPos b) {
        this.dimension = dimension;
        this.a = a;
        this.b = b;
    }

    public static S2CWandSelectionPacket empty() {
        return new S2CWandSelectionPacket(null, null, null);
    }

    public static void encode(S2CWandSelectionPacket msg, FriendlyByteBuf buf) {
        boolean has = msg.dimension != null;
        buf.writeBoolean(has);
        if (!has) {
            return;
        }
        buf.writeResourceLocation(msg.dimension);
        buf.writeBoolean(msg.a != null);
        if (msg.a != null) {
            buf.writeBlockPos(msg.a);
        }
        buf.writeBoolean(msg.b != null);
        if (msg.b != null) {
            buf.writeBlockPos(msg.b);
        }
    }

    public static S2CWandSelectionPacket decode(FriendlyByteBuf buf) {
        if (!buf.readBoolean()) {
            return empty();
        }
        ResourceLocation dim = buf.readResourceLocation();
        BlockPos a = buf.readBoolean() ? buf.readBlockPos() : null;
        BlockPos b = buf.readBoolean() ? buf.readBlockPos() : null;
        return new S2CWandSelectionPacket(dim, a, b);
    }

    public static void handle(S2CWandSelectionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRx.applyWandSelection(msg.dimension, msg.a, msg.b)));
        ctx.setPacketHandled(true);
    }
}
