package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 接管主手里的战术平板的第一人称渲染（掏出 / 持有 / 收回由 TabletAnimator 驱动）。
 *
 * 姿态常量根据参考视频的持有画面校准：平板正面朝向镜头，上边缘向远处倾斜约 35°，
 * 横向居中，下半部分落在屏幕下沿之外。模型 JSON 里 firstperson_* 的 display 已改为单位变换，
 * 所以最终姿态完全由这里决定，不会和 JSON 里的变换叠加。
 *
 * 模型在物品空间内以 (0.5, 0.5, 0.5) 为中心（见 tactical_tablet.json），
 * 渲染时由 ItemRenderer 先平移 -0.5，因此下面的平移 / 旋转 / 缩放都是绕平板中心进行。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class TabletHandRenderer {

    // ---- 持有姿态（视图空间：+x 右，+y 上，-z 朝前） ----
    private static final float HOLD_X = 0.0F;
    private static final float HOLD_Y = -0.308F;
    private static final float HOLD_Z = -0.715F;
    private static final float HOLD_PITCH = -35.0F;
    private static final float SCALE = 0.85F;

    // ---- 掏出 / 收回时相对持有姿态的偏移（v = 0 时的位置：画面左下方外侧，略微侧倾） ----
    private static final float START_DX = -0.30F;
    private static final float START_DY = -0.50F;
    private static final float START_DZ = 0.10F;
    private static final float START_ROLL = 14.0F;
    private static final float START_PITCH = -20.0F;

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.TACTICAL_TABLET.get())) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }
        // 平板由我们自己画：取消原版手臂 / 物品渲染，否则会和平板重叠
        event.setCanceled(true);

        float v = TabletAnimator.visibility(event.getPartialTick());
        if (v <= 0.002F) {
            return;
        }
        boolean leftHanded = player.getMainArm() == HumanoidArm.LEFT;
        ItemDisplayContext context = leftHanded
                ? ItemDisplayContext.FIRST_PERSON_LEFT_HAND
                : ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
        float side = leftHanded ? -1.0F : 1.0F;

        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        float inv = 1.0F - v;
        pose.translate(HOLD_X + START_DX * inv * side, HOLD_Y + START_DY * inv, HOLD_Z + START_DZ * inv);
        pose.mulPose(Axis.ZP.rotationDegrees(START_ROLL * inv * side));
        pose.mulPose(Axis.XP.rotationDegrees(HOLD_PITCH + START_PITCH * inv));
        pose.scale(SCALE, SCALE, SCALE);

        ItemRenderer itemRenderer = mc.getItemRenderer();
        itemRenderer.renderStatic(player, stack, context, leftHanded, pose,
                event.getMultiBufferSource(), mc.level, event.getPackedLight(),
                OverlayTexture.NO_OVERLAY, player.getId() + context.ordinal());
        pose.popPose();
    }

    private TabletHandRenderer() {
    }
}
