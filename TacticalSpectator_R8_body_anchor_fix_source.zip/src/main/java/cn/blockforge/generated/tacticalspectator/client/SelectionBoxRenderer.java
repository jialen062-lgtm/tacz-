package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 选区完成后在世界里画出区域边界（青色线框） */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class SelectionBoxRenderer {

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            return;
        }
        // 选区边框只在玩家手持木棍时显示（主手或副手均可）。
        // 收起/切换木棍后立即隐藏，但不清除已选坐标。
        if (!mc.player.getMainHandItem().is(Items.STICK)
                && !mc.player.getOffhandItem().is(Items.STICK)) {
            return;
        }
        AABB box = ClientState.selectionBox();
        if (box == null || ClientState.selDim == null
                || !ClientState.selDim.equals(mc.level.dimension().location())) {
            return;
        }
        Vec3 cam = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        poseStack.translate(-cam.x, -cam.y, -cam.z);
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vertex = buffers.getBuffer(RenderType.LINES);
        LevelRenderer.renderLineBox(poseStack, vertex, box, 0.25F, 0.75F, 1.0F, 1.0F);
        poseStack.popPose();
        buffers.endBatch(RenderType.LINES);
    }

    private SelectionBoxRenderer() {
    }
}
