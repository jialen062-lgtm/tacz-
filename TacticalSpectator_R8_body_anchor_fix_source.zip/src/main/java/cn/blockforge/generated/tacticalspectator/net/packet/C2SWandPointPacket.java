package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.event.WandEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 客户端用木棍点选方块后，把坐标交给服务端记录（左键=点1，右键=点2）。所有校验在服务端 applyPoint 内完成 */
public final class C2SWandPointPacket {
    public final int point;
    public final BlockPos pos;

    public C2SWandPointPacket(int point, BlockPos pos) {
        this.point = point;
        this.pos = pos;
    }

    public static void encode(C2SWandPointPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.point);
        buf.writeBlockPos(msg.pos);
    }

    public static C2SWandPointPacket decode(FriendlyByteBuf buf) {
        return new C2SWandPointPacket(buf.readByte(), buf.readBlockPos());
    }

    public static void handle(C2SWandPointPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer sender = ctx.getSender();
            if (sender != null) {
                WandEvents.applyPoint(sender, msg.point, msg.pos);
            }
        });
        ctx.setPacketHandled(true);
    }
}
