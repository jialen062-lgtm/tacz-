package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.blaze3d.vertex.PoseStack;

/**
 * First-person spectator body: draws the followed player's body below the camera.
 * The head and hat are hidden to avoid rendering the camera owner's head inside the view.
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SpectatorBodyRenderer {
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || !ClientState.spectating
                || ClientState.spectateTarget == null) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.getCameraEntity() == null) return;

        var entity = mc.level.getPlayerByUUID(ClientState.spectateTarget);
        if (!(entity instanceof AbstractClientPlayer target) || !target.isAlive()) return;
        if (mc.getCameraEntity() != target) return;

        EntityRenderer<?> rawRenderer = mc.getEntityRenderDispatcher().getRenderer(target);
        if (!(rawRenderer instanceof PlayerRenderer renderer)) return;

        Vec3 camera = event.getCamera().getPosition();
        double x = target.getX() - camera.x;
        double y = target.getY() - camera.y;
        double z = target.getZ() - camera.z;
        float partialTick = event.getPartialTick();

        var model = renderer.getModel();
        boolean headVisible = model.head.visible;
        boolean hatVisible = model.hat.visible;
        model.head.visible = false;
        model.hat.visible = false;
        try {
            PoseStack pose = event.getPoseStack();
            MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
            int light = mc.getEntityRenderDispatcher().getPackedLightCoords(target, partialTick);
            mc.getEntityRenderDispatcher().render(target, x, y, z, target.getYRot(), partialTick,
                    pose, buffers, light);
        } finally {
            model.head.visible = headVisible;
            model.hat.visible = hatVisible;
        }
    }

    private SpectatorBodyRenderer() {}
}
