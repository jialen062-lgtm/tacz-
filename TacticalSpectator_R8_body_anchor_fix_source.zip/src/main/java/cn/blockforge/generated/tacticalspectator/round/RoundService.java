package cn.blockforge.generated.tacticalspectator.round;

import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import cn.blockforge.generated.tacticalspectator.region.Region;
import cn.blockforge.generated.tacticalspectator.region.RegionStore;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 回合管理（服务端权威状态，经 RoundStore 持久化到世界存档）：
 *  - 玩家踏入区域自动加入本轮名单（进入即参战）；
 *  - 死亡后标记淘汰，身份绑定“原本所属回合”，与死亡时所处位置无关；
 *  - 复活 / 下线 / 重新连接都不会改变淘汰或存活身份；
 *  - 本轮无人存活即结束，只结束该区域的回合。
 * 每个区域一份 Round，区域之间完全隔离，支持多区域同时进行。
 */
public final class RoundService {

    private static RoundStore store;
    /** 服务器未绑定时的兜底（不持久化），正常运行中不会被使用 */
    private static final Map<Long, Round> UNBOUND = new HashMap<>();
    private static int tick = 0;

    // ---------- 生命周期 ----------

    /** 服务器启动完成后绑定存档数据，并清理已经失效的回合 */
    public static void bind(MinecraftServer server) {
        store = RoundStore.get(server);
        tick = 0;
        RegionStore regions = RegionStore.get(server);
        Iterator<Map.Entry<Long, Round>> it = store.rounds.entrySet().iterator();
        boolean changed = false;
        while (it.hasNext()) {
            Round round = it.next().getValue();
            if (regions.byId(round.regionId) == null || round.allDead()) {
                it.remove();
                changed = true;
            }
        }
        if (changed) {
            store.setDirty();
        }
    }

    /** ServerStopped 之后调用（此时世界已经保存完毕） */
    public static void unbind() {
        store = null;
        UNBOUND.clear();
        tick = 0;
    }

    private static Map<Long, Round> rounds() {
        return store != null ? store.rounds : UNBOUND;
    }

    private static void dirty() {
        if (store != null) {
            store.setDirty();
        }
    }

    // ---------- tick ----------

    public static void onServerTick(MinecraftServer server) {
        tick++;
        if (tick % 10 == 0) {
            RegionStore regions = RegionStore.get(server);
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.isSpectator() || !p.isAlive() || SpectateService.isActive(p)) {
                    continue;
                }
                Region r = regions.smallestAt(p.level().dimension().location(), p.blockPosition());
                if (r != null) {
                    join(server, p, r);
                }
            }
        }
        if (tick % 5 == 0) {
            SpectateService.validate(server);
        }
    }

    // ---------- 加入 / 死亡 / 下线 / 上线 ----------

    /** 进入区域 = 加入本轮名单 */
    public static void join(MinecraftServer server, ServerPlayer player, Region region) {
        UUID id = player.getUUID();
        String name = player.getGameProfile().getName();
        Round existing = firstRoundOf(id);
        if (existing != null) {
            if (existing.regionId == region.id) {
                return;
            }
            Participant old = existing.get(id);
            if (old == null || !old.alive) {
                // 已淘汰的玩家保持淘汰身份，直到原回合结束，不会加入别的区域
                return;
            }
            // 存活玩家进入了另一个区域：离开旧回合，避免同时出现在两个名单里
            existing.remove(id);
            dirty();
            ModNetwork.sendTo(player, new S2CRoundUpdatePacket(existing.regionId, List.of()));
            afterChange(server, existing);
        }
        Round round = rounds().computeIfAbsent(region.id, Round::new);
        if (round.add(id, name)) {
            dirty();
            sync(server, round);
        }
    }

    /**
     * 玩家死亡。身份以“已有的回合名单”为准，不再用死亡位置重新判断区域
     * （死亡时可能已被击退 / 传送出边界）。只有玩家尚未被登记且死在某个区域内时，才按位置补登记。
     */
    public static void onDeath(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        SpectateService.onViewerDeath(player);
        UUID id = player.getUUID();
        Round round = firstRoundOf(id);
        if (round == null) {
            Region region = RegionStore.get(server).smallestAt(player.level().dimension().location(),
                    player.blockPosition());
            if (region == null) {
                return;
            }
            round = rounds().computeIfAbsent(region.id, Round::new);
            round.add(id, player.getGameProfile().getName());
            dirty();
        }
        if (round.setDead(id)) {
            dirty();
        }
        afterChange(server, round);
    }

    public static void onRespawn(ServerPlayer player) {
        SpectateService.onViewerRespawn(player);
        // 复活后仍保留本轮淘汰状态，才可以拿出平板观战（这里刻意不改回存活）。
    }

    /** 下线：保留本轮身份，不从名单里删除 */
    public static void onLogout(ServerPlayer player) {
        SpectateService.onLogout(player);
    }

    /** 上线：恢复正确的参战 / 淘汰状态，并把本轮名单同步给客户端 */
    public static void onLogin(ServerPlayer player) {
        SpectateService.onLogin(player);
        Round round = firstRoundOf(player.getUUID());
        if (round == null) {
            return;
        }
        Participant me = round.get(player.getUUID());
        String name = player.getGameProfile().getName();
        if (me != null && !name.equals(me.name)) {
            me.name = name;
            dirty();
        }
        ModNetwork.sendTo(player, buildPacket(round));
    }

    private static void afterChange(MinecraftServer server, Round round) {
        if (round.allDead()) {
            endRound(server, round);
        } else {
            sync(server, round);
            SpectateService.validate(server);
        }
    }

    // ---------- 区域删除 / 手动重置 ----------

    /** 区域被删除：本轮作废，并清理观战与 HUD */
    public static void onRegionDeleted(MinecraftServer server, long regionId) {
        Round round = rounds().get(regionId);
        if (round == null) {
            return;
        }
        endRound(server, round);
    }

    /** 管理员手动结束某个区域的回合（用于异常残留，例如最后的存活者已下线）。@return 是否存在该回合 */
    public static boolean reset(MinecraftServer server, long regionId) {
        Round round = rounds().get(regionId);
        if (round == null) {
            return false;
        }
        endRound(server, round);
        return true;
    }

    private static void endRound(MinecraftServer server, Round round) {
        List<ServerPlayer> audience = viewers(server, round);
        rounds().remove(round.regionId);
        dirty();
        S2CRoundUpdatePacket clear = new S2CRoundUpdatePacket(round.regionId, List.of());
        for (ServerPlayer v : audience) {
            ModNetwork.sendTo(v, clear);
        }
        SpectateService.onRoundEnd(server, round.regionId);
    }

    // ---------- 查询 ----------

    public static Round byRegion(long regionId) {
        return rounds().get(regionId);
    }

    public static boolean isEliminated(UUID player) {
        Round round = firstRoundOf(player);
        Participant participant = round == null ? null : round.get(player);
        return participant != null && !participant.alive;
    }

    /** 该玩家所在的第一个回合（正常只会在一个区域的名单里） */
    public static Round firstRoundOf(UUID player) {
        for (Round round : rounds().values()) {
            if (round.contains(player)) {
                return round;
            }
        }
        return null;
    }

    // ---------- 同步 ----------

    /** 能看到这个回合 HUD 的人：在线参战者 + 正在观战这个区域的人（去重） */
    private static List<ServerPlayer> viewers(MinecraftServer server, Round round) {
        List<ServerPlayer> out = new ArrayList<>();
        for (UUID uuid : round.participants.keySet()) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) {
                out.add(p);
            }
        }
        for (ServerPlayer s : SpectateService.spectatorsOf(server, round.regionId)) {
            if (!out.contains(s)) {
                out.add(s);
            }
        }
        return out;
    }

    private static S2CRoundUpdatePacket buildPacket(Round round) {
        List<S2CRoundUpdatePacket.Entry> entries = new ArrayList<>();
        for (Participant p : round.orderedList()) {
            if (entries.size() >= S2CRoundUpdatePacket.MAX_ENTRIES) {
                break;
            }
            entries.add(new S2CRoundUpdatePacket.Entry(p.uuid, p.name == null ? "" : p.name, p.alive));
        }
        return new S2CRoundUpdatePacket(round.regionId, entries);
    }

    public static void sync(MinecraftServer server, Round round) {
        if (round == null || server == null) {
            return;
        }
        S2CRoundUpdatePacket packet = buildPacket(round);
        for (ServerPlayer v : viewers(server, round)) {
            ModNetwork.sendTo(v, packet);
        }
    }

    private RoundService() {
    }
}
