package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.UUID;

/**
 * 观战 HUD（只在观战中显示）：
 *  - 顶部居中：正在观战（玩家 ID），每次切换目标后由服务端重发，立即更新；
 *  - 右上角：当前观战区域所有参战玩家的皮肤头像 + 绿 / 红圆点（存活 / 死亡），不显示名字。
 * 名单只取 ClientState.spectateRegion 对应的回合，不会混入其他区域的玩家；
 * 回合结束（全员死亡）时服务端会清除该回合并结束观战，名单随之消失。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class HudRenderer {

    private static final int AVATAR = 16;
    private static final int MARGIN = 4;
    private static final int GREEN = 0xFF3CD95C;
    private static final int RED = 0xFFE14B4B;

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        render(event.getGuiGraphics());
    }

    private static void render(GuiGraphics gui) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null || mc.options.hideGui) {
            return;
        }
        if (!ClientState.spectating) {
            return;
        }
        int screenW = mc.getWindow().getGuiScaledWidth();

        if (ClientState.spectateTarget != null) {
            Component label = Component.translatable("ts.spectate.target", ClientState.spectateTargetName);
            gui.drawCenteredString(mc.font, label, screenW / 2, 12, 0xFFFFFFFF);
        }

        List<S2CRoundUpdatePacket.Entry> entries = ClientState.ROUNDS.get(ClientState.spectateRegion);
        if (entries == null || entries.isEmpty()) {
            return;
        }
        int x = screenW - MARGIN - AVATAR;
        int y = MARGIN;
        for (S2CRoundUpdatePacket.Entry entry : entries) {
            PlayerFaceRenderer.draw(gui, skinOf(mc, entry.uuid(), entry.name()), x, y, AVATAR);
            drawDot(gui, x + AVATAR - 6, y + AVATAR - 6, entry.alive() ? GREEN : RED);
            y += AVATAR + 2;
        }
    }

    /** 头像加载失败（或玩家离线、皮肤未缓存）时退回默认皮肤，不会抛异常 */
    private static ResourceLocation skinOf(Minecraft mc, UUID uuid, String name) {
        try {
            ClientPacketListener connection = mc.getConnection();
            PlayerInfo info = connection == null ? null : connection.getPlayerInfo(uuid);
            GameProfile profile = info != null && info.getProfile() != null
                    ? info.getProfile()
                    : new GameProfile(uuid, name);
            return mc.getSkinManager().getInsecureSkinLocation(profile);
        } catch (RuntimeException e) {
            return DefaultPlayerSkin.getDefaultSkin(uuid);
        }
    }

    /** 5x5 圆形状态点 */
    private static void drawDot(GuiGraphics gui, int x, int y, int color) {
        gui.fill(x + 1, y, x + 4, y + 1, color);
        gui.fill(x, y + 1, x + 5, y + 4, color);
        gui.fill(x + 1, y + 4, x + 4, y + 5, color);
    }

    private HudRenderer() {
    }
}
