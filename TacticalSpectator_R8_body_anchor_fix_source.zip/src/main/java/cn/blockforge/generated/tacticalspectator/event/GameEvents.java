package cn.blockforge.generated.tacticalspectator.event;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.command.TsCommand;
import cn.blockforge.generated.tacticalspectator.net.packet.C2STabletActionPacket;
import cn.blockforge.generated.tacticalspectator.round.RoundService;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 服务端生命周期与玩家状态事件 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID)
public final class GameEvents {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        TsCommand.register(event.getDispatcher());
    }

    /**
     * 手持平板右键方块时不触发方块交互（箱子、门等），让右键落到平板的 use()：进入 / 退出观战。
     * 客户端与服务端两侧同时生效，预测一致。
     */
    @SubscribeEvent
    public static void onRightClickBlockWithTablet(PlayerInteractEvent.RightClickBlock event) {
        if (event.getItemStack().is(ModItems.TACTICAL_TABLET.get())) {
            event.setUseBlock(Event.Result.DENY);
        }
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        RoundService.bind(event.getServer());
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.getServer() != null) {
            RoundService.onServerTick(event.getServer());
        }
    }

    /**
     * LOWEST：其他模组（不死图腾等）取消了死亡事件时我们会被跳过，不会把没死的玩家误记为淘汰。
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            RoundService.onDeath(sp);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            RoundService.onRespawn(sp);
        }
    }

    @SubscribeEvent
    public static void onLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            RoundService.onLogin(sp);
            WandEvents.clearSelection(sp);
        }
    }

    @SubscribeEvent
    public static void onLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            RoundService.onLogout(sp);
            C2STabletActionPacket.onLogout(sp);
            cn.blockforge.generated.tacticalspectator.region.WandSelections.clear(sp.getUUID());
        }
    }

    /** 切换维度：选区预览作废；若是外部（别的模组）传走了观战者，观战随之结束 */
    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            SpectateService.onDimensionChanged(sp);
            WandEvents.clearSelection(sp);
        }
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target) {
            SpectateService.onTracking(viewer, target, true);
        }
    }

    @SubscribeEvent
    public static void onStopTracking(PlayerEvent.StopTracking event) {
        if (event.getEntity() instanceof ServerPlayer viewer && event.getTarget() instanceof ServerPlayer target) {
            SpectateService.onTracking(viewer, target, false);
        }
    }

    /** 关服前先把所有观战者放回原位置 / 原游戏模式，保证玩家数据不会以“锚定状态”被保存 */
    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        SpectateService.stopAll(event.getServer());
        cn.blockforge.generated.tacticalspectator.region.WandSelections.clearAll();
    }

    /** 世界已保存完毕后再解除绑定（回合数据由 RoundStore 随存档保存，不会因关服被清空） */
    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        RoundService.unbind();
        SpectateService.clear();
    }

    private GameEvents() {
    }
}
