package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** 客户端缓存的观战 / HUD / 选区状态（全部来自服务端同步，客户端不自行推断） */
public final class ClientState {

    /** 木棍选区预览（服务端确认后的数据，只用于渲染） */
    public static BlockPos selA;
    public static BlockPos selB;
    public static ResourceLocation selDim;

    /** 我是否处于观战状态（服务端 S2CSpectateModePacket 设置） */
    public static boolean spectating;
    /** 正在观战的区域 ID；HUD 只显示这个区域的名单 */
    public static long spectateRegion = -1L;
    public static UUID spectateTarget;
    public static String spectateTargetName = "";

    /** 我能看到的回合名单：regionId -> 条目（保持加入顺序）。服务端只发与我相关的回合 */
    public static final Map<Long, List<S2CRoundUpdatePacket.Entry>> ROUNDS = new LinkedHashMap<>();

    public static boolean isEliminated(UUID uuid) {
        return ROUNDS.values().stream().flatMap(List::stream)
                .anyMatch(entry -> entry.uuid().equals(uuid) && !entry.alive());
    }

    public static void applyRound(long regionId, List<S2CRoundUpdatePacket.Entry> entries) {
        if (entries.isEmpty()) {
            ROUNDS.remove(regionId);
        } else {
            ROUNDS.put(regionId, entries);
        }
    }

    public static void applySpectate(boolean on, long regionId, UUID target, String targetName) {
        spectating = on;
        if (on) {
            spectateRegion = regionId;
            spectateTarget = target;
            spectateTargetName = targetName == null ? "" : targetName;
        } else {
            spectateRegion = -1L;
            spectateTarget = null;
            spectateTargetName = "";
        }
    }

    public static void applyWandSelection(ResourceLocation dim, BlockPos a, BlockPos b) {
        selDim = dim;
        selA = dim == null ? null : a;
        selB = dim == null ? null : b;
    }

    /** 选区完整时的世界坐标包围盒（含整个方块） */
    public static AABB selectionBox() {
        if (selA == null || selB == null) {
            return null;
        }
        int minX = Math.min(selA.getX(), selB.getX());
        int minY = Math.min(selA.getY(), selB.getY());
        int minZ = Math.min(selA.getZ(), selB.getZ());
        int maxX = Math.max(selA.getX(), selB.getX()) + 1;
        int maxY = Math.max(selA.getY(), selB.getY()) + 1;
        int maxZ = Math.max(selA.getZ(), selB.getZ()) + 1;
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    public static void clear() {
        selA = null;
        selB = null;
        selDim = null;
        applySpectate(false, -1L, null, "");
        ROUNDS.clear();
    }

    private ClientState() {
    }
}
