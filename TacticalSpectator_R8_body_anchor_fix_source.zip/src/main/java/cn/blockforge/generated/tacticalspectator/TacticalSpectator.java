package cn.blockforge.generated.tacticalspectator;

import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Tactical Spectator - 战术观战模组。
 *
 * 模块划分：
 *  - region   区域（木棍选区 + 多区域持久化管理）
 *  - round    回合与参战名单（踏入区域自动加入）
 *  - spectate 战术平板观战（随机首目标，A/D 循环切换）
 *  - client   HUD 圆点列表、选区边界渲染、按键拦截
 *  - net      客户端/服务端同步
 */
@Mod(TacticalSpectator.MOD_ID)
public final class TacticalSpectator {
    public static final String MOD_ID = "tactical_spectator";

    public TacticalSpectator() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModNetwork.init();
    }
}
