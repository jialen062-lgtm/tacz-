package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.round.RoundService;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * 战术平板的客户端请求（全部由服务端再次校验，客户端只能“请求”）：
 *  EQUIP         长按 F：把背包里已有的平板换到手上（只对本轮已淘汰的玩家有效，不发放新物品）；
 *                这个操作本身永远不会进入观战，进入观战只能手持平板右键。
 *  STOW          平板收回动画结束后：把平板换回之前的物品；观战中则一并退出观战；
 *  EXIT_SPECTATE 观战中右键 / 长按 F：立即退出观战。
 */
public record C2STabletActionPacket(byte action) {
    public static final byte EQUIP = 0;
    public static final byte STOW = 1;
    public static final byte EXIT_SPECTATE = 2;

    private static final int ACTION_COOLDOWN_TICKS = 4;
    /** 玩家 -> 平板被换上来之前所在的背包格（-1 = 副手），用于收回时换回去 */
    private static final Map<UUID, Integer> SWAPPED_FROM = new HashMap<>();
    private static final Map<UUID, Integer> LAST_ACTION = new HashMap<>();

    public static void encode(C2STabletActionPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.action);
    }

    public static C2STabletActionPacket decode(FriendlyByteBuf buf) {
        return new C2STabletActionPacket(buf.readByte());
    }

    public static void handle(C2STabletActionPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null || (msg.action != EQUIP && msg.action != STOW && msg.action != EXIT_SPECTATE)) {
                return;
            }
            int now = player.tickCount;
            Integer last = LAST_ACTION.get(player.getUUID());
            if (last != null && now >= last && now - last < ACTION_COOLDOWN_TICKS) {
                return;
            }
            LAST_ACTION.put(player.getUUID(), now);
            switch (msg.action) {
                case EXIT_SPECTATE -> SpectateService.stopFor(player, "ts.spectate.stopped");
                case STOW -> {
                    SpectateService.stopFor(player, "ts.spectate.stopped");
                    stow(player);
                }
                case EQUIP -> {
                    if (player.isAlive() && !player.isSpectator() && !SpectateService.isActive(player)
                            && RoundService.isEliminated(player.getUUID())) {
                        equip(player);
                    }
                }
                default -> {
                }
            }
        });
        ctx.setPacketHandled(true);
    }

    public static void onLogout(ServerPlayer player) {
        SWAPPED_FROM.remove(player.getUUID());
        LAST_ACTION.remove(player.getUUID());
    }

    private static void equip(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        if (inventory.getSelected().is(ModItems.TACTICAL_TABLET.get())) {
            return;
        }
        for (int slot = 0; slot < inventory.items.size(); slot++) {
            if (inventory.getItem(slot).is(ModItems.TACTICAL_TABLET.get())) {
                ItemStack tablet = inventory.getItem(slot);
                inventory.setItem(slot, inventory.getSelected());
                inventory.setItem(inventory.selected, tablet);
                SWAPPED_FROM.put(player.getUUID(), slot);
                player.containerMenu.broadcastChanges();
                return;
            }
        }
        if (player.getOffhandItem().is(ModItems.TACTICAL_TABLET.get())) {
            ItemStack tablet = player.getOffhandItem();
            player.setItemInHand(InteractionHand.OFF_HAND, inventory.getSelected());
            inventory.setItem(inventory.selected, tablet);
            SWAPPED_FROM.put(player.getUUID(), -1);
            player.containerMenu.broadcastChanges();
            return;
        }
        player.displayClientMessage(Component.translatable("ts.tablet.missing"), true);
    }

    /** 把手里的平板换回被它顶掉的物品；没有记录（平板是玩家自己选中的）时不动背包 */
    private static void stow(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        if (!inventory.getSelected().is(ModItems.TACTICAL_TABLET.get())) {
            SWAPPED_FROM.remove(player.getUUID());
            return;
        }
        Integer slot = SWAPPED_FROM.remove(player.getUUID());
        if (slot == null) {
            return;
        }
        ItemStack tablet = inventory.getSelected();
        if (slot == -1) {
            ItemStack previous = player.getOffhandItem();
            player.setItemInHand(InteractionHand.OFF_HAND, tablet);
            inventory.setItem(inventory.selected, previous);
        } else if (slot >= 0 && slot < inventory.items.size() && slot != inventory.selected) {
            ItemStack previous = inventory.getItem(slot);
            inventory.setItem(slot, tablet);
            inventory.setItem(inventory.selected, previous);
        } else {
            return;
        }
        player.containerMenu.broadcastChanges();
    }
}
