package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SWandPointPacket;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 客户端侧的木棍点选：把点击的方块坐标转发给服务端
 * （点击被取消后原版不会发包，必须走自定义通道）。
 * 边框预览不在这里本地设置，而是等服务端校验通过后通过 S2CWandSelectionPacket 同步回来。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class ClientWandEvents {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (!event.getLevel().isClientSide()
                || !event.getItemStack().is(Items.STICK)
                || event.getEntity().isSpectator()) {
            return;
        }
        if (event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START) {
            return;
        }
        ModNetwork.CHANNEL.sendToServer(new C2SWandPointPacket(1, event.getPos()));
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getLevel().isClientSide()
                || !event.getItemStack().is(Items.STICK)
                || event.getEntity().isSpectator()) {
            return;
        }
        ModNetwork.CHANNEL.sendToServer(new C2SWandPointPacket(2, event.getPos()));
    }

    private ClientWandEvents() {
    }
}
