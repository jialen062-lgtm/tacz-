package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.client.ClientRx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/**
 * 通知客户端“我是否处于观战状态、正在观战哪个区域的哪位玩家”。
 * 客户端据此：冻结移动输入、响应 A/D、只显示该区域的名单 HUD、显示“正在观战（玩家 ID）”。
 * 每次切换目标都会重发一次，所以 HUD 文字与服务端目标始终一致。
 */
public final class S2CSpectateModePacket {
    public final boolean on;
    public final long regionId;
    /** 当前目标；on=false 时为 null */
    public final UUID target;
    public final String targetName;

    public S2CSpectateModePacket(boolean on, long regionId, UUID target, String targetName) {
        this.on = on;
        this.regionId = regionId;
        this.target = target;
        this.targetName = targetName == null ? "" : targetName;
    }

    public static void encode(S2CSpectateModePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.on);
        buf.writeLong(msg.regionId);
        boolean hasTarget = msg.target != null;
        buf.writeBoolean(hasTarget);
        if (hasTarget) {
            buf.writeUUID(msg.target);
        }
        buf.writeUtf(msg.targetName, 32);
    }

    public static S2CSpectateModePacket decode(FriendlyByteBuf buf) {
        boolean on = buf.readBoolean();
        long regionId = buf.readLong();
        UUID target = buf.readBoolean() ? buf.readUUID() : null;
        String name = buf.readUtf(32);
        return new S2CSpectateModePacket(on, regionId, target, name);
    }

    public static void handle(S2CSpectateModePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRx.applySpectateMode(msg.on, msg.regionId, msg.target, msg.targetName)));
        ctx.setPacketHandled(true);
    }
}
