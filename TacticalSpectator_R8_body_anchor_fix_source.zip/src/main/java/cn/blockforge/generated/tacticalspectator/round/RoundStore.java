package cn.blockforge.generated.tacticalspectator.round;

import com.mojang.logging.LogUtils;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import org.slf4j.Logger;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 回合名单持久化（SavedData，写进世界存档）。
 * 服务器重启后，已淘汰 / 存活的身份仍然保留；回合结束（无人存活）或区域被删除时清除。
 * 数据由本对象自己持有，不依赖任何会在 ServerStopping 时被清空的静态字段。
 */
public final class RoundStore extends SavedData {
    public static final String DATA_NAME = "tactical_spectator_rounds";
    private static final Logger LOGGER = LogUtils.getLogger();

    /** key = 区域 ID */
    public final Map<Long, Round> rounds = new LinkedHashMap<>();

    public static RoundStore get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(RoundStore::load, RoundStore::new, DATA_NAME);
    }

    public static RoundStore load(CompoundTag tag) {
        RoundStore store = new RoundStore();
        ListTag list = tag.getList("rounds", Tag.TAG_COMPOUND);
        Set<UUID> seen = new HashSet<>();
        for (int i = 0; i < list.size(); i++) {
            try {
                Round round = Round.fromTag(list.getCompound(i));
                // 同一玩家只允许出现在一个回合里（异常存档兜底：保留第一次出现）
                round.participants.keySet().removeIf(id -> !seen.add(id));
                if (!round.participants.isEmpty()) {
                    store.rounds.put(round.regionId, round);
                }
            } catch (Exception e) {
                LOGGER.warn("[TacticalSpectator] Skipping unreadable round entry #{}", i, e);
            }
        }
        return store;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Round round : rounds.values()) {
            list.add(round.toTag());
        }
        tag.put("rounds", list);
        return tag;
    }
}
