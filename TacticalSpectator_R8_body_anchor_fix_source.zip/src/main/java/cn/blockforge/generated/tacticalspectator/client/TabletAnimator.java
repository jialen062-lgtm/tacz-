package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.C2STabletActionPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/**
 * 战术平板第一人称动画状态机（纯客户端，不依赖 TaCZ 的任何接口）。
 *
 *   NONE     未持有：主手没有平板
 *   DRAWING  掏出中：先等待 DRAW_DELAY_TICKS（平板在画面下方不可见，给原来手里的枪退出视野的时间），
 *            再用 DRAW_TICKS 从画面下方抬起到持有位置
 *   HOLDING  持有中：稳定保持
 *   STOWING  收回中：STOW_TICKS 内降回画面下方；降完后向服务端发送 STOW，服务端把平板换回原物品
 *
 * 为什么不直接播放 TaCZ 的枪械动画：TaCZ 的动画状态机只作用于它自己的枪械物品，
 * 并没有给普通物品开放的“播放任意第一人称动画”的接口；平板是普通 Item，所以这里自己驱动，
 * 由 TabletHandRenderer 在 RenderHandEvent 里接管主手渲染。
 * 任何中断（切换物品、切换槽位、死亡、断线）都会把状态复位为 NONE，不会残留。
 */
public final class TabletAnimator {

    public enum State { NONE, DRAWING, HOLDING, STOWING }

    /** 等枪退出视野的时间（tick）。TaCZ 枪的收枪动画较长时可适当调大 */
    public static final int DRAW_DELAY_TICKS = 6;
    public static final int DRAW_TICKS = 10;
    public static final int STOW_TICKS = 8;
    private static final int STOW_CONFIRM_TIMEOUT = 20;

    private static State state = State.NONE;
    private static int ticks;
    private static boolean stowRequested;
    private static boolean stowSent;
    private static int lastSlot = -1;

    public static State state() {
        return state;
    }

    /** 长按 F：请求收回。观战中先退出观战，退出后才会真正开始收回动画 */
    public static void requestStow() {
        stowRequested = true;
    }

    public static void reset() {
        state = State.NONE;
        ticks = 0;
        stowRequested = false;
        stowSent = false;
        lastSlot = -1;
    }

    public static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || !player.isAlive()) {
            reset();
            return;
        }
        boolean holding = player.getMainHandItem().is(ModItems.TACTICAL_TABLET.get());
        int slot = player.getInventory().selected;
        if (!holding || slot != lastSlot) {
            // 物品被切走、槽位变化：动画中断并复位
            if (state != State.NONE || stowRequested || stowSent) {
                reset();
            }
            lastSlot = slot;
            if (!holding) {
                return;
            }
        }
        switch (state) {
            case NONE -> {
                state = State.DRAWING;
                ticks = 0;
            }
            case DRAWING -> {
                ticks++;
                if (ticks >= DRAW_DELAY_TICKS + DRAW_TICKS) {
                    state = State.HOLDING;
                    ticks = 0;
                }
            }
            case HOLDING -> {
                if (stowRequested && !ClientState.spectating) {
                    state = State.STOWING;
                    ticks = 0;
                    stowRequested = false;
                    stowSent = false;
                }
            }
            case STOWING -> {
                ticks++;
                if (!stowSent && ticks >= STOW_TICKS) {
                    ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(C2STabletActionPacket.STOW));
                    stowSent = true;
                } else if (stowSent && ticks >= STOW_TICKS + STOW_CONFIRM_TIMEOUT) {
                    // 服务端没有把平板换走（例如平板本来就是玩家自己选中的）：重新抬起，避免平板一直隐身
                    state = State.DRAWING;
                    ticks = DRAW_DELAY_TICKS;
                    stowSent = false;
                }
            }
        }
    }

    /** 0 = 完全在画面下方（不可见），1 = 持有位置。已含缓动 */
    public static float visibility(float partialTick) {
        switch (state) {
            case DRAWING: {
                float t = (ticks + partialTick - DRAW_DELAY_TICKS) / DRAW_TICKS;
                return easeOutCubic(clamp01(t));
            }
            case HOLDING:
                return 1.0F;
            case STOWING: {
                if (stowSent) {
                    return 0.0F;
                }
                float t = (ticks + partialTick) / STOW_TICKS;
                return 1.0F - easeInCubic(clamp01(t));
            }
            default:
                return 0.0F;
        }
    }

    private static float clamp01(float v) {
        return v < 0.0F ? 0.0F : Math.min(v, 1.0F);
    }

    private static float easeOutCubic(float t) {
        float u = 1.0F - t;
        return 1.0F - u * u * u;
    }

    private static float easeInCubic(float t) {
        return t * t * t;
    }

    private TabletAnimator() {
    }
}
