package cn.blockforge.generated.tacticalspectator;

import cn.blockforge.generated.tacticalspectator.item.TacticalTabletItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TacticalSpectator.MOD_ID);

    /** 战术平板：观战入口物品，模型来自用户提供的 bbmodel 转换结果 */
    public static final RegistryObject<Item> TACTICAL_TABLET =
            ITEMS.register("tactical_tablet", TacticalTabletItem::new);

    private ModItems() {
    }
}
