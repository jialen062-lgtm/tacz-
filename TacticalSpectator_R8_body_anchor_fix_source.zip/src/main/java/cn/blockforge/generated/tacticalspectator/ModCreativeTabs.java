package cn.blockforge.generated.tacticalspectator;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 把战术平板加入原版“工具与效用”创造模式标签页 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModCreativeTabs {

    @SubscribeEvent
    public static void onBuildContents(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.TACTICAL_TABLET.get());
        }
    }

    private ModCreativeTabs() {
    }
}
