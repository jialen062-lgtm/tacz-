package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.client.ClientRx;
import io.netty.handler.codec.DecoderException;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * 回合名单同步：只发给与该回合相关的观众（参战者 + 正在观战该区域的人），
 * 保证不同区域互不串数据。空列表 = 通知客户端移除该回合（隐藏 HUD）。
 */
public final class S2CRoundUpdatePacket {
    /** 单个回合名单的条目上限；超过视为异常数据包 */
    public static final int MAX_ENTRIES = 256;

    public record Entry(UUID uuid, String name, boolean alive) {
    }

    public final long regionId;
    public final List<Entry> entries;

    public S2CRoundUpdatePacket(long regionId, List<Entry> entries) {
        this.regionId = regionId;
        this.entries = entries;
    }

    public static void encode(S2CRoundUpdatePacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.regionId);
        int size = Math.min(msg.entries.size(), MAX_ENTRIES);
        buf.writeVarInt(size);
        for (int i = 0; i < size; i++) {
            Entry e = msg.entries.get(i);
            buf.writeUUID(e.uuid());
            buf.writeUtf(e.name(), 32);
            buf.writeBoolean(e.alive());
        }
    }

    public static S2CRoundUpdatePacket decode(FriendlyByteBuf buf) {
        long region = buf.readLong();
        int size = buf.readVarInt();
        if (size < 0 || size > MAX_ENTRIES) {
            throw new DecoderException("Tactical Spectator: invalid round entry count " + size);
        }
        List<Entry> entries = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            entries.add(new Entry(buf.readUUID(), buf.readUtf(32), buf.readBoolean()));
        }
        return new S2CRoundUpdatePacket(region, entries);
    }

    public static void handle(S2CRoundUpdatePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRx.applyRoundUpdate(msg.regionId, msg.entries)));
        ctx.setPacketHandled(true);
    }
}
