package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenPanelPacket;

/**
 * “军需官”标记：哪只 NPC 是你用魔杖点过、会提供装备的 NPC。
 *
 * <p>标记存在实体自己的持久数据里（{@code ForgeData}），会跟存档一起保存，
 * 所以重启游戏、重新加载区块之后这个 NPC 仍然是军需官。</p>
 */
public final class QuartermasterService {

    /** 标记用的 NBT 键，带模组前缀，避免和别的模组撞车。 */
    public static final String TAG_QUARTERMASTER = "tacz_cnpc_alert.quartermaster";

    /**
     * 一次右键可能同时走到两条路上（客户端发来的包 + 服务端自己的实体交互事件），
     * 这里记一下“这一 tick 谁点过谁”，同一 tick 里的第二次直接丢掉，
     * 免得一次右键被处理两遍（先标记再打开面板、或者潜行取消之后又被重新标记）。
     */
    private static final java.util.Map<String, Long> RECENT_USES = new java.util.HashMap<>();

    private QuartermasterService() {
    }

    public static boolean isQuartermaster(Entity entity) {
        return entity != null && entity.getPersistentData().getBoolean(TAG_QUARTERMASTER);
    }

    public static void setQuartermaster(Entity entity, boolean value) {
        if (entity == null) {
            return;
        }
        if (value) {
            entity.getPersistentData().putBoolean(TAG_QUARTERMASTER, true);
        } else {
            entity.getPersistentData().remove(TAG_QUARTERMASTER);
        }
    }

    /** NPC 死亡时清掉标记，免得同一个实体被复用时误判。 */
    public static void clear(LivingEntity entity) {
        if (entity != null) {
            entity.getPersistentData().remove(TAG_QUARTERMASTER);
        }
    }

    /**
     * 玩家拿魔杖右键了一个 NPC。客户端和服务端都会走这里，所以放在一个地方，避免两边规则写岔。
     *
     * @return 是否消耗了这次右键
     */
    public static boolean handleWandUse(ServerPlayer player, LivingEntity npc, boolean sneaking) {
        if (player == null || npc == null || !npc.isAlive()) {
            return false;
        }
        if (isDuplicateClick(player, npc)) {
            return true;
        }
        if (player.distanceToSqr(npc) > 64.0D) {
            player.displayClientMessage(Component.literal("离得太远了，走近一点再用魔杖。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }
        if (!AlertService.isNpcType(npc)) {
            player.displayClientMessage(Component.literal("这不是 NPC，魔杖对它没用。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }

        // 客户端发来的包带着点击那一刻的潜行状态，服务端自己也知道玩家有没有蹲着；
        // 任何一边说是潜行就按潜行处理，避免移动端的蹲下开关和服务端不同步。
        boolean sneak = sneaking || player.isShiftKeyDown();

        if (sneak) {
            if (isQuartermaster(npc)) {
                setQuartermaster(npc, false);
                player.displayClientMessage(Component.literal("已取消这个 NPC 的军需官身份。")
                        .withStyle(ChatFormatting.YELLOW), true);
            } else {
                player.displayClientMessage(Component.literal("这个 NPC 还不是军需官。")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return true;
        }

        if (!isQuartermaster(npc)) {
            setQuartermaster(npc, true);
            player.displayClientMessage(Component.literal(
                    "这个 NPC 现在是军需官了，再右键一次就能打开配装面板。")
                    .withStyle(ChatFormatting.AQUA), true);
            celebrate(player, npc);
            return true;
        }

        openPanel(player, npc);
        return true;
    }

    /** 把配装面板开给这个玩家：所有清单都在服务端算好再一起发过去。 */
    public static void openPanel(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null) {
            return;
        }
        ModNetwork.sendToPlayer(new OpenPanelPacket(npc.getId(), equipmentIds(), gunIds(), ammoIds(),
                meleeIds(), throwableIds(), attachmentMap()), player);
    }

    /** 空手右键军需官时走这里：同一次点击只开一次面板。 */
    public static void openPanelFromClick(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null || isDuplicateClick(player, npc)) {
            return;
        }
        openPanel(player, npc);
    }

    /**
     * 同一次右键会不会被处理第二遍。
     *
     * @return true 表示这一 tick 里已经处理过同一个人对同一个 NPC 的右键，本次跳过
     */
    private static boolean isDuplicateClick(ServerPlayer player, LivingEntity npc) {
        long now = player.level().getGameTime();
        String key = player.getUUID() + ":" + npc.getId();
        Long last = RECENT_USES.get(key);
        if (last != null && last == now) {
            return true;
        }
        RECENT_USES.put(key, now);
        if (RECENT_USES.size() > 256) {
            RECENT_USES.clear();
        }
        return false;
    }

    private static java.util.List<String> equipmentIds() {
        return MilitaryGearCatalog.equipmentIds().stream().map(ResourceLocation::toString).toList();
    }

    private static java.util.List<String> gunIds() {
        return TaczCompat.allGunIds().stream().map(ResourceLocation::toString).toList();
    }

    private static java.util.List<String> ammoIds() {
        return TaczCompat.allAmmoIds().stream().map(ResourceLocation::toString).toList();
    }

    private static java.util.List<String> meleeIds() {
        return WeaponCatalog.meleeIds().stream().map(ResourceLocation::toString).toList();
    }

    private static java.util.List<String> throwableIds() {
        return WeaponCatalog.throwableIds().stream().map(ResourceLocation::toString).toList();
    }

    private static java.util.Map<String, java.util.List<String>> attachmentMap() {
        java.util.Map<String, java.util.List<String>> map = new java.util.LinkedHashMap<>();
        TaczCompat.attachmentsBySlot().forEach((slot, ids) ->
                map.put(slot, ids.stream().map(ResourceLocation::toString).toList()));
        return map;
    }

    /** 把 NPC 变成军需官时的小小庆祝：头顶冒几个感叹号、响一声。 */
    public static void celebrate(Player player, LivingEntity npc) {
        if (!(npc.level() instanceof ServerLevel level)) {
            return;
        }
        level.sendParticles(ModRegistry.EXCLAIM.get(),
                npc.getX(), npc.getY() + npc.getBbHeight() + 0.5D, npc.getZ(),
                8, 0.35D, 0.35D, 0.35D, 0.01D);
        level.playSound(null, npc.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                SoundSource.NEUTRAL, 0.55F, 1.5F);
    }
}
