package cn.blockforge.generated.taczcnpcalert;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * NPC 地图魔杖。
 *
 * <p>外观直接使用原版钻石镐。拿它右键一个普通 NPC，可以把这个 NPC 设成警长；
 * 之后再用地图魔杖右键，或者空手右键警长，都会打开副本选择面板。
 * 具体的实体交互由 {@link MapWandEvents} 接管，避免 CustomNPCs 自己先弹出对话。</p>
 */
public class MapWandItem extends Item {

    public MapWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            player.displayClientMessage(Component.literal(
                    "拿着地图魔杖右键一个 NPC，把它变成警长；空手右键警长即可选择副本。")
                    .withStyle(ChatFormatting.AQUA), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键 NPC：变成警长").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("右键警长：打开副本面板").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("空手右键警长：也能选择副本").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("潜行右键警长：取消警长").withStyle(ChatFormatting.DARK_GRAY));
    }
}
