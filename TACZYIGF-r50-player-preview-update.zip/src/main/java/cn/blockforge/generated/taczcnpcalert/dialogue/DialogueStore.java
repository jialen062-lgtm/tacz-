package cn.blockforge.generated.taczcnpcalert.dialogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

/**
 * 对话脚本的存放处。
 *
 * <p>脚本以 JSON 字符串保存在 NPC 实体自己的持久化数据（ForgeData）里，
 * NPC 被存盘、重载都不会丢。结构：
 * <pre>
 * {"nodes":[
 *   {"lines":["NPC 台词1","NPC 台词2"],
 *    "options":[{"text":"玩家选项","target":1}]}
 * ]}
 * </pre>
 * 节点 0 是开场；一个节点先按顺序播 lines，播完如果有 options 就轮到玩家选，
 * 选完跳到 target 节点继续；没有 options 就对话结束。</p>
 */
public final class DialogueStore {

    /** 存在 NPC 持久化数据里的标签名。 */
    public static final String TAG = "CnpcDialogueScript";
    /** 脚本最多允许的节点数。 */
    public static final int MAX_NODES = 100;
    /** 单条台词/选项的最大字数。 */
    public static final int MAX_TEXT = 160;

    private DialogueStore() {
    }

    public static String read(Entity npc) {
        return npc.getPersistentData().getString(TAG);
    }

    public static void write(Entity npc, String json) {
        CompoundTag data = npc.getPersistentData();
        if (json == null || json.isEmpty()) {
            data.remove(TAG);
        } else {
            data.putString(TAG, json);
        }
    }

    /** 解析脚本 JSON；不合法或为空返回 null。 */
    public static JsonObject parse(String json) {
        if (json == null || json.isBlank()) {
            return null;
        }
        try {
            JsonElement el = JsonParser.parseString(json);
            if (el.isJsonObject() && el.getAsJsonObject().has("nodes")) {
                return el.getAsJsonObject();
            }
        } catch (Exception ignored) {
            // 坏数据当没脚本处理
        }
        return null;
    }

    public static JsonObject emptyScript() {
        JsonObject root = new JsonObject();
        root.add("nodes", new JsonArray());
        return root;
    }

    public static JsonArray nodes(JsonObject script) {
        JsonElement el = script.get("nodes");
        if (el != null && el.isJsonArray()) {
            return el.getAsJsonArray();
        }
        JsonArray arr = new JsonArray();
        script.add("nodes", arr);
        return arr;
    }

    /** 取得第 index 个节点，不足则自动补齐空节点。 */
    public static JsonObject getOrCreateNode(JsonArray nodes, int index) {
        while (nodes.size() <= index) {
            nodes.add(newNode());
        }
        JsonElement el = nodes.get(index);
        if (el.isJsonObject()) {
            JsonObject node = el.getAsJsonObject();
            if (!node.has("lines") || !node.get("lines").isJsonArray()) {
                node.add("lines", new JsonArray());
            }
            if (!node.has("options") || !node.get("options").isJsonArray()) {
                node.add("options", new JsonArray());
            }
            return node;
        }
        JsonObject replacement = newNode();
        nodes.set(index, replacement);
        return replacement;
    }

    private static JsonObject newNode() {
        JsonObject node = new JsonObject();
        node.add("lines", new JsonArray());
        node.add("options", new JsonArray());
        return node;
    }

    public static JsonArray linesOf(JsonObject node) {
        return node.getAsJsonArray("lines");
    }

    public static JsonArray optionsOf(JsonObject node) {
        return node.getAsJsonArray("options");
    }

    /** 给节点加一句 NPC 台词。 */
    public static void addLine(JsonObject script, int nodeIndex, String text) {
        JsonObject node = getOrCreateNode(nodes(script), nodeIndex);
        linesOf(node).add(text);
    }

    /** 给节点加一个玩家选项，选了之后跳到 target 节点。 */
    public static void addOption(JsonObject script, int nodeIndex, String text, int target) {
        JsonObject node = getOrCreateNode(nodes(script), nodeIndex);
        JsonObject option = new JsonObject();
        option.addProperty("text", text);
        option.addProperty("target", target);
        optionsOf(node).add(option);
    }

    public static String toJson(JsonObject script) {
        return script.toString();
    }
}
