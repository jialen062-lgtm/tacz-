package cn.blockforge.generated.taczcnpcalert;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * NPC 界面魔杖。
 *
 * <p>它长得像一把钻石铲，本身没有左键攻击力。真正的逻辑在 {@link GearWandEvents}：
 * 右键 CNPC 的 NPC 会把这个 NPC 标记成“军需官”，之后右键军需官就会弹出配装面板。</p>
 *
 * <p>这里只负责“右键空气时提示怎么用”，免得玩家拿着魔杖不知道干什么。</p>
 */
public class GearWandItem extends Item {

    public GearWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            player.displayClientMessage(Component.literal(
                    "拿着魔杖右键一个 NPC，把它变成军需官；之后用魔杖或空手右键它都能打开配装面板。")
                    .withStyle(ChatFormatting.AQUA), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键 NPC：变成军需官").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("右键军需官：打开配装面板").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("空手右键军需官：也能打开面板").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("潜行右键军需官：取消军需官").withStyle(ChatFormatting.DARK_GRAY));
    }
}
