package cn.blockforge.generated.taczcnpcalert.dialogue;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.net.DialogueWandInteractPacket;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenDialoguePacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** 对话魔杖 / 对话编辑魔杖的实体交互入口。 */
public final class DialogueWandEvents {

    private DialogueWandEvents() {
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        handleWand(event, event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handleWand(event, event.getTarget());
    }

    private static void handleWand(PlayerInteractEvent event, Entity target) {
        ItemStack stack = event.getItemStack();
        boolean dialogue = stack.is(ModRegistry.DIALOGUE_WAND.get());
        boolean editing = stack.is(ModRegistry.DIALOGUE_EDIT_WAND.get());
        if (!dialogue && !editing) {
            return;
        }
        if (!(target instanceof LivingEntity living) || !AlertService.isNpcType(living)) {
            return;
        }

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getEntity().level().isClientSide()) {
            ModNetwork.sendToServer(new DialogueWandInteractPacket(target.getId(), editing));
        } else if (event.getEntity() instanceof ServerPlayer player) {
            use(player, living, editing);
        }
    }

    /** 服务端：真正执行右键动作。 */
    public static void use(ServerPlayer player, LivingEntity npc, boolean editing) {
        if (editing) {
            DialogueEditService.toggle(player, npc);
            return;
        }
        String json = DialogueStore.read(npc);
        if (DialogueStore.parse(json) == null) {
            player.displayClientMessage(Component.literal(
                    "这个 NPC 还没有对话脚本。拿“对话编辑魔杖”右键它开始编写，聊天框输入 #帮助 看命令。")
                    .withStyle(ChatFormatting.YELLOW), false);
            return;
        }
        ModNetwork.sendToPlayer(new OpenDialoguePacket(npc.getId(), npc.getName().getString(), json), player);
    }
}
