package cn.blockforge.generated.taczcnpcalert;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * 与绿葡萄战术攻防（lrtactical）的可选兼容层。
 *
 * <p>该模组的刀具和投掷物不是逐个注册成物品，而是共用 lrtactical:melee / throwable
 * 基础物品，并通过数据索引 ID 区分。因此不能用 ForgeRegistries.ITEMS 查找
 * lrtactical:dagger 这类索引 ID；这里通过反射读取索引并调用 createItemStack()。</p>
 *
 * <p>全程反射，不把 lrtactical 设为硬依赖；未安装时返回空列表 / 空物品。</p>
 */
public final class LrtacticalCompat {
    private static final String PROVIDER_CLASS = "me.xjqsh.lrtactical.resource.CommonAssetsManager";
    private static final String INTERFACE_CLASS = "me.xjqsh.lrtactical.resource.ICommonResourceProvider";

    private LrtacticalCompat() {
    }

    public static List<ResourceLocation> allMeleeIds() {
        return collect("getMeleeIndexes");
    }

    public static List<ResourceLocation> allThrowableIds() {
        return collect("getThrowableIndexes");
    }

    public static ItemStack buildMelee(ResourceLocation id) {
        return build("getMeleeIndex", id);
    }

    public static ItemStack buildThrowable(ResourceLocation id) {
        return build("getThrowableIndex", id);
    }

    private static List<ResourceLocation> collect(String collectionMethod) {
        Object provider = provider();
        if (provider == null) {
            return List.of();
        }
        try {
            Class<?> api = Class.forName(INTERFACE_CLASS);
            Object result = api.getMethod(collectionMethod).invoke(provider);
            if (!(result instanceof Collection<?> values)) {
                return List.of();
            }
            Map<String, ResourceLocation> unique = new LinkedHashMap<>();
            for (Object index : values) {
                ResourceLocation id = indexId(index);
                if (id != null && "lrtactical".equals(id.getNamespace())) {
                    unique.putIfAbsent(id.toString(), id);
                }
            }
            return List.copyOf(unique.values());
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return List.of();
        }
    }

    private static ItemStack build(String indexMethod, ResourceLocation id) {
        if (id == null || !"lrtactical".equals(id.getNamespace())) {
            return ItemStack.EMPTY;
        }
        Object provider = provider();
        if (provider == null) {
            return ItemStack.EMPTY;
        }
        try {
            Class<?> api = Class.forName(INTERFACE_CLASS);
            Object index = api.getMethod(indexMethod, ResourceLocation.class).invoke(provider, id);
            if (index == null) {
                return ItemStack.EMPTY;
            }
            Object stack = index.getClass().getMethod("createItemStack").invoke(index);
            return stack instanceof ItemStack itemStack ? itemStack : ItemStack.EMPTY;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return ItemStack.EMPTY;
        }
    }

    private static ResourceLocation indexId(Object index) {
        if (index == null) {
            return null;
        }
        try {
            Object id = index.getClass().getMethod("getId").invoke(index);
            return id instanceof ResourceLocation resourceLocation ? resourceLocation : null;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private static Object provider() {
        try {
            Class<?> owner = Class.forName(PROVIDER_CLASS);
            Method get = owner.getMethod("get");
            return get.invoke(null);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }
}
