package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.entity.SmokeCloudEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;

/**
 * NPC 的战场行为：远程投掷 + 烟雾致盲。
 *
 * <p>判定沿用本模组统一的“是不是 NPC”规则（CNPC 或配置命名空间里的生物）。满足条件时，
 * NPC 朝目标抛一颗雷；投掷走抛物线预瞄。雷的种类优先用 TaCZ 扩展包
 * （比如绿葡萄战术攻防）里的投掷物——由 {@link ThrowableLauncher} 借“假玩家”按玩家的方式扔出去；
 * 没有外部真实投掷物或无法使用时，本次不投掷，不生成自制替代品。</p>
 *
 * <p>烟雾致盲：只要目标站在烟雾区里、或 NPC 看向目标的视线穿过烟雾区，就清空当前目标，
 * 并在短时间内（默认 5 秒）拒绝重新索敌——表现就是“烟雾弹一响，NPC 找不到人打”。</p>
 */
public final class NpcThrowEvents {

    /** 下次允许投掷的 tick。 */
    private static final String TAG_NEXT_THROW = "tacz_cnpc_alert.next_throw";
    /** 烟雾致盲到哪个 tick 为止。 */
    private static final String TAG_BLIND_UNTIL = "tacz_cnpc_alert.blind_until";

    /** 扫描间隔：每 5 tick 检查一轮（≈0.25 秒，够用了，省性能）。 */
    private static final int SCAN_INTERVAL = 5;

    private NpcThrowEvents() {
    }

    /** 每维度 tick：处理投掷和“已有目标被烟雾挡住”的清空。 */
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.level.isClientSide()) {
            return;
        }
        if (!(event.level instanceof ServerLevel level)) {
            return;
        }
        long now = level.getGameTime();
        boolean throwEnabled = AlertConfig.NPC_THROW_ENABLED.get();
        if (now % (throwEnabled ? SCAN_INTERVAL : 40) != 0) {
            // 投掷开着每 5 tick 扫一轮；只处理烟雾时降到每 40 tick，省性能。
            return;
        }
        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof Mob mob && AlertService.isNpc(mob)) {
                handleNpc(level, mob, now);
            }
        }
    }

    private static void handleNpc(ServerLevel level, Mob mob, long now) {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive() || target == mob) {
            return;
        }
        if (smokeBlocks(level, mob, target)) {
            mob.setTarget(null);
            mob.getPersistentData().putLong(TAG_BLIND_UNTIL,
                    now + AlertConfig.SMOKE_BLIND_TICKS.get());
            return;
        }
        if (now < mob.getPersistentData().getLong(TAG_BLIND_UNTIL)) {
            return;
        }
        if (AlertConfig.NPC_THROW_ENABLED.get()) {
            maybeThrowGrenade(level, mob, target, now);
        }
    }

    /** 索敌事件兜底：致盲期内或视线被烟雾挡住时，直接把新目标掐掉。 */
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (!(event.getEntity() instanceof Mob mob) || !AlertService.isNpc(mob)) {
            return;
        }
        LivingEntity next = event.getNewTarget();
        if (next == null || mob.level().isClientSide()) {
            return;
        }
        long now = mob.level().getGameTime();
        if (now < mob.getPersistentData().getLong(TAG_BLIND_UNTIL)) {
            event.setNewTarget(null);
            return;
        }
        if (smokeBlocks((ServerLevel) mob.level(), mob, next)) {
            mob.getPersistentData().putLong(TAG_BLIND_UNTIL,
                    now + AlertConfig.SMOKE_BLIND_TICKS.get());
            event.setNewTarget(null);
        }
    }

    private static boolean smokeBlocks(ServerLevel level, Mob mob, LivingEntity target) {
        Vec3 from = mob.getEyePosition();
        Vec3 to = target.getEyePosition().subtract(0.0D, 0.35D, 0.0D);
        return SmokeCloudEntity.blocksSight(level, from, to);
    }

    private static void maybeThrowGrenade(ServerLevel level, Mob mob, LivingEntity target, long now) {
        throwGrenade(level, mob, target, now, null);
    }

    /**
     * 真正执行一次投掷。
     *
     * @param forcedSmoke 调试命令用：null = 正常随机；true/false = 无视冷却、距离和概率，
     *                    直接扔一颗烟雾弹 / 破片手雷。
     * @return 描述这一颗到底是什么（给命令回显用）；没扔返回 null。
     */
    public static String throwGrenade(ServerLevel level, Mob mob, LivingEntity target,
                                      long now, Boolean forcedSmoke) {
        boolean forced = forcedSmoke != null;
        if (!forced) {
            if (now < mob.getPersistentData().getLong(TAG_NEXT_THROW)) {
                return null;
            }
            double dist = mob.distanceTo(target);
            if (dist < AlertConfig.NPC_THROW_MIN_DISTANCE.get()
                    || dist > AlertConfig.NPC_THROW_MAX_DISTANCE.get()) {
                return null;
            }
            if (level.getRandom().nextInt(100) >= AlertConfig.NPC_THROW_CHANCE.get()) {
                return null;
            }
        }
        boolean smoke = forced
                ? forcedSmoke
                : level.getRandom().nextInt(100) < AlertConfig.NPC_SMOKE_CHANCE.get();
        String what = null;

        // 先试 TaCZ 扩展包（绿葡萄战术攻防等）里的真雷：NPC 用玩家的方式把它扔出去。
        if (AlertConfig.NPC_USE_EXTERNAL_THROWABLES.get()) {
            ResourceLocation external = ThrowableLauncher.pick(level.getRandom(), smoke);
            if (external != null && ThrowableLauncher.throwAt(level, mob, target, external)) {
                what = "外部投掷物 " + external;
                if (smoke) {
                    // 别人的烟雾弹不一定有我们认得的烟雾区，补一片，保证“烟雾一响就看不见人”。
                    ThrowableLauncher.planSmokeZone(level, target.position(), 30);
                }
            }
        }

        // 没有绿葡萄等外部真实投掷物，或外部物品拒绝 NPC 使用时，不再生成自制替代品。
        if (what == null) {
            return null;
        }

        mob.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        level.playSound(null, mob.blockPosition(), SoundEvents.SNOWBALL_THROW,
                SoundSource.HOSTILE, 1.0F, 0.85F);
        mob.getPersistentData().putLong(TAG_NEXT_THROW,
                now + AlertConfig.NPC_THROW_COOLDOWN.get() + level.getRandom().nextInt(60));
        return what;
    }

}
