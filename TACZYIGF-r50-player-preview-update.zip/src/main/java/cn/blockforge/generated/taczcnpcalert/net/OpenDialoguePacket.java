package cn.blockforge.generated.taczcnpcalert.net;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** 服务端 → 客户端：打开类 galgame 的 NPC 对话界面。 */
public final class OpenDialoguePacket {

    private final int npcId;
    private final String npcName;
    private final String scriptJson;

    public OpenDialoguePacket(int npcId, String npcName, String scriptJson) {
        this.npcId = npcId;
        this.npcName = npcName == null ? "" : npcName;
        this.scriptJson = scriptJson == null ? "" : scriptJson;
    }

    public static void encode(OpenDialoguePacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.npcId);
        buffer.writeUtf(message.npcName, 256);
        buffer.writeUtf(message.scriptJson, 1_000_000);
    }

    public static OpenDialoguePacket decode(FriendlyByteBuf buffer) {
        int npcId = buffer.readVarInt();
        String name = buffer.readUtf(256);
        return new OpenDialoguePacket(npcId, name, buffer.readUtf(1_000_000));
    }

    public static void handle(OpenDialoguePacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler.openDialogue(
                        message.npcId, message.npcName, message.scriptJson)));
        context.setPacketHandled(true);
    }
}
