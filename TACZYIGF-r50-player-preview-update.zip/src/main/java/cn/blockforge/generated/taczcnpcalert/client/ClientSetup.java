package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 客户端初始化：把感叹号粒子的贴图和渲染工厂、投掷弹体的渲染接上。 */
@Mod.EventBusSubscriber(modid = TaczCnpcAlertMod.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientSetup {

    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onRegisterParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModRegistry.EXCLAIM.get(), ExclaimParticle.Provider::new);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // 烟雾区实体没有模型，粒子自己负责视觉表现。
        event.registerEntityRenderer(ModRegistry.SMOKE_CLOUD.get(), NoopRenderer::new);
    }
}
