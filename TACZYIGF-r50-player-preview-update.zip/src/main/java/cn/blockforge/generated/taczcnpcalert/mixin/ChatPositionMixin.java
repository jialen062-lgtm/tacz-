package cn.blockforge.generated.taczcnpcalert.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 将原版聊天消息区域整体移到快捷栏正上方的水平中央，保留原版消息绘制与交互逻辑。 */
@Mixin(ChatComponent.class)
public abstract class ChatPositionMixin {

    @Unique
    private boolean taczyigf$chatPosePushed;

    @Inject(method = "render", at = @At("HEAD"))
    private void taczyigf$centerChatAboveHotbar(GuiGraphics graphics, int tick, int mouseX, int mouseY, CallbackInfo ci) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.options.hideGui) {
            return;
        }

        double chatScale = minecraft.options.chatScale().get();
        double chatWidth = Math.floor(minecraft.options.chatWidth().get() * 280.0D + 40.0D);
        double renderedWidth = chatWidth * chatScale;
        double guiWidth = minecraft.getWindow().getGuiScaledWidth();
        // 原版聊天区域从 x=2 开始绘制，抵消该边距后将整个消息区域居中。
        double offsetX = (guiWidth - renderedWidth) / 2.0D - 2.0D * chatScale;

        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(offsetX, 0.0D, 0.0D);
        taczyigf$chatPosePushed = true;
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void taczyigf$restoreChatPose(GuiGraphics graphics, int tick, int mouseX, int mouseY, CallbackInfo ci) {
        if (taczyigf$chatPosePushed) {
            graphics.pose().popPose();
            taczyigf$chatPosePushed = false;
        }
    }
}
