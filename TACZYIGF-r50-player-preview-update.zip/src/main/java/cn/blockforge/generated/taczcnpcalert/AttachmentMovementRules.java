package cn.blockforge.generated.taczcnpcalert;

import java.util.Locale;
import java.util.Set;

/** Realistic attachment movement policy. Unknown interfaces remain fixed. */
public final class AttachmentMovementRules {
    public enum Movement { FIXED, CONDITIONAL, RAIL_DEPENDENT, UNKNOWN }
    private static final Set<String> KNOWN_ADJUSTABLE_GRIP_TOKENS = Set.of(
            "vertical", "angled", "foregrip", "handstop", "bipod_grip");
    private AttachmentMovementRules() {}

    public static Movement classify(String slot, String attachmentId) {
        String s = slot == null ? "" : slot.toUpperCase(Locale.ROOT);
        String id = attachmentId == null ? "" : attachmentId.toLowerCase(Locale.ROOT);
        return switch (s) {
            case "STOCK", "MUZZLE", "EXTENDED_MAG" -> Movement.FIXED;
            case "GRIP" -> containsAny(id, KNOWN_ADJUSTABLE_GRIP_TOKENS) ? Movement.CONDITIONAL : Movement.FIXED;
            case "SCOPE", "LASER" -> Movement.RAIL_DEPENDENT;
            default -> Movement.UNKNOWN;
        };
    }

    public static boolean canDrag(String slot, String attachmentId, boolean hasPositionEditor) {
        if (!hasPositionEditor) return false;
        Movement movement = classify(slot, attachmentId);
        return movement == Movement.CONDITIONAL || movement == Movement.RAIL_DEPENDENT;
    }

    public static boolean isRail(String slot) {
        return "SCOPE".equalsIgnoreCase(slot) || "LASER".equalsIgnoreCase(slot);
    }

    /** Scope/laser travel only along the top/side rail axis; small tolerance avoids clipping. */
    public static AttachmentPositionData.Offset constrain(String slot, double x, double y, double z) {
        if (isRail(slot)) return new AttachmentPositionData.Offset(
                Math.max(-0.45D, Math.min(0.45D, x)),
                Math.max(-0.035D, Math.min(0.035D, y)),
                Math.max(-0.035D, Math.min(0.035D, z)));
        return new AttachmentPositionData.Offset(x, y, z);
    }

    private static boolean containsAny(String value, Set<String> tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }
}
