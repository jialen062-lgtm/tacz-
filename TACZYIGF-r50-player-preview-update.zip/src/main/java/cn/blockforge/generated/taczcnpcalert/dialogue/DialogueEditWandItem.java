package cn.blockforge.generated.taczcnpcalert.dialogue;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 对话编辑魔杖。
 *
 * <p>右键 NPC 进入编辑模式，之后在聊天框里用 #说 / #选 / #节点 等命令
 * 编写 NPC 台词、玩家选项和跳转；再右键一次或输入 #结束 退出。
 * 具体解析在 {@link DialogueEditService}。</p>
 */
public final class DialogueEditWandItem extends Item {

    public DialogueEditWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            player.displayClientMessage(Component.literal(
                    "右键 NPC 进入编辑模式，聊天框输入 #帮助 查看命令。")
                    .withStyle(ChatFormatting.GOLD), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键 NPC：编辑它的对话脚本").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("编辑中：#说 台词 / #选 节点号 选项 / #节点 号").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("#查看 看全文 / #结束 退出编辑").withStyle(ChatFormatting.GRAY));
    }
}
