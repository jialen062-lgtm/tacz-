package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.QuartermasterService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 客户端 → 服务端：玩家拿着魔杖右键了某个实体。
 *
 * <p>为什么不让原版交互直接处理？因为 CustomNPCs 的 NPC 会自己抢右键（弹对话），
 * 所以客户端先把它拦下来，改发这个包，由服务端来判断“标记成军需官”还是“打开面板”。</p>
 */
public final class WandInteractPacket {

    private final int entityId;
    private final boolean sneaking;

    public WandInteractPacket(int entityId, boolean sneaking) {
        this.entityId = entityId;
        this.sneaking = sneaking;
    }

    public static void encode(WandInteractPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.entityId);
        buffer.writeBoolean(message.sneaking);
    }

    public static WandInteractPacket decode(FriendlyByteBuf buffer) {
        return new WandInteractPacket(buffer.readVarInt(), buffer.readBoolean());
    }

    public static void handle(WandInteractPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null || !holdsWand(player)) {
                return;
            }
            Entity target = player.level().getEntity(message.entityId);
            if (!(target instanceof LivingEntity npc)) {
                return;
            }
            if (!AlertService.isNpcType(npc)) {
                return;
            }
            QuartermasterService.handleWandUse(player, npc, message.sneaking);
        });
        context.setPacketHandled(true);
    }

    private static boolean holdsWand(ServerPlayer player) {
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        return main.is(ModRegistry.GEAR_WAND.get()) || off.is(ModRegistry.GEAR_WAND.get());
    }
}
