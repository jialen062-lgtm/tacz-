package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.net.MapWandInteractPacket;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** NPC 地图魔杖和警长的实体交互入口。 */
public final class MapWandEvents {

    private MapWandEvents() {
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        handleWand(event, event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handleWand(event, event.getTarget());
    }

    private static void handleWand(PlayerInteractEvent event, Entity target) {
        if (!hasMapWand(event.getItemStack())) {
            return;
        }
        if (!(target instanceof LivingEntity living) || !AlertService.isNpcType(living)) {
            return;
        }

        boolean sneaking = event.getEntity().isShiftKeyDown();
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (event.getEntity().level().isClientSide()) {
            ModNetwork.sendToServer(new MapWandInteractPacket(target.getId(), sneaking));
        } else if (event.getEntity() instanceof ServerPlayer player) {
            SheriffService.handleWandUse(player, living, sneaking);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractEmptyHand(PlayerInteractEvent.EntityInteract event) {
        handleEmptyHand(event, event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractEmptyHandSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handleEmptyHand(event, event.getTarget());
    }

    private static void handleEmptyHand(PlayerInteractEvent event, Entity target) {
        Player player = event.getEntity();
        if (!player.getMainHandItem().isEmpty() || !player.getOffhandItem().isEmpty()) {
            return;
        }
        if (!(target instanceof LivingEntity living) || !SheriffService.isSheriff(living)) {
            return;
        }
        if (player.isShiftKeyDown()) {
            return;
        }

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!player.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {
            SheriffService.openPanelFromClick(serverPlayer, living);
        }
    }

    private static boolean hasMapWand(ItemStack stack) {
        return stack.is(ModRegistry.MAP_WAND.get());
    }
}
