package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.WandInteractPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * “右键 NPC”这件事由两个入口接管，客户端和服务端各管一半。
 *
 * <p>为什么不只靠 {@code Item#interactLivingEntity}：CustomNPCs 的 NPC 会自己处理右键（弹对话），
 * 等轮到物品时右键已经被吃掉了。所以这里在 Forge 的实体交互事件上抢一层：</p>
 * <ul>
 *   <li>拿着魔杖右键 NPC：把它标记成军需官 / 打开配装面板 /（潜行）取消军需官</li>
 *   <li><b>空手</b>右键军需官：同样打开配装面板；潜行空手右键仍然交给 CNPC 弹对话</li>
 * </ul>
 *
 * <p>客户端把原版交互拦掉（避免 NPC 同时弹对话），服务端再按同样的规则执行一次。
 * 一次右键可能两条路都走到，所以 {@link QuartermasterService} 里有同一 tick 的去重。</p>
 */
public final class GearWandEvents {

    private GearWandEvents() {
    }

    /**
     * 拿着魔杖右键 NPC。
     *
     * <p>两种实体交互事件都接上：有的模组（包括 CNPC）会先吃掉“精确点击”那一路，
     * 只接 {@code EntityInteract} 的话偶尔会漏。重复触发由服务端的同 tick 去重兜住。</p>
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        handleWand(event, event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handleWand(event, event.getTarget());
    }

    private static void handleWand(PlayerInteractEvent event, Entity target) {
        ItemStack held = event.getItemStack();
        if (!held.is(ModRegistry.GEAR_WAND.get())) {
            return;
        }
        if (!(target instanceof LivingEntity living) || !AlertService.isNpcType(living)) {
            return;
        }

        boolean sneaking = event.getEntity().isShiftKeyDown();

        if (event.getEntity().level().isClientSide()) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            ModNetwork.sendToServer(new WandInteractPacket(target.getId(), sneaking));
        } else if (event.getEntity() instanceof ServerPlayer player) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            QuartermasterService.handleWandUse(player, living, sneaking);
        }
    }

    /** 空手右键已经认定成军需官的 NPC：直接开面板。 */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractEmptyHand(PlayerInteractEvent.EntityInteract event) {
        handleEmptyHand(event, event.getTarget());
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractEmptyHandSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handleEmptyHand(event, event.getTarget());
    }

    private static void handleEmptyHand(PlayerInteractEvent event, Entity target) {
        Player player = event.getEntity();
        if (!player.getMainHandItem().isEmpty() || !player.getOffhandItem().isEmpty()) {
            return;
        }
        if (!(target instanceof LivingEntity living) || !AlertService.isNpcType(living)) {
            return;
        }
        if (!QuartermasterService.isQuartermaster(living)) {
            return;
        }
        // 潜行空手右键 = 正常和 NPC 说话，留给 CNPC 自己的对话逻辑。
        if (player.isShiftKeyDown()) {
            return;
        }

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!player.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {
            QuartermasterService.openPanelFromClick(serverPlayer, living);
        }
    }
}
