package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** 将军需面板操作结果同步到客户端面板最上层显示。 */
public final class PanelNoticePacket {
    private final String message;
    public PanelNoticePacket(String message) { this.message = message == null ? "" : message; }
    public static void encode(PanelNoticePacket msg, FriendlyByteBuf buf) { buf.writeUtf(msg.message, 256); }
    public static PanelNoticePacket decode(FriendlyByteBuf buf) { return new PanelNoticePacket(buf.readUtf(256)); }
    public static void handle(PanelNoticePacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPanelHandler.showPanelNotice(msg.message)));
        ctx.setPacketHandled(true);
    }
}
