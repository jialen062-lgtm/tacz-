package cn.blockforge.generated.taczcnpcalert;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 和 TaCZ（永恒枪械工坊）对接的兼容层。
 *
 * <p>这里刻意不 import 任何 TaCZ 的类：模组不把 TaCZ 当硬依赖，玩家没装 TaCZ 时整个模组照常启动，
 * 只是面板里的枪械页会显示“未检测到 TaCZ”。所有 TaCZ 调用都走反射，并且包在 try/catch 里，
 * 任何一个接口名对不上都只会让某一个小功能失效，不会让游戏崩掉。</p>
 *
 * <p>枪械、配件、子弹的物品本身都是 TaCZ 的通用物品，真正的区别写在 NBT 里：</p>
 * <ul>
 *   <li>枪：{@code GunId}（字符串）+ {@code GunCurrentAmmoCount}（整数）</li>
 *   <li>配件：{@code AttachmentId}</li>
 *   <li>子弹：{@code AmmoId}</li>
 * </ul>
 */
public final class TaczCompat {

    /** TaCZ 的六个配件槽位，顺序就是面板里的显示顺序。 */
    public static final List<String> SLOTS = List.of("SCOPE", "MUZZLE", "STOCK", "GRIP", "LASER", "EXTENDED_MAG");

    private static final String TAG_GUN_ID = "GunId";
    private static final String TAG_AMMO_ID = "AmmoId";
    private static final String TAG_ATTACHMENT_ID = "AttachmentId";
    private static final String TAG_AMMO_COUNT = "GunCurrentAmmoCount";
    private static final String TAG_ATTACHMENT_PREFIX = "Attachment";

    private static boolean tried;
    private static boolean available;

    private static Class<?> gunInterface;
    private static Class<?> attachmentInterface;
    private static Class<?> ammoInterface;
    private static Class<?> attachmentTypeClass;
    private static Item gunItem;
    private static Item attachmentItem;
    private static Item ammoItem;
    private static Item meleeItem;

    private static Method getAllGuns;
    private static Method getAllAmmo;
    private static Method getAllAttachments;
    private static Method getAllMelee;
    private static Method installAttachmentMethod;
    private static Method unloadAttachmentMethod;
    private static Method allowAttachmentMethod;
    private static Method allowAttachmentTypeMethod;
    private static Method attachmentTypeMethod;
    private static Method attachmentIdMethod;
    private static Method ammoIdMethod;
    private static Method isAmmoOfGunMethod;

    private static final Map<String, List<ResourceLocation>> CACHE = new ConcurrentHashMap<>();
    private static final Map<String, Map<String, List<ResourceLocation>>> ATTACHMENT_SLOTS =
            new ConcurrentHashMap<>();

    private TaczCompat() {
    }

    // ---------------------------------------------------------------- 初始化

    private static synchronized void init() {
        if (tried) {
            return;
        }
        tried = true;
        try {
            gunInterface = Class.forName("com.tacz.guns.api.item.IGun");
            attachmentInterface = Class.forName("com.tacz.guns.api.item.IAttachment");
            ammoInterface = Class.forName("com.tacz.guns.api.item.IAmmo");
            attachmentTypeClass = Class.forName("com.tacz.guns.api.item.attachment.AttachmentType");

            for (Item item : ForgeRegistries.ITEMS) {
                if (gunItem == null && gunInterface.isInstance(item)) {
                    gunItem = item;
                }
                if (attachmentItem == null && attachmentInterface.isInstance(item)) {
                    attachmentItem = item;
                }
                if (ammoItem == null && ammoInterface.isInstance(item)) {
                    ammoItem = item;
                }
                if (meleeItem == null && item.getClass().getSimpleName().toLowerCase().contains("melee")) {
                    meleeItem = item;
                }
            }
            if (meleeItem == null) {
                meleeItem = ForgeRegistries.ITEMS.getValue(
                        ResourceLocation.fromNamespaceAndPath("tacz", "melee"));
            }

            installAttachmentMethod = find(gunInterface, "installAttachment", ItemStack.class, ItemStack.class);
            allowAttachmentMethod = find(gunInterface, "allowAttachment", ItemStack.class, ItemStack.class);
            unloadAttachmentMethod = find(gunInterface, "unloadAttachment", ItemStack.class, attachmentTypeClass);
            allowAttachmentTypeMethod = find(gunInterface, "allowAttachmentType", ItemStack.class, attachmentTypeClass);
            attachmentTypeMethod = find(attachmentInterface, "getType", ItemStack.class);
            attachmentIdMethod = find(attachmentInterface, "getAttachmentId", ItemStack.class);
            ammoIdMethod = find(ammoInterface, "getAmmoId", ItemStack.class);
            isAmmoOfGunMethod = find(ammoInterface, "isAmmoOfGun", ItemStack.class, ItemStack.class);

            Class<?> timeless = Class.forName("com.tacz.guns.api.TimelessAPI");
            getAllGuns = findAny(timeless, "getAllCommonGunIndex", "getAllGunIndex");
            getAllAmmo = findAny(timeless, "getAllCommonAmmoIndex", "getAllAmmoIndex");
            getAllAttachments = findAny(timeless, "getAllCommonAttachmentIndex", "getAllAttachmentIndex");
            getAllMelee = findAny(timeless, "getAllCommonMeleeIndex", "getAllMeleeIndex", "getAllCommonMeleeWeaponIndex");

            available = gunItem != null;
            if (!available) {
                TaczCnpcAlertMod.LOGGER.warn("找到了 TaCZ 的类，但注册表里没有枪械物品，枪械功能不可用。");
            }
        } catch (ClassNotFoundException exception) {
            available = false;
        } catch (RuntimeException exception) {
            available = false;
            TaczCnpcAlertMod.LOGGER.warn("初始化 TaCZ 兼容层时出错，枪械功能将不可用。", exception);
        }
    }

    private static Method find(Class<?> owner, String name, Class<?>... parameterTypes) {
        try {
            Method method = owner.getMethod(name, parameterTypes);
            method.setAccessible(true);
            return method;
        } catch (ReflectiveOperationException | SecurityException ignored) {
            return null;
        }
    }

    private static Method findAny(Class<?> owner, String... names) {
        for (String name : names) {
            Method method = find(owner, name);
            if (method != null) {
                return method;
            }
        }
        return null;
    }

    public static boolean isAvailable() {
        init();
        return available;
    }

    /** 换世界/换枪包时把缓存扔掉，让面板重新读一遍枪包数据。 */
    public static void invalidateCache() {
        CACHE.clear();
        ATTACHMENT_SLOTS.clear();
    }

    /** 枪械、配件、子弹各自的“通用物品”。 */
    public static ItemStack emptyGun() {
        init();
        return gunItem == null ? ItemStack.EMPTY : new ItemStack(gunItem);
    }

    // ---------------------------------------------------------------- 读 NBT

    public static boolean isGun(ItemStack stack) {
        init();
        return stack != null && !stack.isEmpty() && gunInterface != null && gunInterface.isInstance(stack.getItem());
    }

    public static ResourceLocation gunIdOf(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return null;
        }
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(TAG_GUN_ID)) {
            return null;
        }
        return ResourceLocation.tryParse(tag.getString(TAG_GUN_ID));
    }

    public static boolean isAttachment(ItemStack stack) {
        init();
        return stack != null && !stack.isEmpty() && attachmentInterface != null
                && attachmentInterface.isInstance(stack.getItem());
    }

    public static boolean isAmmo(ItemStack stack) {
        init();
        return stack != null && !stack.isEmpty() && ammoInterface != null
                && ammoInterface.isInstance(stack.getItem());
    }

    /** 使用 TaCZ 自身的 IAmmo 规则判断子弹是否适配指定枪械。 */
    public static boolean isAmmoOfGun(ItemStack gun, ItemStack ammo) {
        init();
        if (!isGun(gun) || !isAmmo(ammo) || isAmmoOfGunMethod == null) {
            return false;
        }
        try {
            Object result = isAmmoOfGunMethod.invoke(ammo.getItem(), gun, ammo);
            return result instanceof Boolean compatible && compatible;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    public static ResourceLocation attachmentIdOf(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return null;
        }
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(TAG_ATTACHMENT_ID)) {
            return null;
        }
        return ResourceLocation.tryParse(tag.getString(TAG_ATTACHMENT_ID));
    }

    public static ResourceLocation ammoIdOf(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()) {
            return null;
        }
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(TAG_AMMO_ID)) {
            return null;
        }
        return ResourceLocation.tryParse(tag.getString(TAG_AMMO_ID));
    }

    /** 这个配件属于哪个槽位（SCOPE / MUZZLE / ...），来自 TaCZ 自己的判断。 */
    public static String slotOfAttachment(ItemStack stack) {
        init();
        if (!isAttachment(stack) || attachmentTypeMethod == null) {
            return null;
        }
        try {
            Object result = attachmentTypeMethod.invoke(stack.getItem(), stack);
            if (result instanceof Enum<?> value) {
                String name = value.name();
                return "NONE".equals(name) ? null : name;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // 读不到就当作没有槽位，界面会跳过它。
        }
        return null;
    }

    // ---------------------------------------------------------------- 构造物品

    /**
     * 造一把枪。TaCZ 的枪械物品本身是通用的，{@code GunId} 决定它是 AK 还是 M4。
     * 弹匣默认给满（按枪械数据里的容量，读不到就给 30 发）。
     */
    public static ItemStack buildGun(ResourceLocation gunId) {
        init();
        if (gunItem == null || gunId == null) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = new ItemStack(gunItem);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putString(TAG_GUN_ID, gunId.toString());
        tag.putString("GunFireMode", "UNKNOWN");
        tag.putInt(TAG_AMMO_COUNT, 30);
        tag.putBoolean("HasBulletInBarrel", true);
        return stack;
    }

    public static ItemStack buildAmmo(ResourceLocation ammoId, int count) {
        init();
        if (ammoItem == null || ammoId == null) {
            return ItemStack.EMPTY;
        }
        int stackSize = Math.max(1, Math.min(count, ammoItem.getMaxStackSize()));
        ItemStack stack = new ItemStack(ammoItem, stackSize);
        stack.getOrCreateTag().putString(TAG_AMMO_ID, ammoId.toString());
        return stack;
    }

    public static ItemStack buildAttachment(ResourceLocation attachmentId) {
        init();
        if (attachmentItem == null || attachmentId == null) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = new ItemStack(attachmentItem);
        stack.getOrCreateTag().putString(TAG_ATTACHMENT_ID, attachmentId.toString());
        return stack;
    }

    // ---------------------------------------------------------------- 配件装拆

    /**
     * 让 TaCZ 自己校验配件与枪械的兼容性，再调用原生安装方法。
     * 不再直接写 NBT 兜底：那会绕过枪械槽位限制，甚至把枪口/枪托等固定接口
     * 当成可任意安装的槽位，造成显示与实际模型不一致。
     */
    public static boolean canInstallAttachment(ItemStack gun, ItemStack attachment) {
        init();
        if (!isGun(gun) || !isAttachment(attachment) || installAttachmentMethod == null) {
            return false;
        }
        String slot = slotOfAttachment(attachment);
        if (slot == null || !allowsSlot(gun, slot)) {
            return false;
        }
        if (allowAttachmentMethod == null) {
            return true;
        }
        try {
            Object result = allowAttachmentMethod.invoke(gun.getItem(), gun, attachment);
            return result instanceof Boolean allowed && allowed;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    public static boolean installAttachment(ItemStack gun, ItemStack attachment) {
        init();
        if (!canInstallAttachment(gun, attachment)) {
            return false;
        }
        try {
            installAttachmentMethod.invoke(gun.getItem(), gun, attachment);
            ResourceLocation id = attachmentIdOf(attachment);
            return id != null && id.equals(installedAttachmentId(gun, slotOfAttachment(attachment)));
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    /** 卸下某个槽位的配件。只调用 TaCZ 原生卸载接口，不直接改写配件 NBT。 */
    public static boolean unloadAttachment(ItemStack gun, String slot) {
        init();
        if (!isGun(gun) || slot == null || !allowsSlot(gun, slot)
                || unloadAttachmentMethod == null) {
            return false;
        }
        Object type = attachmentType(slot);
        if (type == null) {
            return false;
        }
        try {
            unloadAttachmentMethod.invoke(gun.getItem(), gun, type);
            return installedAttachmentId(gun, slot) == null;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    /** 某把枪某个槽位现在装的是什么配件；空槽返回空串。 */
    public static ResourceLocation installedAttachmentId(ItemStack gun, String slot) {
        if (gun == null || gun.isEmpty() || slot == null) {
            return null;
        }
        CompoundTag tag = gun.getTag();
        if (tag == null) {
            return null;
        }
        String key = TAG_ATTACHMENT_PREFIX + slot;
        if (!tag.contains(key, 10)) {
            return null;
        }
        ItemStack installed = ItemStack.of(tag.getCompound(key));
        if (installed.isEmpty()) {
            return null;
        }
        return attachmentIdOf(installed);
    }

    /** 该枪是否支持这个槽位（由 TaCZ 自己的 allowAttachmentType 判断）。 */
    public static boolean allowsSlot(ItemStack gun, String slot) {
        init();
        if (!isGun(gun) || allowAttachmentTypeMethod == null) {
            return true;
        }
        Object type = attachmentType(slot);
        if (type == null) {
            return false;
        }
        try {
            Object result = allowAttachmentTypeMethod.invoke(gun.getItem(), gun, type);
            return result instanceof Boolean allowed && allowed;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return true;
        }
    }

    private static Object attachmentType(String slot) {
        if (attachmentTypeClass == null || slot == null) {
            return null;
        }
        try {
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object value = Enum.valueOf((Class<? extends Enum>) attachmentTypeClass.asSubclass(Enum.class),
                    slot.toUpperCase(Locale.ROOT));
            return value;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    // ---------------------------------------------------------------- 全量列表

    /** 所有能拿到 ID 的枪械；客户端、服务端都能调用。 */
    public static List<ResourceLocation> allGunIds() {
        return collect("guns", getAllGuns, "guns");
    }

    public static List<ResourceLocation> allAmmoIds() {
        return collect("ammo", getAllAmmo, "ammo");
    }

    public static List<ResourceLocation> allAttachmentIds() {
        return collect("attachments", getAllAttachments, "attachments");
    }

    /** TaCZ 近战武器的通用物品是否找到了（没找到时近战页退化为按注册名直接发物品）。 */
    public static boolean hasMeleeItem() {
        init();
        return meleeItem != null;
    }

    /** 所有近战武器 ID（来自 TaCZ 的索引，读不到时是空表）。 */
    public static List<ResourceLocation> allMeleeIds() {
        init();
        if (meleeItem == null) {
            return List.of();
        }
        return collect("melee", getAllMelee, "melee");
    }

    /** 造一把近战武器：和枪一样是通用物品 + NBT 里的 ID。 */
    public static ItemStack buildMelee(ResourceLocation meleeId) {
        init();
        if (meleeItem == null || meleeId == null) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = new ItemStack(meleeItem);
        stack.getOrCreateTag().putString(TAG_GUN_ID, meleeId.toString());
        return stack;
    }

    @SuppressWarnings("unchecked")
    private static List<ResourceLocation> collect(String cacheKey, Method method, String folder) {
        init();
        List<ResourceLocation> cached = CACHE.get(cacheKey);
        if (cached != null) {
            return cached;
        }
        List<ResourceLocation> result = new ArrayList<>();
        if (method != null) {
            try {
                Object raw = method.invoke(null);
                if (raw instanceof Map<?, ?> map) {
                    for (Object key : map.keySet()) {
                        addId(result, key);
                    }
                } else if (raw instanceof Collection<?> collection) {
                    for (Object element : collection) {
                        if (element instanceof Map.Entry<?, ?> entry) {
                            addId(result, entry.getKey());
                        } else {
                            addId(result, element);
                        }
                    }
                }
            } catch (ReflectiveOperationException | RuntimeException exception) {
                TaczCnpcAlertMod.LOGGER.warn("读取 TaCZ 的 {} 列表失败", cacheKey, exception);
            }
        }
        // 老版本 TaCZ 可能没有“列出全部索引”的公开方法，这时直接翻枪包的数据文件。
        if (result.isEmpty()) {
            result.addAll(scanIndexFolder(folder));
        }
        result.sort((left, right) -> left.toString().compareToIgnoreCase(right.toString()));
        List<ResourceLocation> immutable = List.copyOf(result);
        CACHE.put(cacheKey, immutable);
        return immutable;
    }

    /**
     * 兜底：直接扫资源包里的 {@code data/<枪包>/index/<folder>/*.json}。
     * 每个文件名就是一个 ID，比如 {@code index/guns/ak47.json} 对应 {@code tacz:ak47}。
     */
    private static List<ResourceLocation> scanIndexFolder(String folder) {
        List<ResourceLocation> result = new ArrayList<>();
        net.minecraft.server.MinecraftServer server =
                net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return result;
        }
        String prefix = "index/" + folder + "/";
        try {
            var resources = server.getResourceManager().listResources("index",
                    id -> id.getPath().startsWith(prefix) && id.getPath().endsWith(".json"));
            for (ResourceLocation key : resources.keySet()) {
                String path = key.getPath();
                if (!path.startsWith(prefix) || !path.endsWith(".json")) {
                    continue;
                }
                String name = path.substring(prefix.length(), path.length() - ".json".length());
                if (name.isEmpty() || name.contains("/")) {
                    continue;
                }
                result.add(ResourceLocation.fromNamespaceAndPath(key.getNamespace(), name));
            }
        } catch (RuntimeException exception) {
            TaczCnpcAlertMod.LOGGER.warn("扫描枪包目录 index/{} 失败", folder, exception);
        }
        return result;
    }

    private static void addId(List<ResourceLocation> target, Object candidate) {
        if (candidate instanceof ResourceLocation id) {
            target.add(id);
        } else if (candidate instanceof String text) {
            ResourceLocation id = ResourceLocation.tryParse(text);
            if (id != null) {
                target.add(id);
            }
        }
    }

    /** 按槽位把配件分组，界面里做“选瞄具/枪口/…”。 */
    public static Map<String, List<ResourceLocation>> attachmentsBySlot() {
        Map<String, List<ResourceLocation>> cached = ATTACHMENT_SLOTS.get("map");
        if (cached != null) {
            return cached;
        }
        Map<String, List<ResourceLocation>> result = new LinkedHashMap<>();
        for (String slot : SLOTS) {
            result.put(slot, new ArrayList<>());
        }
        for (ResourceLocation id : allAttachmentIds()) {
            String slot = slotOfAttachment(buildAttachment(id));
            if (slot != null && result.containsKey(slot)) {
                result.get(slot).add(id);
            }
        }
        Map<String, List<ResourceLocation>> frozen = new LinkedHashMap<>();
        result.forEach((slot, ids) -> frozen.put(slot, List.copyOf(ids)));
        ATTACHMENT_SLOTS.put("map", frozen);
        return frozen;
    }

    /** 给界面用的“这个 ID 的中文/英文显示名”，能在客户端拿到 TaCZ 的枪名。 */
    public static String displayName(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return "?";
        }
        try {
            return stack.getHoverName().getString();
        } catch (RuntimeException exception) {
            return "?";
        }
    }

    /** 让玩家看到某个 Optional 是否为空的小工具（避免在别处重复写 try）。 */
    public static boolean isPresent(Optional<?> optional) {
        return optional != null && optional.isPresent();
    }
}
