package cn.blockforge.generated.taczcnpcalert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenDungeonPanelPacket;

/**
 * “警长”标记与副本选择。
 *
 * <p>地图魔杖右键普通 NPC 后，NPC 会被持久标记成警长。警长面板中的副本清单来自配置，
 * 玩家选择后会同时记录到 NPC 和玩家身上；如果配置了合法维度与坐标，则直接传送过去。
 * 配置保持默认时不会擅自改变玩家位置，只记录并提示选择结果。</p>
 */
public final class SheriffService {

    public static final String TAG_SHERIFF = "tacz_cnpc_alert.sheriff";
    public static final String TAG_SELECTED_DUNGEON = "tacz_cnpc_alert.selected_dungeon";
    public static final String ACTION_DUNGEON = "dungeon";
    public static final String ACTION_CLEAR_DUNGEON = "clear_dungeon";

    private static final Map<String, Long> RECENT_USES = new HashMap<>();

    private SheriffService() {
    }

    public static boolean isSheriff(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(TAG_SHERIFF);
    }

    public static void setSheriff(LivingEntity entity, boolean value) {
        if (entity == null) {
            return;
        }
        if (value) {
            entity.getPersistentData().putBoolean(TAG_SHERIFF, true);
        } else {
            entity.getPersistentData().remove(TAG_SHERIFF);
        }
    }

    /** 地图魔杖右键 NPC：首次设成警长，已标记时打开副本面板；潜行则取消。 */
    public static boolean handleWandUse(ServerPlayer player, LivingEntity npc, boolean sneaking) {
        if (player == null || npc == null || !npc.isAlive()) {
            return false;
        }
        if (isDuplicateClick(player, npc)) {
            return true;
        }
        if (player.distanceToSqr(npc) > 64.0D) {
            player.displayClientMessage(Component.literal("离得太远了，走近一点再使用地图魔杖。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }
        if (!AlertService.isNpcType(npc)) {
            player.displayClientMessage(Component.literal("这不是可标记的 NPC，地图魔杖对它没用。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }

        boolean sneak = sneaking || player.isShiftKeyDown();
        if (sneak) {
            if (isSheriff(npc)) {
                setSheriff(npc, false);
                npc.getPersistentData().remove(TAG_SELECTED_DUNGEON);
                player.displayClientMessage(Component.literal("已取消这个 NPC 的警长身份。")
                        .withStyle(ChatFormatting.YELLOW), true);
            } else {
                player.displayClientMessage(Component.literal("这个 NPC 还不是警长。")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return true;
        }

        if (!isSheriff(npc)) {
            setSheriff(npc, true);
            player.displayClientMessage(Component.literal("这个 NPC 现在是警长了，空手右键它即可选择副本。")
                    .withStyle(ChatFormatting.AQUA), true);
            QuartermasterService.celebrate(player, npc);
            return true;
        }

        openPanel(player, npc);
        return true;
    }

    /** 空手右键警长：不走标记流程，直接打开副本面板。 */
    public static void openPanelFromClick(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null || !isSheriff(npc) || isDuplicateClick(player, npc)) {
            return;
        }
        openPanel(player, npc);
    }

    /** 把副本清单交给客户端面板，同时告知警长当前保存的选择。 */
    public static void openPanel(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null) {
            return;
        }
        ModNetwork.sendToPlayer(new OpenDungeonPanelPacket(npc.getId(), dungeonNames(),
                npc.getPersistentData().getString(TAG_SELECTED_DUNGEON)), player);
    }

    /** 面板点击副本后由服务端校验并应用。 */
    public static void handlePanelAction(ServerPlayer player, LivingEntity npc, int dungeonIndex, boolean clear) {
        if (player == null || npc == null) {
            return;
        }
        if (!isSheriff(npc)) {
            hint(player, "这个 NPC 不是警长，无法选择副本。");
            return;
        }
        if (player.distanceToSqr(npc) > 64.0D) {
            hint(player, "离警长太远了，请先靠近一些。");
            return;
        }

        List<? extends String> configured = AlertConfig.DUNGEON_ENTRIES.get();
        if (clear) {
            npc.getPersistentData().remove(TAG_SELECTED_DUNGEON);
            player.getPersistentData().remove(TAG_SELECTED_DUNGEON);
            hint(player, "已清除当前副本选择。");
            return;
        }
        if (dungeonIndex < 0 || dungeonIndex >= configured.size()) {
            hint(player, "这个副本不在当前配置列表中。");
            return;
        }

        DungeonEntry entry = parseEntry(configured.get(dungeonIndex));
        npc.getPersistentData().putString(TAG_SELECTED_DUNGEON, entry.name());
        player.getPersistentData().putString(TAG_SELECTED_DUNGEON, entry.name());
        String teleportFailure = teleportFailure(entry, player);
        if (teleportFailure == null) {
            teleportToDungeon(player, entry);
            hint(player, "警长已带你进入副本：" + entry.name());
        } else {
            hint(player, "已选择副本：" + entry.name() + "（" + teleportFailure + "）");
        }
    }

    /** 把配置里的副本项转换成面板可以显示的副本名。 */
    public static List<String> dungeonNames() {
        return AlertConfig.DUNGEON_ENTRIES.get().stream().map(SheriffService::parseEntry).map(DungeonEntry::name).toList();
    }

    private record DungeonEntry(String name, ResourceLocation dimension, double x, double y, double z, boolean hasLocation) {
    }

    private static DungeonEntry parseEntry(String raw) {
        String value = raw == null ? "" : raw.trim();
        String name = value;
        ResourceLocation dimension = null;
        double x = 0.0D;
        double y = 0.0D;
        double z = 0.0D;
        boolean hasLocation = false;

        int at = value.indexOf('@');
        if (at >= 0) {
            name = value.substring(0, at).trim();
            String location = value.substring(at + 1).trim();
            // 维度本身也可能包含命名空间冒号，例如 minecraft:overworld:100 64 -200。
            // 坐标分隔符应取最后一个冒号，不能取第一个冒号。
            int colon = location.lastIndexOf(':');
            if (colon >= 0) {
                dimension = ResourceLocation.tryParse(location.substring(0, colon).trim());
                String[] parts = location.substring(colon + 1).trim().split("\\s+");
                if (dimension != null && parts.length == 3) {
                    try {
                        x = Double.parseDouble(parts[0]);
                        y = Double.parseDouble(parts[1]);
                        z = Double.parseDouble(parts[2]);
                        hasLocation = true;
                    } catch (NumberFormatException ignored) {
                        // 配置写错时只显示副本名，不改变玩家位置。
                    }
                }
            }
        }
        return new DungeonEntry(name.isBlank() ? value : name, dimension, x, y, z, hasLocation);
    }

    private static String teleportFailure(DungeonEntry entry, ServerPlayer player) {
        if (!entry.hasLocation() || entry.dimension() == null) {
            return "入口格式不对，请写成 副本名@minecraft:overworld:100 64 -200";
        }
        ServerLevel targetLevel = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, entry.dimension()));
        if (targetLevel == null) {
            return "找不到维度 " + entry.dimension();
        }
        if (!targetLevel.isInWorldBounds(BlockPos.containing(entry.x(), entry.y(), entry.z()))) {
            return "入口坐标超出世界范围";
        }
        return null;
    }

    private static void teleportToDungeon(ServerPlayer player, DungeonEntry entry) {
        ServerLevel targetLevel = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, entry.dimension()));
        if (targetLevel != null) {
            player.teleportTo(targetLevel, entry.x(), entry.y(), entry.z(), player.getYRot(), player.getXRot());
        }
    }

    private static boolean isDuplicateClick(ServerPlayer player, LivingEntity npc) {
        long now = player.level().getGameTime();
        String key = player.getUUID() + ":" + npc.getId();
        Long last = RECENT_USES.get(key);
        if (last != null && last == now) {
            return true;
        }
        RECENT_USES.put(key, now);
        if (RECENT_USES.size() > 256) {
            RECENT_USES.clear();
        }
        return false;
    }

    private static void hint(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(ChatFormatting.AQUA), true);
    }
}
