package cn.blockforge.generated.taczcnpcalert.mixin;

import cn.blockforge.generated.taczcnpcalert.AttachmentMovementRules;
import cn.blockforge.generated.taczcnpcalert.AttachmentPositionData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;

/**
 * Applies an offset only to the active attachment render call. Reflection keeps TaCZ optional
 * at compile time; the target is resolved only when TaCZ is installed.
 */
@Pseudo
@Mixin(targets = "com.tacz.guns.client.model.functional.AttachmentRender", remap = false)
public abstract class AttachmentRenderMixin {
    @Unique private static final ThreadLocal<Deque<Boolean>> TACZCNPC$POSES =
            ThreadLocal.withInitial(ArrayDeque::new);

    @Inject(method = "render", at = @At("HEAD"), remap = false)
    private void taczcnpc$pushOffset(PoseStack poseStack, VertexConsumer vertexConsumer, ItemDisplayContext displayContext,
                                     int packedLight, int packedOverlay, CallbackInfo ci) {
        boolean pushed = false;
        try {
            Object model = readField(this, "bedrockGunModel");
            Object type = readField(this, "type");
            if (model != null && type != null) {
                Method attachmentsMethod = model.getClass().getMethod("getCurrentAttachmentItem");
                Object attachmentsObject = attachmentsMethod.invoke(model);
                if (attachmentsObject instanceof EnumMap<?, ?> attachments) {
                    Object attachmentObject = attachments.get(type);
                    if (attachmentObject instanceof ItemStack attachment && !attachment.isEmpty()) {
                        ItemStack gun = (ItemStack) model.getClass().getMethod("getCurrentGunItem").invoke(model);
                        String slot = type.toString();
                        String id = AttachmentPositionData.attachmentKey(attachment);
                        if (AttachmentMovementRules.canDrag(slot, id, true)) {
                            AttachmentPositionData.Offset offset = AttachmentPositionData.get(gun, slot, attachment);
                            if (!offset.isZero()) {
                                poseStack.pushPose();
                                poseStack.translate(offset.x(), offset.y(), offset.z());
                                pushed = true;
                            }
                        }
                    }
                }
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Preserve vanilla TaCZ rendering if a future TaCZ build changes its internals.
        }
        TACZCNPC$POSES.get().push(pushed);
    }

    @Inject(method = "render", at = @At("RETURN"), remap = false)
    private void taczcnpc$popOffset(PoseStack poseStack, VertexConsumer vertexConsumer, ItemDisplayContext displayContext,
                                    int packedLight, int packedOverlay, CallbackInfo ci) {
        Deque<Boolean> states = TACZCNPC$POSES.get();
        if (!states.isEmpty() && states.pop()) poseStack.popPose();
        if (states.isEmpty()) TACZCNPC$POSES.remove();
    }

    @Unique
    private static Object readField(Object instance, String name) throws ReflectiveOperationException {
        Class<?> type = instance.getClass();
        while (type != null) {
            try {
                Field field = type.getDeclaredField(name);
                field.setAccessible(true);
                return field.get(instance);
            } catch (NoSuchFieldException ignored) { type = type.getSuperclass(); }
        }
        throw new NoSuchFieldException(name);
    }
}
