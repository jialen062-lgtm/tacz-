package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Optional;

/** Optional Curios bridge. Reflection keeps Curios genuinely optional at class-loading time. */
public final class CuriosCompat {
    private CuriosCompat() {}
    public static boolean tryEquip(ServerPlayer player, ItemStack stack) {
        if (!ModList.get().isLoaded("curios") || stack == null || stack.isEmpty()) return false;
        try {
            Class<?> api = Class.forName("top.theillusivec4.curios.api.CuriosApi");
            Method getInventory = api.getMethod("getCuriosInventory", LivingEntity.class);
            Object optionalObject = getInventory.invoke(null, player);
            Object inventory;
            if (optionalObject instanceof Optional<?> optional) {
                if (optional.isEmpty()) return false;
                inventory = optional.get();
            } else {
                // Curios/Forge releases have exposed both Optional and LazyOptional.
                // LazyOptional.resolve() returns Optional and avoids relying on getValue().
                Object resolved = optionalObject.getClass().getMethod("resolve").invoke(optionalObject);
                if (!(resolved instanceof Optional<?> optional) || optional.isEmpty()) return false;
                inventory = optional.get();
            }
            Object mapObject = callPublic(inventory, "getCurios");
            if (!(mapObject instanceof Map<?, ?> curios)) return false;
            for (Object handler : curios.values()) {
                Object stacks = callPublic(handler, "getStacks");
                int slots = (Integer) callPublic(stacks, "getSlots");
                Method getStack = publicMethod(stacks, "getStackInSlot", int.class);
                Method isValid = publicMethod(stacks, "isItemValid", int.class, ItemStack.class);
                Method setStack = publicMethod(stacks, "setStackInSlot", int.class, ItemStack.class);
                for (int i = 0; i < slots; i++) {
                    ItemStack current = (ItemStack) getStack.invoke(stacks, i);
                    boolean valid = (Boolean) isValid.invoke(stacks, i, stack);
                    if (current.isEmpty() && valid) {
                        ItemStack equipped = stack.copy();
                        equipped.setCount(1);
                        setStack.invoke(stacks, i, equipped);
                        player.getInventory().setChanged();
                        player.containerMenu.broadcastChanges();
                        return true;
                    }
                }
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            TaczCnpcAlertMod.LOGGER.warn("Curios 饰品槽兼容失败，已回退到原版装备槽处理。", exception);
        }
        return false;
    }

    /** Resolve public API methods on their public interface, not a package-private implementation. */
    private static Object callPublic(Object target, String name) throws ReflectiveOperationException {
        return publicMethod(target, name).invoke(target);
    }

    private static Method publicMethod(Object target, String name, Class<?>... parameters)
            throws ReflectiveOperationException {
        Class<?> type = target.getClass();
        while (type != null) {
            for (Class<?> iface : type.getInterfaces()) {
                try {
                    Method method = iface.getMethod(name, parameters);
                    method.setAccessible(true);
                    return method;
                } catch (NoSuchMethodException ignored) { }
            }
            type = type.getSuperclass();
        }
        Method method = target.getClass().getMethod(name, parameters);
        method.setAccessible(true);
        return method;
    }
}
