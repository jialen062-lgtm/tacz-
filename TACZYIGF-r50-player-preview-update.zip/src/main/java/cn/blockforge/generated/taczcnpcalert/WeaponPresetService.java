package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Player-persistent, category-separated full ItemStack presets. */
public final class WeaponPresetService {
    private static final String ROOT = "TaczCnpcWeaponPresets";
    private static final String PISTOLS = "pistols";
    private static final String RIFLES = "long_guns";
    private static final int MAX_PRESETS_PER_CATEGORY = 50;
    private WeaponPresetService() {}

    public static boolean isPistol(ItemStack gun) {
        var id = TaczCompat.gunIdOf(gun);
        String path = id == null ? "" : id.getPath().toLowerCase(Locale.ROOT);
        String[] tokens = {"pistol", "handgun", "revolver", "glock", "deagle", "desert_eagle", "m1911", "1911", "usp", "beretta", "p99", "makarov", "five_seven", "fn57", "cz75", "mp443", "p226", "p320", "tt33", "colt"};
        for (String token : tokens) if (path.contains(token)) return true;
        return false;
    }
    public static String category(ItemStack gun) { return isPistol(gun) ? PISTOLS : RIFLES; }

    public static void save(ServerPlayer player, int inventorySlot) {
        if (inventorySlot < 0 || inventorySlot >= player.getInventory().getContainerSize()) return;
        ItemStack gun = player.getInventory().getItem(inventorySlot);
        if (!TaczCompat.isGun(gun)) { hint(player, "请选择背包中的 TaCZ 枪械后再保存预设。"); return; }
        String category = category(gun);
        CompoundTag root = player.getPersistentData().getCompound(ROOT);
        ListTag list = root.getList(category, 10);
        if (list.size() >= MAX_PRESETS_PER_CATEGORY) { hint(player, "该类别预设已达到上限（50个）。"); return; }
        CompoundTag preset = new CompoundTag();
        String gunName = TaczCompat.displayName(gun);
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd HH:mm"));
        preset.putString("name", gunName + " · " + time);
        preset.put("stack", gun.save(new CompoundTag()));
        preset.putString("gun_id", TaczCompat.gunIdOf(gun) == null ? "" : TaczCompat.gunIdOf(gun).toString());
        list.add(preset);
        root.put(category, list);
        player.getPersistentData().put(ROOT, root);
        hint(player, (PISTOLS.equals(category) ? "手枪" : "长枪") + "预设已保存：" + gunName);
    }

    public static void sendList(ServerPlayer player) {
        CompoundTag root = player.getPersistentData().getCompound(ROOT);
        List<String> entries = new ArrayList<>();
        append(entries, root.getList(PISTOLS, 10), PISTOLS);
        append(entries, root.getList(RIFLES, 10), RIFLES);
        cn.blockforge.generated.taczcnpcalert.net.ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new cn.blockforge.generated.taczcnpcalert.net.WeaponPresetListPacket(entries));
    }
    private static void append(List<String> out, ListTag list, String category) {
        for (int i = 0; i < list.size(); i++) {
            CompoundTag tag = list.getCompound(i);
            out.add(category + "|" + i + "|" + tag.getString("name") + "|" + tag.getString("gun_id"));
        }
    }

    public static void apply(ServerPlayer player, String encoded) {
        String[] parts = encoded.split(":", 2);
        if (parts.length != 2) return;
        String category = parts[0]; int index;
        try { index = Integer.parseInt(parts[1]); } catch (NumberFormatException e) { return; }
        if (!PISTOLS.equals(category) && !RIFLES.equals(category)) return;
        ListTag list = player.getPersistentData().getCompound(ROOT).getList(category, 10);
        if (index < 0 || index >= list.size()) { hint(player, "预设不存在。"); return; }
        ItemStack saved = ItemStack.of(list.getCompound(index).getCompound("stack"));
        if (!TaczCompat.isGun(saved)) { hint(player, "预设数据无效，无法恢复。"); return; }
        if (!category(saved).equals(category)) {
            hint(player, "预设类别与枪械数据不一致，已拒绝恢复。");
            return;
        }
        var savedId = TaczCompat.gunIdOf(saved); int target = -1;
        // Prefer replacing the exact weapon; otherwise replace only a gun in the same
        // pistol/long-gun category. Ordinary inventory items and the other category
        // are never touched by preset restore.
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack current = player.getInventory().getItem(i);
            if (TaczCompat.isGun(current) && savedId != null && savedId.equals(TaczCompat.gunIdOf(current))) { target = i; break; }
        }
        if (target < 0) for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack current = player.getInventory().getItem(i);
            if (TaczCompat.isGun(current) && category(current).equals(category)) { target = i; break; }
        }
        if (target < 0) for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (player.getInventory().getItem(i).isEmpty()) { target = i; break; }
        }
        if (target < 0) { hint(player, "背包没有空位，未恢复预设，也没有覆盖其他物品。"); return; }
        player.getInventory().setItem(target, saved.copy());
        player.getInventory().setChanged(); player.containerMenu.broadcastChanges();
        hint(player, "已恢复完整枪械预设：" + saved.getHoverName().getString());
    }
    private static void hint(ServerPlayer player, String message) {
        cn.blockforge.generated.taczcnpcalert.net.ModNetwork.sendToPlayer(new cn.blockforge.generated.taczcnpcalert.net.PanelNoticePacket(message), player);
    }
}
