package cn.blockforge.generated.taczcnpcalert;

import java.util.List;
import java.util.Locale;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * “投掷物禁止破坏方块”的兜底保护。
 *
 * <p>本模组自己的手雷爆炸本来就不破坏方块；这里管的是<b>别的模组 / 扩展包</b>的雷：
 * 只要爆炸来自“名字里带 grenade / bomb / frag 之类”的弹体（或者来自弹体自己实现的爆炸类，
 * 比如 TaCZ 的 {@code ProjectileExplosion}），就在引爆前把“要炸掉的方块清单”清空——
 * 伤害保留、方块一个不动。</p>
 *
 * <p>同时防止“爆炸时顺手点燃火焰”。原版 TNT、苦力怕、别的武器的爆炸完全不受影响。</p>
 */
public final class ExplosionProtection {

    private ExplosionProtection() {
    }

    public static void onDetonate(ExplosionEvent.Detonate event) {
        Level level = event.getLevel();
        if (level.isClientSide() || !AlertConfig.PROTECT_TERRAIN.get()) {
            return;
        }
        Explosion explosion = event.getExplosion();
        Entity direct = explosion.getDirectSourceEntity();
        Entity source = direct != null ? direct : explosion.getIndirectSourceEntity();
        if (isGrenadeLike(source) || isProjectileExplosion(explosion)) {
            List<net.minecraft.core.BlockPos> blocks = event.getAffectedBlocks();
            if (!blocks.isEmpty()) {
                blocks.clear();
            }
        }
    }

    /** 起爆方块被移除后位置会写入这个集合，用来兜住“连锁二次爆炸”的情况。 */
    public static boolean shouldProtect(Explosion explosion) {
        return explosion != null
                && (isGrenadeLike(explosion.getDirectSourceEntity()) || isProjectileExplosion(explosion));
    }

    /**
     * 有些扩展包的雷把自己的爆炸实现成一个 Explosion 子类（弹体实体已经被移除了，
     * 拿不到来源实体），类名里通常带 projectile / grenade / bomb，这种也一起保护。
     * 原版 TNT、苦力怕用的就是 Explosion 本身，不受影响。
     */
    private static boolean isProjectileExplosion(Explosion explosion) {
        if (explosion == null || explosion.getClass() == Explosion.class) {
            return false;
        }
        String name = explosion.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        return name.contains("projectile") || name.contains("grenade") || name.contains("bomb");
    }

    private static boolean isGrenadeLike(Entity source) {
        if (source == null) {
            return false;
        }
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(source.getType());
        if (id == null) {
            return false;
        }
        if (id.getNamespace().equalsIgnoreCase(TaczCnpcAlertMod.MOD_ID)) {
            return true; // 本模组的雷本来就用 NONE 引爆，这里只是双保险
        }
        if (id.getNamespace().equals("minecraft")) {
            return false; // 原版 TNT、苦力怕、末地水晶这些一律不管
        }
        String path = id.getPath().toLowerCase(Locale.ROOT);
        String className = source.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        // 名字里带 grenade / bomb / frag 之类就算“雷类”，不管它是哪个 modid 注册的：
        // 绿葡萄战术攻防这类扩展包的命名空间不一定叫 tacz，按名字认才不会漏。
        return WeaponCatalog.looksLikeGrenadePath(path)
                || className.contains("grenade")
                || className.contains("bomb");
    }
}
