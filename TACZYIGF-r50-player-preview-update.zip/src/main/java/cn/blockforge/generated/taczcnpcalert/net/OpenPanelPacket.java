package cn.blockforge.generated.taczcnpcalert.net;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 服务端 → 客户端：打开军需官配装面板，顺便把“能领什么”的清单一起带过去。
 *
 * <p>清单由服务端打包，而不是让客户端自己去读配置 / 问 TaCZ：这样联机时两边看到的完全一样，
 * 即使客户端那边的枪包索引还没同步完，面板里的枪械、子弹、配件也不会是空的。</p>
 */
public final class OpenPanelPacket {

    private final int npcId;
    /** “装备”页的物品注册名（服务端自动从军事装备模组里认出来的）。 */
    private final List<String> equipmentIds;
    private final List<String> gunIds;
    private final List<String> ammoIds;
    /** “近战武器”页（TaCZ 近战 + 扩展包识别出来的冷兵器）。 */
    private final List<String> meleeIds;
    /** “投掷物”页（绿葡萄等外部扩展包识别出来的真实投掷物）。 */
    private final List<String> throwableIds;
    /** 槽位名（SCOPE / MUZZLE / ...）→ 该槽位可用的配件 ID。 */
    private final Map<String, List<String>> attachments;

    public OpenPanelPacket(int npcId, List<String> equipmentIds, List<String> gunIds, List<String> ammoIds,
                           List<String> meleeIds, List<String> throwableIds,
                           Map<String, List<String>> attachments) {
        this.npcId = npcId;
        this.equipmentIds = List.copyOf(equipmentIds);
        this.gunIds = List.copyOf(gunIds);
        this.ammoIds = List.copyOf(ammoIds);
        this.meleeIds = List.copyOf(meleeIds);
        this.throwableIds = List.copyOf(throwableIds);
        this.attachments = new LinkedHashMap<>(attachments);
    }

    public int npcId() {
        return npcId;
    }

    public List<String> equipmentIds() {
        return equipmentIds;
    }

    public List<String> gunIds() {
        return gunIds;
    }

    public List<String> ammoIds() {
        return ammoIds;
    }

    public List<String> meleeIds() {
        return meleeIds;
    }

    public List<String> throwableIds() {
        return throwableIds;
    }

    public Map<String, List<String>> attachments() {
        return attachments;
    }

    public static void encode(OpenPanelPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.npcId);
        buffer.writeCollection(message.equipmentIds, FriendlyByteBuf::writeUtf);
        buffer.writeCollection(message.gunIds, FriendlyByteBuf::writeUtf);
        buffer.writeCollection(message.ammoIds, FriendlyByteBuf::writeUtf);
        buffer.writeCollection(message.meleeIds, FriendlyByteBuf::writeUtf);
        buffer.writeCollection(message.throwableIds, FriendlyByteBuf::writeUtf);
        buffer.writeVarInt(message.attachments.size());
        message.attachments.forEach((slot, ids) -> {
            buffer.writeUtf(slot);
            buffer.writeCollection(ids, FriendlyByteBuf::writeUtf);
        });
    }

    public static OpenPanelPacket decode(FriendlyByteBuf buffer) {
        int npcId = buffer.readVarInt();
        List<String> equipment = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
        List<String> guns = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
        List<String> ammos = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
        List<String> melee = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
        List<String> throwables = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
        int size = buffer.readVarInt();
        Map<String, List<String>> attachments = new LinkedHashMap<>();
        for (int i = 0; i < size; i++) {
            String slot = buffer.readUtf();
            List<String> ids = buffer.readCollection(ArrayList::new, FriendlyByteBuf::readUtf);
            attachments.put(slot, ids);
        }
        return new OpenPanelPacket(npcId, equipment, guns, ammos, melee, throwables, attachments);
    }

    public static void handle(OpenPanelPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        // 客户端类只能在客户端加载，所以这里的 lambda 用 DistExecutor 包一层。
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler.openPanel(
                        message.npcId, message.equipmentIds, message.gunIds, message.ammoIds,
                        message.meleeIds, message.throwableIds, message.attachments)));
        context.setPacketHandled(true);
    }
}
