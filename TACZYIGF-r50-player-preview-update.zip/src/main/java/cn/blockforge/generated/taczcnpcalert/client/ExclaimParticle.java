package cn.blockforge.generated.taczcnpcalert.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * NPC 头顶弹出来的感叹号：不落地、缓慢上飘、最后淡出。
 * 纯客户端表现，服务端只负责发一条“在这弹一个”的指令。
 */
public class ExclaimParticle extends TextureSheetParticle {

    private final SpriteSet sprites;

    protected ExclaimParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.lifetime = 24;
        this.quadSize = 0.55F;
        this.gravity = 0.0F;
        this.hasPhysics = false;
        this.friction = 0.96F;
        this.xd = 0.0D;
        this.yd = 0.03D;
        this.zd = 0.0D;
        this.setSpriteFromAge(sprites);
        this.alpha = 1.0F;
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(this.sprites);
        // 最后 6 tick 淡出
        this.alpha = Math.max(0.0F, Math.min(1.0F, (this.lifetime - this.age) / 6.0F));
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    /** 从贴图集里取出这张贴图，再由服务端/客户端逐帧挑选。 */
    public static class Provider implements ParticleProvider<SimpleParticleType> {

        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                       double x, double y, double z,
                                       double dx, double dy, double dz) {
            return new ExclaimParticle(level, x, y, z, this.sprites);
        }
    }
}
