package cn.blockforge.generated.taczcnpcalert;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.RegisterCommandsEvent;

/**
 * 调试命令：/taczcnpc alert —— 在玩家脚下假装响一枪，
 * 用来确认“喊话 + 感叹号 + 喊声”这一套是否正常，不用真的去开枪。
 * 它不受“同一个 NPC 1 分钟一次”的限制，方便反复测试。
 */
public final class AlertCommands {

    private AlertCommands() {
    }

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("taczcnpc")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("alert")
                        .executes(context -> {
                            ServerPlayer player = context.getSource().getPlayerOrException();
                            if (player.level() instanceof ServerLevel serverLevel) {
                                AlertService.handleDebugGunshot(serverLevel, player.getX(), player.getY(), player.getZ(), player);
                            }
                            return Command.SINGLE_SUCCESS;
                        }))
                .then(Commands.literal("throwables")
                        .executes(context -> {
                            java.util.List<net.minecraft.resources.ResourceLocation> ids =
                                    WeaponCatalog.throwableIds();
                            var source = context.getSource();
                            source.sendSuccess(() -> Component.literal(
                                    "认出来的投掷物（军需官面板“投掷物”页同款）共 " + ids.size() + " 种："), false);
                            StringBuilder line = new StringBuilder();
                            int shown = 0;
                            for (net.minecraft.resources.ResourceLocation id : ids) {
                                if (shown >= 40) {
                                    source.sendSuccess(() -> Component.literal("…（还有更多，面板里能翻到）"), false);
                                    break;
                                }
                                line.append(id).append("  ");
                                shown++;
                                if (shown % 3 == 0) {
                                    String text = line.toString().trim();
                                    source.sendSuccess(() -> Component.literal(text), false);
                                    line.setLength(0);
                                }
                            }
                            if (line.length() > 0) {
                                String text = line.toString().trim();
                                source.sendSuccess(() -> Component.literal(text), false);
                            }
                            return Command.SINGLE_SUCCESS;
                        }))
                .then(Commands.literal("throwtest")
                        .executes(context -> debugThrow(context, true))
                        .then(Commands.argument("kind", StringArgumentType.word())
                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                        java.util.List.of("smoke", "frag"), builder))
                                .executes(context -> debugThrow(context,
                                        !StringArgumentType.getString(context, "kind").equalsIgnoreCase("frag")))))
                .then(Commands.literal("respawn")
                        .executes(context -> {
                            int respawned = AlertService.respawnWaitingNpcs(context.getSource().getServer());
                            if (respawned < 0) {
                                context.getSource().sendFailure(Component.literal(
                                        "未检测到 CustomNPCs 非官方版，无法执行 NPC 重生。"));
                                return 0;
                            }
                            context.getSource().sendSuccess(
                                    () -> Component.literal("已重生 " + respawned + " 个正在等待重生的 NPC。"), true);
                            return respawned;
                        })));
    }

    /** /taczcnpc throwtest [smoke|frag]：让最近的 NPC 立刻朝你扔一颗（默认烟雾弹，不伤人）。 */
    private static int debugThrow(CommandContext<CommandSourceStack> context, boolean smoke)
            throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = context.getSource().getPlayerOrException();
        if (!(player.level() instanceof ServerLevel level)) {
            return 0;
        }
        Mob npc = nearestNpc(level, player);
        if (npc == null) {
            context.getSource().sendFailure(Component.literal("32 格内没有 NPC，先放一个 CNPC 的 NPC 再试。"));
            return 0;
        }
        String what = NpcThrowEvents.throwGrenade(level, npc, player, level.getGameTime(), smoke);
        context.getSource().sendSuccess(() -> Component.literal("最近的 NPC 朝你扔了一颗：" + what), false);
        return Command.SINGLE_SUCCESS;
    }

    /** 找玩家 32 格内离得最近的 NPC（调试用）。 */
    private static Mob nearestNpc(ServerLevel level, Player player) {
        Mob best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Mob mob : level.getEntitiesOfClass(Mob.class, player.getBoundingBox().inflate(32.0D),
                AlertService::isNpc)) {
            double distance = mob.distanceToSqr(player);
            if (distance < bestDistance) {
                bestDistance = distance;
                best = mob;
            }
        }
        return best;
    }
}
