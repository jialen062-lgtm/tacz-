package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueWandEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 客户端 → 服务端：玩家拿对话魔杖（或编辑魔杖）右键了某个 NPC。 */
public final class DialogueWandInteractPacket {

    private final int entityId;
    private final boolean editing;

    public DialogueWandInteractPacket(int entityId, boolean editing) {
        this.entityId = entityId;
        this.editing = editing;
    }

    public static void encode(DialogueWandInteractPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.entityId);
        buffer.writeBoolean(message.editing);
    }

    public static DialogueWandInteractPacket decode(FriendlyByteBuf buffer) {
        return new DialogueWandInteractPacket(buffer.readVarInt(), buffer.readBoolean());
    }

    public static void handle(DialogueWandInteractPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null || !holdsWand(player, message.editing)) {
                return;
            }
            Entity target = player.level().getEntity(message.entityId);
            if (!(target instanceof LivingEntity npc) || !AlertService.isNpcType(npc)) {
                return;
            }
            if (player.distanceToSqr(npc) > 64.0) {
                return;
            }
            DialogueWandEvents.use(player, npc, message.editing);
        });
        context.setPacketHandled(true);
    }

    private static boolean holdsWand(ServerPlayer player, boolean editing) {
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        var wand = editing ? ModRegistry.DIALOGUE_EDIT_WAND.get() : ModRegistry.DIALOGUE_WAND.get();
        return main.is(wand) || off.is(wand);
    }
}
