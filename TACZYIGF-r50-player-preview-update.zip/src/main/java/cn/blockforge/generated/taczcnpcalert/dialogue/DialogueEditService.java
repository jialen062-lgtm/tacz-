package cn.blockforge.generated.taczcnpcalert.dialogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.ServerChatEvent;

/**
 * 对话编辑魔杖的服务端逻辑。
 *
 * <p>拿编辑魔杖右键 NPC 进入编辑模式后，聊天框里以 # 开头的消息会被拦截，
 * 变成编辑命令（#说 #选 #节点 #查看 #清空 #帮助 #结束），其余聊天照常发送。</p>
 */
public final class DialogueEditService {

    /** 玩家 UUID → 正在编辑的 NPC UUID。 */
    private static final Map<UUID, UUID> EDITING = new ConcurrentHashMap<>();
    /** 玩家 UUID → 当前编辑到第几个节点。 */
    private static final Map<UUID, Integer> CURSOR = new ConcurrentHashMap<>();

    private DialogueEditService() {
    }

    /** 右键切换：进入/退出对某个 NPC 的编辑模式。 */
    public static void toggle(ServerPlayer player, Entity npc) {
        UUID pid = player.getUUID();
        if (npc.getUUID().equals(EDITING.get(pid))) {
            stop(player, "已退出对话编辑模式。");
            return;
        }
        EDITING.put(pid, npc.getUUID());
        CURSOR.put(pid, 0);
        tell(player, ChatFormatting.LIGHT_PURPLE,
                "【对话编辑模式】正在编辑：" + npc.getName().getString());
        sendHelp(player);
    }

    public static void onLoggedOut(UUID playerId) {
        EDITING.remove(playerId);
        CURSOR.remove(playerId);
    }

    /** 拦截聊天：编辑模式下的 # 命令。 */
    public static void onChat(ServerChatEvent event) {
        String raw = event.getRawText();
        if (raw == null) {
            return;
        }
        String text = raw.trim();
        if (text.isEmpty() || !(text.startsWith("#") || text.startsWith("＃"))) {
            return;
        }
        ServerPlayer player = event.getPlayer();
        UUID pid = player.getUUID();
        if (!EDITING.containsKey(pid)) {
            // 没在编辑模式就不管 # 开头的消息，避免影响别的模组
            return;
        }
        Entity npc = findNpc(player, EDITING.get(pid));
        if (!(npc instanceof LivingEntity living)) {
            stop(player, "那个 NPC 不在了，已退出编辑模式。");
            return;
        }
        event.setCanceled(true);
        handleCommand(player, living, text.substring(1).trim());
    }

    private static void handleCommand(ServerPlayer player, Entity npc, String cmd) {
        if (cmd.isEmpty()) {
            sendHelp(player);
            return;
        }
        if (cmd.startsWith("说")) {
            String text = stripKeyword(cmd, "说");
            if (text.isEmpty()) {
                warn(player, "用法：#说 你好啊，旅人。");
                return;
            }
            int node = cursor(player);
            JsonObject script = loadOrNew(npc);
            JsonArray lines = DialogueStore.linesOf(DialogueStore.getOrCreateNode(DialogueStore.nodes(script), node));
            if (lines.size() >= 20) {
                warn(player, "一个节点最多 20 句台词。");
                return;
            }
            DialogueStore.addLine(script, node, clamp(text));
            save(npc, script);
            tell(player, ChatFormatting.GREEN, "已加入 NPC 台词（节点 " + node + " 第 " + lines.size() + " 句）：" + clamp(text));
        } else if (cmd.startsWith("选")) {
            String rest = stripKeyword(cmd, "选");
            int space = rest.indexOf(' ');
            if (space < 0) {
                warn(player, "用法：#选 1 发生了什么？（1 是选完后跳到的节点号）");
                return;
            }
            int target;
            try {
                target = Integer.parseInt(rest.substring(0, space).trim());
            } catch (NumberFormatException ex) {
                warn(player, "节点号要是数字，例如：#选 1 发生了什么？");
                return;
            }
            String text = rest.substring(space + 1).trim();
            if (text.isEmpty()) {
                warn(player, "选项内容不能为空。");
                return;
            }
            if (target < 0 || target >= DialogueStore.MAX_NODES) {
                warn(player, "目标节点号要在 0 ~ " + (DialogueStore.MAX_NODES - 1) + " 之间。");
                return;
            }
            int node = cursor(player);
            JsonObject script = loadOrNew(npc);
            JsonArray options = DialogueStore.optionsOf(DialogueStore.getOrCreateNode(DialogueStore.nodes(script), node));
            if (options.size() >= 6) {
                warn(player, "一个节点最多 6 个选项。");
                return;
            }
            DialogueStore.addOption(script, node, clamp(text), target);
            save(npc, script);
            tell(player, ChatFormatting.AQUA, "已加入玩家选项（节点 " + node + " → 节点 " + target + "）：" + clamp(text));
        } else if (cmd.startsWith("节点")) {
            String arg = stripKeyword(cmd, "节点");
            try {
                int node = Integer.parseInt(arg);
                if (node < 0 || node >= DialogueStore.MAX_NODES) {
                    warn(player, "节点号要在 0 ~ " + (DialogueStore.MAX_NODES - 1) + " 之间。");
                    return;
                }
                CURSOR.put(player.getUUID(), node);
                tell(player, ChatFormatting.YELLOW, "当前编辑节点：" + node + "（0 是开场）");
            } catch (NumberFormatException ex) {
                warn(player, "用法：#节点 1");
            }
        } else if (cmd.startsWith("查看")) {
            dump(player, npc);
        } else if (cmd.startsWith("清空")) {
            DialogueStore.write(npc, "");
            CURSOR.put(player.getUUID(), 0);
            tell(player, ChatFormatting.GOLD, "已清空该 NPC 的对话脚本。");
        } else if (cmd.startsWith("结束")) {
            stop(player, "已退出对话编辑模式。脚本已保存。");
        } else if (cmd.startsWith("帮助")) {
            sendHelp(player);
        } else {
            warn(player, "不认识这个命令，输入 #帮助 查看用法。");
        }
    }

    private static void dump(ServerPlayer player, Entity npc) {
        JsonObject script = DialogueStore.parse(DialogueStore.read(npc));
        if (script == null) {
            tell(player, ChatFormatting.GRAY, "（这个 NPC 还没有任何对话）");
            return;
        }
        JsonArray nodes = DialogueStore.nodes(script);
        tell(player, ChatFormatting.LIGHT_PURPLE, "—— " + npc.getName().getString() + " 的对话脚本 ——");
        for (int i = 0; i < nodes.size(); i++) {
            JsonObject node = DialogueStore.getOrCreateNode(nodes, i);
            JsonArray lines = DialogueStore.linesOf(node);
            JsonArray options = DialogueStore.optionsOf(node);
            if (lines.size() == 0 && options.size() == 0) {
                continue;
            }
            tell(player, ChatFormatting.YELLOW, "【节点 " + i + "】");
            for (JsonElement line : lines) {
                tell(player, ChatFormatting.WHITE, "  说：" + safeText(line));
            }
            for (JsonElement el : options) {
                if (el.isJsonObject()) {
                    JsonObject option = el.getAsJsonObject();
                    tell(player, ChatFormatting.AQUA, "  选：" + optionText(option)
                            + " → 节点 " + optionTarget(option));
                }
            }
        }
    }

    /** 客户端界面解析用的安全取文本。 */
    public static String optionText(JsonObject option) {
        JsonElement el = option.get("text");
        return el == null || !el.isJsonPrimitive() ? "" : el.getAsString();
    }

    public static int optionTarget(JsonObject option) {
        JsonElement el = option.get("target");
        if (el == null || !el.isJsonPrimitive()) {
            return -1;
        }
        try {
            return el.getAsInt();
        } catch (Exception ex) {
            return -1;
        }
    }

    private static String safeText(JsonElement el) {
        return el == null || !el.isJsonPrimitive() ? "" : el.getAsString();
    }

    private static JsonObject loadOrNew(Entity npc) {
        JsonObject script = DialogueStore.parse(DialogueStore.read(npc));
        return script == null ? DialogueStore.emptyScript() : script;
    }

    private static void save(Entity npc, JsonObject script) {
        DialogueStore.write(npc, DialogueStore.toJson(script));
    }

    private static int cursor(ServerPlayer player) {
        return CURSOR.getOrDefault(player.getUUID(), 0);
    }

    private static void stop(ServerPlayer player, String message) {
        EDITING.remove(player.getUUID());
        CURSOR.remove(player.getUUID());
        tell(player, ChatFormatting.GRAY, message);
    }

    private static Entity findNpc(ServerPlayer player, UUID npcId) {
        if (player.getServer() == null) {
            return null;
        }
        for (ServerLevel level : player.getServer().getAllLevels()) {
            Entity entity = level.getEntity(npcId);
            if (entity != null) {
                return entity;
            }
        }
        return null;
    }

    private static String stripKeyword(String cmd, String keyword) {
        String rest = cmd.substring(keyword.length()).trim();
        while (!rest.isEmpty() && (rest.charAt(0) == '：' || rest.charAt(0) == ':' || rest.charAt(0) == ' ')) {
            rest = rest.substring(1).trim();
        }
        return rest;
    }

    private static String clamp(String text) {
        return text.length() <= DialogueStore.MAX_TEXT ? text : text.substring(0, DialogueStore.MAX_TEXT);
    }

    private static void sendHelp(ServerPlayer player) {
        tell(player, ChatFormatting.GRAY, "  #说 <文本>          给当前节点加一句 NPC 台词");
        tell(player, ChatFormatting.GRAY, "  #选 <节点号> <文本>  加一个玩家选项，选完跳到该节点");
        tell(player, ChatFormatting.GRAY, "  #节点 <号>           切换当前编辑的节点（0 是开场）");
        tell(player, ChatFormatting.GRAY, "  #查看 / #清空 / #帮助 / #结束");
        tell(player, ChatFormatting.GRAY, "  例：#说 你好啊，旅人。 然后 #选 1 出什么事了？ 再 #节点 1 #说 矿洞被僵尸占了。");
    }

    private static void tell(ServerPlayer player, ChatFormatting color, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(color), false);
    }

    private static void warn(ServerPlayer player, String message) {
        tell(player, ChatFormatting.RED, message);
    }
}
