package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.entity.SmokeCloudEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * “让 NPC 扔别的模组的雷”的通用发射器。
 *
 * <p>思路：TaCZ 扩展包（比如绿葡萄战术攻防）的投掷物都是<b>右键使用</b>的物品，
 * 它们真正的抛雷逻辑写在物品自己身上。所以这里不去猜它们的类名，而是造一个
 * 一次性的“假玩家”（Forge 自带的 FakePlayer），把 NPC 的眼睛位置和朝向抄过去、
 * 把雷塞进他手里，然后照玩家的方式调用 {@code ItemStack.use()}——
 * 物品自己就会把雷实体扔出来。扔完立刻清空手上的东西、把假玩家挪回原位。</p>
 *
 * <p>扔不出来（物品不是投掷物、或者那个 mod 的抛雷写在别处）就返回 false，
 * 调用方本次不投掷，不生成自制替代品。</p>
 */
public final class ThrowableLauncher {

    /** 预估的投掷初速度，用来算抛物线仰角（原版雪球是 1.5）。 */
    private static final double NOMINAL_SPEED = 1.5D;
    /** 预估的重力，每 tick 下落的格数（原版投掷物约 0.03～0.05）。 */
    private static final double NOMINAL_GRAVITY = 0.035D;

    /** 改名缓存：把一个投掷物 ID 归成“烟”还是“炸”。 */
    private static List<ResourceLocation> smokeCache;
    private static List<ResourceLocation> fragCache;

    private ThrowableLauncher() {
    }

    /** 外部投掷物清单变了（reload / 换存档）时清缓存。 */
    public static synchronized void invalidate() {
        smokeCache = null;
        fragCache = null;
    }

    // ---------------------------------------------------------------- 选雷

    /** 绿葡萄等外部扩展包有没有可用的真实投掷物。 */
    public static boolean hasExternal() {
        return !fragList().isEmpty() || !smokeList().isEmpty();
    }

    /**
     * 随机挑一颗外部投掷物。
     *
     * @param smoke true 表示想扔烟雾类（用来致盲），false 表示想扔爆炸类；
     *              没有对应类别时返回 null，本次不投掷。
     */
    public static ResourceLocation pick(RandomSource random, boolean smoke) {
        List<ResourceLocation> pool = smoke ? smokeList() : fragList();
        if (pool.isEmpty()) {
            return null;
        }
        return pool.get(random.nextInt(pool.size()));
    }

    /** 这个投掷物是不是烟雾类（名字里带 smoke）。 */
    public static boolean looksSmokey(ResourceLocation id) {
        return id != null && id.getPath().toLowerCase(Locale.ROOT).contains("smoke");
    }

    private static synchronized List<ResourceLocation> smokeList() {
        if (smokeCache == null) {
            List<ResourceLocation> result = new ArrayList<>();
            for (ResourceLocation id : WeaponCatalog.thirdPartyThrowableIds()) {
                if (looksSmokey(id)) {
                    result.add(id);
                }
            }
            smokeCache = List.copyOf(result);
        }
        return smokeCache;
    }

    private static synchronized List<ResourceLocation> fragList() {
        if (fragCache == null) {
            List<ResourceLocation> result = new ArrayList<>();
            for (ResourceLocation id : WeaponCatalog.thirdPartyThrowableIds()) {
                if (!looksSmokey(id)) {
                    result.add(id);
                }
            }
            fragCache = List.copyOf(result);
        }
        return fragCache;
    }

    // ---------------------------------------------------------------- 扔雷

    /**
     * 让 NPC “用玩家的方式”把 id 对应的投掷物扔向目标。
     *
     * @return 真的扔出去了（场上有新实体）才返回 true。
     */
    public static boolean throwAt(ServerLevel level, Mob npc, LivingEntity target, ResourceLocation id) {
        if (level == null || npc == null || target == null || id == null) {
            return false;
        }
        // lrtactical 使用统一 throwable 基础物品，具体型号由索引 ID 决定；
        // 其它模组若注册了独立物品，则继续兼容原来的注册表路径。
        ItemStack throwableStack = LrtacticalCompat.buildThrowable(id);
        if (throwableStack.isEmpty()) {
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item == null) {
                return false;
            }
            throwableStack = new ItemStack(item);
        }
        FakePlayer fake = null;
        Vec3 eye = npc.getEyePosition();
        int before = countNearbyEntities(level, eye);
        try {
            fake = FakePlayerFactory.getMinecraft(level);
            fake.setPos(eye.x, npc.getY(), eye.z);
            fake.setOldPosAndRot();
            aimAt(fake, eye, target);
            fake.setOnGround(true);
            fake.setItemInHand(InteractionHand.MAIN_HAND, throwableStack.copy());

            ItemStack held = fake.getMainHandItem();
            InteractionResultHolder<ItemStack> result = held.use(level, fake, InteractionHand.MAIN_HAND);
            boolean charging = fake.isUsingItem();
            if (charging) {
                // 蓄力型投掷物：直接按“蓄满松手”处理（timeLeft = 0 表示已经充满）。
                held.releaseUsing(level, fake, 0);
                fake.stopUsingItem();
            }
            if (countNearbyEntities(level, eye) > before) {
                return true; // 场上多了一个实体，基本就是刚扔出去的雷
            }
            if (charging) {
                return true; // 蓄力型：松手那一刻由物品自己生成，实体可能下一 tick 才出现
            }
            return result != null && result.getResult().consumesAction();
        } catch (RuntimeException exception) {
            // 有的扩展包在“已经生成弹体之后”才去发包，那一步可能抛异常；
            // 这里再数一次实体，扔出去了就算成功，免得 NPC 一次丢两颗。
            if (countNearbyEntities(level, eye) > before) {
                return true;
            }
            TaczCnpcAlertMod.LOGGER.warn("NPC 投掷 {} 失败，改用本模组的雷。", id, exception);
            return false;
        } finally {
            if (fake != null) {
                fake.stopUsingItem();
                fake.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
                fake.setXRot(0.0F);
                fake.setYRot(0.0F);
            }
        }
    }

    /** 假玩家身边 8 格内的实体数量，用来判断“雷到底扔出来没有”。 */
    private static int countNearbyEntities(ServerLevel level, Vec3 center) {
        AABB box = new AABB(center, center).inflate(8.0D);
        List<Entity> found = level.getEntities((Entity) null, box,
                entity -> !(entity instanceof Player));
        return found.size();
    }

    /**
     * 把假玩家转到“朝目标抛物投掷”的角度：水平方向对准目标，
     * 仰角按抛物线反推（解不出就用 45°）。
     */
    private static void aimAt(FakePlayer fake, Vec3 from, LivingEntity target) {
        Vec3 to = target.getEyePosition().subtract(0.0D, 0.35D, 0.0D);
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        double angle = solveLaunchAngle(horizontal, dy);
        fake.setYRot(yaw);
        fake.setYHeadRot(yaw);
        fake.setXRot((float) -Math.toDegrees(angle));
    }

    /** 已知水平距离和高度差，反推需要的仰角（弧度）。 */
    private static double solveLaunchAngle(double horizontal, double height) {
        if (horizontal < 0.5D) {
            return Math.toRadians(70.0D);
        }
        double v2 = NOMINAL_SPEED * NOMINAL_SPEED;
        double g = NOMINAL_GRAVITY;
        double discriminant = v2 * v2 - g * (g * horizontal * horizontal + 2.0D * height * v2);
        if (discriminant < 0.0D) {
            return Math.toRadians(45.0D); // 太远了，扔不到，用最省的 45° 碰运气
        }
        double angle = Math.atan((v2 - Math.sqrt(discriminant)) / (g * horizontal));
        return Math.max(Math.toRadians(-10.0D), Math.min(Math.toRadians(75.0D), angle));
    }

    // ---------------------------------------------------------------- 烟雾致盲对接

    /**
     * 别的 mod / 玩家扔出的烟雾弹也要让 NPC “看不见”。
     *
     * <p>我们的致盲判定只认自己那片烟雾区，所以这里监听实体生成：
     * 一旦发现外面的烟雾类弹体，就隔 1.5 秒（≈30 tick，大概是它落地的时刻）
     * 在它的位置补一片“看不见的墙”，这样 NPC 的索敌逻辑就照常失效。</p>
     */
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || event.loadedFromDisk()) {
            return;
        }
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        if (!AlertConfig.EXTERNAL_SMOKE_BLINDS.get()) {
            return;
        }
        Entity entity = event.getEntity();
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (id == null || id.getNamespace().equalsIgnoreCase(TaczCnpcAlertMod.MOD_ID)) {
            return; // 自己家的烟雾弹已经自带烟雾区了
        }
        String path = id.getPath().toLowerCase(Locale.ROOT);
        if (!path.contains("smoke")) {
            return;
        }
        // 30 tick 后再补烟雾区：那时候雷基本落地了，跟着弹体当前位置走最准。
        planSmokeZoneTracking(level, entity, 30);
    }

    /** 过 delayTicks 之后在 at 位置生成一片致盲烟雾区。 */
    public static void planSmokeZone(ServerLevel level, Vec3 at, int delayTicks) {
        planSmokeZoneInternal(level, null, at, delayTicks);
    }

    /** 过 delayTicks 之后在 entity（雷）当时的位置生成烟雾区；雷没了就用 start 位置。 */
    private static void planSmokeZoneTracking(ServerLevel level, Entity entity, int delayTicks) {
        planSmokeZoneInternal(level, entity, entity == null ? null : entity.position(), delayTicks);
    }

    private static void planSmokeZoneInternal(ServerLevel level, Entity track, Vec3 start, int delayTicks) {
        if (level == null || start == null) {
            return;
        }
        MinecraftServer server = level.getServer();
        if (server == null) {
            return;
        }
        DelayedTasks.schedule(server, delayTicks, srv -> {
            ServerLevel target = srv.getLevel(level.dimension());
            if (target == null) {
                return;
            }
            Vec3 at = track != null && !track.isRemoved() ? track.position() : start;
            SmokeCloudEntity cloud = new SmokeCloudEntity(target, at.x, at.y + 0.5D, at.z);
            cloud.setRadius(AlertConfig.SMOKE_RADIUS.get());
            cloud.setDuration(AlertConfig.SMOKE_DURATION.get());
            target.addFreshEntity(cloud);
        });
    }
}
