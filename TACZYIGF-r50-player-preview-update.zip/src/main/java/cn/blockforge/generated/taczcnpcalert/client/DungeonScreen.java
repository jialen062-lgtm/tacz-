package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.SheriffService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** 警长 NPC 的副本选择界面。 */
public final class DungeonScreen extends Screen {

    private static final int WIDTH = 300;
    private static final int HEIGHT = 190;
    private final int npcId;
    private final List<String> dungeonNames;
    private final String selectedDungeon;
    private int left;
    private int top;

    public DungeonScreen(int npcId, List<String> dungeonNames, String selectedDungeon) {
        super(Component.literal("警长 · 副本选择"));
        this.npcId = npcId;
        this.dungeonNames = List.copyOf(dungeonNames);
        this.selectedDungeon = selectedDungeon == null ? "" : selectedDungeon;
    }

    @Override
    protected void init() {
        this.left = (this.width - WIDTH) / 2;
        this.top = (this.height - HEIGHT) / 2;

        int columns = 2;
        int buttonWidth = 128;
        int buttonHeight = 22;
        int gapX = 8;
        int startX = this.left + (WIDTH - columns * buttonWidth - gapX) / 2;
        int startY = this.top + 52;
        for (int index = 0; index < this.dungeonNames.size(); index++) {
            final int dungeonIndex = index;
            int column = index % columns;
            int row = index / columns;
            int y = startY + row * (buttonHeight + 6);
            if (y + buttonHeight > this.top + HEIGHT - 38) {
                break;
            }
            this.addRenderableWidget(Button.builder(Component.literal(this.dungeonNames.get(index)),
                            button -> select(dungeonIndex))
                    .bounds(startX + column * (buttonWidth + gapX), y, buttonWidth, buttonHeight)
                    .build());
        }

        this.addRenderableWidget(Button.builder(Component.literal("清除选择"), button -> clearSelection())
                .bounds(this.left + 20, this.top + HEIGHT - 28, 80, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("关闭"), button -> onClose())
                .bounds(this.left + WIDTH - 100, this.top + HEIGHT - 28, 80, 20).build());
    }

    private void select(int dungeonIndex) {
        ModNetwork.sendToServer(new PanelActionPacket(
                SheriffService.ACTION_DUNGEON, Integer.toString(dungeonIndex), 0, this.npcId));
        onClose();
    }

    private void clearSelection() {
        ModNetwork.sendToServer(new PanelActionPacket(
                SheriffService.ACTION_CLEAR_DUNGEON, "-1", 0, this.npcId));
        onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int x = this.left;
        int y = this.top;
        graphics.fill(x, y, x + WIDTH, y + HEIGHT, 0xE8121418);
        int border = 0xFF3A4757;
        graphics.fill(x, y, x + WIDTH, y + 2, border);
        graphics.fill(x, y + HEIGHT - 2, x + WIDTH, y + HEIGHT, border);
        graphics.fill(x, y, x + 2, y + HEIGHT, border);
        graphics.fill(x + WIDTH - 2, y, x + WIDTH, y + HEIGHT, border);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, x + WIDTH / 2, y + 10, 0xFFFFFF);
        String selected = selectedDungeon.isBlank() ? "当前未选择副本" : "当前选择：" + selectedDungeon;
        graphics.drawCenteredString(this.font, Component.literal(selected).withStyle(ChatFormatting.GOLD),
                x + WIDTH / 2, y + 31, 0xFFD700);
        if (this.dungeonNames.isEmpty()) {
            graphics.drawCenteredString(this.font, Component.literal("没有可玩的副本，请检查配置"),
                    x + WIDTH / 2, y + 82, 0xFFAAAAAA);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
