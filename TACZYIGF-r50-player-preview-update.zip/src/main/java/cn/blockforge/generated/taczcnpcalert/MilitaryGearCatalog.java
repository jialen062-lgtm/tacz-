package cn.blockforge.generated.taczcnpcalert;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.TagKey;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * “装备”页里到底该列哪些东西。
 *
 * <p>以前这里读的是配置文件里手写的一串物品名，所以永远只有那套铁装。现在改成自动识别：
 * 你装的军事装备模组（默认 {@code fracturepoint}，也就是 Fracture Point）里，
 * 凡是头盔、防弹衣、护腿、靴子、制服、肩甲、背包、面罩、夜视仪、防弹插板这类装备，
 * 会被自动挑出来放进面板。一个都没挑到（比如没装那个模组）时，才退回配置里的备用清单。</p>
 *
 * <p>结果缓存起来，只在服务端启动 / 重载时算一次。</p>
 */
public final class MilitaryGearCatalog {

    /**
     * 物品注册名里出现这些单词（下划线分段）就算“装备”。
     * 例如 {@code nato_sqad_leader_chestplate} 里有 {@code chestplate}，{@code iz_boots_ops} 里有 {@code boots}。
     */
    private static final Set<String> GEAR_TOKENS = Set.of(
            "helmet", "chestplate", "leggings", "boots", "uniform", "shoulderpads",
            "backpack", "balaclava", "vest", "mask", "goggles", "cap", "panama", "carrier");

    /** 分类：0 = 头部，1 = 躯干，2 = 腿脚，3 = 其它（背包、插板、夜视仪……）。 */
    private static final Set<String> HEAD_TOKENS = Set.of(
            "helmet", "balaclava", "mask", "goggles", "cap", "panama");
    private static final Set<String> BODY_TOKENS = Set.of(
            "chestplate", "vest", "uniform", "shoulderpads");
    private static final Set<String> LEG_TOKENS = Set.of("leggings", "boots");

    private static List<ResourceLocation> cache;

    private MilitaryGearCatalog() {
    }

    /** 服务端启动 / 重载时清一次缓存，改完配置不用重启就能生效。 */
    public static synchronized void invalidate() {
        cache = null;
    }

    /** 装备页要列出的物品，按“头部 → 躯干 → 腿脚 → 其它”排好序。 */
    public static synchronized List<ResourceLocation> equipmentIds() {
        if (cache == null) {
            cache = build();
        }
        return cache;
    }

    /** 给界面的分类筛选按钮用：0 头、1 躯干、2 腿脚、3 其它。 */
    public static int categoryOf(ResourceLocation id) {
        if (id == null) {
            return 3;
        }
        Set<String> tokens = tokensOf(id.getPath());
        if (!java.util.Collections.disjoint(tokens, HEAD_TOKENS)) {
            return 0;
        }
        if (!java.util.Collections.disjoint(tokens, BODY_TOKENS)) {
            return 1;
        }
        if (!java.util.Collections.disjoint(tokens, LEG_TOKENS)) {
            return 2;
        }
        return 3;
    }

    private static List<ResourceLocation> build() {
        LinkedHashSet<ResourceLocation> ids = new LinkedHashSet<>();

        // 1) 配置里手动补的物品，优先级最高。
        for (String raw : AlertConfig.EQUIPMENT_EXTRA.get()) {
            ResourceLocation id = parse(raw);
            if (id != null && ForgeRegistries.ITEMS.containsKey(id)) {
                ids.add(id);
            }
        }

        // 2) 军事装备模组里自动认出来的装备。
        Set<String> namespaces = new HashSet<>();
        for (String raw : AlertConfig.MILITARY_NAMESPACES.get()) {
            if (raw != null && !raw.isBlank()) {
                namespaces.add(raw.trim().toLowerCase(Locale.ROOT));
            }
        }
        List<ResourceLocation> detected = new ArrayList<>();
        if (!namespaces.isEmpty()) {
            for (ResourceLocation id : ForgeRegistries.ITEMS.getKeys()) {
                if (!namespaces.contains(id.getNamespace().toLowerCase(Locale.ROOT))) {
                    continue;
                }
                Item item = ForgeRegistries.ITEMS.getValue(id);
                if (item == null || item instanceof BlockItem) {
                    continue;
                }
                if (looksLikeGear(id.getPath(), item)) {
                    detected.add(id);
                }
            }
        }
        // 3) Curios 标签中的装备不受 military_namespaces 限制，允许其他模组的背包/面罩等进入装备页。
        for (ResourceLocation id : ForgeRegistries.ITEMS.getKeys()) {
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item != null && !(item instanceof BlockItem) && isCuriosWearable(item)) {
                detected.add(id);
            }
        }
        detected.sort(Comparator
                .comparingInt((ResourceLocation id) -> categoryOf(id))
                .thenComparing(ResourceLocation::toString));
        ids.addAll(detected);

        // 3) 一个都没认出来（多半是没装军事装备模组），用备用清单，别让面板空着。
        if (ids.isEmpty()) {
            for (String raw : AlertConfig.FALLBACK_EQUIPMENT.get()) {
                ResourceLocation id = parse(raw);
                if (id != null && ForgeRegistries.ITEMS.containsKey(id)) {
                    ids.add(id);
                }
            }
        }
        return List.copyOf(ids);
    }

    /**
     * 判断一个物品算不算“装备”。
     *
     * <p>只要是原版的护甲类物品就直接算；其它（Curios 的背包、制服，或者被模组自己重写过的护甲）
     * 看注册名里有没有护甲相关的单词。防弹插板比较特殊：只有名字里同时带 plate 和 level
     * （例如 {@code steel_plate_level_iii}）才算，免得把钢板、陶瓷片这些材料也列进去。</p>
     */
    private static boolean isCuriosWearable(Item item) {
        try {
            for (TagKey<Item> tag : ForgeRegistries.ITEMS.tags().getTagNames().toList()) {
                if ("curios".equals(tag.location().getNamespace())
                        && !"curio".equals(tag.location().getPath())
                        && new ItemStack(item).is(tag)) return true;
            }
        } catch (RuntimeException ignored) {
            // Curios tags may not be synced during early registry setup; normal namespace scan still works.
        }
        return false;
    }

    private static boolean looksLikeGear(String path, Item item) {
        if (item instanceof ArmorItem) {
            return true;
        }
        Set<String> tokens = tokensOf(path);
        if (!java.util.Collections.disjoint(tokens, GEAR_TOKENS)) {
            return true;
        }
        return tokens.contains("plate") && tokens.contains("level");
    }

    private static Set<String> tokensOf(String path) {
        Set<String> tokens = new HashSet<>();
        if (path == null || path.isBlank()) {
            return tokens;
        }
        for (String part : path.toLowerCase(Locale.ROOT).split("_")) {
            if (!part.isBlank()) {
                tokens.add(part);
            }
        }
        return tokens;
    }

    private static ResourceLocation parse(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        return ResourceLocation.tryParse(raw.trim());
    }
}
