package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * 负责“听见”枪声：TaCZ 每开一枪会生成子弹实体，本模组只盯着这个实体。
 *
 * <p>只有枪声能惊动 NPC：脚步、方块声、交互声、其他生物的声音一律不算，
 * 所以这里不再监听 {@code PlayLevelSoundEvent}。</p>
 */
public final class GunshotEvents {

    private GunshotEvents() {
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        Level level = event.getLevel();
        if (level.isClientSide() || event.loadedFromDisk()) {
            return;
        }
        Entity entity = event.getEntity();
        if (!AlertService.isGunshotEntity(entity)) {
            return;
        }
        Entity shooter = entity instanceof Projectile projectile ? projectile.getOwner() : null;
        AlertService.handleGunshot(level, entity.getX(), entity.getY(), entity.getZ(), shooter);
    }

    /** NPC 受伤也算一种惊动；如果攻击者是玩家，NPC 会被视为已经发现玩家，从而按规则零触发。 */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!AlertConfig.HURT_COUNTS_AS_COMBAT.get()) {
            return;
        }
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        if (!AlertService.isNpc(event.getEntity())) {
            return;
        }
        AlertService.markCombat(event.getEntity());
    }

    /** NPC 被打死时，播“嫌疑人已清除 / 继续前进”的无线电。 */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide()) {
            return;
        }
        AlertService.handleNpcDeath(event.getEntity(), event.getSource());
    }
}
