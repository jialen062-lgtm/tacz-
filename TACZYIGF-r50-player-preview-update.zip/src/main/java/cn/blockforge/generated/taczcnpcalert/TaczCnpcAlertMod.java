package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueEditService;
import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueWandEvents;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * TACZ × CNPC：枪声惊动 NPC + 军需官 NPC 配装面板。
 *
 * <p>枪声部分：TaCZ 每开一枪会在服务端生成一个子弹实体，这是唯一的触发源；
 * 模组找出附近属于 CustomNPCs 的 NPC，尚未发现玩家的全部警觉，已经发现玩家的零触发，
 * 同一个 NPC 默认 1 分钟内最多警觉一次。玩家打死 NPC 时，聊天框会播
 * “玩家ID: 嫌疑人已清除!”，2 秒后再播“指挥部: 继续前进!”；这两句只认击杀者，
 * 不受距离限制。</p>
 *
 * <p>配装部分：用“NPC 界面魔杖”右键 NPC 可以把它变成军需官；再右键军需官打开面板，
 * 里面能领装备、领枪械、领子弹，也能给背包里的枪装拆 TaCZ 配件。</p>
 *
 * <p>本模组不直接依赖 TaCZ / CNPC 的 Java API：TaCZ 部分走实体注册名识别和反射，
 * CNPC 部分按注册名识别，所以缺其中任何一个时模组照样能启动，只是对应功能不会触发。</p>
 */
@Mod(TaczCnpcAlertMod.MOD_ID)
public final class TaczCnpcAlertMod {

    public static final String MOD_ID = "tacz_cnpc_alert";
    public static final Logger LOGGER = LoggerFactory.getLogger("TACZ-CNPC-Alert");

    public TaczCnpcAlertMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AlertConfig.SPEC);
        modBus.addListener(TaczCnpcAlertMod::onBuildCreativeTabs);

        ModNetwork.register();

        MinecraftForge.EVENT_BUS.addListener(GunshotEvents::onEntityJoinLevel);
        MinecraftForge.EVENT_BUS.addListener(ThrowableLauncher::onEntityJoinLevel);
        MinecraftForge.EVENT_BUS.addListener(GunshotEvents::onLivingHurt);
        MinecraftForge.EVENT_BUS.addListener(GunshotEvents::onLivingDeath);
        MinecraftForge.EVENT_BUS.addListener(DelayedTasks::onServerTick);
        MinecraftForge.EVENT_BUS.addListener((ServerStoppedEvent event) -> DelayedTasks.onServerStopped(event.getServer()));
        MinecraftForge.EVENT_BUS.addListener((ServerStartedEvent event) -> {
            TaczCompat.invalidateCache();
            MilitaryGearCatalog.invalidate();
            WeaponCatalog.invalidate();
            ThrowableLauncher.invalidate();
        });
        MinecraftForge.EVENT_BUS.addListener(AlertCommands::onRegisterCommands);
        MinecraftForge.EVENT_BUS.addListener(ExplosionProtection::onDetonate);
        MinecraftForge.EVENT_BUS.addListener(NpcThrowEvents::onLevelTick);
        MinecraftForge.EVENT_BUS.addListener(NpcThrowEvents::onChangeTarget);
        MinecraftForge.EVENT_BUS.addListener(GearWandEvents::onEntityInteract);
        MinecraftForge.EVENT_BUS.addListener(GearWandEvents::onEntityInteractSpecific);
        MinecraftForge.EVENT_BUS.addListener(GearWandEvents::onEntityInteractEmptyHand);
        MinecraftForge.EVENT_BUS.addListener(GearWandEvents::onEntityInteractEmptyHandSpecific);
        MinecraftForge.EVENT_BUS.addListener(MapWandEvents::onEntityInteract);
        MinecraftForge.EVENT_BUS.addListener(MapWandEvents::onEntityInteractSpecific);
        MinecraftForge.EVENT_BUS.addListener(MapWandEvents::onEntityInteractEmptyHand);
        MinecraftForge.EVENT_BUS.addListener(MapWandEvents::onEntityInteractEmptyHandSpecific);

        // —— 对话扩展包 ——
        MinecraftForge.EVENT_BUS.addListener(DialogueWandEvents::onEntityInteract);
        MinecraftForge.EVENT_BUS.addListener(DialogueWandEvents::onEntityInteractSpecific);
        MinecraftForge.EVENT_BUS.addListener(DialogueEditService::onChat);
        MinecraftForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent event) ->
                DialogueEditService.onLoggedOut(event.getEntity().getUUID()));

        if (ModList.get().isLoaded("tacz")) {
            LOGGER.info("已检测到 TaCZ，枪声侦测和配装面板的枪械功能可用。");
        } else {
            LOGGER.warn("没有检测到 TaCZ（modid: tacz），枪声触发和枪械页不可用。");
        }
        if (ModList.get().isLoaded("customnpcs")) {
            LOGGER.info("已检测到 CustomNPCs，NPC 警觉和军需官生效。");
        } else {
            LOGGER.warn("没有检测到 CustomNPCs（modid: customnpcs），不会有 NPC 喊话。");
        }
    }

    /** 把各类魔杖放进原版“工具与实用物品”创造模式页。 */
    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModRegistry.GEAR_WAND.get());
            event.accept(ModRegistry.MAP_WAND.get());
            event.accept(ModRegistry.DIALOGUE_WAND.get());
            event.accept(ModRegistry.DIALOGUE_EDIT_WAND.get());
        }
    }
}
