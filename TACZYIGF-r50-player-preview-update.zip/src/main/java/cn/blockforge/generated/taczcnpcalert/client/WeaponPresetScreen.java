package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.PanelActionService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** History picker for independently stored pistol and long-gun presets. */
public final class WeaponPresetScreen extends Screen {
    private final Screen parent;
    private final List<String> entries;
    private int page;
    private String categoryFilter = "all";
    private final List<Button> rows = new ArrayList<>();
    private Button previous, next;
    private static final int PAGE_SIZE = 8;

    public WeaponPresetScreen(Screen parent, List<String> entries) {
        super(Component.literal("枪械预设历史"));
        this.parent = parent;
        this.entries = List.copyOf(entries);
    }
    @Override protected void init() {
        rows.clear();
        int left = (width - 340) / 2, top = (height - 260) / 2;
        addRenderableWidget(Button.builder(Component.literal("全部"), b -> setFilter("all"))
                .bounds(left + 10, top + 34, 70, 18).build());
        addRenderableWidget(Button.builder(Component.literal("手枪"), b -> setFilter("pistols"))
                .bounds(left + 88, top + 34, 70, 18).build());
        addRenderableWidget(Button.builder(Component.literal("长枪"), b -> setFilter("long_guns"))
                .bounds(left + 166, top + 34, 70, 18).build());
        List<String> visibleEntries = filteredEntries();
        for (int i = 0; i < PAGE_SIZE; i++) {
            final int index = page * PAGE_SIZE + i;
            Button button = Button.builder(Component.literal(label(visibleEntries, index)), b -> apply(index))
                    .bounds(left + 10, top + 58 + i * 20, 320, 18).build();
            button.visible = index < visibleEntries.size();
            rows.add(addRenderableWidget(button));
        }
        previous = addRenderableWidget(Button.builder(Component.literal("上一页"), b -> { page = Math.max(0, page - 1); rebuildWidgets(); })
                .bounds(left + 10, top + 230, 80, 18).build());
        next = addRenderableWidget(Button.builder(Component.literal("下一页"), b -> { page++; rebuildWidgets(); })
                .bounds(left + 250, top + 230, 80, 18).build());
        addRenderableWidget(Button.builder(Component.literal("返回"), b -> onClose())
                .bounds(left + 130, top + 230, 80, 18).build());
        updatePageButtons();
    }
    private List<String> filteredEntries() {
        if ("all".equals(categoryFilter)) return entries;
        List<String> result = new ArrayList<>();
        for (String entry : entries) if (entry.startsWith(categoryFilter + "|")) result.add(entry);
        return result;
    }
    private void setFilter(String filter) {
        categoryFilter = filter;
        page = 0;
        rebuildWidgets();
    }
    private String label(List<String> source, int index) {
        if (index >= source.size()) return "";
        String[] p = source.get(index).split("\\|", 4);
        String type = p.length > 0 && "pistols".equals(p[0]) ? "[手枪] " : "[长枪] ";
        return type + (p.length > 2 ? p[2] : "未知预设");
    }
    private void apply(int index) {
        List<String> visibleEntries = filteredEntries();
        if (index < 0 || index >= visibleEntries.size()) return;
        String[] p = visibleEntries.get(index).split("\\|", 4);
        if (p.length < 2) return;
        ModNetwork.sendToServer(new PanelActionPacket(PanelActionService.ACTION_PRESET_APPLY, p[0] + ":" + p[1], 0));
        onClose();
    }
    private void updatePageButtons() {
        if (previous != null) previous.active = page > 0;
        if (next != null) next.active = (page + 1) * PAGE_SIZE < filteredEntries().size();
    }
    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int left = (width - 340) / 2, top = (height - 260) / 2;
        g.fill(left, top, left + 340, top + 254, 0xF9000000);
        g.fill(left, top, left + 340, top + 2, 0xFFFFA34A);
        g.drawCenteredString(font, "枪械预设历史 · 手枪 / 长枪独立保存", width / 2, top + 12, 0xFFFFFFFF);
        if (filteredEntries().isEmpty()) g.drawCenteredString(font, "当前分类还没有保存过预设", width / 2, top + 148, 0xFFAAAAAA);
        super.render(g, mx, my, pt);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
}
