package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server -> client list of saved pistol and long-gun presets. */
public final class WeaponPresetListPacket {
    private final List<String> entries;
    public WeaponPresetListPacket(List<String> entries) { this.entries = List.copyOf(entries); }
    public static void encode(WeaponPresetListPacket msg, FriendlyByteBuf buf) {
        buf.writeCollection(msg.entries, (b, s) -> b.writeUtf(s, 512));
    }
    public static WeaponPresetListPacket decode(FriendlyByteBuf buf) {
        return new WeaponPresetListPacket(buf.readCollection(ArrayList::new, b -> b.readUtf(512)));
    }
    public static void handle(WeaponPresetListPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientPanelHandler.openWeaponPresets(msg.entries)));
        ctx.setPacketHandled(true);
    }
}
