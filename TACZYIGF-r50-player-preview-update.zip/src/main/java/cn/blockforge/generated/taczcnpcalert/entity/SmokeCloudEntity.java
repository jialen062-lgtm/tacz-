package cn.blockforge.generated.taczcnpcalert.entity;

import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 烟雾区：烟雾弹落地后生成的“看不见的墙”。
 *
 * <p>实体本身不渲染任何模型，只负责两件事：</p>
 * <ul>
 *   <li>客户端每 tick 在球体内撒烟雾粒子，做视觉遮挡；</li>
 *   <li>服务端用它来判断 NPC 的视线是否被烟雾挡住
 *       （{@link #blocksSight}），挡住就丢失目标、无法索敌。</li>
 * </ul>
 */
public class SmokeCloudEntity extends Entity {

    private double radius = 4.5D;
    private int duration = 300;
    private int age;

    public SmokeCloudEntity(EntityType<? extends SmokeCloudEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
        this.blocksBuilding = false;
    }

    public SmokeCloudEntity(Level level, double x, double y, double z) {
        this(ModRegistry.SMOKE_CLOUD.get(), level);
        this.setPos(x, y, z);
    }

    public void setRadius(double radius) {
        this.radius = Math.max(1.0D, radius);
    }

    public double getRadius() {
        return this.radius;
    }

    public void setDuration(int ticks) {
        this.duration = Math.max(20, ticks);
    }

    /** 线段 from→to 是否穿过这团烟雾（球心到线段最短距离 ≤ 半径）。 */
    public boolean blocksLine(Vec3 from, Vec3 to) {
        Vec3 center = this.position();
        Vec3 dir = to.subtract(from);
        double lenSq = dir.lengthSqr();
        if (lenSq < 1.0E-4D) {
            return center.distanceToSqr(from) <= radius * radius;
        }
        double t = Math.max(0.0D, Math.min(1.0D, center.subtract(from).dot(dir) / lenSq));
        Vec3 closest = from.add(dir.x * t, dir.y * t, dir.z * t);
        return center.distanceToSqr(closest) <= radius * radius;
    }

    /** 某个点（比如目标站位）是否站在烟雾里。 */
    public boolean contains(Vec3 point) {
        return this.position().distanceToSqr(point) <= radius * radius;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            if (this.random.nextInt(2) == 0) {
                spawnSmokePuffs(4);
            }
            return;
        }
        this.age++;
        if (this.age >= this.duration) {
            this.discard();
        }
    }

    private void spawnSmokePuffs(int count) {
        RandomSource random = this.random;
        for (int i = 0; i < count; i++) {
            double x = this.getX() + (random.nextDouble() - 0.5D) * 2.0D * radius;
            double y = this.getY() + (random.nextDouble() - 0.3D) * radius;
            double z = this.getZ() + (random.nextDouble() - 0.5D) * 2.0D * radius;
            this.level().addParticle(ParticleTypes.CLOUD, x, y, z,
                    (random.nextDouble() - 0.5D) * 0.02D, 0.01D, (random.nextDouble() - 0.5D) * 0.02D);
        }
    }

    /** 视野检查：从 from 看向 to 是否被任何一片烟雾挡住，或者 to 就站在烟雾里。 */
    public static boolean blocksSight(Level level, Vec3 from, Vec3 to) {
        AABB area = new AABB(from, to).inflate(8.0D);
        for (SmokeCloudEntity cloud : level.getEntitiesOfClass(SmokeCloudEntity.class, area)) {
            if (cloud.contains(to) || cloud.blocksLine(from, to)) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("radius")) {
            this.radius = Math.max(1.0D, tag.getDouble("radius"));
        }
        if (tag.contains("duration")) {
            this.duration = Math.max(20, tag.getInt("duration"));
        }
        this.age = tag.getInt("age");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putDouble("radius", this.radius);
        tag.putInt("duration", this.duration);
        tag.putInt("age", this.age);
    }
}
