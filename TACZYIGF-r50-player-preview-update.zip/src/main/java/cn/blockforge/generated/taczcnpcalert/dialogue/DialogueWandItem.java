package cn.blockforge.generated.taczcnpcalert.dialogue;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * NPC 对话魔杖。
 *
 * <p>拿它右键一个已经写好脚本的 NPC，会弹出类 galgame 的对话界面：
 * 对话框旁边显示 NPC 和玩家本人的皮肤模型（含装备），谁说话谁亮。</p>
 */
public final class DialogueWandItem extends Item {

    public DialogueWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            player.displayClientMessage(Component.literal(
                    "拿着对话魔杖右键 NPC，即可开始对话。")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键 NPC：打开对话界面").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("NPC 台词和玩家选项用“对话编辑魔杖”编写").withStyle(ChatFormatting.GRAY));
    }
}
