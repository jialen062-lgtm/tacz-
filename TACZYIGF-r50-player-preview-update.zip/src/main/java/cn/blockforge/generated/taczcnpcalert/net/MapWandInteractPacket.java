package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.SheriffService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 客户端 → 服务端：玩家拿地图魔杖右键了某个 NPC。 */
public final class MapWandInteractPacket {

    private final int entityId;
    private final boolean sneaking;

    public MapWandInteractPacket(int entityId, boolean sneaking) {
        this.entityId = entityId;
        this.sneaking = sneaking;
    }

    public static void encode(MapWandInteractPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.entityId);
        buffer.writeBoolean(message.sneaking);
    }

    public static MapWandInteractPacket decode(FriendlyByteBuf buffer) {
        return new MapWandInteractPacket(buffer.readVarInt(), buffer.readBoolean());
    }

    public static void handle(MapWandInteractPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null || !holdsMapWand(player)) {
                return;
            }
            Entity target = player.level().getEntity(message.entityId);
            if (!(target instanceof LivingEntity npc) || !AlertService.isNpcType(npc)) {
                return;
            }
            SheriffService.handleWandUse(player, npc, message.sneaking);
        });
        context.setPacketHandled(true);
    }

    private static boolean holdsMapWand(ServerPlayer player) {
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        return main.is(ModRegistry.MAP_WAND.get()) || off.is(ModRegistry.MAP_WAND.get());
    }
}
