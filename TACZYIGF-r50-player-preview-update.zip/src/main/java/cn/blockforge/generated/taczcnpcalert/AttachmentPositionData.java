package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

/** Stores per-gun, per-slot attachment offsets. Values are model-space units. */
public final class AttachmentPositionData {
    private static final String ROOT = "TaczCnpcAlertAttachmentOffsets";
    private AttachmentPositionData() {}

    public record Offset(double x, double y, double z) {
        public Offset {
            x = clamp(x); y = clamp(y); z = clamp(z);
        }
        private static double clamp(double v) {
            if (!Double.isFinite(v)) return 0.0D;
            return Math.max(-1.0D, Math.min(1.0D, v));
        }
        public boolean isZero() { return x == 0.0D && y == 0.0D && z == 0.0D; }
    }

    public static String attachmentKey(ItemStack attachment) {
        if (attachment == null || attachment.isEmpty()) return "";
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(attachment.getItem());
        return id == null ? "" : id.toString();
    }

    public static Offset get(ItemStack gun, String slot, ItemStack attachment) {
        if (gun == null || gun.isEmpty() || slot == null) return new Offset(0, 0, 0);
        String attachmentId = attachmentKey(attachment);
        if (attachmentId.isEmpty()) return new Offset(0, 0, 0);
        CompoundTag root = gun.getTagElement(ROOT);
        if (root == null) return new Offset(0, 0, 0);
        CompoundTag slotTag = root.getCompound(slot);
        CompoundTag value = slotTag.getCompound(attachmentId);
        return new Offset(value.getDouble("x"), value.getDouble("y"), value.getDouble("z"));
    }

    /** Server-side caller must validate AttachmentMovementRules before invoking this method. */
    public static void set(ItemStack gun, String slot, ItemStack attachment, double x, double y, double z) {
        if (gun == null || gun.isEmpty() || slot == null) return;
        String attachmentId = attachmentKey(attachment);
        if (attachmentId.isEmpty()) return;
        Offset offset = new Offset(x, y, z);
        CompoundTag root = gun.getOrCreateTagElement(ROOT);
        CompoundTag slotTag = root.getCompound(slot);
        if (offset.isZero()) {
            slotTag.remove(attachmentId);
        } else {
            CompoundTag value = new CompoundTag();
            value.putDouble("x", offset.x());
            value.putDouble("y", offset.y());
            value.putDouble("z", offset.z());
            slotTag.put(attachmentId, value);
        }
        if (slotTag.isEmpty()) root.remove(slot); else root.put(slot, slotTag);
        if (root.isEmpty()) gun.removeTagKey(ROOT);
    }
}
