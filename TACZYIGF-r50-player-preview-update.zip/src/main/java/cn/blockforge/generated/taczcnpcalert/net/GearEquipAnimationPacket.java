package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** 服务端确认穿戴成功后，通知客户端播放对应部位的推进动画。 */
public final class GearEquipAnimationPacket {
    private final int category;
    public GearEquipAnimationPacket(int category) { this.category = category; }
    public static void encode(GearEquipAnimationPacket msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.category); }
    public static GearEquipAnimationPacket decode(FriendlyByteBuf buf) { return new GearEquipAnimationPacket(buf.readVarInt()); }
    public static void handle(GearEquipAnimationPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPanelHandler.playGearEquipAnimation(msg.category)));
        ctx.setPacketHandled(true);
    }
}
