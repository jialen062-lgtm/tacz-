package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Enforces the armory's one-main/one-secondary/one-melee/one-type-of-throwable rules. */
public final class LoadoutInventoryService {
    private static final String TAG_ROLE = "taczyigf_loadout_role";
    private static final String ROLE_MAIN = "main";
    private static final String ROLE_SECONDARY = "secondary";
    private static final String ROLE_MELEE = "melee";
    private static final String ROLE_THROWABLE = "throwable";
    private static final String TAG_THROWABLE_ID = "taczyigf_throwable_id";
    private static final int HOTBAR_SIZE = 9;

    private LoadoutInventoryService() {}

    public static boolean equipGun(ServerPlayer player, ItemStack incoming) {
        if (incoming.isEmpty() || !TaczCompat.isGun(incoming)) return false;
        Inventory inv = player.getInventory();
        migrateLegacyGuns(inv);
        int selected = clampHotbar(inv.selected);
        ItemStack held = inv.getItem(selected);
        String heldRole = role(held);

        String targetRole;
        if (TaczCompat.isGun(held)) {
            if (heldRole == null) {
                heldRole = hasRole(inv, ROLE_MAIN) ? ROLE_SECONDARY : ROLE_MAIN;
                setRole(held, heldRole);
            }
            targetRole = ROLE_MAIN.equals(heldRole) ? ROLE_SECONDARY : ROLE_MAIN;
        } else {
            targetRole = hasRole(inv, ROLE_MAIN) ? ROLE_SECONDARY : ROLE_MAIN;
        }

        // Remove the previous gun of the same class. The other class is never touched.
        removeRole(inv, targetRole);
        setRole(incoming, targetRole);

        int destination;
        if (TaczCompat.isGun(held) && role(held) != null && !targetRole.equals(role(held))) {
            destination = adjacentFreeHotbar(inv, selected);
        } else {
            destination = selected;
            if (destination == selected && !inv.getItem(destination).isEmpty()) {
                // Replacing the same-class gun is intentional; never overwrite a non-gun item.
                if (!TaczCompat.isGun(inv.getItem(destination))) destination = adjacentFreeHotbar(inv, selected);
            }
        }
        if (destination < 0) destination = firstEmpty(inv);
        if (destination < 0) return false;

        inv.setItem(destination, incoming.copy());
        inv.selected = destination;
        inv.setChanged();
        player.containerMenu.broadcastChanges();
        return true;
    }

    public static boolean equipThrowable(ServerPlayer player, ItemStack incoming, String id) {
        if (incoming.isEmpty()) return false;
        Inventory inv = player.getInventory();
        int oldSlot = findRole(inv, ROLE_THROWABLE);
        ItemStack old = oldSlot < 0 ? ItemStack.EMPTY : inv.getItem(oldSlot);
        String oldId = old.isEmpty() || !old.hasTag() ? null : old.getTag().getString(TAG_THROWABLE_ID);
        if (id.equals(oldId)) {
            if (old.getCount() >= 2) {
                hint(player, "同一种投掷物最多携带两个。");
                return true;
            }
            old.grow(1);
            inv.selected = oldSlot;
        } else {
            if (oldSlot >= 0) inv.setItem(oldSlot, ItemStack.EMPTY);
            incoming.setCount(Math.min(2, incoming.getCount()));
            CompoundTag tag = incoming.getOrCreateTag();
            tag.putString(TAG_ROLE, ROLE_THROWABLE);
            tag.putString(TAG_THROWABLE_ID, id);
            int destination = oldSlot >= 0 ? oldSlot : clampHotbar(inv.selected);
            // The first throwable may occupy the selected slot; if it contains a gun or
            // another loadout item, use the nearest empty slot rather than deleting it.
            if (!inv.getItem(destination).isEmpty()) {
                int empty = adjacentOrAnyEmpty(inv, clampHotbar(inv.selected));
                if (empty < 0) return false;
                destination = empty;
            }
            inv.setItem(destination, incoming.copy());
            inv.selected = destination;
        }
        inv.setChanged();
        player.containerMenu.broadcastChanges();
        return true;
    }

    public static boolean equipMelee(ServerPlayer player, ItemStack incoming) {
        if (incoming.isEmpty()) return false;
        Inventory inv = player.getInventory();
        int oldSlot = findRole(inv, ROLE_MELEE);
        int destination = oldSlot >= 0 ? oldSlot : clampHotbar(inv.selected);
        if (oldSlot >= 0) inv.setItem(oldSlot, ItemStack.EMPTY);
        else if (!inv.getItem(destination).isEmpty()) {
            destination = adjacentOrAnyEmpty(inv, clampHotbar(inv.selected));
            if (destination < 0) return false;
        }
        setRole(incoming, ROLE_MELEE);
        inv.setItem(destination, incoming.copy());
        inv.selected = destination;
        inv.setChanged();
        player.containerMenu.broadcastChanges();
        return true;
    }

    private static int adjacentFreeHotbar(Inventory inv, int anchor) {
        int right = anchor + 1;
        int left = anchor - 1;
        if (right < HOTBAR_SIZE && inv.getItem(right).isEmpty()) return right;
        if (left >= 0 && inv.getItem(left).isEmpty()) return left;
        for (int distance = 2; distance < HOTBAR_SIZE; distance++) {
            right = anchor + distance;
            left = anchor - distance;
            if (right < HOTBAR_SIZE && inv.getItem(right).isEmpty()) return right;
            if (left >= 0 && inv.getItem(left).isEmpty()) return left;
        }
        return -1;
    }

    private static int adjacentOrAnyEmpty(Inventory inv, int anchor) {
        int hotbar = adjacentFreeHotbar(inv, anchor);
        return hotbar >= 0 ? hotbar : firstEmpty(inv);
    }

    private static int firstEmpty(Inventory inv) {
        for (int i = HOTBAR_SIZE; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).isEmpty()) return i;
        }
        for (int i = 0; i < HOTBAR_SIZE; i++) {
            if (inv.getItem(i).isEmpty()) return i;
        }
        return -1;
    }

    private static int clampHotbar(int slot) {
        return Math.max(0, Math.min(HOTBAR_SIZE - 1, slot));
    }

    private static String role(ItemStack stack) {
        return stack.isEmpty() || !stack.hasTag() ? null : stack.getTag().getString(TAG_ROLE);
    }

    private static void setRole(ItemStack stack, String role) {
        stack.getOrCreateTag().putString(TAG_ROLE, role);
    }

    private static void migrateLegacyGuns(Inventory inv) {
        boolean mainFound = hasRole(inv, ROLE_MAIN);
        boolean secondaryFound = hasRole(inv, ROLE_SECONDARY);
        // Give the currently held legacy gun first claim on the missing role; it is
        // the reference weapon the player is actively using for adjacent placement.
        int selected = clampHotbar(inv.selected);
        ItemStack held = inv.getItem(selected);
        if (TaczCompat.isGun(held) && role(held) == null) {
            if (!mainFound) {
                setRole(held, ROLE_MAIN);
                mainFound = true;
            } else if (!secondaryFound) {
                setRole(held, ROLE_SECONDARY);
                secondaryFound = true;
            }
        }
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (i == selected) continue;
            ItemStack stack = inv.getItem(i);
            if (!TaczCompat.isGun(stack) || role(stack) != null) continue;
            if (!mainFound) {
                setRole(stack, ROLE_MAIN);
                mainFound = true;
            } else if (!secondaryFound) {
                setRole(stack, ROLE_SECONDARY);
                secondaryFound = true;
            }
        }
    }

    private static boolean hasRole(Inventory inv, String role) {
        return findRole(inv, role) >= 0;
    }

    private static int findRole(Inventory inv, String role) {
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (role.equals(role(inv.getItem(i)))) return i;
        }
        return -1;
    }

    private static void removeRole(Inventory inv, String role) {
        int slot = findRole(inv, role);
        if (slot >= 0) inv.setItem(slot, ItemStack.EMPTY);
    }

    private static void hint(ServerPlayer player, String message) {
        cn.blockforge.generated.taczcnpcalert.net.ModNetwork.sendToPlayer(
                new cn.blockforge.generated.taczcnpcalert.net.PanelNoticePacket(message), player);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal(message), true);
    }
}
