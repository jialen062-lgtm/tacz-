package cn.blockforge.generated.taczcnpcalert;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * “近战武器”和“投掷物”两页清单的自动识别。
 *
 * <p>识别规则和装备页一样走“白名单命名空间 + 注册名关键词”，不硬依赖 TaCZ 或任何扩展包的类：
 * 装了 TaCZ、绿葡萄战术攻防或别的军事扩展包时，它们的刀、斧、雷会自动出现在
 * 军需官面板里；投掷物页只显示外部扩展包的真实投掷物，不生成本模组自制雷。</p>
 *
 * <p>结果缓存，服务端启动 / reload 时重算。</p>
 */
public final class WeaponCatalog {

    /** 近战：注册名里出现这些单词就算近战武器。 */
    private static final Set<String> MELEE_TOKENS = Set.of(
            "melee", "knife", "knives", "bayonet", "machete", "katana", "dagger",
            "tomahawk", "hatchet", "kukri", "gladius", "fist", "brassknuckle", "crowbar",
            // lrtactical 的命名不一定包含 knife / grenade 等通用关键词。
            "baseball", "karambit");

    /** 投掷：注册名关键词。 */
    private static final Set<String> THROWABLE_TOKENS = Set.of(
            "grenade", "frag", "molotov", "flashbang", "smoke", "incendiary",
            "bomb", "throwable", "stun", "detonate",
            // 绿葡萄战术攻防使用的具体型号：M67、RGN、C4。
            "m67", "rgn", "c4");

    /** 物品类名关键词：注册名认不出来时（比如雷叫 m67），按物品的 Java 类名兜底认。 */
    private static final Set<String> MELEE_CLASS_TOKENS = Set.of("melee");
    private static final Set<String> THROWABLE_CLASS_TOKENS = Set.of(
            "grenade", "throwable", "throwitem", "bomb", "explosive");

    /** 明显不是近战 / 投掷的关键词（防弹衣型号里常带 "combat_knife"? 不会；主要是挡面罩、弹药这类）。 */
    private static final Set<String> EXCLUDE_TOKENS = Set.of(
            "mask", "goggles", "helmet", "chestplate", "leggings", "boots", "uniform",
            "vest", "plate", "ammo", "magazine", "mag", "launcher", "rifle", "pistol",
            "carbine", "shotgun", "smg", "lmg", "scope", "muzzle", "stock", "grip", "laser");

    /** 绿葡萄的 modid 固定加入扫描，避免旧配置文件仍只有旧默认值时漏掉近战。 */
    private static final List<String> KNOWN_EXTERNAL_NAMESPACES = List.of(
            "lrtactical", "tacz", "fracturepoint");

    private static List<ResourceLocation> meleeCache;
    private static List<ResourceLocation> throwableCache;

    private WeaponCatalog() {
    }

    public static synchronized void invalidate() {
        meleeCache = null;
        throwableCache = null;
        // 注意：这里不顺手清 ThrowableLauncher 的缓存。
        // 那边的缓存方法会反过来读本类，两边同时持锁有死锁风险，改由主类按顺序分别调用。
    }

    /** 近战页清单。 */
    public static synchronized List<ResourceLocation> meleeIds() {
        if (meleeCache == null) {
            meleeCache = build(AlertConfig.MELEE_NAMESPACES.get(), AlertConfig.MELEE_EXTRA.get(),
                    MELEE_TOKENS, MELEE_CLASS_TOKENS, false);
        }
        return meleeCache;
    }

    /** 投掷物页清单：只列出绿葡萄等外部扩展包的真实投掷物。 */
    public static synchronized List<ResourceLocation> throwableIds() {
        if (throwableCache == null) {
            throwableCache = build(AlertConfig.THROWABLE_NAMESPACES.get(), AlertConfig.THROWABLE_EXTRA.get(),
                    THROWABLE_TOKENS, THROWABLE_CLASS_TOKENS, true).stream()
                    .filter(id -> !id.getNamespace().equalsIgnoreCase(TaczCnpcAlertMod.MOD_ID))
                    .toList();
        }
        return throwableCache;
    }

    /** 供 NPC 投掷使用的外部真实投掷物，和军需官面板显示的清单完全一致。 */
    public static List<ResourceLocation> thirdPartyThrowableIds() {
        return throwableIds();
    }

    /** 给爆炸保护用：路径里带投掷关键词（如 grenade / frag / bomb）就算“雷类”。 */
    public static boolean looksLikeGrenadePath(String path) {
        if (path == null) {
            return false;
        }
        String lower = path.toLowerCase(Locale.ROOT);
        for (String token : THROWABLE_TOKENS) {
            if (lower.contains(token)) {
                return true;
            }
        }
        return false;
    }

    /** 命名空间是否属于要扫描的投掷白名单。 */
    public static boolean isThrowableNamespace(String namespace) {
        for (String candidate : AlertConfig.THROWABLE_NAMESPACES.get()) {
            if (candidate != null && candidate.equalsIgnoreCase(namespace)) {
                return true;
            }
        }
        return namespace.equalsIgnoreCase(TaczCnpcAlertMod.MOD_ID);
    }

    private static List<ResourceLocation> build(List<? extends String> configNamespaces,
                                                List<? extends String> extras,
                                                Set<String> tokens, Set<String> classTokens,
                                                boolean alwaysScanEveryNamespace) {
        LinkedHashSet<ResourceLocation> ids = new LinkedHashSet<>();

        // 1) 配置里手动写的。
        for (String raw : extras) {
            ResourceLocation id = parse(raw);
            if (id != null) {
                addIfRegistered(ids, id);
            }
        }

        // 2) TaCZ 近战：反射读它自己的武器索引，能读到多少算多少。
        if (tokens == MELEE_TOKENS) {
            for (ResourceLocation id : TaczCompat.allMeleeIds()) {
                addIfRegistered(ids, id);
            }
            // lrtactical 的每把刀是数据索引，不是独立注册物品。
            ids.addAll(LrtacticalCompat.allMeleeIds());
        } else if (tokens == THROWABLE_TOKENS) {
            // 同理：M67 / RGN / C4 等通过通用 throwable 物品 + 索引 ID 构造。
            ids.addAll(LrtacticalCompat.allThrowableIds());
        }

        // 3) 白名单命名空间里按注册名 / 物品类名自动认。
        ScanReport report = scanNamespaces(ids, namespacesWithKnownExternal(configNamespaces), tokens, classTokens);

        // 4) 兜底：白名单没认出东西时，把整个注册表扫一遍。
        //    投掷物直接一直扫——关键词（grenade / frag / smoke …）够特别，
        //    这样不管绿葡萄战术攻防用的是哪个 modid，它的雷都能自动出现在面板里。
        if (alwaysScanEveryNamespace || report.foundNothingThirdParty()) {
            scanNamespaces(ids, null, tokens, classTokens);
        }
        return List.copyOf(ids);
    }

    private static List<String> namespacesWithKnownExternal(List<? extends String> configured) {
        LinkedHashSet<String> merged = new LinkedHashSet<>(KNOWN_EXTERNAL_NAMESPACES);
        if (configured != null) {
            merged.addAll(configured);
        }
        return List.copyOf(merged);
    }

    /** 扫描结果小记：有没有认出“别的 mod”的物品、白名单认出了几个。 */
    private record ScanReport(int matched, int thirdParty) {
        boolean foundNothingThirdParty() {
            return thirdParty == 0;
        }
    }

    /**
     * 扫注册表。{@code namespaces} 为 null 表示不按命名空间过滤（扫全部物品）。
     */
    private static ScanReport scanNamespaces(Set<ResourceLocation> ids,
                                             List<? extends String> namespaces,
                                             Set<String> tokens, Set<String> classTokens) {
        Set<String> wanted = new HashSet<>();
        if (namespaces != null) {
            for (String raw : namespaces) {
                if (raw != null && !raw.isBlank()) {
                    wanted.add(raw.trim().toLowerCase(Locale.ROOT));
                }
            }
            if (wanted.isEmpty()) {
                return new ScanReport(0, 0);
            }
        }
        int matched = 0;
        int thirdParty = 0;
        for (ResourceLocation id : ForgeRegistries.ITEMS.getKeys()) {
            if (wanted != null && !wanted.contains(id.getNamespace().toLowerCase(Locale.ROOT))) {
                continue;
            }
            if (ids.contains(id)) {
                continue; // 已经被前一步（手动清单 / TaCZ 索引）加进去了
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item == null || item instanceof BlockItem) {
                continue;
            }
            if (!matches(id.getPath(), item, tokens, classTokens)) {
                continue;
            }
            matched++;
            if (!id.getNamespace().equalsIgnoreCase(TaczCnpcAlertMod.MOD_ID)) {
                thirdParty++;
            }
            ids.add(id);
        }
        return new ScanReport(matched, thirdParty);
    }

    private static boolean matches(String path, Item item, Set<String> tokens, Set<String> classTokens) {
        Set<String> parts = tokensOf(path);
        boolean byName = false;
        for (String token : tokens) {
            if (parts.contains(token)) {
                byName = true;
                break;
            }
        }
        String simpleName = item.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        boolean byClass = false;
        for (String classToken : classTokens) {
            if (simpleName.contains(classToken)) {
                byClass = true;
                break;
            }
        }
        if (!byName && !byClass) {
            return false;
        }
        for (String token : parts) {
            if (EXCLUDE_TOKENS.contains(token)) {
                return false;
            }
        }
        return true;
    }

    private static Set<String> tokensOf(String path) {
        Set<String> tokens = new HashSet<>();
        if (path == null || path.isBlank()) {
            return tokens;
        }
        for (String part : path.toLowerCase(Locale.ROOT).split("[_/]")) {
            if (!part.isBlank()) {
                tokens.add(part);
            }
        }
        return tokens;
    }

    private static void addIfRegistered(Set<ResourceLocation> target, ResourceLocation id) {
        if (id != null && ForgeRegistries.ITEMS.containsKey(id)) {
            target.add(id);
        }
    }

    private static ResourceLocation parse(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        return ResourceLocation.tryParse(raw.trim());
    }
}
