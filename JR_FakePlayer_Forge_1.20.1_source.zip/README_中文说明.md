# JR FakePlayer Command Bridge（Forge 1.20.1）

## 功能

增加短命令 `/jr <玩家ID>`，将其转交给底层 Advanced Fake Players 模组的 `/fakeplayer spawn <玩家ID>`。

同时提供：

- `/jr remove <玩家ID>`：删除测试假玩家。
- `/jr list`：列出底层模组登记的假玩家。

命令需要 OP 等级 2 或更高权限。

## 重要：这是一个命令桥接模组

本模组不自行伪造网络连接或构造普通生物来冒充玩家。实际 `ServerPlayer` 假玩家由 Advanced Fake Player（提供 `/fakeplayer` 命令的底层模组）创建、加入服务器玩家列表并管理存档。因此必须同时安装底层模组。本工程不把底层模组的内部 mod ID 写死为硬依赖，而是在执行命令时检查 `/fakeplayer` 命令是否存在。

底层模组：Advanced Fake Player（Forge 1.20.1）
https://modrinth.com/mod/advanced-fake-player

安装底层模组和本模组时，均需放入服务器的 `mods` 文件夹；客户端也安装两者，确保客户端与服务器模组列表一致。

底层模组会按生成时使用的玩家名查询 Mojang 账号皮肤。若输入的是有效正版 Java Edition 用户名，底层模组会尝试取得该账号皮肤；1-2 位名字不可能对应正版 Java 账号，底层模组文档说明这类名字会使用默认皮肤。离线/非正版名称不会因此变成正版账号，也不会获得该账号的皮肤。

## 环境

- Minecraft Java Edition 1.20.1
- Minecraft Forge 47.x（本工程按 47.2.8 编译）
- Java 17
- Advanced Fake Players 1.0.0 或更高版本

## 使用

```text
/jr Notch
/jr remove Notch
/jr list
```

## 编译

在仓库根目录执行：

```bash
gradle build --no-daemon
```

成功后 JAR 位于 `build/libs/`。仓库已附带 GitHub Actions 工作流；推送到 main/master 后会自动构建并上传 JAR Artifact。

## 权限与安全说明

命令仅允许 OP 等级 2 或更高权限的来源执行。假玩家的创建、玩家列表行为和存档由底层依赖模组处理。
