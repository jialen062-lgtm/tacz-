package com.blockforge.jrfakeplayer;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.regex.Pattern;

/**
 * Adds short /jr aliases for the Advanced Fake Players command set.
 * The companion mod creates and manages the actual ServerPlayer fake.
 */
@Mod(JRFakePlayerMod.MOD_ID)
public final class JRFakePlayerMod {
    public static final String MOD_ID = "jr_fakeplayer";
    private static final Pattern VALID_PLAYER_NAME = Pattern.compile("^[A-Za-z0-9_]{1,16}$");

    public JRFakePlayerMod() {
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
            Commands.literal("jr")
                .requires(source -> source.hasPermission(2))
                // /jr <playerID> -> /fakeplayer spawn <playerID>
                .then(Commands.argument("playerId", StringArgumentType.word())
                    .executes(context -> {
                        String playerId = StringArgumentType.getString(context, "playerId");
                        if (!isValidPlayerName(playerId)) {
                            context.getSource().sendFailure(Component.literal(
                                "玩家ID格式无效。只允许 1-16 位英文字母、数字和下划线。"
                            ));
                            return 0;
                        }
                        return forward(context.getSource(), "fakeplayer spawn " + playerId);
                    })
                )
                // /jr remove <playerID> -> /fakeplayer remove <playerID>
                .then(Commands.literal("remove")
                    .then(Commands.argument("playerId", StringArgumentType.word())
                        .executes(context -> {
                            String playerId = StringArgumentType.getString(context, "playerId");
                            if (!isValidPlayerName(playerId)) {
                                context.getSource().sendFailure(Component.literal("玩家ID格式无效。"));
                                return 0;
                            }
                            return forward(context.getSource(), "fakeplayer remove " + playerId);
                        })
                    )
                )
                // /jr list -> /fakeplayer list
                .then(Commands.literal("list")
                    .executes(context -> forward(context.getSource(), "fakeplayer list"))
                )
        );
    }

    private static boolean isValidPlayerName(String playerId) {
        return playerId != null && VALID_PLAYER_NAME.matcher(playerId).matches();
    }

    private static int forward(CommandSourceStack source, String command) {
        // Avoid a startup hard-dependency on a particular companion mod ID:
        // the bridge only needs its documented /fakeplayer command root.
        if (source.getServer().getCommands().getDispatcher().getRoot().getChild("fakeplayer") == null) {
            source.sendFailure(Component.literal(
                "未检测到 /fakeplayer 命令。请先安装并启用 Advanced Fake Player（Forge 1.20.1）模组。"
            ));
            return 0;
        }

        // Re-dispatch through the server command dispatcher so the companion mod
        // performs its normal permission checks, player creation, skin lookup,
        // player-list registration and persistence handling.
        return source.getServer().getCommands().performPrefixedCommand(source, command);
    }
}
