# TACZYIGF r51 预览与配件替换改造

基于 r50 的源码修改，版本号为 `1.0.0-r51`。

## 本次变更

1. 枪械页选中枪械时，中央预览改为玩家上半身持有当前选中枪械；切换枪械会同步替换主手物品。
2. 人物预览增加配置文件偏移：`player_preview_x`、`player_preview_y`、`player_preview_z`，单位为 GUI 像素，默认 0，允许范围 -200 到 200。
3. 移除配件位置编辑状态、拖动偏移和滚轮改偏移入口。点击已安装配件槽位会打开该槽位配件列表。
4. 同一槽位替换配件时先卸下旧配件；如果新配件安装失败，则恢复原枪副本，避免丢失旧配件。
5. 重做人物预览旋转：左右按钮每次旋转 90 度；枪械页预览也支持拖动细调人物旋转；只旋转预览，不改变游戏内玩家朝向。
6. 枪械/物品模型预览启用标准 alpha 混合并关闭面剔除，尝试避免部分材质面消失或看似透明。
7. 物品模型旋转枢轴改为按 BakedModel 实际顶点计算几何包围盒中心，旋转与缩放均围绕该中心执行；无法读取顶点时回退到标准物品中心。
8. 保留 r50 的模型裁切修复及其他现有功能。

## 旋转枢轴补充

TaCZ 枪械优先通过反射读取 `GunDisplayInstance` 的 `BedrockGunModel.getOffset()`，并应用与 `FIXED` 预览相同的 `GunItemTransforms`，使旋转枢轴与 TaCZ 实际 Bedrock 模型中心一致；不增加 TaCZ 硬编译依赖。其他普通物品模型读取 unculled 与六个方向 quad 顶点，计算 XYZ 包围盒中心。旋转和缩放都围绕计算出的中心进行。若第三方模型 API 不可用或模型没有可读取几何，则回退到通用模型中心，避免预览崩溃。

## 配置文件

游戏启动后，客户端配置文件位于：

`config/taczyigf-graphics.properties`

其中新增：

```properties
player_preview_x=0.0
player_preview_y=0.0
player_preview_z=0.0
```

- X：左右偏移
- Y：上下偏移
- Z：前后深度偏移

调整后保存文件并重启游戏/重新打开界面观察效果。偏移范围为 -200 到 200。

## 构建

仓库工作流：`.github/workflows/build-r51.yml`

工作流要求仓库根目录存在 `TACZYIGF-r51-preview-rework-source.zip`，运行后会上传 `TACZYIGF-r51-preview-rework` artifact。

**验证说明：** 当前工作环境没有 Gradle 可执行程序，且无法访问外网下载 Gradle，因此尚未完成 Gradle 编译，也没有进行 Minecraft 客户端实测。透明材质处理和人物上半身取景仍需在游戏中验证。
