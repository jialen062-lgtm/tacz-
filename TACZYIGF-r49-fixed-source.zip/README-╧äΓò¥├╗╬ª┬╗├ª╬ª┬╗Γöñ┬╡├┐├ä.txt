TACZ × CNPC 警报模组 —— r42 版本源码
=====================================

这是什么
  本压缩包是 1.0.0-r42 版 jar 的完整工程源码（对应 2026-11-11 那次构建）。
  注意：这是"源码"，不是放进 mods 文件夹就能用的成品模组。

环境要求
  - JDK 17
  - Gradle（工程未包含 gradlew 包装器，用本机 Gradle 8.x 即可）
  - 联网：首次构建会自动下载 Minecraft 1.20.1 / Forge 47.x 的依赖

怎么编译
  在解压目录执行：  gradle build
  产物在：          build/libs/tacz_cnpc_alert-1.0.0-r42.jar
  把这个 jar 放进游戏的 mods 文件夹即可。

依赖的前置模组
  - Minecraft Forge 1.20.1（47.x）
  - TaCZ（枪械模组）、Creates NPCs（CNPC）等，详见 build.gradle 和 mods.toml

主要代码位置
  src/main/java/cn/blockforge/generated/taczcnpcalert/   模组逻辑
  src/main/resources/assets/                             贴图、模型、语言文件
