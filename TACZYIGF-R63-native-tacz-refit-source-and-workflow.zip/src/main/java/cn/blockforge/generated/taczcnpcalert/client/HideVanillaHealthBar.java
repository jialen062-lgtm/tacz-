package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** 隐藏原版红心血条（自定义血量显示已按需求移除）。 */
@Mod.EventBusSubscriber(modid = TaczCnpcAlertMod.MOD_ID)
public final class HideVanillaHealthBar {

    private HideVanillaHealthBar() {}

    @SubscribeEvent
    public static void onOverlayPre(RenderGuiOverlayEvent.Pre event) {
        if ("minecraft".equals(event.getOverlay().id().getNamespace())
                && "health".equals(event.getOverlay().id().getPath())) {
            event.setCanceled(true);
        }
    }
}
