package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.NativeRefitSessionService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: start the quartermaster's native TaCZ refit session. */
public final class BeginNativeRefitPacket {
    private final int npcId;

    public BeginNativeRefitPacket(int npcId) {
        this.npcId = npcId;
    }

    public static void encode(BeginNativeRefitPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.npcId);
    }

    public static BeginNativeRefitPacket decode(FriendlyByteBuf buffer) {
        return new BeginNativeRefitPacket(buffer.readVarInt());
    }

    public static void handle(BeginNativeRefitPacket message, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                NativeRefitSessionService.begin(player, message.npcId);
            }
        });
        context.setPacketHandled(true);
    }
}
