package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.NativeRefitSessionService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: install a catalog attachment without requiring a physical attachment item. */
public final class InstallVirtualAttachmentPacket {
    private final String attachmentId;
    private final String attachmentSlot;

    public InstallVirtualAttachmentPacket(String attachmentId, String attachmentSlot) {
        this.attachmentId = attachmentId == null ? "" : attachmentId;
        this.attachmentSlot = attachmentSlot == null ? "" : attachmentSlot;
    }

    public static void encode(InstallVirtualAttachmentPacket message, FriendlyByteBuf buffer) {
        buffer.writeUtf(message.attachmentId, 256);
        buffer.writeUtf(message.attachmentSlot, 32);
    }

    public static InstallVirtualAttachmentPacket decode(FriendlyByteBuf buffer) {
        return new InstallVirtualAttachmentPacket(buffer.readUtf(256), buffer.readUtf(32));
    }

    public static void handle(InstallVirtualAttachmentPacket message, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                NativeRefitSessionService.installVirtualAttachment(
                        player, message.attachmentId, message.attachmentSlot);
            }
        });
        context.setPacketHandled(true);
    }
}
