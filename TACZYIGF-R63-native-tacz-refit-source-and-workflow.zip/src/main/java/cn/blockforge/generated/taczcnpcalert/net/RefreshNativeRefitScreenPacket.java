package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.NativeRefitClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: rebuild TaCZ's native refit widgets after an attachment update. */
public final class RefreshNativeRefitScreenPacket {
    public static void encode(RefreshNativeRefitScreenPacket message, FriendlyByteBuf buffer) {}
    public static RefreshNativeRefitScreenPacket decode(FriendlyByteBuf buffer) {
        return new RefreshNativeRefitScreenPacket();
    }

    public static void handle(RefreshNativeRefitScreenPacket message, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> NativeRefitClientState::refreshCurrentScreen));
        context.setPacketHandled(true);
    }
}
