package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.NativeRefitClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: open TaCZ's own GunRefitScreen on the staged inventory gun. */
public final class OpenNativeRefitScreenPacket {
    private final int originalSelected;
    private final int activeSlot;

    public OpenNativeRefitScreenPacket(int originalSelected, int activeSlot) {
        this.originalSelected = originalSelected;
        this.activeSlot = activeSlot;
    }

    public static void encode(OpenNativeRefitScreenPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.originalSelected);
        buffer.writeVarInt(message.activeSlot);
    }

    public static OpenNativeRefitScreenPacket decode(FriendlyByteBuf buffer) {
        return new OpenNativeRefitScreenPacket(buffer.readVarInt(), buffer.readVarInt());
    }

    public static void handle(OpenNativeRefitScreenPacket message, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> NativeRefitClientState.open(message.originalSelected, message.activeSlot)));
        context.setPacketHandled(true);
    }
}
