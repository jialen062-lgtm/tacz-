package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenNativeRefitScreenPacket;
import cn.blockforge.generated.taczcnpcalert.net.RefreshNativeRefitScreenPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.protocol.game.ClientboundSetCarriedItemPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.ModList;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-authoritative session for the native TaCZ refit screen.
 *
 * The real gun ItemStack is temporarily staged in a hotbar slot because TaCZ's
 * own GunRefitScreen reads LocalPlayer#getMainHandItem(). It is moved back to
 * its original inventory slot when the screen closes or the player disconnects.
 */
public final class NativeRefitSessionService {
    private record Session(int originalSelected, int originalGunSlot, int activeSlot, boolean moved) {}

    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();

    private NativeRefitSessionService() {}

    public static void begin(ServerPlayer player, int npcId) {
        if (!ModList.get().isLoaded("tacz") || !TaczCompat.isAvailable()) {
            hint(player, "没有检测到可用的 TaCZ，无法打开原版改枪界面。");
            return;
        }

        Entity target = player.level().getEntity(npcId);
        if (!(target instanceof LivingEntity npc)
                || !QuartermasterService.isQuartermaster(npc)
                || !AlertService.isNpcType(npc)
                || player.distanceToSqr(npc) > 64.0D) {
            hint(player, "军需官状态已失效，请重新与军需官交互。");
            return;
        }

        // Close any stale session before starting another one.
        end(player);

        Inventory inventory = player.getInventory();
        int originalSelected = inventory.selected;
        int gunSlot = findGunSlot(inventory);
        if (gunSlot < 0) {
            hint(player, "背包里没有检测到 TaCZ 枪械，请先领取或放入一把枪。");
            return;
        }

        int activeSlot = gunSlot;
        boolean moved = false;
        if (gunSlot >= 9) {
            // Move the same stack (not a copy) into the currently selected hotbar slot.
            // The item displaced from the hotbar is staged in the gun's original slot.
            activeSlot = Math.max(0, Math.min(8, originalSelected));
            ItemStack gunStack = inventory.getItem(gunSlot);
            ItemStack displaced = inventory.getItem(activeSlot);
            inventory.setItem(activeSlot, gunStack);
            inventory.setItem(gunSlot, displaced);
            moved = true;
        }

        inventory.selected = activeSlot;
        inventory.setChanged();
        SESSIONS.put(player.getUUID(), new Session(originalSelected, gunSlot, activeSlot, moved));

        player.inventoryMenu.broadcastChanges();
        player.connection.send(new ClientboundSetCarriedItemPacket(activeSlot));

        ItemStack activeGun = inventory.getItem(activeSlot);
        hint(player, "已检测到背包枪械：" + TaczCompat.displayName(activeGun) + "。改装将直接写入这把枪。");
        ModNetwork.sendToPlayer(new OpenNativeRefitScreenPacket(originalSelected, activeSlot), player);
    }

    private static int findGunSlot(Inventory inventory) {
        int selected = Math.max(0, Math.min(8, inventory.selected));
        if (TaczCompat.isGun(inventory.getItem(selected))) return selected;

        // Prefer another hotbar gun so no inventory swap is necessary.
        for (int slot = 0; slot < 9; slot++) {
            if (slot != selected && TaczCompat.isGun(inventory.getItem(slot))) return slot;
        }
        for (int slot = 9; slot < 36; slot++) {
            if (TaczCompat.isGun(inventory.getItem(slot))) return slot;
        }
        return -1;
    }

    public static void end(ServerPlayer player) {
        Session session = SESSIONS.remove(player.getUUID());
        if (session == null) return;

        Inventory inventory = player.getInventory();
        if (session.moved()) {
            ItemStack staged = inventory.getItem(session.activeSlot());
            ItemStack displaced = inventory.getItem(session.originalGunSlot());
            if (TaczCompat.isGun(staged)) {
                inventory.setItem(session.originalGunSlot(), staged);
                inventory.setItem(session.activeSlot(), displaced);
            } else {
                // Never overwrite an unexpected item if the player inventory changed externally.
                hint(player, "改装会话结束，但临时枪械槽位已被外部修改；请检查背包。");
            }
        }
        inventory.selected = session.originalSelected();
        inventory.setChanged();
        player.inventoryMenu.broadcastChanges();
        player.connection.send(new ClientboundSetCarriedItemPacket(session.originalSelected()));
    }

    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            end(player);
        }
    }

    public static void installVirtualAttachment(ServerPlayer player, String rawId, String slot) {
        Session session = SESSIONS.get(player.getUUID());
        if (session == null) {
            hint(player, "改装会话已结束，请重新打开军需官改装界面。");
            return;
        }
        if (!TaczCompat.SLOTS.contains(slot)) {
            hint(player, "无效的配件槽位。");
            return;
        }
        ResourceLocation attachmentId = ResourceLocation.tryParse(rawId);
        if (attachmentId == null) {
            hint(player, "配件 ID 无效。");
            return;
        }

        Inventory inventory = player.getInventory();
        ItemStack gun = inventory.getItem(session.activeSlot());
        if (!TaczCompat.isGun(gun)) {
            hint(player, "当前选中的物品不再是 TaCZ 枪械，已拒绝改装。");
            return;
        }

        ItemStack attachment = TaczCompat.buildAttachment(attachmentId);
        if (attachment.isEmpty() || !slot.equals(TaczCompat.slotOfAttachment(attachment))) {
            hint(player, "TaCZ 配件索引与槽位不匹配，已拒绝安装。");
            return;
        }
        if (!TaczCompat.allowsSlot(gun, slot)) {
            hint(player, "这把枪没有对应的配件接口。");
            return;
        }

        ItemStack testGun = gun.copy();
        ResourceLocation oldAttachment = TaczCompat.installedAttachmentId(testGun, slot);
        if (oldAttachment != null && !TaczCompat.unloadAttachment(testGun, slot)) {
            hint(player, "TaCZ 无法卸下当前槽位配件，未执行替换。");
            return;
        }
        if (!TaczCompat.canInstallAttachment(testGun, attachment)) {
            hint(player, "TaCZ 判定该配件与这把枪不兼容。");
            return;
        }

        ItemStack originalGun = gun.copy();
        if (oldAttachment != null && !TaczCompat.unloadAttachment(gun, slot)) {
            hint(player, "旧配件卸载失败，未执行替换。");
            return;
        }
        if (TaczCompat.installAttachment(gun, attachment)
                && attachmentId.equals(TaczCompat.installedAttachmentId(gun, slot))) {
            inventory.setChanged();
            player.inventoryMenu.broadcastChanges();
            hint(player, "已免费安装：" + TaczCompat.displayName(attachment)
                    + "（已直接改装背包中的原枪）");
        } else {
            inventory.setItem(session.activeSlot(), originalGun);
            inventory.setChanged();
            player.inventoryMenu.broadcastChanges();
            hint(player, "安装失败，原枪配置已回滚。");
        }

        ModNetwork.sendToPlayer(new RefreshNativeRefitScreenPacket(), player);
    }

    private static void hint(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(ChatFormatting.AQUA), true);
    }
}
