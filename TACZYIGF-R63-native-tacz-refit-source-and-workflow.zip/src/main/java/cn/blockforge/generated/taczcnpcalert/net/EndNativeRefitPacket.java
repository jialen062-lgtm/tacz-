package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.NativeRefitSessionService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: restore the player's original inventory arrangement after leaving TaCZ's refit UI. */
public final class EndNativeRefitPacket {
    public static void encode(EndNativeRefitPacket message, FriendlyByteBuf buffer) {}
    public static EndNativeRefitPacket decode(FriendlyByteBuf buffer) { return new EndNativeRefitPacket(); }

    public static void handle(EndNativeRefitPacket message, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                NativeRefitSessionService.end(player);
            }
        });
        context.setPacketHandled(true);
    }
}
