package cn.blockforge.generated.taczcnpcalert.mixin;

import cn.blockforge.generated.taczcnpcalert.TaczCompat;
import cn.blockforge.generated.taczcnpcalert.client.NativeRefitClientState;
import cn.blockforge.generated.taczcnpcalert.net.InstallVirtualAttachmentPacket;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

/**
 * Replaces TaCZ's "attachments physically present in inventory" list only while
 * opened from the quartermaster. The underlying GunRefitScreen, textures, model
 * preview, slot buttons, statistics, and transform animations remain TaCZ-native.
 */
@Pseudo
@Mixin(targets = "com.tacz.guns.client.gui.GunRefitScreen", remap = false)
public abstract class GunRefitScreenAttachmentsMixin extends Screen {
    @Unique private int taczyigf$virtualAttachmentPage;
    @Unique private String taczyigf$lastAttachmentSlot = "";
    @Unique private Inventory taczyigf$virtualInventory;

    protected GunRefitScreenAttachmentsMixin(Component title) {
        super(title);
    }

    @Inject(method = "addInventoryAttachmentButtons", at = @At("HEAD"), cancellable = true, remap = false)
    private void taczyigf$useAllCatalogAttachments(CallbackInfo ci) {
        if (!NativeRefitClientState.isActive()) return;

        // In quartermaster mode, always suppress TaCZ's inventory-item list.
        // This makes the virtual catalog independent of physical attachment stacks.
        ci.cancel();

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;
        ItemStack gun = minecraft.player.getMainHandItem();
        if (!TaczCompat.isGun(gun)) return;

        String slot = taczyigf$currentAttachmentSlot();
        if (slot == null || "NONE".equals(slot)) {
            taczyigf$lastAttachmentSlot = "NONE";
            taczyigf$virtualAttachmentPage = 0;
            return;
        }
        if (!TaczCompat.SLOTS.contains(slot)) return;

        if (!slot.equals(taczyigf$lastAttachmentSlot)) {
            taczyigf$lastAttachmentSlot = slot;
            taczyigf$virtualAttachmentPage = 0;
        }

        List<ResourceLocation> candidates = new ArrayList<>();
        List<String> catalog = NativeRefitClientState.attachmentIds(slot);
        if (catalog.isEmpty()) {
            catalog = TaczCompat.allAttachmentIds().stream().map(ResourceLocation::toString).toList();
        }
        for (String rawId : catalog) {
            ResourceLocation id = ResourceLocation.tryParse(rawId);
            if (id == null) continue;
            ItemStack attachment = TaczCompat.buildAttachment(id);
            if (attachment.isEmpty() || !slot.equals(TaczCompat.slotOfAttachment(attachment))) continue;

            ItemStack testGun = gun.copy();
            ResourceLocation installed = TaczCompat.installedAttachmentId(testGun, slot);
            if (installed != null && !TaczCompat.unloadAttachment(testGun, slot)) continue;
            if (TaczCompat.canInstallAttachment(testGun, attachment)) {
                candidates.add(id);
            }
        }

        int pageSize = 8;
        int totalPages = Math.max(1, (candidates.size() + pageSize - 1) / pageSize);
        taczyigf$virtualAttachmentPage = Math.max(0, Math.min(totalPages - 1, taczyigf$virtualAttachmentPage));

        int guiWidth = minecraft.getWindow().getGuiScaledWidth();
        int startX = Math.max(4, guiWidth - 126);
        int startY = 50;

        if (candidates.isEmpty()) {
            this.addRenderableWidget(taczyigf$button(startX, startY, 118, 18,
                    "没有兼容配件", button -> {}));
            return;
        }

        int start = taczyigf$virtualAttachmentPage * pageSize;
        int end = Math.min(candidates.size(), start + pageSize);
        // TaCZ's own InventoryAttachmentSlot reads an Inventory for its icon/tooltip.
        // This is a short-lived client-only virtual inventory, not the player's inventory.
        taczyigf$virtualInventory = new Inventory(minecraft.player);
        for (int index = start; index < end; index++) {
            ResourceLocation id = candidates.get(index);
            int virtualSlot = index - start;
            ItemStack item = TaczCompat.buildAttachment(id);
            taczyigf$virtualInventory.setItem(virtualSlot, item);
            Button iconButton = taczyigf$nativeAttachmentSlot(
                    startX + 96, startY + virtualSlot * 18, virtualSlot, taczyigf$virtualInventory,
                    button -> ModNetwork.sendToServer(new InstallVirtualAttachmentPacket(id.toString(), slot)));
            if (iconButton != null) {
                this.addRenderableWidget(iconButton);
            } else {
                String label = taczyigf$shortName(TaczCompat.displayName(item));
                this.addRenderableWidget(taczyigf$button(startX, startY + virtualSlot * 18,
                        118, 16, label,
                        button -> ModNetwork.sendToServer(new InstallVirtualAttachmentPacket(id.toString(), slot))));
            }
        }

        if (totalPages > 1) {
            int navY = startY + pageSize * 18 + 2;
            this.addRenderableWidget(taczyigf$button(startX, navY, 56, 16, "上一页",
                    button -> {
                        taczyigf$virtualAttachmentPage = Math.max(0, taczyigf$virtualAttachmentPage - 1);
                        NativeRefitClientState.refreshCurrentScreen();
                    }));
            this.addRenderableWidget(taczyigf$button(startX + 62, navY, 56, 16, "下一页",
                    button -> {
                        taczyigf$virtualAttachmentPage = Math.min(totalPages - 1, taczyigf$virtualAttachmentPage + 1);
                        NativeRefitClientState.refreshCurrentScreen();
                    }));
        }
    }

    @Unique
    private String taczyigf$currentAttachmentSlot() {
        try {
            Class<?> transform = Class.forName("com.tacz.guns.client.animation.screen.RefitTransform");
            Object current = transform.getMethod("getCurrentTransformType").invoke(null);
            return current instanceof Enum<?> value ? value.name() : "NONE";
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
            return "NONE";
        }
    }

    @Unique
    private Button taczyigf$nativeAttachmentSlot(int x, int y, int slot, Inventory virtualInventory,
                                                  Button.OnPress press) {
        try {
            Class<?> slotClass = Class.forName(
                    "com.tacz.guns.client.gui.components.refit.InventoryAttachmentSlot");
            Constructor<?> constructor = slotClass.getDeclaredConstructor(
                    int.class, int.class, int.class, Inventory.class, Button.OnPress.class);
            constructor.setAccessible(true);
            Object value = constructor.newInstance(x, y, slot, virtualInventory, press);
            if (value instanceof Button button) return button;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
            // Fall back to the TaCZ flat-color button when the component constructor changes.
        }
        return null;
    }

    @Unique
    private Button taczyigf$button(int x, int y, int width, int height, String text, Button.OnPress press) {
        Component label = Component.literal(text);
        // Use TaCZ's own flat button component when available, preserving its palette.
        try {
            Class<?> flatButton = Class.forName("com.tacz.guns.client.gui.components.FlatColorButton");
            Constructor<?> constructor = flatButton.getDeclaredConstructor(
                    int.class, int.class, int.class, int.class, Component.class, Button.OnPress.class);
            constructor.setAccessible(true);
            Object value = constructor.newInstance(x, y, width, height, label, press);
            if (value instanceof Button button) return button;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
            // Fallback is used only if a TaCZ release changes this public UI helper constructor.
        }
        return Button.builder(label, press).bounds(x, y, width, height).build();
    }

    @Unique
    private static String taczyigf$shortName(String name) {
        if (name == null || name.isBlank()) return "未知配件";
        return name.length() > 15 ? name.substring(0, 14) + "…" : name;
    }
}
