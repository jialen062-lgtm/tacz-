package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * 模组的网络通道，负责 NPC 交互、行动选择、准备状态、对话编辑和装备同步。
 * <ul>
 *   <li>{@link WandInteractPacket}：拿着界面魔杖右键了 NPC（客户端 → 服务端）</li>
 *   <li>{@link MapWandInteractPacket}：拿着地图魔杖右键了 NPC（客户端 → 服务端）</li>
 *   <li>{@link OpenPanelPacket}：打开军需官面板（服务端 → 客户端）</li>
 *   <li>{@link OpenDungeonPanelPacket}：打开警长行动选择面板（服务端 → 客户端）</li>
 *   <li>{@link PanelActionPacket}：在面板里点了领取/改造/选择行动（客户端 → 服务端）</li>
 * </ul>
 */
public final class ModNetwork {

    private static final String PROTOCOL = "4";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ResourceLocation.fromNamespaceAndPath(TaczCnpcAlertMod.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(WandInteractPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(WandInteractPacket::encode)
                .decoder(WandInteractPacket::decode)
                .consumerMainThread(WandInteractPacket::handle)
                .add();

        CHANNEL.messageBuilder(MapWandInteractPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(MapWandInteractPacket::encode)
                .decoder(MapWandInteractPacket::decode)
                .consumerMainThread(MapWandInteractPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenPanelPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenPanelPacket::encode)
                .decoder(OpenPanelPacket::decode)
                .consumerMainThread(OpenPanelPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDungeonPanelPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDungeonPanelPacket::encode)
                .decoder(OpenDungeonPanelPacket::decode)
                .consumerMainThread(OpenDungeonPanelPacket::handle)
                .add();

        CHANNEL.messageBuilder(PanelActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(PanelActionPacket::encode)
                .decoder(PanelActionPacket::decode)
                .consumerMainThread(PanelActionPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDialoguePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDialoguePacket::encode)
                .decoder(OpenDialoguePacket::decode)
                .consumerMainThread(OpenDialoguePacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDialogueEditorPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDialogueEditorPacket::encode)
                .decoder(OpenDialogueEditorPacket::decode)
                .consumerMainThread(OpenDialogueEditorPacket::handle)
                .add();

        CHANNEL.messageBuilder(SaveDialogueEditorPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SaveDialogueEditorPacket::encode)
                .decoder(SaveDialogueEditorPacket::decode)
                .consumerMainThread(SaveDialogueEditorPacket::handle)
                .add();

        CHANNEL.messageBuilder(CloseDialogueEditorPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(CloseDialogueEditorPacket::encode)
                .decoder(CloseDialogueEditorPacket::decode)
                .consumerMainThread(CloseDialogueEditorPacket::handle)
                .add();

        CHANNEL.messageBuilder(GearEquipAnimationPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(GearEquipAnimationPacket::encode)
                .decoder(GearEquipAnimationPacket::decode)
                .consumerMainThread(GearEquipAnimationPacket::handle)
                .add();

        CHANNEL.messageBuilder(PanelNoticePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(PanelNoticePacket::encode)
                .decoder(PanelNoticePacket::decode)
                .consumerMainThread(PanelNoticePacket::handle)
                .add();

        CHANNEL.messageBuilder(WeaponPresetListPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(WeaponPresetListPacket::encode)
                .decoder(WeaponPresetListPacket::decode)
                .consumerMainThread(WeaponPresetListPacket::handle)
                .add();

        CHANNEL.messageBuilder(ToggleReadyPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ToggleReadyPacket::encode)
                .decoder(ToggleReadyPacket::decode)
                .consumerMainThread(ToggleReadyPacket::handle)
                .add();

        CHANNEL.messageBuilder(PreparationStatusPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(PreparationStatusPacket::encode)
                .decoder(PreparationStatusPacket::decode)
                .consumerMainThread(PreparationStatusPacket::handle)
                .add();

        CHANNEL.messageBuilder(BeginNativeRefitPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(BeginNativeRefitPacket::encode)
                .decoder(BeginNativeRefitPacket::decode)
                .consumerMainThread(BeginNativeRefitPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenNativeRefitScreenPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenNativeRefitScreenPacket::encode)
                .decoder(OpenNativeRefitScreenPacket::decode)
                .consumerMainThread(OpenNativeRefitScreenPacket::handle)
                .add();

        CHANNEL.messageBuilder(EndNativeRefitPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(EndNativeRefitPacket::encode)
                .decoder(EndNativeRefitPacket::decode)
                .consumerMainThread(EndNativeRefitPacket::handle)
                .add();

        CHANNEL.messageBuilder(InstallVirtualAttachmentPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(InstallVirtualAttachmentPacket::encode)
                .decoder(InstallVirtualAttachmentPacket::decode)
                .consumerMainThread(InstallVirtualAttachmentPacket::handle)
                .add();

        CHANNEL.messageBuilder(RefreshNativeRefitScreenPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(RefreshNativeRefitScreenPacket::encode)
                .decoder(RefreshNativeRefitScreenPacket::decode)
                .consumerMainThread(RefreshNativeRefitScreenPacket::handle)
                .add();
    }

    public static void sendToServer(Object message) {
        CHANNEL.sendToServer(message);
    }

    public static void sendToPlayer(Object message, ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }
}
