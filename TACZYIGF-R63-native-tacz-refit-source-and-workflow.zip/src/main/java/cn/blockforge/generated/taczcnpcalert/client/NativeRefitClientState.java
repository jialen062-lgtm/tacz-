package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.net.EndNativeRefitPacket;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/** Client-side bridge that opens TaCZ's actual refit Screen and restores the quartermaster panel afterward. */
@Mod.EventBusSubscriber(modid = "tacz_cnpc_alert", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NativeRefitClientState {
    private static boolean active;
    private static int originalSelected;
    private static Screen parent;
    private static Map<String, List<String>> attachmentCatalog = Map.of();

    private NativeRefitClientState() {}

    public static boolean isActive() {
        return active;
    }

    public static void setAttachmentCatalog(Map<String, List<String>> catalog) {
        attachmentCatalog = catalog == null ? Map.of() : Map.copyOf(catalog);
    }

    public static List<String> attachmentIds(String slot) {
        return attachmentCatalog.getOrDefault(slot, List.of());
    }

    public static void open(int originalSelectedSlot, int activeSlot) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            ModNetwork.sendToServer(new EndNativeRefitPacket());
            return;
        }

        parent = minecraft.screen;
        originalSelected = Math.max(0, Math.min(8, originalSelectedSlot));
        active = true;

        minecraft.player.getInventory().selected = Math.max(0, Math.min(8, activeSlot));
        if (minecraft.getConnection() != null) {
            minecraft.getConnection().send(new ServerboundSetCarriedItemPacket(minecraft.player.getInventory().selected));
        }

        try {
            Class<?> screenClass = Class.forName("com.tacz.guns.client.gui.GunRefitScreen");
            Constructor<?> constructor = screenClass.getDeclaredConstructor();
            constructor.setAccessible(true);
            Object instance = constructor.newInstance();
            if (!(instance instanceof Screen screen)) {
                throw new IllegalStateException("TaCZ GunRefitScreen is not a Minecraft Screen");
            }
            minecraft.setScreen(screen);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException exception) {
            active = false;
            restoreClientSelection(minecraft);
            ModNetwork.sendToServer(new EndNativeRefitPacket());
            if (minecraft.player != null) {
                minecraft.player.displayClientMessage(
                        Component.literal("无法打开当前 TaCZ 版本的原版改枪界面：" + exception.getClass().getSimpleName()),
                        true);
            }
            parent = null;
        }
    }

    public static void refreshCurrentScreen() {
        Minecraft minecraft = Minecraft.getInstance();
        if (!active || !isNativeRefitScreen(minecraft.screen)) return;
        try {
            Method init = minecraft.screen.getClass().getMethod("init");
            init.invoke(minecraft.screen);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // The installed attachment is already synchronized; a screen rebuild is only visual refresh.
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !active) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            active = false;
            parent = null;
            attachmentCatalog = Map.of();
            return;
        }
        if (!isNativeRefitScreen(minecraft.screen)) {
            closeAndRestore(minecraft);
        }
    }

    private static boolean isNativeRefitScreen(Screen screen) {
        return screen != null && screen.getClass().getName().equals("com.tacz.guns.client.gui.GunRefitScreen");
    }

    private static void closeAndRestore(Minecraft minecraft) {
        active = false;
        restoreClientSelection(minecraft);
        ModNetwork.sendToServer(new EndNativeRefitPacket());
        Screen returnScreen = parent;
        parent = null;
        attachmentCatalog = Map.of();
        if (returnScreen != null && minecraft.player != null) {
            minecraft.setScreen(returnScreen);
        }
    }

    private static void restoreClientSelection(Minecraft minecraft) {
        if (minecraft.player == null) return;
        minecraft.player.getInventory().selected = originalSelected;
        if (minecraft.getConnection() != null) {
            minecraft.getConnection().send(new ServerboundSetCarriedItemPacket(originalSelected));
        }
    }
}
