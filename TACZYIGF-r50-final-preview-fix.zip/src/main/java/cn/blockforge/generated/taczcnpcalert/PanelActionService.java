package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 面板上的点击动作全部在服务端这里落实：
 * 领装备、领枪、领子弹、给手里的枪装/拆配件。
 *
 * <p>客户端只负责发“我点了什么”，不直接改自己的背包，这样联机时也公平、也同步得出去。</p>
 */
public final class PanelActionService {

    public static final String ACTION_EQUIP = "equip";
    public static final String ACTION_GUN = "gun";
    public static final String ACTION_AMMO = "ammo";
    public static final String ACTION_AMMO_BULK = "ammo_bulk";
    public static final String ACTION_MELEE = "melee";
    public static final String ACTION_THROWABLE = "throwable";
    public static final String ACTION_INSTALL = "install";
    public static final String ACTION_UNINSTALL = "uninstall";
    public static final String ACTION_SET_ATTACHMENT_OFFSET = "set_attachment_offset";
    public static final String ACTION_PRESET_SAVE = "preset_save";
    public static final String ACTION_PRESET_LIST = "preset_list";
    public static final String ACTION_PRESET_APPLY = "preset_apply";

    /** 一次“批量领子弹”给几组。 */
    private static final int BULK_STACKS = 8;

    private PanelActionService() {
    }

    public static void handle(ServerPlayer player, cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket packet) {
        String action = packet.action();
        String id = packet.id();
        if (SheriffService.ACTION_DUNGEON.equals(action) || SheriffService.ACTION_CLEAR_DUNGEON.equals(action)) {
            LivingEntity npc = packet.npcId() < 0 ? null : findNpc(player, packet.npcId());
            SheriffService.handlePanelAction(player, npc, parseDungeonIndex(id),
                    SheriffService.ACTION_CLEAR_DUNGEON.equals(action));
            return;
        }
        switch (action) {
            case ACTION_EQUIP -> equipWearable(player, id);
            case ACTION_GUN -> {
                if (!TaczCompat.isAvailable()) {
                    hint(player, "没有检测到 TaCZ，无法发放枪械。");
                    return;
                }
                ItemStack stack = TaczCompat.buildGun(parse(id));
                if (stack.isEmpty()) {
                    hint(player, "找不到这把枪：" + id);
                    return;
                }
                if (LoadoutInventoryService.equipGun(player, stack)) {
                    hint(player, "已装备枪械：" + TaczCompat.displayName(stack));
                } else {
                    hint(player, "快捷栏和背包没有可用位置，未替换现有武器。");
                }
            }
            case ACTION_AMMO -> giveAmmo(player, id, 1);
            case ACTION_AMMO_BULK -> giveAmmo(player, id, BULK_STACKS);
            case ACTION_THROWABLE -> {
                ItemStack stack = equipmentStack(id);
                if (stack.isEmpty()) {
                    stack = LrtacticalCompat.buildThrowable(parse(id));
                }
                if (stack.isEmpty()) {
                    hint(player, "找不到这种投掷物：" + id);
                } else if (LoadoutInventoryService.equipThrowable(player, stack, id)) {
                    hint(player, "投掷物已更新（仅一种，最多两个）。");
                } else {
                    hint(player, "没有可用的投掷物栏位，未覆盖其他物品。");
                }
            }
            case ACTION_MELEE -> {
                // 先兼容逐件注册物品，再尝试 lrtactical 的数据索引物品，最后回退到 TaCZ 索引。
                ItemStack stack = equipmentStack(id);
                if (stack.isEmpty()) {
                    stack = LrtacticalCompat.buildMelee(parse(id));
                }
                if (stack.isEmpty()) {
                    stack = TaczCompat.buildMelee(parse(id));
                }
                if (stack.isEmpty()) {
                    hint(player, "找不到这件近战武器：" + id);
                } else if (LoadoutInventoryService.equipMelee(player, stack)) {
                    hint(player, "近战武器已装备（仅保留一种）。");
                } else {
                    hint(player, "没有可用的近战武器栏位，未覆盖其他物品。");
                }
            }
            case ACTION_INSTALL -> install(player, parse(id), packet.slot());
            case ACTION_UNINSTALL -> uninstall(player, id, packet.slot());
            case ACTION_SET_ATTACHMENT_OFFSET -> setAttachmentOffset(player, id, packet);
            case ACTION_PRESET_SAVE -> WeaponPresetService.save(player, packet.slot());
            case ACTION_PRESET_LIST -> WeaponPresetService.sendList(player);
            case ACTION_PRESET_APPLY -> WeaponPresetService.apply(player, id);
            default -> hint(player, "未知操作：" + action);
        }
    }


    /** 将装备真正穿戴到原版装备槽；成功后才向客户端发送镜头动画。 */
    private static void equipWearable(ServerPlayer player, String id) {
        ItemStack stack = equipmentStack(id);
        if (stack.isEmpty()) {
            hint(player, "找不到这件装备：" + id);
            return;
        }
        if (net.minecraftforge.fml.ModList.get().isLoaded("curios") && CuriosCompat.tryEquip(player, stack)) {
            hint(player, "已装备到 Curios 饰品槽：" + stack.getHoverName().getString());
            cn.blockforge.generated.taczcnpcalert.net.ModNetwork.sendToPlayer(
                    new cn.blockforge.generated.taczcnpcalert.net.GearEquipAnimationPacket(3), player);
            return;
        }
        Equipable equipable = Equipable.get(stack);
        if (equipable == null) {
            hint(player, "这件物品没有原版穿戴槽位，暂不能直接装备：" + stack.getHoverName().getString());
            return;
        }
        EquipmentSlot slot = equipable.getEquipmentSlot();
        if (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND) {
            hint(player, "这件物品不是可穿戴护甲，无法放入装备栏。");
            return;
        }
        ItemStack equipped = stack.copy();
        equipped.setCount(1);
        player.setItemSlot(slot, equipped);
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
        hint(player, "已穿戴：" + equipped.getHoverName().getString());
        int category = switch (slot) {
            case HEAD -> 0;
            case CHEST -> 1;
            case LEGS, FEET -> 2;
            default -> 3;
        };
        cn.blockforge.generated.taczcnpcalert.net.ModNetwork.sendToPlayer(
                new cn.blockforge.generated.taczcnpcalert.net.GearEquipAnimationPacket(category), player);
    }

    private static void giveAmmo(ServerPlayer player, String id, int stacks) {
        if (!TaczCompat.isAvailable()) {
            hint(player, "没有检测到 TaCZ，无法发放子弹。");
            return;
        }
        ResourceLocation ammoId = parse(id);
        if (ammoId == null) {
            return;
        }
        int given = 0;
        for (int i = 0; i < stacks; i++) {
            ItemStack stack = TaczCompat.buildAmmo(ammoId, AlertConfig.AMMO_STACK_SIZE.get());
            if (stack.isEmpty()) {
                break;
            }
            give(player, stack);
            given++;
        }
        if (given == 0) {
            hint(player, "找不到这种子弹：" + id);
        } else {
            hint(player, "已领取子弹 ×" + given + " 组");
        }
    }

    private static void install(ServerPlayer player, ResourceLocation attachmentId, int inventorySlot) {
        if (!TaczCompat.isAvailable() || attachmentId == null) {
            return;
        }
        ItemStack gun = gunInSlot(player, inventorySlot);
        if (gun.isEmpty()) {
            hint(player, "背包里这个位置不是枪械。");
            return;
        }
        ItemStack attachment = TaczCompat.buildAttachment(attachmentId);
        if (attachment.isEmpty()) {
            hint(player, "找不到这个配件：" + attachmentId);
            return;
        }
        String slot = TaczCompat.slotOfAttachment(attachment);
        if (slot == null) {
            hint(player, "无法识别这个配件的安装接口。");
            return;
        }
        if (!TaczCompat.allowsSlot(gun, slot)) {
            hint(player, "这把枪没有 " + slotName(slot) + " 槽位。");
            return;
        }
        if (!TaczCompat.canInstallAttachment(gun, attachment)) {
            hint(player, "TaCZ 判定这个配件与当前枪械不兼容。");
            return;
        }
        if (TaczCompat.installAttachment(gun, attachment)) {
            player.containerMenu.broadcastChanges();
            // TaCZ 自己会拒绝不兼容的配件，只是不会报错；这里回头看一眼到底装上没有。
            if (hasAttachment(gun, attachmentId)) {
                hint(player, "已装上：" + TaczCompat.displayName(attachment));
            } else {
                hint(player, "这把枪装不了这个配件。");
            }
        } else {
            hint(player, "这个配件装不上去。");
        }
    }


    private static void setAttachmentOffset(ServerPlayer player, String slot,
                                            cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket packet) {
        if (slot == null || !TaczCompat.SLOTS.contains(slot)) return;
        ItemStack gun = gunInSlot(player, packet.slot());
        if (gun.isEmpty() || !TaczCompat.allowsSlot(gun, slot)) return;
        ResourceLocation installedId = TaczCompat.installedAttachmentId(gun, slot);
        if (installedId == null || !installedId.toString().equals(packet.id())) return;
        ItemStack attachment = TaczCompat.buildAttachment(installedId);
        if (attachment.isEmpty() || !AttachmentMovementRules.canDrag(slot, installedId.toString(), true)) {
            hint(player, "该配件按安装规则不可移动。");
            return;
        }
        AttachmentPositionData.Offset safe = AttachmentMovementRules.constrain(slot, installedId.toString(),
                packet.offsetX(), packet.offsetY(), packet.offsetZ());
        AttachmentPositionData.set(gun, slot, attachment, safe.x(), safe.y(), safe.z());
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
    }

    private static boolean hasAttachment(ItemStack gun, ResourceLocation attachmentId) {
        for (String candidate : TaczCompat.SLOTS) {
            ResourceLocation installed = TaczCompat.installedAttachmentId(gun, candidate);
            if (installed != null && installed.equals(attachmentId)) {
                return true;
            }
        }
        return false;
    }

    private static void uninstall(ServerPlayer player, String slot, int inventorySlot) {
        if (!TaczCompat.isAvailable() || slot == null || slot.isBlank()) {
            return;
        }
        ItemStack gun = gunInSlot(player, inventorySlot);
        if (gun.isEmpty()) {
            hint(player, "背包里这个位置不是枪械。");
            return;
        }
        if (!TaczCompat.allowsSlot(gun, slot)) {
            hint(player, "这把枪不支持这个配件接口。");
            return;
        }
        if (TaczCompat.unloadAttachment(gun, slot)) {
            player.containerMenu.broadcastChanges();
            if (TaczCompat.installedAttachmentId(gun, slot) == null) {
                hint(player, "已卸下" + slotName(slot) + "配件。");
            } else {
                hint(player, "卸不下来，这把枪的" + slotName(slot) + "槽位可能不支持拆装。");
            }
        }
    }

    private static ItemStack gunInSlot(ServerPlayer player, int inventorySlot) {
        if (inventorySlot < 0 || inventorySlot >= player.getInventory().getContainerSize()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = player.getInventory().getItem(inventorySlot);
        return TaczCompat.isGun(stack) ? stack : ItemStack.EMPTY;
    }

    private static int parseDungeonIndex(String id) {
        try {
            return Integer.parseInt(id);
        } catch (NumberFormatException exception) {
            return -1;
        }
    }

    private static LivingEntity findNpc(ServerPlayer player, int entityId) {
        if (player == null || entityId < 0) {
            return null;
        }
        if (player.level().getEntity(entityId) instanceof LivingEntity entity
                && SheriffService.isSheriff(entity)
                && AlertService.isNpcType(entity)) {
            return entity;
        }
        return null;
    }

    private static ItemStack equipmentStack(String id) {
        ResourceLocation key = parse(id);
        if (key == null) {
            return ItemStack.EMPTY;
        }
        Item item = ForgeRegistries.ITEMS.getValue(key);
        return item == null ? ItemStack.EMPTY : new ItemStack(item);
    }

    private static ResourceLocation parse(String id) {
        if (id == null || id.isBlank()) {
            return null;
        }
        ResourceLocation parsed = ResourceLocation.tryParse(id);
        if (parsed == null) {
            parsed = ResourceLocation.tryParse("tacz:" + id);
        }
        return parsed;
    }

    private static boolean give(ServerPlayer player, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        player.containerMenu.broadcastChanges();
        return true;
    }

    private static void hint(ServerPlayer player, String message) {
        cn.blockforge.generated.taczcnpcalert.net.ModNetwork.sendToPlayer(
                new cn.blockforge.generated.taczcnpcalert.net.PanelNoticePacket(message), player);
        player.displayClientMessage(Component.literal(message).withStyle(ChatFormatting.AQUA), true);
    }

    /** 槽位英文名 → 面板上用的中文名。 */
    public static String slotName(String slot) {
        return switch (slot == null ? "" : slot.toUpperCase(java.util.Locale.ROOT)) {
            case "SCOPE" -> "瞄具";
            case "MUZZLE" -> "枪口";
            case "STOCK" -> "枪托";
            case "GRIP" -> "握把";
            case "LASER" -> "激光";
            case "EXTENDED_MAG" -> "扩容弹匣";
            default -> slot;
        };
    }
}
