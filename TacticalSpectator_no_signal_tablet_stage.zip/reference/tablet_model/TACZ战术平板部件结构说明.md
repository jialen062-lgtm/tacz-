# TACZ Tactical Tablet（战术观战平板）模型部件结构说明

适用：Minecraft 1.20.1 Forge 模组 · Blockbench 立方体建模 · 现实军用加固平板风格（横屏）

## 一、总体规格

| 项目 | 数值 |
| --- | --- |
| 宽度 | 16 模型单位（含护套，x: -8 ~ +8） |
| 高度 | 11 模型单位（含护套，y: 0 ~ 11） |
| 厚度 | 1.8 模型单位（护套处，z: -0.9 ~ +0.9；机身 1.4） |
| 朝向 | 屏幕朝 +z（南面），背面朝 -z（北面） |
| 原点 | 底部中心 (0, 0, 0)，适合第一人称手持变换 |
| 部件组 | 9 组，共 27 个立方体，全部轴对齐（无旋转立方体，兼容 Java 物品模型导出） |
| 穿插检查 | 程序化体积相交检测：0 处穿插，所有部件相邻贴合 |

## 二、部件组结构（outliner）

| 组名 | 立方体 | 说明 |
| --- | --- | --- |
| **Body** | body_main | 主机身，哑光黑，15×10×1.4，真实厚度 |
| **Front_Frame** | frame_top / bottom / left / right | 深军绿正面边框，厚 0.2，贴合机身前面 |
| **Screen** | screen_bezel / screen_display | 黑色屏幕边框 + 显示屏；屏幕南面使用独立 screen.png，可整体替换观战 UI |
| **Corner_Protection** | corner_TL_h / TL_v / TR_h / TR_v / BL_h / BL_v / BR_h / BR_v | 四角 L 形橡胶防撞护套，厚于机身（1.8），包裹边角不穿插 |
| **Side_Buttons** | btn_left_1 / 2、btn_right_1 / 2 | 左右各 2 个实体功能键，凸出侧面 0.4 |
| **Power_Button** | power_key | 顶部电源键（带绿色指示点贴图） |
| **Camera** | camera_base / camera_lens | 背部摄像头底座 + 逐级凸出的镜片 |
| **Back_Details** | back_vents / back_serial / port_cover | 背部散热格栅、军用编号铭牌「TAC-07 / MIL-SPEC」、顶部接口保护盖 |
| **Rubber_Grip** | grip_left / grip_right | 背部两条竖向防滑橡胶条 |

层级深度说明：机身 z±0.7 → 边框/屏幕 z+0.7~0.9 → 护套 z±0.9 → 摄像头底座 z-0.95 → 镜片 z-1.05，各部件有真实前后层次，绝非同一平面。

## 三、贴图清单（textures/，Minecraft 像素风）

| 文件 | 尺寸 | 内容分区（像素坐标） |
| --- | --- | --- |
| body.png | 64×64 | (0,0)-(32,32) 哑光黑机身；(32,0)-(64,32) 深军绿外框；(0,32)-(32,64) 屏幕黑边框 |
| screen.png | 128×80 | 整张 = 观战 UI（SPECTATE 标题栏 / 队员列表 / 小地图 / 状态栏），**替换此文件即可换观战界面** |
| rubber.png | 64×64 | 橡胶斜纹防滑纹理（护套 + 防滑条共用） |
| buttons.png | 32×32 | (0,0) 功能键面；(16,0) 键侧；(0,16) 电源键面（绿点）；(16,16) 军绿键侧 |
| back.png | 64×64 | (0,0) 散热格栅；(0,16) TAC-07 铭牌；(32,0) 摄像头镜片；(32,16) 摄像头底座；(48,0) 接口保护盖 |

bbmodel 内已内嵌全部贴图（base64），**单独打开 .bbmodel 即可看到完整带贴图模型**，无需额外配置路径；textures/ 目录下的独立 PNG 供模组资源包使用。

## 四、手持显示变换（display，已经写入 bbmodel 与 Java JSON）

| 场景 | rotation | translation | scale |
| --- | --- | --- | --- |
| firstperson_righthand | [10, -90, 0] | [1.5, 3.0, 1.5] | 0.85 |
| firstperson_lefthand | [10, 90, 0] | [1.5, 3.0, 1.5] | 0.85 |
| thirdperson_* | [0, 0, 0] | [0, 2.5, 1.5] | 0.55 |
| gui | [15, -25, 0] | [0, 0, 0] | 0.8 |
| fixed（展示框） | [-90, 0, 0] | [0, 0, -6] | 0.9 |
| ground | [0, 0, 0] | [0, 2, 0] | 0.5 |

在 Blockbench 中：打开文件 → 右侧 Display 面板即可逐场景调整旋转/缩放/位移；模型组 origin 统一设在 (0, 5.5, 0)（几何中心），整组旋转不会偏心。

## 五、使用方法

**Blockbench 编辑**：直接双击 `TACZ_Tactical_Tablet.bbmodel`（格式 java_block，Blockbench 4.x 可开）。改屏幕 UI：替换 screen.png 后在 Blockbench 纹理面板刷新，或直接改内嵌贴图。

**模组内使用（Java JSON）**：`TACZ_Tactical_Tablet_java.json` 为标准 Java 物品模型（UV 已换算到 0~16 规范空间）。放入 `assets/<modid>/models/item/`，贴图按以下命名放入 `assets/<modid>/textures/item/`：
- tacz_tablet_body.png ← body.png
- tacz_tablet_screen.png ← screen.png
- tacz_tablet_rubber.png ← rubber.png
- tacz_tablet_buttons.png ← buttons.png
- tacz_tablet_back.png ← back.png

**观战 UI 动态化建议**：屏幕为独立立方体 + 独立贴图，运行时可用 RenderType 半透明层或动态纹理（DynamicTexture）只刷新 screen 贴图实现实时观战画面，无需动模型。

## 六、交付文件清单

1. TACZ_Tactical_Tablet.bbmodel —— Blockbench 源文件（内嵌贴图，可直接打开编辑）
2. textures/*.png —— 5 张独立像素贴图
3. TACZ_Tactical_Tablet_preview.png —— 正面 3/4 + 背面 3/4 双视角预览（由模型本体软件渲染，非概念图）
4. TACZ_Tactical_Tablet_front.png —— 正面平视预览
5. TACZ_Tactical_Tablet_java.json —— Minecraft Java 版物品模型导出
6. 本说明文档

生成器源码：`tablet/gen_tablet.py`（可改尺寸/配色/部件后重新生成）。

---

内容由 AI 生成
