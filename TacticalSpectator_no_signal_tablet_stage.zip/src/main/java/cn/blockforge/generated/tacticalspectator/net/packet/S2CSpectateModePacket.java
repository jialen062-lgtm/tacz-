package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.client.ClientRx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 通知客户端“我是否处于观战状态”（决定 A/D 是否切换、是否冻结移动） */
public final class S2CSpectateModePacket {
    public final boolean on;

    public S2CSpectateModePacket(boolean on) {
        this.on = on;
    }

    public static void encode(S2CSpectateModePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.on);
    }

    public static S2CSpectateModePacket decode(FriendlyByteBuf buf) {
        return new S2CSpectateModePacket(buf.readBoolean());
    }

    public static void handle(S2CSpectateModePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRx.applySpectateMode(msg.on)));
        ctx.setPacketHandled(true);
    }
}
