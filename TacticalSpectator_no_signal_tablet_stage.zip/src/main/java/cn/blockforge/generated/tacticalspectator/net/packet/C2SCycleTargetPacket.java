package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 观战中按 A(-1) / D(+1) 请求切换目标；目标由服务端校验，客户端只发方向 */
public final class C2SCycleTargetPacket {
    public final int dir;

    public C2SCycleTargetPacket(int dir) {
        this.dir = dir;
    }

    public static void encode(C2SCycleTargetPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.dir);
    }

    public static C2SCycleTargetPacket decode(FriendlyByteBuf buf) {
        return new C2SCycleTargetPacket(buf.readVarInt());
    }

    public static void handle(C2SCycleTargetPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer sender = ctx.getSender();
            if (sender != null) {
                SpectateService.cycle(sender, msg.dir);
            }
        });
        ctx.setPacketHandled(true);
    }
}
