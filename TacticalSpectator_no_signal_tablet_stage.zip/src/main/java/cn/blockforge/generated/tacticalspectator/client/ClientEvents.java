package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SCycleTargetPacket;
import cn.blockforge.generated.tacticalspectator.net.packet.C2STabletActionPacket;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * 客户端 tick / 按键：
 *  - 观战中按 A/D 发送切换请求（非观战状态完全不干预）；
 *  - 观战中冻结本体移动输入（身体留在大厅，不干扰观战目标）；
 *  - 断开连接时清空本地状态。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    private static final int TABLET_HOLD_TICKS = 10;
    private static int swapHeldTicks;
    private static boolean pendingHolsterExit;

    @SubscribeEvent
    public static void onKey(InputEvent.Key event) {
        if (event.getAction() != GLFW.GLFW_PRESS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null || !ClientState.spectating) {
            return;
        }
        if (event.getKey() == GLFW.GLFW_KEY_A) {
            ModNetwork.CHANNEL.sendToServer(new C2SCycleTargetPacket(-1));
        } else if (event.getKey() == GLFW.GLFW_KEY_D) {
            ModNetwork.CHANNEL.sendToServer(new C2SCycleTargetPacket(1));
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            TabletAnimation.clear();
            pendingHolsterExit = false;
            handleTabletKey(mc);
            return;
        }
        boolean tabletInHands = mc.player.getMainHandItem().is(ModItems.TACTICAL_TABLET.get())
                || mc.player.getOffhandItem().is(ModItems.TACTICAL_TABLET.get());
        TabletAnimation.tick(mc.player.isAlive(), tabletInHands);
        boolean holsterFinished = TabletAnimation.consumeHolsterCompletion();
        if (pendingHolsterExit && holsterFinished) {
            pendingHolsterExit = false;
            ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(true));
        }
        handleTabletKey(mc);
        if (mc.player == null || !ClientState.spectating) {
            return;
        }
        Options options = mc.options;
        freeze(options.keyUp);
        freeze(options.keyDown);
        freeze(options.keyLeft);
        freeze(options.keyRight);
        freeze(options.keyJump);
        freeze(options.keyShift);
        freeze(options.keySprint);
    }

    private static void handleTabletKey(Minecraft mc) {
        if (mc.player == null || mc.screen != null || !mc.isWindowActive() || mc.getConnection() == null) {
            swapHeldTicks = 0;
            return;
        }
        boolean tabletInHands = mc.player.getMainHandItem().is(ModItems.TACTICAL_TABLET.get())
                || mc.player.getOffhandItem().is(ModItems.TACTICAL_TABLET.get());
        KeyMapping swap = mc.options.keySwapOffhand;
        boolean pressed = false;
        while (swap.consumeClick()) {
            pressed = true;
        }
        if (swap.isDown()) {
            if (pressed || swapHeldTicks > 0) {
                if (swapHeldTicks < TABLET_HOLD_TICKS && ++swapHeldTicks == TABLET_HOLD_TICKS) {
                    if (ClientState.spectating) {
                        TabletAnimation.beginHolster();
                        pendingHolsterExit = true;
                    } else if (!tabletInHands) {
                        TabletAnimation.beginDraw();
                        ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(false));
                    }
                }
            }
            return;
        }
        if ((pressed || swapHeldTicks > 0) && swapHeldTicks < TABLET_HOLD_TICKS) {
            // Short F tap always requests the tablet, regardless of round/elimination state.
            ModNetwork.CHANNEL.sendToServer(new C2STabletActionPacket(false));
        }
        swapHeldTicks = 0;
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (ClientState.spectating) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    private static void freeze(KeyMapping key) {
        if (key.isDown()) {
            key.setDown(false);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.clear();
        TabletAnimation.clear();
        pendingHolsterExit = false;
        swapHeldTicks = 0;
    }

    private ClientEvents() {
    }
}
