package cn.blockforge.generated.tacticalspectator.event;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.region.WandSelections;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 木棍选区工具（通用侧）：
 *  - 任意原版木棍，左键方块 = 位置 1，右键方块 = 位置 2；
 *  - 两侧同时取消这次交互：左键不会破坏方块，右键不会打开箱子等；
 *  - 客户端取消后原版不再发包，所以点选由客户端类转发到服务端（见 applyPoint）。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID)
public final class WandEvents {

    /** 选点距离上限（防作弊：客户端 packet 里的坐标必须离玩家足够近） */
    public static final double MAX_RANGE = 64.0;

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (!isWand(event.getEntity(), event.getItemStack())) {
            return;
        }
        event.setCanceled(true);
        if (!event.getLevel().isClientSide
                && event.getAction() == PlayerInteractEvent.LeftClickBlock.Action.START) {
            // 后备路径：客户端未拦截（理论上不会发生）时服务端仍能记录
            applyPoint((ServerPlayer) event.getEntity(), 1, event.getPos());
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!isWand(event.getEntity(), event.getItemStack())) {
            return;
        }
        event.setCanceled(true);
        if (!event.getLevel().isClientSide) {
            applyPoint((ServerPlayer) event.getEntity(), 2, event.getPos());
        }
    }

    /** 服务端统一入口：校验 + 记录 + 提示（客户端 packet 也走这里） */
    public static void applyPoint(ServerPlayer player, int point, BlockPos pos) {
        if (point != 1 && point != 2) {
            return;
        }
        if (!isWand(player, player.getMainHandItem()) && !isWand(player, player.getOffhandItem())) {
            return;
        }
        if (player.isSpectator()) {
            return;
        }
        if (!pos.closerThan(player.blockPosition(), MAX_RANGE)) {
            player.displayClientMessage(Component.translatable("ts.wand.far"), false);
            return;
        }
        boolean changed = WandSelections.setPoint(player.getUUID(),
                player.level().dimension().location(), point, pos);
        if (!changed) {
            return;
        }
        player.displayClientMessage(Component.translatable(
                point == 1 ? "ts.wand.pos1" : "ts.wand.pos2",
                pos.getX(), pos.getY(), pos.getZ()), false);
        WandSelections.Sel sel = WandSelections.get(player.getUUID());
        if (sel != null && sel.a != null && sel.b != null) {
            long volume = (long) (Math.abs(sel.a.getX() - sel.b.getX()) + 1)
                    * (Math.abs(sel.a.getY() - sel.b.getY()) + 1)
                    * (Math.abs(sel.a.getZ() - sel.b.getZ()) + 1);
            player.displayClientMessage(Component.translatable("ts.wand.done", volume), false);
        }
    }

    private static boolean isWand(net.minecraft.world.entity.player.Player player,
                                  net.minecraft.world.item.ItemStack stack) {
        return !player.isSpectator() && stack.is(Items.STICK);
    }

    private WandEvents() {
    }
}
