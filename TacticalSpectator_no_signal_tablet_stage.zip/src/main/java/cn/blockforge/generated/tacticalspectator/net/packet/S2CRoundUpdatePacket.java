package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.client.ClientRx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * 回合名单同步：只发给与该回合相关的观众（参战者 + 正在观战该区域的人），
 * 保证不同区域互不串数据。空列表 = 通知客户端移除该回合（隐藏 HUD）。
 */
public final class S2CRoundUpdatePacket {

    public record Entry(UUID uuid, String name, boolean alive) {
    }

    public final long regionId;
    public final List<Entry> entries;

    public S2CRoundUpdatePacket(long regionId, List<Entry> entries) {
        this.regionId = regionId;
        this.entries = entries;
    }

    public static void encode(S2CRoundUpdatePacket msg, FriendlyByteBuf buf) {
        buf.writeLong(msg.regionId);
        buf.writeVarInt(msg.entries.size());
        for (Entry e : msg.entries) {
            buf.writeUUID(e.uuid());
            buf.writeUtf(e.name(), 32);
            buf.writeBoolean(e.alive());
        }
    }

    public static S2CRoundUpdatePacket decode(FriendlyByteBuf buf) {
        long region = buf.readLong();
        int size = buf.readVarInt();
        List<Entry> entries = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            entries.add(new Entry(buf.readUUID(), buf.readUtf(32), buf.readBoolean()));
        }
        return new S2CRoundUpdatePacket(region, entries);
    }

    public static void handle(S2CRoundUpdatePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientRx.applyRoundUpdate(msg.regionId, msg.entries)));
        ctx.setPacketHandled(true);
    }
}
