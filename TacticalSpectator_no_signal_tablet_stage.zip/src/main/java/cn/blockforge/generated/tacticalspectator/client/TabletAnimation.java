package cn.blockforge.generated.tacticalspectator.client;

/**
 * First-person tactical tablet animation state machine.
 * Timings are expressed in client ticks and interpolated during rendering.
 */
public final class TabletAnimation {
    public enum State { NONE, DRAWING, HELD, HOLSTERING }

    private static final int DRAW_TICKS = 18;
    private static final int HOLSTER_TICKS = 16;
    private static State state = State.NONE;
    private static int age;
    private static boolean completionPending;

    public static void beginDraw() {
        state = State.DRAWING;
        age = 0;
        completionPending = false;
    }

    public static void markHeld() {
        if (state == State.NONE) {
            state = State.HELD;
            age = 0;
        }
    }

    public static void beginHolster() {
        if (state == State.NONE) return;
        state = State.HOLSTERING;
        age = 0;
        completionPending = false;
    }

    public static void tick(boolean playerAlive, boolean tabletInEitherHand) {
        if (!playerAlive) {
            clear();
            return;
        }
        switch (state) {
            case DRAWING -> {
                if (++age >= DRAW_TICKS) {
                    state = tabletInEitherHand ? State.HELD : State.NONE;
                    age = 0;
                }
            }
            case HOLSTERING -> {
                if (++age >= HOLSTER_TICKS) {
                    state = State.NONE;
                    age = 0;
                    completionPending = true;
                }
            }
            case HELD -> {
                if (!tabletInEitherHand) {
                    state = State.NONE;
                    age = 0;
                }
            }
            case NONE -> age = 0;
        }
    }

    /** True exactly once when a F-key holster animation has finished. */
    public static boolean consumeHolsterCompletion() {
        if (!completionPending) return false;
        completionPending = false;
        return true;
    }

    public static State state() { return state; }

    public static float progress(float partialTick) {
        int duration = state == State.HOLSTERING ? HOLSTER_TICKS : DRAW_TICKS;
        return clamp((age + partialTick) / duration);
    }

    public static void clear() {
        state = State.NONE;
        age = 0;
        completionPending = false;
    }

    private static float clamp(float value) {
        return Math.max(0.0F, Math.min(1.0F, value));
    }

    private TabletAnimation() {}
}
