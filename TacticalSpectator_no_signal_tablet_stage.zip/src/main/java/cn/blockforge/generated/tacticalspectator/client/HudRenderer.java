package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.UUID;

/**
 * 右上角极简 HUD：小头像 + 绿/红圆点，无任何文字。
 * 只显示服务端同步过来的、与本玩家相关的回合名单（天然不串区）。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class HudRenderer {

    private static final int AVATAR = 16;
    private static final int MARGIN = 4;
    private static final int GREEN = 0xFF3CD95C;
    private static final int RED = 0xFFE14B4B;

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        render(event.getGuiGraphics());
    }

    private static void render(GuiGraphics gui) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null || mc.options.hideGui) {
            return;
        }
        if (!ClientState.spectating || ClientState.ROUNDS.isEmpty()) {
            return;
        }
        int screenW = mc.getWindow().getGuiScaledWidth();
        int x = screenW - MARGIN - AVATAR;
        int y = MARGIN;
        for (List<cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket.Entry> entries
                : ClientState.ROUNDS.values()) {
            for (var entry : entries) {
                PlayerFaceRenderer.draw(gui, skinOf(mc, entry.uuid(), entry.name()), x, y, AVATAR);
                drawDot(gui, x + AVATAR - 6, y + AVATAR - 6, entry.alive() ? GREEN : RED);
                y += AVATAR + 2;
            }
            y += 3;
        }
    }

    private static ResourceLocation skinOf(Minecraft mc, UUID uuid, String name) {
        ClientPacketListener connection = mc.getConnection();
        PlayerInfo info = connection == null ? null : connection.getPlayerInfo(uuid);
        com.mojang.authlib.GameProfile profile = info != null && info.getProfile() != null
                ? info.getProfile()
                : new com.mojang.authlib.GameProfile(uuid, name);
        return mc.getSkinManager().getInsecureSkinLocation(profile);
    }

    /** 5x5 圆形状态点 */
    private static void drawDot(GuiGraphics gui, int x, int y, int color) {
        gui.fill(x + 1, y, x + 4, y + 1, color);
        gui.fill(x, y + 1, x + 5, y + 4, color);
        gui.fill(x + 1, y + 4, x + 4, y + 5, color);
    }

    private HudRenderer() {
    }
}
