package cn.blockforge.generated.tacticalspectator.item;

import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * 战术平板：观战入口。
 * 手持右键：在本轮名单内且有存活目标时进入观战；观战中再右键退出。
 * 模型与贴图来自用户提供的 TACZ_Tactical_Tablet.bbmodel（已转换为物品模型）。
 */
public final class TacticalTabletItem extends Item {

    public TacticalTabletItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            SpectateService.toggle(sp);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
