package cn.blockforge.generated.tacticalspectator.net;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SCycleTargetPacket;
import cn.blockforge.generated.tacticalspectator.net.packet.C2STabletActionPacket;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SWandPointPacket;
import net.minecraftforge.network.NetworkDirection;
import java.util.Optional;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CSpectateModePacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** 客户端 <-> 服务端同步通道 */
public final class ModNetwork {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            id("main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static ResourceLocation id(String path) {
        return new ResourceLocation(TacticalSpectator.MOD_ID, path);
    }

    public static void init() {
        int index = 0;
        CHANNEL.registerMessage(index++, C2SWandPointPacket.class,
                C2SWandPointPacket::encode, C2SWandPointPacket::decode, C2SWandPointPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(index++, C2SCycleTargetPacket.class,
                C2SCycleTargetPacket::encode, C2SCycleTargetPacket::decode, C2SCycleTargetPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(index++, S2CRoundUpdatePacket.class,
                S2CRoundUpdatePacket::encode, S2CRoundUpdatePacket::decode, S2CRoundUpdatePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(index++, S2CSpectateModePacket.class,
                S2CSpectateModePacket::encode, S2CSpectateModePacket::decode, S2CSpectateModePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(index, C2STabletActionPacket.class,
                C2STabletActionPacket::encode, C2STabletActionPacket::decode, C2STabletActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    public static void sendTo(ServerPlayer player, Object message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }

    private ModNetwork() {
    }
}
