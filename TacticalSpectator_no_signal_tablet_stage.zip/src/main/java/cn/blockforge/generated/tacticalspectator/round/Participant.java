package cn.blockforge.generated.tacticalspectator.round;

import java.util.UUID;

/** 本轮名单中的一名参战玩家 */
public final class Participant {
    public final UUID uuid;
    public final String name;
    public boolean alive;

    public Participant(UUID uuid, String name, boolean alive) {
        this.uuid = uuid;
        this.name = name;
        this.alive = alive;
    }
}
