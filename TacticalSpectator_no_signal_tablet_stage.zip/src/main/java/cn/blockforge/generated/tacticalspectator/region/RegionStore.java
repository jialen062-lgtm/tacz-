package cn.blockforge.generated.tacticalspectator.region;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 区域持久化存储（SavedData，写进世界存档，重启不丢）。
 * 允许重叠；同一位置命中多个区域时取体积最小者，体积相同按稳定唯一 ID 排序。
 */
public final class RegionStore extends SavedData {
    public static final String DATA_NAME = "tactical_spectator_regions";

    private final Map<Long, Region> regions = new LinkedHashMap<>();
    private long nextId = 1L;

    public static RegionStore get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(RegionStore::load, RegionStore::new, DATA_NAME);
    }

    public static RegionStore load(CompoundTag tag) {
        RegionStore store = new RegionStore();
        store.nextId = tag.getLong("nextId");
        if (store.nextId < 1L) {
            store.nextId = 1L;
        }
        ListTag list = tag.getList("regions", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Region r = Region.fromTag(list.getCompound(i));
            store.regions.put(r.id, r);
            if (r.id >= store.nextId) {
                store.nextId = r.id + 1;
            }
        }
        return store;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("nextId", nextId);
        ListTag list = new ListTag();
        for (Region r : regions.values()) {
            list.add(r.toTag());
        }
        tag.put("regions", list);
        return tag;
    }

    public Region byName(String name) {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        for (Region r : regions.values()) {
            if (r.lowerName.equals(lower)) {
                return r;
            }
        }
        return null;
    }

    public Region byId(long id) {
        return regions.get(id);
    }

    public List<Region> all() {
        return new ArrayList<>(regions.values());
    }

    public List<String> names() {
        List<String> out = new ArrayList<>();
        for (Region r : regions.values()) {
            out.add(r.name);
        }
        return out;
    }

    /** 创建区域；名称重复时返回 null */
    public Region create(String name, java.util.UUID owner, String ownerName, ResourceLocation dim,
                         BlockPos a, BlockPos b) {
        if (byName(name) != null) {
            return null;
        }
        Region r = new Region(nextId++, name, owner, ownerName, dim, a, b);
        regions.put(r.id, r);
        setDirty();
        return r;
    }

    public boolean remove(long id) {
        boolean removed = regions.remove(id) != null;
        if (removed) {
            setDirty();
        }
        return removed;
    }

    public void resize(Region region, BlockPos a, BlockPos b) {
        region.setBox(a, b);
        setDirty();
    }

    /** 该点所属区域中体积最小者；体积相同取 ID 更小者（稳定排序） */
    public Region smallestAt(ResourceLocation dim, BlockPos pos) {
        Region best = null;
        long bestVolume = Long.MAX_VALUE;
        for (Region r : regions.values()) {
            if (!r.contains(dim, pos)) {
                continue;
            }
            long v = r.volume();
            if (v < bestVolume || (v == bestVolume && best != null && r.id < best.id)) {
                best = r;
                bestVolume = v;
            }
        }
        return best;
    }
}
