package cn.blockforge.generated.tacticalspectator.client;

import cn.blockforge.generated.tacticalspectator.TacticalSpectator;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.C2SWandPointPacket;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 客户端侧的木棍点选：更新本地预览框，并把坐标转发给服务端
 * （左键点击被取消后原版不会发包，必须走自定义通道）。
 */
@Mod.EventBusSubscriber(modid = TacticalSpectator.MOD_ID, value = Dist.CLIENT)
public final class ClientWandEvents {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (!event.getLevel().isClientSide()
                || !event.getItemStack().is(Items.STICK)
                || event.getEntity().isSpectator()) {
            return;
        }
        if (event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START) {
            return;
        }
        updateDimension(event.getLevel().dimension().location());
        ClientState.selA = event.getPos();
        ModNetwork.CHANNEL.sendToServer(new C2SWandPointPacket(1, event.getPos()));
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getLevel().isClientSide()
                || !event.getItemStack().is(Items.STICK)
                || event.getEntity().isSpectator()) {
            return;
        }
        updateDimension(event.getLevel().dimension().location());
        ClientState.selB = event.getPos();
        ModNetwork.CHANNEL.sendToServer(new C2SWandPointPacket(2, event.getPos()));
    }

    private static void updateDimension(net.minecraft.resources.ResourceLocation dimension) {
        if (!dimension.equals(ClientState.selDim)) {
            ClientState.selA = null;
            ClientState.selB = null;
            ClientState.selDim = dimension;
        }
    }

    private ClientWandEvents() {
    }
}
