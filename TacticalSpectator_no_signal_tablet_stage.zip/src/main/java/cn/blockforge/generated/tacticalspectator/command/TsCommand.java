package cn.blockforge.generated.tacticalspectator.command;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.region.Region;
import cn.blockforge.generated.tacticalspectator.region.RegionStore;
import cn.blockforge.generated.tacticalspectator.region.WandSelections;
import cn.blockforge.generated.tacticalspectator.round.RoundService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * /ts 指令族：
 *   /ts region create <名称>   —— 用当前选区创建区域（权限 1，或单人开作弊）
 *   /ts region list            —— 列出所有区域
 *   /ts region delete <名称>   —— 删除区域（所有者或 OP）
 *   /ts region resize <名称>   —— 用当前选区调整区域（所有者或 OP）
 *   /ts tablet [玩家]          —— 发放战术平板（OP）
 */
public final class TsCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("ts")
                .then(Commands.literal("region")
                        .then(Commands.literal("create")
                                .requires(s -> s.hasPermission(1))
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .executes(TsCommand::create)))
                        .then(Commands.literal("list")
                                .executes(TsCommand::list))
                        .then(Commands.literal("delete")
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .suggests(TsCommand::suggestNames)
                                        .executes(TsCommand::delete)))
                        .then(Commands.literal("resize")
                                .then(Commands.argument("name", StringArgumentType.word())
                                        .suggests(TsCommand::suggestNames)
                                        .executes(TsCommand::resize))))
                .then(Commands.literal("tablet")
                        .requires(s -> s.hasPermission(2))
                        .executes(ctx -> giveTablet(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> giveTablet(ctx, EntityArgument.getPlayer(ctx, "player"))))));
    }

    private static int create(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        String name = StringArgumentType.getString(ctx, "name");
        RegionStore store = RegionStore.get(ctx.getSource().getServer());
        if (store.byName(name) != null) {
            player.displayClientMessage(Component.translatable("ts.region.exists", name), false);
            return 0;
        }
        WandSelections.Sel sel = WandSelections.get(player.getUUID());
        if (sel == null || sel.a == null || sel.b == null) {
            player.displayClientMessage(Component.translatable("ts.region.noselection"), false);
            return 0;
        }
        Region region = store.create(name, player.getUUID(),
                player.getGameProfile().getName(), sel.dim, sel.a, sel.b);
        ctx.getSource().sendSuccess(() ->
                Component.translatable("ts.region.created", name, region.volume()), true);
        return 1;
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        RegionStore store = RegionStore.get(ctx.getSource().getServer());
        var regions = store.all();
        if (regions.isEmpty()) {
            ctx.getSource().sendSuccess(() -> Component.translatable("ts.region.empty"), false);
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.translatable("ts.region.count", regions.size()), false);
        for (Region r : regions) {
            ctx.getSource().sendSuccess(() -> Component.translatable("ts.region.row",
                    r.name, r.ownerName == null || r.ownerName.isEmpty() ? "-" : r.ownerName,
                    r.dimension.toString(), r.volume(),
                    r.minX, r.minY, r.minZ, r.maxX, r.maxY, r.maxZ), false);
        }
        return regions.size();
    }

    private static int delete(CommandContext<CommandSourceStack> ctx) {
        RegionStore store = RegionStore.get(ctx.getSource().getServer());
        String name = StringArgumentType.getString(ctx, "name");
        Region region = store.byName(name);
        if (region == null) {
            ctx.getSource().sendFailure(Component.translatable("ts.region.notfound", name));
            return 0;
        }
        if (!canManage(ctx.getSource(), region)) {
            ctx.getSource().sendFailure(Component.translatable("ts.region.noperm"));
            return 0;
        }
        store.remove(region.id);
        RoundService.onRegionDeleted(ctx.getSource().getServer(), region.id);
        ctx.getSource().sendSuccess(() -> Component.translatable("ts.region.deleted", region.name), true);
        return 1;
    }

    private static int resize(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        RegionStore store = RegionStore.get(ctx.getSource().getServer());
        String name = StringArgumentType.getString(ctx, "name");
        Region region = store.byName(name);
        if (region == null) {
            player.displayClientMessage(Component.translatable("ts.region.notfound", name), false);
            return 0;
        }
        if (!canManage(ctx.getSource(), region)) {
            player.displayClientMessage(Component.translatable("ts.region.noperm"), false);
            return 0;
        }
        WandSelections.Sel sel = WandSelections.get(player.getUUID());
        if (sel == null || sel.a == null || sel.b == null) {
            player.displayClientMessage(Component.translatable("ts.region.noselection"), false);
            return 0;
        }
        if (!region.dimension.equals(sel.dim)) {
            player.displayClientMessage(Component.translatable("ts.region.dimdiff"), false);
            return 0;
        }
        store.resize(region, sel.a, sel.b);
        player.displayClientMessage(
                Component.translatable("ts.region.resized", region.name, region.volume()), false);
        return 1;
    }

    private static int giveTablet(CommandContext<CommandSourceStack> ctx, ServerPlayer target) {
        ItemStack stack = new ItemStack(ModItems.TACTICAL_TABLET.get());
        if (!target.getInventory().add(stack)) {
            target.drop(stack, false);
        }
        ctx.getSource().sendSuccess(() ->
                Component.translatable("ts.tablet.given", target.getDisplayName()), false);
        return 1;
    }

    /** 所有者可管理自己的区域；OP（权限 2）可管理所有区域 */
    private static boolean canManage(CommandSourceStack source, Region region) {
        if (source.hasPermission(2)) {
            return true;
        }
        ServerPlayer player = source.getEntity() instanceof ServerPlayer sp ? sp : null;
        return player != null && region.owner != null && region.owner.equals(player.getUUID());
    }

    /** 区域名自动补全 */
    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestNames(
            CommandContext<CommandSourceStack> ctx,
            com.mojang.brigadier.suggestion.SuggestionsBuilder builder) {
        RegionStore store = RegionStore.get(ctx.getSource().getServer());
        return SharedSuggestionProvider.suggest(store.names(), builder);
    }
}
