package cn.blockforge.generated.tacticalspectator.round;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 一个区域当前回合的状态：参战名单（按加入顺序）、存活/死亡。
 * 每个区域一份，区域之间数据完全隔离。
 */
public final class Round {
    /** 区域 ID（与 Region.id 一致，long 稳定唯一） */
    public final long regionId;
    public final Map<UUID, Participant> participants = new LinkedHashMap<>();

    public Round(long regionId) {
        this.regionId = regionId;
    }

    public boolean contains(UUID player) {
        return participants.containsKey(player);
    }

    public Participant get(UUID player) {
        return participants.get(player);
    }

    /** @return true 表示这是新加入的参战玩家 */
    public boolean add(UUID player, String name) {
        if (participants.containsKey(player)) {
            return false;
        }
        participants.put(player, new Participant(player, name, true));
        return true;
    }

    /** @return true 状态发生变化 */
    public boolean setDead(UUID player) {
        Participant p = participants.get(player);
        if (p == null || !p.alive) {
            return false;
        }
        p.alive = false;
        return true;
    }

    /** 复活：@return true 状态发生变化 */
    public boolean revive(UUID player) {
        Participant p = participants.get(player);
        if (p == null || p.alive) {
            return false;
        }
        p.alive = true;
        return true;
    }

    public boolean remove(UUID player) {
        return participants.remove(player) != null;
    }

    public boolean allDead() {
        if (participants.isEmpty()) {
            return true;
        }
        for (Participant p : participants.values()) {
            if (p.alive) {
                return false;
            }
        }
        return true;
    }

    /** 存活者名单，按加入顺序（HUD 与 A/D 循环共用同一顺序） */
    public List<Participant> aliveList() {
        List<Participant> out = new ArrayList<>();
        for (Participant p : participants.values()) {
            if (p.alive) {
                out.add(p);
            }
        }
        return out;
    }

    public List<Participant> orderedList() {
        return new ArrayList<>(participants.values());
    }
}
