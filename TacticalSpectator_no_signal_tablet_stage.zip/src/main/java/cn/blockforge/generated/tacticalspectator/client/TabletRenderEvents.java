package cn.blockforge.generated.tacticalspectator.client;

import com.mojang.math.Axis;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.common.Mod;

/** Applies smooth first-person transforms without replacing Forge/vanilla item rendering. */
@Mod.EventBusSubscriber(modid = cn.blockforge.generated.tacticalspectator.TacticalSpectator.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TabletRenderEvents {
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onRenderHand(RenderHandEvent event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;

        TabletAnimation.State state = TabletAnimation.state();
        if (state == TabletAnimation.State.NONE || state == TabletAnimation.State.HELD) return;

        float raw = TabletAnimation.progress(event.getPartialTick());
        // Smoothstep avoids abrupt acceleration at either end of the motion.
        float eased = raw * raw * (3.0F - 2.0F * raw);
        var pose = event.getPoseStack();
        if (state == TabletAnimation.State.DRAWING) {
                if (event.getItemStack().isEmpty()) return;
                // The currently held firearm is lowered out of view while the server swaps in the tablet.
                if (!isTablet(event.getItemStack())) {
                    float lower = Math.min(1.0F, raw * 2.8F);
                    pose.translate(0.0D, -0.95D * lower, 0.12D * lower);
                    pose.mulPose(Axis.XP.rotationDegrees(-28.0F * lower));
                    pose.mulPose(Axis.ZP.rotationDegrees(8.0F * lower));
                } else {
                    float remaining = 1.0F - eased;
                    pose.translate(0.0D, 0.78D * remaining, -0.22D * remaining);
                    pose.mulPose(Axis.XP.rotationDegrees(48.0F * remaining));
                    pose.mulPose(Axis.ZP.rotationDegrees(-18.0F * remaining));
                }
        } else if (state == TabletAnimation.State.HOLSTERING) {
            // Tablet leaves toward the lower edge; if the server has already restored the old item,
            // it follows the inverse path so the hand does not pop back to its idle pose.
            pose.translate(0.0D, -0.82D * eased, 0.16D * eased);
            pose.mulPose(Axis.XP.rotationDegrees(-42.0F * eased));
            pose.mulPose(Axis.ZP.rotationDegrees(14.0F * eased));
        }
    }

    private static boolean isTablet(net.minecraft.world.item.ItemStack stack) {
        return stack.getItem() == cn.blockforge.generated.tacticalspectator.ModItems.TACTICAL_TABLET.get();
    }

    private TabletRenderEvents() {}
}
