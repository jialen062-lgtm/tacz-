package cn.blockforge.generated.tacticalspectator.item;

import cn.blockforge.generated.tacticalspectator.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Inventory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server-authoritative tablet equip/restore; never creates a tablet item. */
public final class TabletInventoryService {
    private record RestorePoint(int selectedSlot, int tabletSlot, boolean offhand) {}
    private static final Map<UUID, RestorePoint> RESTORE_POINTS = new ConcurrentHashMap<>();

    public static boolean equip(ServerPlayer player) {
        Inventory inventory = player.getInventory();
        if (inventory.getSelected().is(ModItems.TACTICAL_TABLET.get())) return true;

        for (int slot = 0; slot < inventory.items.size(); slot++) {
            if (slot == inventory.selected) continue;
            if (inventory.getItem(slot).is(ModItems.TACTICAL_TABLET.get())) {
                RESTORE_POINTS.put(player.getUUID(), new RestorePoint(inventory.selected, slot, false));
                ItemStack tablet = inventory.getItem(slot);
                inventory.setItem(slot, inventory.getSelected());
                inventory.setItem(inventory.selected, tablet);
                player.containerMenu.broadcastChanges();
                return true;
            }
        }

        if (player.getOffhandItem().is(ModItems.TACTICAL_TABLET.get())) {
            RESTORE_POINTS.put(player.getUUID(), new RestorePoint(inventory.selected, -1, true));
            ItemStack tablet = player.getOffhandItem();
            player.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, inventory.getSelected());
            inventory.setItem(inventory.selected, tablet);
            player.containerMenu.broadcastChanges();
            return true;
        }
        return false;
    }

    /** Restores the item displaced when the tablet was equipped, if the tablet is still held. */
    public static void restore(ServerPlayer player) {
        RestorePoint point = RESTORE_POINTS.remove(player.getUUID());
        if (point == null) return;
        Inventory inventory = player.getInventory();
        if (point.offhand()) {
            int tabletNow = -1;
            for (int slot = 0; slot < inventory.items.size(); slot++) {
                if (inventory.getItem(slot).is(ModItems.TACTICAL_TABLET.get())) {
                    tabletNow = slot;
                    break;
                }
            }
            if (tabletNow >= 0) {
                ItemStack tablet = inventory.getItem(tabletNow);
                inventory.setItem(tabletNow, player.getOffhandItem());
                player.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, tablet);
            }
        } else {
            int tabletNow = -1;
            for (int slot = 0; slot < inventory.items.size(); slot++) {
                if (inventory.getItem(slot).is(ModItems.TACTICAL_TABLET.get())) {
                    tabletNow = slot;
                    break;
                }
            }
            if (tabletNow >= 0 && point.tabletSlot() >= 0 && tabletNow != point.tabletSlot()) {
                ItemStack tablet = inventory.getItem(tabletNow);
                inventory.setItem(tabletNow, inventory.getItem(point.tabletSlot()));
                inventory.setItem(point.tabletSlot(), tablet);
            }
        }
        player.containerMenu.broadcastChanges();
    }

    public static void forget(ServerPlayer player) {
        RESTORE_POINTS.remove(player.getUUID());
    }

    private TabletInventoryService() {}
}
