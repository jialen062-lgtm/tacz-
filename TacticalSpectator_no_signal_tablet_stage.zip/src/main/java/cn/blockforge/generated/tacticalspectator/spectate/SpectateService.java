package cn.blockforge.generated.tacticalspectator.spectate;

import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CSpectateModePacket;
import cn.blockforge.generated.tacticalspectator.region.Region;
import cn.blockforge.generated.tacticalspectator.region.RegionStore;
import cn.blockforge.generated.tacticalspectator.round.Round;
import cn.blockforge.generated.tacticalspectator.round.RoundService;
import cn.blockforge.generated.tacticalspectator.item.TabletInventoryService;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetCameraPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** 用原版镜头消息切换视角，玩家本体留在原处。 */
public final class SpectateService {
    private record Session(long regionId, UUID target) {}

    private static final Map<UUID, Session> ACTIVE = new HashMap<>();
    // 只向客户端已收到的实体切镜头，否则原版会忽略镜头消息。
    private static final Map<UUID, Set<UUID>> TRACKED_PLAYERS = new HashMap<>();

    public static void tracking(ServerPlayer viewer, ServerPlayer target, boolean tracking) {
        if (tracking) {
            TRACKED_PLAYERS.computeIfAbsent(viewer.getUUID(), id -> new HashSet<>()).add(target.getUUID());
        } else {
            Set<UUID> targets = TRACKED_PLAYERS.get(viewer.getUUID());
            if (targets != null) {
                targets.remove(target.getUUID());
                if (targets.isEmpty()) {
                    TRACKED_PLAYERS.remove(viewer.getUUID());
                }
            }
        }
    }

    public static boolean toggle(ServerPlayer player) {
        if (ACTIVE.containsKey(player.getUUID())) {
            stopFor(player, "ts.spectate.stopped");
            return true;
        }
        Round round = RoundService.firstRoundOf(player.getUUID());
        var participant = round == null ? null : round.get(player.getUUID());
        if (round == null || participant == null || participant.alive || !player.isAlive() || player.isSpectator()) {
            tell(player, "ts.spectate.none");
            return false;
        }
        List<ServerPlayer> targets = targets(player, round);
        if (targets.isEmpty()) {
            tell(player, "ts.spectate.unavailable");
            return false;
        }
        select(player, round.regionId, randomTarget(targets));
        RoundService.sync(player.getServer(), round);
        return true;
    }

    public static void cycle(ServerPlayer player, int direction) {
        Session session = ACTIVE.get(player.getUUID());
        if (session == null || direction == 0) {
            return;
        }
        List<ServerPlayer> targets = targets(player, RoundService.byRegion(session.regionId));
        if (targets.isEmpty()) {
            stopFor(player, "ts.spectate.unavailable");
            return;
        }
        int current = -1;
        for (int i = 0; i < targets.size(); i++) {
            if (targets.get(i).getUUID().equals(session.target)) {
                current = i;
                break;
            }
        }
        int next = current < 0 ? (direction > 0 ? 0 : targets.size() - 1)
                : Math.floorMod(current + Integer.signum(direction), targets.size());
        select(player, session.regionId, targets.get(next));
    }

    public static void validate(MinecraftServer server) {
        for (var entry : new ArrayList<>(ACTIVE.entrySet())) {
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                ACTIVE.remove(entry.getKey());
                continue;
            }
            Session session = entry.getValue();
            List<ServerPlayer> targets = targets(player, RoundService.byRegion(session.regionId));
            if (targets.isEmpty()) {
                stopFor(player, "ts.spectate.unavailable");
            } else if (targets.stream().noneMatch(target -> target.getUUID().equals(session.target))) {
                select(player, session.regionId, randomTarget(targets));
            }
        }
    }

    private static List<ServerPlayer> targets(ServerPlayer viewer, Round round) {
        List<ServerPlayer> result = new ArrayList<>();
        var viewerParticipant = round == null ? null : round.get(viewer.getUUID());
        if (round == null || viewerParticipant == null || viewerParticipant.alive
                || !viewer.isAlive() || viewer.isSpectator()) {
            return result;
        }
        RegionStore regions = RegionStore.get(viewer.getServer());
        Set<UUID> tracked = TRACKED_PLAYERS.getOrDefault(viewer.getUUID(), Set.of());
        for (var participant : round.orderedList()) {
            if (!participant.alive || !tracked.contains(participant.uuid)) {
                continue;
            }
            ServerPlayer target = viewer.getServer().getPlayerList().getPlayer(participant.uuid);
            if (target == null || target == viewer || !target.isAlive() || target.isSpectator()
                    || target.level() != viewer.level()) {
                continue;
            }
            Region currentRegion = regions.smallestAt(target.level().dimension().location(), target.blockPosition());
            if (currentRegion != null && currentRegion.id == round.regionId) {
                result.add(target);
            }
        }
        return result;
    }

    private static ServerPlayer randomTarget(List<ServerPlayer> targets) {
        return targets.get(ThreadLocalRandom.current().nextInt(targets.size()));
    }

    private static void select(ServerPlayer player, long regionId, ServerPlayer target) {
        Session old = ACTIVE.put(player.getUUID(), new Session(regionId, target.getUUID()));
        player.connection.send(new ClientboundSetCameraPacket(target));
        if (old == null) {
            ModNetwork.sendTo(player, new S2CSpectateModePacket(true));
        }
        player.displayClientMessage(Component.translatable("ts.spectate.target", target.getGameProfile().getName()), true);
    }

    public static boolean isActive(ServerPlayer player) {
        return ACTIVE.containsKey(player.getUUID());
    }

    public static void stopFor(ServerPlayer player, String messageKey) {
        if (ACTIVE.remove(player.getUUID()) == null) {
            return;
        }
        player.connection.send(new ClientboundSetCameraPacket(player));
        ModNetwork.sendTo(player, new S2CSpectateModePacket(false));
        if (messageKey != null) {
            tell(player, messageKey);
        }
    }

    public static void onLogout(ServerPlayer player) {
        UUID id = player.getUUID();
        ACTIVE.remove(id);
        TabletInventoryService.forget(player);
        TRACKED_PLAYERS.remove(id);
        TRACKED_PLAYERS.values().forEach(targets -> targets.remove(id));
    }

    public static void onRoundEnd(MinecraftServer server, long regionId) {
        for (ServerPlayer spectator : spectatorsOf(server, regionId)) {
            stopFor(spectator, "ts.spectate.ended");
        }
    }

    public static List<ServerPlayer> spectatorsOf(MinecraftServer server, long regionId) {
        List<ServerPlayer> result = new ArrayList<>();
        ACTIVE.forEach((id, session) -> {
            if (session.regionId == regionId) {
                ServerPlayer spectator = server.getPlayerList().getPlayer(id);
                if (spectator != null) {
                    result.add(spectator);
                }
            }
        });
        return result;
    }

    public static void clear() {
        ACTIVE.clear();
        TRACKED_PLAYERS.clear();
    }

    private static void tell(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private SpectateService() {}
}
