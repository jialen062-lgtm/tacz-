package cn.blockforge.generated.tacticalspectator.round;

import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CRoundUpdatePacket;
import cn.blockforge.generated.tacticalspectator.region.Region;
import cn.blockforge.generated.tacticalspectator.region.RegionStore;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 回合管理（服务端内存状态，权威数据）：
 *  - 玩家踏入区域自动加入本轮名单（进入即参战）；
 *  - 死亡/复活/退出都会更新名单并同步给相关观众；
 *  - 全员死亡即本轮结束（隐藏 HUD、结束观战，等待下一轮）。
 * 每个区域一份 Round，区域之间完全隔离，支持多区域同时战斗。
 */
public final class RoundService {

    /** key = 区域 ID */
    private static final Map<Long, Round> ROUNDS = new HashMap<>();
    private static int tick = 0;

    public static void onServerTick(MinecraftServer server) {
        tick++;
        if (tick % 10 == 0) {
            RegionStore store = RegionStore.get(server);
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.isSpectator() || !p.isAlive()) {
                    continue;
                }
                Region r = store.smallestAt(p.level().dimension().location(), p.blockPosition());
                if (r != null) {
                    join(server, p, r);
                }
            }
        }
        if (tick % 5 == 0) {
            SpectateService.validate(server);
        }
    }

    /** 进入区域 = 加入本轮名单 */
    public static void join(MinecraftServer server, ServerPlayer player, Region region) {
        UUID id = player.getUUID();
        Round previous = firstRoundOf(id);
        if (previous != null) {
            Participant existing = previous.get(id);
            // 淘汰身份在本轮结束前不可通过重新进入区域恢复。
            if (existing == null || previous.regionId == region.id || !existing.alive) {
                return;
            }
            // 同一玩家只允许属于一个活动回合；转入另一区域时移除旧的存活记录。
            previous.remove(id);
            refreshAfterDeparture(server, previous);
            ModNetwork.sendTo(player, new S2CRoundUpdatePacket(previous.regionId, List.of()));
        }
        Round round = ROUNDS.computeIfAbsent(region.id, Round::new);
        if (round.add(id, player.getGameProfile().getName())) {
            sync(server, round);
        }
    }

    public static void onDeath(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        SpectateService.stopFor(player, null);
        // 必须使用死亡前已经登记的回合身份，不能依赖死亡瞬间的位置：
        // 击退、传送或维度变化都可能使死亡位置不再处于原区域。
        Round round = firstRoundOf(player.getUUID());
        if (round != null && round.setDead(player.getUUID())) {
            refreshAfterDeparture(server, round);
        }
    }

    public static void onRespawn(ServerPlayer player) {
        SpectateService.stopFor(player, null);
        // 大厅复活后仍保留本轮淘汰状态，才可以打开平板观战。
    }

    public static void onLogout(ServerPlayer player) {
        SpectateService.onLogout(player);
        // 离线不等于退出本轮：保留 Participant，重连后仍是原来的存活/淘汰身份。
        // 观战会话与跟踪缓存则由 SpectateService 清理。

    }

    private static void refreshAfterDeparture(MinecraftServer server, Round round) {
        if (round.allDead()) {
            endRound(server, round);
        } else {
            sync(server, round);
            SpectateService.validate(server);
        }
    }

    /** 区域被删除：本轮作废 */
    public static void onRegionDeleted(MinecraftServer server, long regionId) {
        Round round = ROUNDS.remove(regionId);
        if (round == null) {
            return;
        }
        for (ServerPlayer v : viewers(server, round)) {
            ModNetwork.sendTo(v, new S2CRoundUpdatePacket(regionId, List.of()));
        }
        SpectateService.onRoundEnd(server, regionId);
    }

    public static Round byRegion(long regionId) {
        return ROUNDS.get(regionId);
    }

    public static boolean isEliminated(UUID player) {
        Round round = firstRoundOf(player);
        Participant participant = round == null ? null : round.get(player);
        return participant != null && !participant.alive;
    }

    /** 该玩家所在的第一个回合（正常只会在一个区域的名单里） */
    public static Round firstRoundOf(UUID player) {
        for (Round round : ROUNDS.values()) {
            if (round.contains(player)) {
                return round;
            }
        }
        return null;
    }

    public static void clear() {
        ROUNDS.clear();
        tick = 0;
    }

    // ---------- 同步 ----------

    private static List<Round> snapshot() {
        return new ArrayList<>(ROUNDS.values());
    }

    /** 能看到这个回合 HUD 的人：在线参战者 + 正在观战这个区域的人 */
    private static List<ServerPlayer> viewers(MinecraftServer server, Round round) {
        List<ServerPlayer> out = new ArrayList<>();
        for (UUID uuid : round.participants.keySet()) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) {
                out.add(p);
            }
        }
        out.addAll(SpectateService.spectatorsOf(server, round.regionId));
        return out;
    }

    public static void sync(MinecraftServer server, Round round) {
        if (round == null) {
            return;
        }
        List<S2CRoundUpdatePacket.Entry> entries = new ArrayList<>();
        for (Participant p : round.orderedList()) {
            entries.add(new S2CRoundUpdatePacket.Entry(p.uuid, p.name, p.alive));
        }
        S2CRoundUpdatePacket packet = new S2CRoundUpdatePacket(round.regionId, entries);
        for (ServerPlayer v : viewers(server, round)) {
            ModNetwork.sendTo(v, packet);
        }
    }

    private static void endRound(MinecraftServer server, Round round) {
        ROUNDS.remove(round.regionId);
        for (ServerPlayer v : viewers(server, round)) {
            ModNetwork.sendTo(v, new S2CRoundUpdatePacket(round.regionId, List.of()));
        }
        SpectateService.onRoundEnd(server, round.regionId);
    }

    private RoundService() {
    }
}
