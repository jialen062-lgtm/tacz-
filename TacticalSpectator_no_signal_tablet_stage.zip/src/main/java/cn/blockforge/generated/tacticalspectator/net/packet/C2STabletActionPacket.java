package cn.blockforge.generated.tacticalspectator.net.packet;

import cn.blockforge.generated.tacticalspectator.item.TabletInventoryService;
import cn.blockforge.generated.tacticalspectator.spectate.SpectateService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 长按换手键只取出背包里已有的平板，不发放新物品。 */
public record C2STabletActionPacket(boolean exitSpectating) {
    public static void encode(C2STabletActionPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.exitSpectating);
    }

    public static C2STabletActionPacket decode(FriendlyByteBuf buf) {
        return new C2STabletActionPacket(buf.readBoolean());
    }

    public static void handle(C2STabletActionPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) {
                return;
            }
            if (msg.exitSpectating) {
                SpectateService.stopFor(player, "ts.spectate.stopped");
                TabletInventoryService.restore(player);
            } else if (player.isAlive() && !player.isSpectator() && !SpectateService.isActive(player)) {
                // Tablet access is independent of round/elimination state. This only equips
                // the item; it never starts spectating or grants a camera target.
                TabletInventoryService.equip(player);
            }
        });
        ctx.setPacketHandled(true);
    }

}
