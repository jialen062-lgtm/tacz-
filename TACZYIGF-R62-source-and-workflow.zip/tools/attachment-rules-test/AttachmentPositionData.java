package cn.blockforge.generated.taczcnpcalert;

/** Test-only stand-in for the Minecraft-backed offset record. */
public final class AttachmentPositionData {
    private AttachmentPositionData() {}
    public record Offset(double x, double y, double z) {}
}
