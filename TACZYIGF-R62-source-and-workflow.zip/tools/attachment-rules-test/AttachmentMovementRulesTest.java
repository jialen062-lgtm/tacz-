package cn.blockforge.generated.taczcnpcalert;

public final class AttachmentMovementRulesTest {
    private static int assertions;

    public static void main(String[] args) {
        fixedSlotsStayFixed();
        onlyNamedAdjustableGripsMove();
        railsRequireExplicitVerification();
        offsetsStayOnOneAxisAndWithinBounds();
        System.out.println("AttachmentMovementRules: " + assertions + " assertions passed");
    }

    private static void fixedSlotsStayFixed() {
        for (String slot : new String[]{"STOCK", "MUZZLE", "EXTENDED_MAG", "MAG", "SIGHT_FRONT", "SIGHT_REAR"}) {
            check(!AttachmentMovementRules.canDrag(slot, "tacz:vertical_grip", true), slot + " must stay fixed");
        }
        check(!AttachmentMovementRules.canDrag("UNKNOWN", "tacz:vertical_grip", true), "unknown slot must not move");
        check(!AttachmentMovementRules.canDrag("GRIP", "tacz:vertical_grip", false), "editor gate must be enforced");
    }

    private static void onlyNamedAdjustableGripsMove() {
        for (String id : new String[]{"tacz:vertical_grip", "tacz:grip_vertical", "tacz:angled_grip",
                "tacz:grip_angled", "tacz:foregrip_mlok", "tacz:fore_grip", "tacz:handstop",
                "tacz:hand_stop", "tacz:stubby_grip"}) {
            check(AttachmentMovementRules.canDrag("GRIP", id, true), id + " should be movable");
        }
        for (String id : new String[]{"tacz:pistol_grip", "tacz:weapon_grip", "tacz:vertical_laser",
                "tacz:bipod_grip", "tacz:unknown"}) {
            check(!AttachmentMovementRules.canDrag("GRIP", id, true), id + " must not be assumed movable");
        }
    }

    private static void railsRequireExplicitVerification() {
        for (String slot : new String[]{"SCOPE", "LASER"}) {
            check(!AttachmentMovementRules.canDrag(slot, "tacz:optic", true), slot + " needs verified rail");
            check(AttachmentMovementRules.canDrag(slot, "tacz:optic", true, true), slot + " may move on verified rail");
            check(!AttachmentMovementRules.usesLongitudinalRail(slot, "tacz:optic"), slot + " default rail must be false");
            check(AttachmentMovementRules.usesLongitudinalRail(slot, "tacz:optic", true), slot + " verified rail must be true");
        }
    }

    private static void offsetsStayOnOneAxisAndWithinBounds() {
        AttachmentPositionData.Offset grip = AttachmentMovementRules.constrain(
                "GRIP", "tacz:vertical_grip", 1.0, 0.7, -0.4);
        near(0.22, grip.x(), "grip max");
        near(0.0, grip.y(), "grip y locked");
        near(0.0, grip.z(), "grip z locked");

        AttachmentPositionData.Offset railDenied = AttachmentMovementRules.constrain(
                "SCOPE", "tacz:optic", 0.3, 0.2, 0.1);
        near(0.0, railDenied.x(), "unverified scope offset denied");

        AttachmentPositionData.Offset rail = AttachmentMovementRules.constrain(
                "SCOPE", "tacz:optic", -1.0, 0.2, 0.1, true);
        near(-0.45, rail.x(), "verified rail max");
        near(0.0, rail.y(), "rail y locked");
        near(0.0, rail.z(), "rail z locked");

        AttachmentPositionData.Offset fixed = AttachmentMovementRules.constrain(
                "STOCK", "tacz:stock", 0.2, 0.1, 0.1, true);
        near(0.0, fixed.x(), "stock remains fixed");
    }

    private static void check(boolean value, String message) {
        assertions++;
        if (!value) throw new AssertionError(message);
    }

    private static void near(double expected, double actual, String message) {
        assertions++;
        if (Math.abs(expected - actual) > 1.0E-9) {
            throw new AssertionError(message + ": expected " + expected + ", got " + actual);
        }
    }
}
