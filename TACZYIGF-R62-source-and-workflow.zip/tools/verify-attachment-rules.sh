#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
PACKAGE_DIR="$TMP/cn/blockforge/generated/taczcnpcalert"
mkdir -p "$PACKAGE_DIR"
cp "$ROOT/src/main/java/cn/blockforge/generated/taczcnpcalert/AttachmentMovementRules.java" "$PACKAGE_DIR/"
cp "$ROOT/tools/attachment-rules-test/AttachmentPositionData.java" "$PACKAGE_DIR/"
cp "$ROOT/tools/attachment-rules-test/AttachmentMovementRulesTest.java" "$PACKAGE_DIR/"
javac -encoding UTF-8 -d "$TMP/classes" "$PACKAGE_DIR"/*.java
java -cp "$TMP/classes" cn.blockforge.generated.taczcnpcalert.AttachmentMovementRulesTest
