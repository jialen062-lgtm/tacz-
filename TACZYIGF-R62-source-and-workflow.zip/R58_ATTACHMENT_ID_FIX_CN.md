# TACZYIGF r58：配件 ID 隔离与移动规则验证

基于 r57 源码继续修改，保留 r55/r56 的人物与物品预览修正、r57 的真实弹药索引显示和保守配件移动规则。

## 本次改动

- `TaczCompat.java`：读取配件 ID 时优先调用 TaCZ `IAttachment.getAttachmentId(ItemStack)`，旧 `AttachmentId` NBT 仅作兼容兜底。
- `AttachmentPositionData.java`：偏移键由通用物品注册 ID 改为每个配件自己的 TaCZ ID。TaCZ 的多个配件共用一个通用 `Item`，旧键会导致同一槽位不同配件共用偏移；r58 修复了这个键冲突。
- `AttachmentMovementRules.java`：握把白名单改为更明确的前握把/手挡 ID 片段，移除过宽的 `vertical`、`angled` 和不确定的 `bipod_grip` 命中；增加显式 `verifiedRail` 的轨道查询/约束重载。未提供模型导轨验证时，瞄具/激光仍固定。
- `build.gradle`：版本号更新为 `1.0.0-r58`。
- `tools/verify-attachment-rules.sh`：新增不依赖 ForgeGradle 的独立规则验证脚本。

## API 核对

TaCZ 1.20.1 的 `IAttachment` 提供 `getAttachmentId(ItemStack)`；`AttachmentRender` 持有 `bedrockGunModel` 与 `type` 字段，模型提供 `getCurrentAttachmentItem()` 和 `getCurrentGunItem()`。当前仍未启用 `AttachmentRenderMixin`，因为完整的 UI 拖动控件、服务端偏移动作与实机坐标轴校准尚未完成；本版不宣称配件拖动已可用。

## 验证边界

- r57 源码 ZIP、r58 源码 ZIP 完整性检查通过。
- 独立 Java 规则测试通过（固定槽位、白名单握把、未知配件、未验证导轨、偏移轴/范围约束）。
- 当前环境没有 Gradle/Gradle Wrapper，未执行 ForgeGradle `clean build`；也没有在 Minecraft 客户端实测。
- GitHub 仓库连接当前只有读取权限（Contents 写入返回 403），所以本次不能直接提交到 `jialen062-lgtm/tacz-`。源码包与补丁已在本地生成，待用户上传后由 GitHub Actions 编译。
