# TACZYIGF r57：弹药真实属性与配件移动规则收紧

基于用户 Library 中最新的 r56 源码继续修改，保留 r56 的人物比例、选枪悬停锁存、背包静态预览和 TaCZ 枪械朝向修正。

## 本次改动

- `TaczCompat.java`：弹药 ID 优先通过 TaCZ `IAmmo.getAmmoId(ItemStack)` 读取，旧版 `AmmoId` NBT 作为兜底。
- `TaczCompat.java`：增加弹药索引详情，读取真实弹种名称、最大堆叠、说明和 ID；按 `GunData.ammoId` 匹配枪械，逐把读取 `BulletData` 的伤害、弹速、弹丸数、可穿透实体数、重力、存续时间，并读取该枪弹匣容量。
- `PanelScreen.java`：弹药页右侧详情显示当前堆叠数量与真实索引/弹道数据；开启适配筛选时优先显示当前手持枪械的数据。
- `AttachmentMovementRules.java`：枪托、枪口、弹匣保持固定；只有 ID 能确认是前握把/手挡的 GRIP 可移动；SCOPE/LASER 不再仅凭槽位就允许拖动，必须有具体枪械模型的已验证导轨信息才可启用。
- `build.gradle`：修正此前 r56 源码仍标记 r55 的版本号，升级为 `1.0.0-r57`。

## API 核对

已对用户提供的 TaCZ `1.20.1-1.1.8-hotfix2` JAR 使用 `javap` 核对：

- `IAmmo.getAmmoId(ItemStack)`、`IAmmo.isAmmoOfGun(ItemStack, ItemStack)`
- `TimelessAPI.getCommonAmmoIndex(ResourceLocation)`、`getAllCommonGunIndex()`、`getCommonGunIndex(ResourceLocation)`
- `CommonAmmoIndex.getPojo()`、`getStackSize()`；`AmmoIndexPOJO.getName()`、`getTooltip()`
- `CommonGunIndex.getGunData()`、`getBulletData()`、`getPojo()`；`GunData.getAmmoId()`、`getAmmoAmount()`
- `BulletData.getDamageAmount()`、`getSpeed()`、`getBulletAmount()`、`getPierce()`、`getGravity()`、`getLifeSecond()`

“可穿透实体数”显示 TaCZ BulletData 的 `pierce`（投射物沿路径可命中的实体数量上限），不将它误标成现实防弹穿甲等级。弹药索引本身没有统一伤害；伤害仍按每把兼容枪械分别显示。

## 验证边界

- r56 源码 ZIP、r55 源码 ZIP 均通过 `unzip -t`。
- TaCZ 1.1.8-hotfix2 的上述 API 方法签名已用本地 JAR 核对。
- 配件移动规则的独立 Java 测试待执行；本地没有 Gradle/Gradle Wrapper，因此尚未执行 ForgeGradle `clean build`。
- 尚未进入 Minecraft 实机验证弹药列表/右侧面板显示。
- `AttachmentRenderMixin` 仍未加入 Mixin 配置，且 r56 页面尚无实际配件偏移编辑控件/服务端动作；本版没有声称配件拖动已经完成。后续必须先实现完整编辑控件和服务端校验，再启用渲染注入。
- NPC、对话、警觉、命令、枪械预设和 LRTactical 动态索引兼容代码未改动。LRTactical 本体 JAR 未在本轮可访问文件中，九个指定 ID 尚未实机验证。
