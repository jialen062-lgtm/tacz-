# TACZYIGF R62（源码开发版）

目标环境：Minecraft 1.20.1 / Forge 47.4.0 / Java 17。

## 本版功能

- 警告角色名称颜色：嫌疑人红色；玩家 ID、指挥部名称蓝色。
- 警长面板改为“选择行动”，顶部按配置顺序切换章节；默认第一章节。
- 选择行动后进入全服准备大厅。所有在线玩家按 Y 准备/取消；HUD 显示行动名、准备人数、玩家名单和倒计时。全部准备后服务器统一 10 秒倒计时；取消准备或新玩家加入会取消倒计时，玩家退出后重新检查名单。
- 倒计时结束后服务器统一传送在线参与者到行动地图。
- 玩家重生后传送到可配置的死亡返回点；如果 taczgz 已接管该次死亡进入区域观战，则保留观战。
- 行动传送后按配置延迟播放指挥部开场台词，再广播每位参与者使用自己游戏 ID 的自动回复。
- 移除普通对话魔杖；空手右键有对话脚本的普通 NPC 触发对话。警长、军需官和无脚本 NPC 的原有交互不被抢占。
- 对话编辑魔杖打开可视化编辑器，支持节点、NPC 台词、玩家选项、跳转、预览、保存、清空和显式退出；ESC 关闭会自动保存草稿并保留服务端编辑会话。

## 行动配置

配置文件：`config/tacz_cnpc_alert-common.toml`，章节配置位于 `[alert.dungeon]`。

`action_chapters` 每一项格式：

```toml
action_chapters = [
  "第一章节|警局突入@minecraft:overworld:100 64 -200",
  "第一章节|仓库搜查@minecraft:overworld:250 64 80",
  "第二章节|地下研究所@minecraft:the_nether:20 70 20"
]
```

增加行动就增加一行；删除行动就删除对应行；删除章节就删除该章节所有行；重命名章节就修改这些行的章节名。章节显示顺序按配置首次出现顺序。`action_chapters` 为空时兼容旧 `entries`。

死亡返回点配置字段：`death_return_enabled`、`death_return_dimension`、`death_return_x`、`death_return_y`、`death_return_z`。

行动开场对话配置字段：`entry_dialogue_enabled`、`entry_command_speaker`、`entry_command_line`、`entry_player_line`、`entry_command_delay_ticks`、`entry_player_delay_ticks`。

## 构建与验证

- GitHub Actions 工作流：`.github/workflows/build-r62.yml`，使用 Java 17、Gradle 8.8。
- 本地构建命令：`gradle --no-daemon clean build`。
- 静态检查和资源解析结果见 `BUILD_STATUS_CN.md`。
- 当前工作环境缺少 Gradle、Gradle Wrapper 和 Java 17，因此尚不能声称 Forge 编译成功；多人联机验收步骤见 `R62_IN_PROGRESS_CN.md`。

`taczgz` 是独立模组，请单独使用 `taczgz-1.0.1` 源码和它自己的构建工作流；不要把它的源码合并进本项目。
