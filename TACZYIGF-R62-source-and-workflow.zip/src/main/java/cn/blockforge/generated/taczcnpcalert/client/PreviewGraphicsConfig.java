package cn.blockforge.generated.taczcnpcalert.client;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** 客户端 3D 预览图形设置；仅保存模型尺寸、装备缩放速度等预览设置。 */
public final class PreviewGraphicsConfig {
    private static final String FILE_NAME = "taczyigf-graphics.properties";
    private static boolean loaded;

    /** 枪械、投掷物、近战及其他非弹药物品的 3D 预览基础缩放。 */
    public static double gunPreviewScale = 80.0D;
    /** 弹药 3D 预览基础缩放。 */
    public static double ammoPreviewScale = 80.0D;
    /** 玩家人物预览基础大小；装备聚焦放大在此基础上叠加。 */
    public static double playerPreviewScale = 0.60D;
    /** 装备选中放大速度倍率，越大越快。 */
    public static double gearZoomSpeed = 1.0D;
    /** 人物预览在 GUI 中的 X/Y/Z 偏移，单位为 GUI 像素。 */
    public static double playerPreviewOffsetX = 0.0D;
    public static double playerPreviewOffsetY = 0.0D;
    public static double playerPreviewOffsetZ = 0.0D;

    private PreviewGraphicsConfig() {}

    public static void load() {
        if (loaded) return;
        loaded = true;
        Path file = configPath();
        Properties properties = new Properties();
        if (Files.isRegularFile(file)) {
            try (Reader reader = Files.newBufferedReader(file)) {
                properties.load(reader);
                gunPreviewScale = clamp(parse(properties, "gun_preview_scale", gunPreviewScale), 1.0D, 1000.0D);
                ammoPreviewScale = clamp(parse(properties, "ammo_preview_scale", ammoPreviewScale), 1.0D, 1000.0D);
                playerPreviewScale = clamp(parse(properties, "player_preview_scale", playerPreviewScale), 0.35D, 1.50D);
                gearZoomSpeed = clamp(parse(properties, "gear_zoom_speed", gearZoomSpeed), 0.25D, 3.0D);
                playerPreviewOffsetX = clamp(parse(properties, "player_preview_x", playerPreviewOffsetX), -200.0D, 200.0D);
                playerPreviewOffsetY = clamp(parse(properties, "player_preview_y", playerPreviewOffsetY), -200.0D, 200.0D);
                playerPreviewOffsetZ = clamp(parse(properties, "player_preview_z", playerPreviewOffsetZ), -200.0D, 200.0D);
            } catch (IOException ignored) {
                // 配置文件损坏或不可读时继续使用默认值，避免影响游戏启动。
            }
        } else {
            save();
        }
    }

    public static void save() {
        Path file = configPath();
        Properties properties = new Properties();
        properties.setProperty("gun_preview_scale", Double.toString(clamp(gunPreviewScale, 1.0D, 1000.0D)));
        properties.setProperty("ammo_preview_scale", Double.toString(clamp(ammoPreviewScale, 1.0D, 1000.0D)));
        properties.setProperty("player_preview_scale", Double.toString(clamp(playerPreviewScale, 0.35D, 1.50D)));
        properties.setProperty("gear_zoom_speed", Double.toString(clamp(gearZoomSpeed, 0.25D, 3.0D)));
        properties.setProperty("player_preview_x", Double.toString(clamp(playerPreviewOffsetX, -200.0D, 200.0D)));
        properties.setProperty("player_preview_y", Double.toString(clamp(playerPreviewOffsetY, -200.0D, 200.0D)));
        properties.setProperty("player_preview_z", Double.toString(clamp(playerPreviewOffsetZ, -200.0D, 200.0D)));
        try {
            Files.createDirectories(file.getParent());
            try (Writer writer = Files.newBufferedWriter(file)) {
                properties.store(writer, "TACZYIGF 图形设置（仅客户端）");
            }
        } catch (IOException ignored) {
            // 写入失败时保留本次运行中的设置；下次启动仍可重新尝试。
        }
    }

    public static int gearZoomDurationTicks() {
        return Math.max(1, (int) Math.round(4.0D / clamp(gearZoomSpeed, 0.25D, 3.0D)));
    }

    private static Path configPath() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve(FILE_NAME);
    }

    private static double parse(Properties properties, String key, double fallback) {
        try {
            return Double.parseDouble(properties.getProperty(key, Double.toString(fallback)));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
