package cn.blockforge.generated.taczcnpcalert.dialogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenDialogueEditorPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Server-owned visual dialogue editor sessions. Closing the screen does not discard the session. */
public final class DialogueEditService {
    private static final Map<UUID, UUID> EDITING = new ConcurrentHashMap<>();

    private DialogueEditService() {}

    public static void toggle(ServerPlayer player, Entity npc) {
        UUID playerId = player.getUUID();
        EDITING.put(playerId, npc.getUUID());
        ModNetwork.sendToPlayer(new OpenDialogueEditorPacket(
                npc.getId(), npc.getName().getString(), DialogueStore.read(npc)), player);
    }

    public static void onLoggedOut(UUID playerId) {
        EDITING.remove(playerId);
    }

    public static void closeFromEditor(ServerPlayer player, int npcId) {
        // This packet can only close the sender's own session; it never writes to an entity.
        if (EDITING.remove(player.getUUID()) != null) {
            tell(player, ChatFormatting.GRAY, "已退出对话编辑会话。");
        }
    }

    /** Validate the editor session, entity identity, distance and complete JSON structure before saving. */
    public static void saveFromEditor(ServerPlayer player, int npcId, String json) {
        UUID expected = EDITING.get(player.getUUID());
        Entity target = player.level().getEntity(npcId);
        if (expected == null || !(target instanceof LivingEntity npc) || !npc.getUUID().equals(expected)
                || !AlertService.isNpcType(npc) || player.distanceToSqr(npc) > 64.0D) {
            tell(player, ChatFormatting.RED, "编辑会话已失效或 NPC 距离过远，请重新打开编辑器。");
            return;
        }
        if (json == null || json.length() > 32767) {
            tell(player, ChatFormatting.RED, "脚本超过长度限制，未保存。");
            return;
        }
        if (!json.isBlank()) {
            JsonObject script = DialogueStore.parse(json);
            if (script == null || !validate(script)) {
                tell(player, ChatFormatting.RED, "脚本结构无效：请检查节点、台词、选项和跳转编号。");
                return;
            }
        }
        DialogueStore.write(npc, json);
        tell(player, ChatFormatting.GREEN, "对话脚本已保存并同步到服务器。");
    }

    private static boolean validate(JsonObject script) {
        JsonElement nodesElement = script.get("nodes");
        if (nodesElement == null || !nodesElement.isJsonArray()) return false;
        JsonArray nodes = nodesElement.getAsJsonArray();
        if (nodes.size() > DialogueStore.MAX_NODES) return false;
        for (JsonElement nodeElement : nodes) {
            if (!nodeElement.isJsonObject()) return false;
            JsonObject node = nodeElement.getAsJsonObject();
            JsonElement linesElement = node.get("lines");
            JsonElement optionsElement = node.get("options");
            if (linesElement == null || !linesElement.isJsonArray() || optionsElement == null || !optionsElement.isJsonArray()) return false;
            JsonArray lines = linesElement.getAsJsonArray();
            JsonArray options = optionsElement.getAsJsonArray();
            if (lines.size() > 20 || options.size() > 6) return false;
            for (JsonElement line : lines) {
                if (!line.isJsonPrimitive() || !line.getAsJsonPrimitive().isString() || line.getAsString().length() > DialogueStore.MAX_TEXT) return false;
            }
            for (JsonElement optionElement : options) {
                if (!optionElement.isJsonObject()) return false;
                JsonObject option = optionElement.getAsJsonObject();
                JsonElement text = option.get("text");
                JsonElement target = option.get("target");
                if (text == null || !text.isJsonPrimitive() || !text.getAsJsonPrimitive().isString()
                        || text.getAsString().isBlank() || text.getAsString().length() > DialogueStore.MAX_TEXT
                        || target == null || !target.isJsonPrimitive()) return false;
                try {
                    int index = target.getAsInt();
                    if (index < 0 || index >= nodes.size()) return false;
                } catch (Exception invalid) { return false; }
            }
        }
        return true;
    }

    private static void tell(ServerPlayer player, ChatFormatting color, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(color), false);
    }
}
