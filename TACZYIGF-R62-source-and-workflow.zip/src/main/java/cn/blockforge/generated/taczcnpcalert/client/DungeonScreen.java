package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.SheriffService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Chapter tabs and action list. Selecting an action opens the server preparation lobby. */
public final class DungeonScreen extends Screen {
    private record Action(int configIndex, String name) {}
    private static final int ROW_HEIGHT = 28;
    private final int npcId;
    private final Map<String, List<Action>> chapters = new LinkedHashMap<>();
    private final String selectedDungeon;
    private String selectedChapter = "";
    private int scroll;
    private int chapterScroll;
    private int panelLeft;
    private int panelRight;
    private int listTop;
    private int listBottom;

    public DungeonScreen(int npcId, List<String> encodedEntries, String selectedDungeon) {
        super(Component.literal("警长 · 选择行动"));
        this.npcId = npcId;
        this.selectedDungeon = selectedDungeon == null ? "" : selectedDungeon;
        String chapter = "第一章节";
        for (String item : encodedEntries) {
            if (item.startsWith("@chapter:")) {
                chapter = item.substring("@chapter:".length());
                chapters.computeIfAbsent(chapter, k -> new ArrayList<>());
            } else if (item.startsWith("@action:")) {
                String rest = item.substring("@action:".length());
                int split = rest.indexOf(':');
                if (split > 0) {
                    try {
                        int index = Integer.parseInt(rest.substring(0, split));
                        String name = rest.substring(split + 1);
                        chapters.computeIfAbsent(chapter, k -> new ArrayList<>()).add(new Action(index, name));
                    } catch (NumberFormatException ignored) { }
                }
            } else {
                chapters.computeIfAbsent(chapter, k -> new ArrayList<>()).add(new Action(chapters.values().stream().mapToInt(List::size).sum(), item));
            }
        }
        if (chapters.isEmpty()) chapters.put("第一章节", new ArrayList<>());
        selectedChapter = chapters.keySet().iterator().next();
    }

    @Override
    protected void init() {
        panelLeft = Math.max(12, width / 2 - 210);
        panelRight = Math.min(width - 12, panelLeft + 420);
        listTop = 118;
        listBottom = height - 58;
        clampScroll();
    }

    private List<Action> currentActions() { return chapters.getOrDefault(selectedChapter, List.of()); }
    private int visibleRows() { return Math.max(1, (listBottom - listTop) / ROW_HEIGHT); }
    private void clampScroll() { scroll = Math.max(0, Math.min(scroll, Math.max(0, currentActions().size() - visibleRows()))); }

    private void select(int index) {
        List<Action> actions = currentActions();
        if (index < 0 || index >= actions.size()) return;
        ModNetwork.sendToServer(new PanelActionPacket(SheriffService.ACTION_DUNGEON,
                Integer.toString(actions.get(index).configIndex()), 0, npcId));
        onClose();
    }

    private void clearSelection() {
        ModNetwork.sendToServer(new PanelActionPacket(SheriffService.ACTION_CLEAR_DUNGEON, "-1", 0, npcId));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.fill(panelLeft, 0, panelRight, height, 0xD9000000);
        g.fill(panelLeft, 0, panelLeft + 2, height, 0x55FFFFFF);
        g.drawString(font, "警长 · 选择行动", panelLeft + 18, 22, 0xFFFFFFFF, false);
        g.drawString(font, selectedDungeon.isBlank() ? "请选择行动" : "上次选择：" + selectedDungeon,
                panelLeft + 18, 48, 0xFFFFD34D, false);

        int tabX = panelLeft + 16;
        int tabY = 76;
        int chapterIndex = 0;
        for (String chapter : chapters.keySet()) {
            if (chapterIndex++ < chapterScroll) continue;
            int tabW = Math.max(70, font.width(chapter) + 18);
            boolean hover = mouseX >= tabX && mouseX <= tabX + tabW && mouseY >= tabY && mouseY <= tabY + 24;
            int bg = chapter.equals(selectedChapter) ? 0xCC315B88 : (hover ? 0x77555555 : 0x44333333);
            g.fill(tabX, tabY, tabX + tabW, tabY + 24, bg);
            g.drawCenteredString(font, chapter, tabX + tabW / 2, tabY + 8, 0xFFFFFFFF);
            tabX += tabW + 5;
            if (tabX > panelRight - 75) break;
        }

        List<Action> actions = currentActions();
        for (int row = 0; row < visibleRows(); row++) {
            int index = scroll + row;
            if (index >= actions.size()) break;
            int y = listTop + row * ROW_HEIGHT;
            boolean hover = mouseX >= panelLeft + 14 && mouseX <= panelRight - 14 && mouseY >= y && mouseY < y + 23;
            g.fill(panelLeft + 14, y, panelRight - 14, y + 23, hover ? 0x55FFFFFF : 0x22000000);
            g.drawString(font, actions.get(index).name(), panelLeft + 26, y + 7,
                    hover ? 0xFFFFFF55 : 0xFFEDEDED, false);
        }
        if (actions.isEmpty()) g.drawString(font, "本章节没有配置行动", panelLeft + 20, listTop + 10, 0xFFFF7777, false);
        if (actions.size() > visibleRows()) g.drawString(font,
                "滚轮浏览  " + (scroll + 1) + " / " + actions.size(), panelLeft + 18, listBottom + 7, 0xFFAAAAAA, false);
        g.drawString(font, "清除选择", panelLeft + 18, height - 35, 0xFFE5E5E5, false);
        g.drawString(font, "关闭", panelRight - 60, height - 35, 0xFFE5E5E5, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int tabX = panelLeft + 16;
        int chapterIndex = 0;
        for (String chapter : chapters.keySet()) {
            if (chapterIndex++ < chapterScroll) continue;
            int tabW = Math.max(70, font.width(chapter) + 18);
            if (mouseX >= tabX && mouseX <= tabX + tabW && mouseY >= 76 && mouseY <= 100) {
                selectedChapter = chapter;
                scroll = 0;
                return true;
            }
            tabX += tabW + 5;
            if (tabX > panelRight - 75) break;
        }
        if (mouseY >= listTop && mouseY < listBottom && mouseX >= panelLeft + 14 && mouseX <= panelRight - 14) {
            select(scroll + ((int) mouseY - listTop) / ROW_HEIGHT);
            return true;
        }
        if (mouseY >= height - 45 && mouseX < panelLeft + 120) { clearSelection(); return true; }
        if (mouseY >= height - 45 && mouseX >= panelRight - 80 && mouseX <= panelRight) { onClose(); return true; }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (mouseX >= panelLeft && mouseX <= panelRight && mouseY >= 72 && mouseY <= 104) {
            chapterScroll = Math.max(0, Math.min(chapters.size() - 1, chapterScroll + (int) Math.signum(delta)));
            return true;
        }
        if (mouseX >= panelLeft && mouseX <= panelRight && mouseY >= listTop && mouseY <= listBottom) {
            scroll -= (int) Math.signum(delta);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
