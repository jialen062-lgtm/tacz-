package cn.blockforge.generated.taczcnpcalert;

import java.util.Locale;
import java.util.Set;

/**
 * Conservative, real-world attachment movement policy.
 * Only accessories mounted on a longitudinal rail may slide, and they may
 * move only along that rail axis. Parts with no verified adjustment interface stay fixed.
 */
public final class AttachmentMovementRules {
    public enum Movement { FIXED, CONDITIONAL, RAIL_DEPENDENT, UNKNOWN }

    private static final Set<String> KNOWN_ADJUSTABLE_GRIP_TOKENS = Set.of(
            "vertical_grip", "grip_vertical", "angled_grip", "grip_angled",
            "foregrip", "fore_grip", "handstop", "hand_stop", "stubby_grip");

    private AttachmentMovementRules() {}

    public static Movement classify(String slot, String attachmentId) {
        return classify(slot, attachmentId, false);
    }

    /**
     * Rail-mounted optics/lasers are movable only when the caller has verified a real rail
     * position for this specific weapon model. Slot type alone is not proof of a movable rail.
     */
    public static Movement classify(String slot, String attachmentId, boolean verifiedRail) {
        String s = slot == null ? "" : slot.toUpperCase(Locale.ROOT);
        String id = attachmentId == null ? "" : attachmentId.toLowerCase(Locale.ROOT);
        return switch (s) {
            // These parts are mounted to fixed interfaces and are not user-slidable in this editor.
            case "STOCK", "MUZZLE", "EXTENDED_MAG", "MAG", "SIGHT_FRONT", "SIGHT_REAR" -> Movement.FIXED;
            // Only recognisable rail-mounted foregrips / handstops are movable.
            case "GRIP" -> containsAny(id, KNOWN_ADJUSTABLE_GRIP_TOKENS)
                    ? Movement.CONDITIONAL : Movement.FIXED;
            // Scope/laser slots exist in TaCZ, but a slot does not prove the model has a movable rail.
            case "SCOPE", "LASER" -> verifiedRail ? Movement.RAIL_DEPENDENT : Movement.FIXED;
            default -> Movement.UNKNOWN;
        };
    }

    public static boolean canDrag(String slot, String attachmentId, boolean hasPositionEditor) {
        return canDrag(slot, attachmentId, hasPositionEditor, false);
    }

    public static boolean canDrag(String slot, String attachmentId, boolean hasPositionEditor,
                                  boolean verifiedRail) {
        if (!hasPositionEditor) return false;
        Movement movement = classify(slot, attachmentId, verifiedRail);
        return movement == Movement.CONDITIONAL || movement == Movement.RAIL_DEPENDENT;
    }

    public static boolean isRail(String slot) {
        return "SCOPE".equalsIgnoreCase(slot) || "LASER".equalsIgnoreCase(slot);
    }

    public static boolean usesLongitudinalRail(String slot, String attachmentId) {
        return usesLongitudinalRail(slot, attachmentId, false);
    }

    public static boolean usesLongitudinalRail(String slot, String attachmentId, boolean verifiedRail) {
        Movement movement = classify(slot, attachmentId, verifiedRail);
        return movement == Movement.RAIL_DEPENDENT || movement == Movement.CONDITIONAL;
    }

    /**
     * A movable attachment may only slide along the firearm's mounting rail (X axis).
     * It cannot be freely lifted, shifted sideways, or moved through the receiver.
     */
    public static AttachmentPositionData.Offset constrain(String slot, String attachmentId,
                                                            double x, double y, double z) {
        return constrain(slot, attachmentId, x, y, z, false);
    }

    public static AttachmentPositionData.Offset constrain(String slot, String attachmentId,
                                                            double x, double y, double z,
                                                            boolean verifiedRail) {
        if (!canDrag(slot, attachmentId, true, verifiedRail)) {
            return new AttachmentPositionData.Offset(0.0D, 0.0D, 0.0D);
        }
        double limit = "GRIP".equalsIgnoreCase(slot) ? 0.22D : 0.45D;
        return new AttachmentPositionData.Offset(
                Math.max(-limit, Math.min(limit, x)), 0.0D, 0.0D);
    }

    /** Backwards-compatible overload for older callers; unknown slots remain fixed. */
    public static AttachmentPositionData.Offset constrain(String slot, double x, double y, double z) {
        return constrain(slot, "", x, y, z);
    }

    private static boolean containsAny(String value, Set<String> tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }
}
