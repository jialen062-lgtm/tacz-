package cn.blockforge.generated.taczcnpcalert.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/**
 * 类 galgame 的 NPC 对话界面。
 *
 * <p>底部半透明对话框：说话人名字（NPC 红色 / 玩家蓝色）+ 当前台词；
 * 左右两侧分别是 NPC 和玩家本人的 3D 模型（皮肤 + 装备），谁说话谁亮、另一个变暗。
 * 点击 / 回车 / 空格 播放下一句；NPC 说完后如果有玩家选项，会在对话框上方弹出选项条，
 * 点一个就跳到对应节点继续。</p>
 */
public final class DialogueScreen extends Screen {

    /** 一个对话节点：先按顺序播 lines，播完若有 options 就轮到玩家选。 */
    private record Node(List<String> lines, List<Option> options) {
    }

    private record Option(String text, int target) {
    }

    private static final int BOX_MARGIN_BOTTOM = 36;
    private static final int BOX_HEIGHT = 58;
    private static final int OPTION_HEIGHT = 22;

    private final int npcId;
    private final String npcName;
    private final List<Node> nodes = new ArrayList<>();

    private int nodeIndex;
    private int lineIndex;
    private boolean choosing;
    private boolean emptyScript;

    public DialogueScreen(int npcId, String npcName, String scriptJson) {
        super(Component.literal("对话"));
        this.npcId = npcId;
        this.npcName = npcName == null || npcName.isEmpty() ? "NPC" : npcName;
        parse(scriptJson);
        this.emptyScript = nodes.isEmpty()
                || (nodes.get(0).lines().isEmpty() && nodes.get(0).options().isEmpty());
    }

    private void parse(String scriptJson) {
        try {
            JsonElement root = JsonParser.parseString(scriptJson);
            if (!root.isJsonObject()) {
                return;
            }
            JsonElement nodesEl = root.getAsJsonObject().get("nodes");
            if (nodesEl == null || !nodesEl.isJsonArray()) {
                return;
            }
            for (JsonElement nodeEl : nodesEl.getAsJsonArray()) {
                List<String> lines = new ArrayList<>();
                List<Option> options = new ArrayList<>();
                if (nodeEl.isJsonObject()) {
                    JsonObject node = nodeEl.getAsJsonObject();
                    JsonElement linesEl = node.get("lines");
                    if (linesEl != null && linesEl.isJsonArray()) {
                        for (JsonElement line : linesEl.getAsJsonArray()) {
                            if (line.isJsonPrimitive()) {
                                lines.add(line.getAsString());
                            }
                        }
                    }
                    JsonElement optionsEl = node.get("options");
                    if (optionsEl != null && optionsEl.isJsonArray()) {
                        for (JsonElement optionEl : optionsEl.getAsJsonArray()) {
                            if (optionEl.isJsonObject()) {
                                JsonObject option = optionEl.getAsJsonObject();
                                JsonElement text = option.get("text");
                                JsonElement target = option.get("target");
                                String optionText = text != null && text.isJsonPrimitive() ? text.getAsString() : "";
                                int optionTarget = -1;
                                if (target != null && target.isJsonPrimitive()) {
                                    try {
                                        optionTarget = target.getAsInt();
                                    } catch (Exception ignored) {
                                        // 跳不到哪去就当结束
                                    }
                                }
                                options.add(new Option(optionText, optionTarget));
                            }
                        }
                    }
                }
                nodes.add(new Node(List.copyOf(lines), List.copyOf(options)));
            }
        } catch (Exception ignored) {
            // 脚本坏了就显示空对话
        }
    }

    @Override
    public boolean isPauseScreen() {
        // 对话时世界继续流动，角色模型才会做待机动画
        return false;
    }

    private Node currentNode() {
        return nodeIndex >= 0 && nodeIndex < nodes.size() ? nodes.get(nodeIndex) : null;
    }

    private String currentLine() {
        Node node = currentNode();
        if (node == null) {
            return "";
        }
        if (node.lines().isEmpty()) {
            return "";
        }
        int i = Math.min(lineIndex, node.lines().size() - 1);
        return node.lines().get(i);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);

        LivingEntity npc = findNpc();
        LivingEntity player = this.minecraft == null ? null : this.minecraft.player;
        Node node = currentNode();

        // —— 左右立绘：谁说话谁亮 ——
        int footY = this.height - BOX_MARGIN_BOTTOM - 6;
        if (npc != null) {
            int scale = charScale(npc);
            if (choosing) {
                RenderSystem.setShaderColor(0.42F, 0.42F, 0.42F, 1.0F);
            }
            InventoryScreen.renderEntityInInventoryFollowsAngle(
                    graphics, this.width - 100, footY, scale, 0.8F, 0F, npc);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        }
        if (player != null) {
            int scale = charScale(player);
            if (!choosing) {
                RenderSystem.setShaderColor(0.42F, 0.42F, 0.42F, 1.0F);
            }
            InventoryScreen.renderEntityInInventoryFollowsAngle(
                    graphics, 100, footY, scale, -0.8F, 0F, player);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        }

        int boxW = Math.min(this.width - 40, Math.max(240, (int) (this.width * 0.55F)));
        int boxX = (this.width - boxW) / 2;
        int boxY = this.height - BOX_HEIGHT - BOX_MARGIN_BOTTOM;

        // —— 选项条（轮到玩家时） ——
        if (choosing && node != null && !node.options().isEmpty()) {
            int startY = boxY - node.options().size() * (OPTION_HEIGHT + 4) - 8;
            for (int i = 0; i < node.options().size(); i++) {
                int top = startY + i * (OPTION_HEIGHT + 4);
                boolean hover = mouseX >= boxX && mouseX <= boxX + boxW
                        && mouseY >= top && mouseY <= top + OPTION_HEIGHT;
                graphics.fill(boxX, top, boxX + boxW, top + OPTION_HEIGHT, hover ? 0xE0101A26 : 0xA0000000);
                graphics.fill(boxX, top, boxX + 2, top + OPTION_HEIGHT, 0xFF3FC1DC);
                String text = "» " + node.options().get(i).text();
                text = this.font.plainSubstrByWidth(text, boxW - 20);
                graphics.drawString(this.font, text, boxX + 10, top + (OPTION_HEIGHT - this.font.lineHeight) / 2,
                        hover ? 0xFFFFFF : 0xBFBFBF, false);
            }
        }

        // —— 对话框 ——
        graphics.fill(boxX, boxY, boxX + boxW, boxY + BOX_HEIGHT, 0xC8000000);
        graphics.fill(boxX, boxY, boxX + boxW, boxY + 1, 0x40FFFFFF);
        graphics.fill(boxX, boxY + BOX_HEIGHT - 1, boxX + boxW, boxY + BOX_HEIGHT, 0x40FFFFFF);

        String speaker = choosing ? "玩家回答" : this.npcName;
        int speakerColor = choosing ? 0xFF3B82F6 : 0xFFEF4444;
        graphics.drawString(this.font, "[" + speaker + "]", boxX + 10, boxY + 7, speakerColor, true);

        String hint = emptyScript ? "这个 NPC 还没有对话脚本，请使用对话编辑魔杖编辑。"
                : (choosing ? "请选择你的回答：" : "说：" + currentLine());
        List<net.minecraft.util.FormattedCharSequence> wrapped = this.font.split(Component.literal(hint), boxW - 24);
        int textY = boxY + 22;
        for (int i = 0; i < wrapped.size() && i < 2; i++) {
            graphics.drawString(this.font, wrapped.get(i), boxX + 12, textY, 0xEFEFEF);
            textY += this.font.lineHeight + 2;
        }

        if (!choosing && !emptyScript) {
            graphics.drawString(this.font, "»", boxX + boxW - 18, boxY + BOX_HEIGHT - 16,
                    (System.currentTimeMillis() / 400) % 2 == 0 ? 0xFFD18F : 0x8A6B42, false);
        }
    }

    private LivingEntity findNpc() {
        if (this.minecraft == null || this.minecraft.level == null) {
            return null;
        }
        Entity entity = this.minecraft.level.getEntity(this.npcId);
        return entity instanceof LivingEntity living ? living : null;
    }

    private int charScale(LivingEntity entity) {
        float blocks = Math.max(0.6F, entity.getBbHeight());
        int scale = (int) (this.height * 0.62F / blocks);
        return Math.max(24, Math.min(200, scale));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        Node node = currentNode();
        if (choosing && node != null && !node.options().isEmpty()) {
            int boxW = Math.min(this.width - 40, Math.max(240, (int) (this.width * 0.55F)));
            int boxX = (this.width - boxW) / 2;
            int boxY = this.height - BOX_HEIGHT - BOX_MARGIN_BOTTOM;
            int startY = boxY - node.options().size() * (OPTION_HEIGHT + 4) - 8;
            for (int i = 0; i < node.options().size(); i++) {
                int top = startY + i * (OPTION_HEIGHT + 4);
                if (mouseX >= boxX && mouseX <= boxX + boxW && mouseY >= top && mouseY <= top + OPTION_HEIGHT) {
                    choose(node.options().get(i));
                    return true;
                }
            }
            return true; // 选择阶段点空白不算跳过
        }
        advance();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == 257 || keyCode == 32) && !choosing) { // ENTER / SPACE
            advance();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void advance() {
        if (emptyScript) {
            onClose();
            return;
        }
        Node node = currentNode();
        if (node == null) {
            onClose();
            return;
        }
        if (lineIndex + 1 < node.lines().size()) {
            lineIndex++;
            return;
        }
        if (!node.options().isEmpty()) {
            choosing = true;
            return;
        }
        onClose();
    }

    private void choose(Option option) {
        choosing = false;
        lineIndex = 0;
        if (option.target() < 0 || option.target() >= nodes.size()) {
            onClose();
            return;
        }
        nodeIndex = option.target();
        Node node = currentNode();
        if (node == null) {
            onClose();
            return;
        }
        if (node.lines().isEmpty()) {
            if (!node.options().isEmpty()) {
                choosing = true;
            } else {
                onClose();
            }
        }
    }
}
