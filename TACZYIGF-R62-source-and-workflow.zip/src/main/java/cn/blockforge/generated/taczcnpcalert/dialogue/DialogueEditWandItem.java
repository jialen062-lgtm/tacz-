package cn.blockforge.generated.taczcnpcalert.dialogue;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 对话编辑魔杖。
 *
 * <p>右键 NPC 打开可视化编辑器，在界面中管理节点、NPC 台词、玩家选项和跳转目标。</p>
 */
public final class DialogueEditWandItem extends Item {

    public DialogueEditWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            player.displayClientMessage(Component.literal(
                    "右键 NPC 打开可视化对话编辑器。")
                    .withStyle(ChatFormatting.GOLD), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键 NPC：编辑它的对话脚本").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("可新增、修改、删除台词与玩家选项").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("支持节点切换、跳转设置、预览和保存").withStyle(ChatFormatting.GRAY));
    }
}
