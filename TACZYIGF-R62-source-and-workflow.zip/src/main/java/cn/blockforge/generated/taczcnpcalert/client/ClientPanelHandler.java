package cn.blockforge.generated.taczcnpcalert.client;

import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;

/** 客户端专用的小入口：服务端说“可以打开面板了”，这里就打开。 */
public final class ClientPanelHandler {

    private ClientPanelHandler() {
    }

    public static void openPanel(int npcId, List<String> equipmentIds, List<String> gunIds, List<String> ammoIds,
                                 List<String> meleeIds, List<String> throwableIds,
                                 Map<String, List<String>> attachments) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.setScreen(new PanelScreen(npcId, equipmentIds, gunIds, ammoIds, meleeIds, throwableIds,
                attachments));
    }

    public static void openWeaponPresets(List<String> entries) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;
        minecraft.setScreen(new WeaponPresetScreen(minecraft.screen, entries));
    }

    public static void playGearEquipAnimation(int category) {
        if (Minecraft.getInstance().screen instanceof PanelScreen panel) {
            panel.playGearEquipAnimation(category);
        }
    }

    public static void showPanelNotice(String message) {
        if (Minecraft.getInstance().screen instanceof PanelScreen panel) {
            panel.showPanelNotice(message);
        }
    }

    public static void openDungeonPanel(int npcId, List<String> dungeonNames, String selectedDungeon) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.setScreen(new DungeonScreen(npcId, dungeonNames, selectedDungeon));
    }

    /** 打开类 galgame 的 NPC 对话界面。 */
    public static void openDialogue(int npcId, String npcName, String scriptJson) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        minecraft.setScreen(new DialogueScreen(npcId, npcName, scriptJson));
    }
    public static void openDialogueEditor(int npcId, String npcName, String json) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) minecraft.setScreen(new DialogueEditorScreen(npcId, npcName, json));
    }

}
