package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TaczCnpcAlertMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class PreparationHud {
    private PreparationHud() {}

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("action_preparation", (gui, graphics, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || !ClientPreparationState.active) return;
            int x = 12;
            int y = 12;
            int shown = Math.min(8, ClientPreparationState.players.size());
            int panelHeight = 52 + shown * 11 + (ClientPreparationState.players.size() > shown ? 11 : 0);
            graphics.fill(x - 6, y - 5, x + 230, y + panelHeight, 0x99000000);
            graphics.drawString(gui.getFont(), Component.literal("行动准备：" + ClientPreparationState.actionName),
                    x, y, 0xFFFFD34D, true);
            y += 12;
            graphics.drawString(gui.getFont(),
                    Component.literal("已准备 " + ClientPreparationState.readyCount + "/" + ClientPreparationState.totalCount),
                    x, y, 0xFFFFFFFF, true);
            y += 12;
            String countdown = ClientPreparationState.countdownSeconds > 0
                    ? "出发倒计时：" + ClientPreparationState.countdownSeconds + " 秒" : "等待所有玩家准备（按 Y 切换）";
            graphics.drawString(gui.getFont(), Component.literal(countdown), x, y, 0xFF66CCFF, true);
            y += 13;
            for (int i = 0; i < shown; i++) {
                var player = ClientPreparationState.players.get(i);
                String line = (player.ready() ? "[✓] " : "[ ] ") + player.name();
                graphics.drawString(gui.getFont(), Component.literal(line), x, y,
                        player.ready() ? 0xFF77DD99 : 0xFFDDDDDD, true);
                y += 11;
            }
            if (ClientPreparationState.players.size() > shown) {
                graphics.drawString(gui.getFont(),
                        Component.literal("另有 " + (ClientPreparationState.players.size() - shown) + " 名玩家"),
                        x, y, 0xFFAAAAAA, true);
            }
        });
    }
}
