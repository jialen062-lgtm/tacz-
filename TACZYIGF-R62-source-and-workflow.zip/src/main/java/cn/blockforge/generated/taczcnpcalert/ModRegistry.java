package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueEditWandItem;
import cn.blockforge.generated.taczcnpcalert.entity.SmokeCloudEntity;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** 本模组需要注册的东西：头顶弹的感叹号粒子，以及“NPC 界面魔杖”物品。 */
public final class ModRegistry {

    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, TaczCnpcAlertMod.MOD_ID);

    /** 感叹号粒子，true 表示不受原版粒子数量限制。 */
    public static final RegistryObject<SimpleParticleType> EXCLAIM =
            PARTICLES.register("exclaim", () -> new SimpleParticleType(true));

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TaczCnpcAlertMod.MOD_ID);

    /** NPC 界面魔杖：使用自定义钻石铲贴图，右键 NPC 把它变成军需官。 */
    public static final RegistryObject<Item> GEAR_WAND =
            ITEMS.register("gear_wand", () -> new GearWandItem(new Item.Properties()
                    .stacksTo(1)
                    .rarity(Rarity.UNCOMMON)));

    /** NPC 地图魔杖：直接使用原版钻石镐材质，右键 NPC 把它变成警长。 */
    public static final RegistryObject<Item> MAP_WAND =
            ITEMS.register("map_wand", () -> new MapWandItem(new Item.Properties()
                    .stacksTo(1)
                    .rarity(Rarity.RARE)));

    /** 对话编辑魔杖（扩展包）：右键 NPC 进入编辑模式，用聊天命令写对话脚本。 */
    public static final RegistryObject<Item> DIALOGUE_EDIT_WAND =
            ITEMS.register("dialogue_edit_wand", () -> new DialogueEditWandItem(new Item.Properties()
                    .stacksTo(1)
                    .rarity(Rarity.RARE)));

    /** 外部投掷物落点生成的烟雾区，仅用于让 NPC 暂时失去目标。 */
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TaczCnpcAlertMod.MOD_ID);

    public static final RegistryObject<EntityType<SmokeCloudEntity>> SMOKE_CLOUD =
            ENTITY_TYPES.register("smoke_cloud",
                    () -> EntityType.Builder.<SmokeCloudEntity>of(SmokeCloudEntity::new, MobCategory.MISC)
                            .sized(2.0F, 2.0F)
                            .clientTrackingRange(10)
                            .build("smoke_cloud"));

    private ModRegistry() {
    }

    public static void register(IEventBus modBus) {
        PARTICLES.register(modBus);
        ITEMS.register(modBus);
        ENTITY_TYPES.register(modBus);
    }
}
