package cn.blockforge.generated.taczcnpcalert;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.event.TickEvent;

/**
 * 一个极简的“过几秒再做”队列：Forge 没有自带定时器，就自己按服务器 tick 数计时。
 * 用于警告续播、重生后返回点，以及行动进入地图后的分段对话。
 */
public final class DelayedTasks {

    private record Task(long dueTick, Consumer<MinecraftServer> action) {
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private DelayedTasks() {
    }

    /** 安排一个延迟任务；delayTicks 为 0 时下一 tick 执行。 */
    public static void schedule(MinecraftServer server, int delayTicks, Consumer<MinecraftServer> action) {
        if (server == null || action == null) {
            return;
        }
        TASKS.add(new Task(server.getTickCount() + Math.max(0, delayTicks), action));
    }

    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || TASKS.isEmpty()) {
            return;
        }
        MinecraftServer server = event.getServer();
        long now = server.getTickCount();
        // Remove due tasks before running callbacks. A callback may enqueue another delayed task
        // (the entry dialogue schedules the player's reply after the command line); executing it
        // while iterating TASKS would otherwise cause ConcurrentModificationException.
        List<Task> due = new ArrayList<>();
        Iterator<Task> iterator = TASKS.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.dueTick() <= now) {
                due.add(task);
                iterator.remove();
            }
        }
        for (Task task : due) {
            try {
                task.action().accept(server);
            } catch (RuntimeException exception) {
                TaczCnpcAlertMod.LOGGER.warn("执行延迟任务时出错", exception);
            }
        }
    }

    /** 服务器关掉时清空，免得残留任务在下一个世界里乱播。 */
    public static void onServerStopped(MinecraftServer server) {
        TASKS.clear();
    }
}
