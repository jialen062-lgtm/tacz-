package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.PanelActionService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 客户端 → 服务端：玩家在配装或行动面板里点了一下东西。
 *
 * <p>面板本身只是画出来的界面，真正“发枪、发子弹、装配件、选择行动”都在服务端做，
 * 这样联机时也不会出现只有自己看得到的状态。</p>
 */
public final class PanelActionPacket {

    /** 动作名；具体含义见 {@link PanelActionService} 和 {@link cn.blockforge.generated.taczcnpcalert.SheriffService}。 */
    private final String action;
    /** 目标 ID（物品注册名、枪械 ID、配件 ID），动作不需要时为空串。 */
    private final String id;
    /** 玩家背包里的槽位序号，改枪时用。 */
    private final int slot;
    /** 打开面板的 NPC 实体 ID，行动选择用它做服务端校验。 */
    private final int npcId;
    private final double offsetX;
    private final double offsetY;
    private final double offsetZ;

    public PanelActionPacket(String action, String id, int slot) {
        this(action, id, slot, -1, 0.0D, 0.0D, 0.0D);
    }

    public PanelActionPacket(String action, String id, int slot, int npcId) {
        this(action, id, slot, npcId, 0.0D, 0.0D, 0.0D);
    }

    public PanelActionPacket(String action, String id, int slot, int npcId,
                             double offsetX, double offsetY, double offsetZ) {
        this.action = action == null ? "" : action;
        this.id = id == null ? "" : id;
        this.slot = slot;
        this.npcId = npcId;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.offsetZ = offsetZ;
    }

    public String action() {
        return action;
    }

    public String id() {
        return id;
    }

    public int slot() {
        return slot;
    }

    public int npcId() { return npcId; }
    public double offsetX() { return offsetX; }
    public double offsetY() { return offsetY; }
    public double offsetZ() { return offsetZ; }

    public static void encode(PanelActionPacket message, FriendlyByteBuf buffer) {
        buffer.writeUtf(message.action, 64);
        buffer.writeUtf(message.id, 256);
        buffer.writeVarInt(message.slot);
        buffer.writeVarInt(message.npcId);
        buffer.writeDouble(message.offsetX);
        buffer.writeDouble(message.offsetY);
        buffer.writeDouble(message.offsetZ);
    }

    public static PanelActionPacket decode(FriendlyByteBuf buffer) {
        return new PanelActionPacket(buffer.readUtf(64), buffer.readUtf(256),
                buffer.readVarInt(), buffer.readVarInt(), buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
    }

    public static void handle(PanelActionPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                PanelActionService.handle(player, message);
            }
        });
        context.setPacketHandled(true);
    }
}
