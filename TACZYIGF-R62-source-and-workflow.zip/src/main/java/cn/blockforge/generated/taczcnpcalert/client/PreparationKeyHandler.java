package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = TaczCnpcAlertMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class PreparationKeyHandler {
    public static final KeyMapping TOGGLE_READY = new KeyMapping(
            "key.tacz_cnpc_alert.toggle_ready", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Y,
            "key.categories.tacz_cnpc_alert");

    private PreparationKeyHandler() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_READY);
    }
}
