package cn.blockforge.generated.taczcnpcalert;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.OpenDungeonPanelPacket;

/**
 * “警长”标记与行动选择。
 *
 * <p>地图魔杖右键普通 NPC 后，NPC 会被持久标记成警长。警长面板中的行动清单来自配置，
 * 玩家选择后会进入服务器统一管理的全服准备大厅；只有所有在线玩家准备完成并结束倒计时后，才统一传送到配置的维度与坐标。
 * 配置缺少有效入口时会提示配置错误，不会改变玩家位置。</p>
 */
public final class SheriffService {

    public static final String TAG_SHERIFF = "tacz_cnpc_alert.sheriff";
    public static final String TAG_SELECTED_DUNGEON = "tacz_cnpc_alert.selected_dungeon";
    public static final String ACTION_DUNGEON = "dungeon";
    public static final String ACTION_CLEAR_DUNGEON = "clear_dungeon";

    private static final Map<String, Long> RECENT_USES = new HashMap<>();

    private SheriffService() {
    }

    public static boolean isSheriff(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(TAG_SHERIFF);
    }

    public static void setSheriff(LivingEntity entity, boolean value) {
        if (entity == null) {
            return;
        }
        if (value) {
            entity.getPersistentData().putBoolean(TAG_SHERIFF, true);
        } else {
            entity.getPersistentData().remove(TAG_SHERIFF);
        }
    }

    /** 地图魔杖右键 NPC：首次设成警长，已标记时打开行动面板；潜行则取消。 */
    public static boolean handleWandUse(ServerPlayer player, LivingEntity npc, boolean sneaking) {
        if (player == null || npc == null || !npc.isAlive()) {
            return false;
        }
        if (isDuplicateClick(player, npc)) {
            return true;
        }
        if (player.distanceToSqr(npc) > 64.0D) {
            player.displayClientMessage(Component.literal("离得太远了，走近一点再使用地图魔杖。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }
        if (!AlertService.isNpcType(npc)) {
            player.displayClientMessage(Component.literal("这不是可标记的 NPC，地图魔杖对它没用。")
                    .withStyle(ChatFormatting.GRAY), true);
            return true;
        }

        boolean sneak = sneaking || player.isShiftKeyDown();
        if (sneak) {
            if (isSheriff(npc)) {
                setSheriff(npc, false);
                npc.getPersistentData().remove(TAG_SELECTED_DUNGEON);
                player.displayClientMessage(Component.literal("已取消这个 NPC 的警长身份。")
                        .withStyle(ChatFormatting.YELLOW), true);
            } else {
                player.displayClientMessage(Component.literal("这个 NPC 还不是警长。")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return true;
        }

        if (!isSheriff(npc)) {
            setSheriff(npc, true);
            player.displayClientMessage(Component.literal("这个 NPC 现在是警长了，空手右键它即可选择行动。")
                    .withStyle(ChatFormatting.AQUA), true);
            QuartermasterService.celebrate(player, npc);
            return true;
        }

        openPanel(player, npc);
        return true;
    }

    /** 空手右键警长：不走标记流程，直接打开行动面板。 */
    public static void openPanelFromClick(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null || !isSheriff(npc) || isDuplicateClick(player, npc)) {
            return;
        }
        openPanel(player, npc);
    }

    /** 把行动清单交给客户端面板，同时告知警长当前保存的选择。 */
    public static void openPanel(ServerPlayer player, LivingEntity npc) {
        if (player == null || npc == null) {
            return;
        }
        ModNetwork.sendToPlayer(new OpenDungeonPanelPacket(npc.getId(), dungeonNames(),
                npc.getPersistentData().getString(TAG_SELECTED_DUNGEON)), player);
    }

    /** 面板点击行动后由服务端校验并应用。 */
    public static void handlePanelAction(ServerPlayer player, LivingEntity npc, int dungeonIndex, boolean clear) {
        if (player == null || npc == null) {
            return;
        }
        if (!isSheriff(npc)) {
            hint(player, "这个 NPC 不是警长，无法选择行动。");
            return;
        }
        if (player.distanceToSqr(npc) > 64.0D) {
            hint(player, "离警长太远了，请先靠近一些。");
            return;
        }

        List<String> configured = configuredActionEntries();
        if (clear) {
            npc.getPersistentData().remove(TAG_SELECTED_DUNGEON);
            player.getPersistentData().remove(TAG_SELECTED_DUNGEON);
            hint(player, "已清除当前行动选择。");
            return;
        }
        if (dungeonIndex < 0 || dungeonIndex >= configured.size()) {
            hint(player, "这个行动不在当前配置列表中。");
            return;
        }

        DungeonEntry entry = parseEntry(configured.get(dungeonIndex));
        String teleportFailure = teleportFailure(entry, player);
        if (teleportFailure == null) {
            if (ActionPreparationService.begin(player, entry.name(), entry.dimension(), entry.x(), entry.y(), entry.z())) {
                npc.getPersistentData().putString(TAG_SELECTED_DUNGEON, entry.name());
                player.getPersistentData().putString(TAG_SELECTED_DUNGEON, entry.name());
                hint(player, "已选择行动：" + entry.name() + "。等待全服玩家准备完成后统一出发。");
            }
        } else {
            hint(player, "行动入口无效：" + entry.name() + "（" + teleportFailure + "）");
        }
    }

    /** 面板数据：章节标记与行动标记混合传输，行动索引始终对应服务端配置顺序。 */
    public static List<String> dungeonNames() {
        List<String> result = new java.util.ArrayList<>();
        List<String> entries = configuredActionEntries();
        String currentChapter = null;
        for (int i = 0; i < entries.size(); i++) {
            String raw = entries.get(i);
            String chapter = chapterOf(raw);
            if (!chapter.equals(currentChapter)) {
                currentChapter = chapter;
                result.add("@chapter:" + chapter);
            }
            result.add("@action:" + i + ":" + parseEntry(raw).name());
        }
        return result;
    }

    private static List<String> configuredActionEntries() {
        List<? extends String> chapters = AlertConfig.ACTION_CHAPTERS.get();
        if (chapters != null && !chapters.isEmpty()) return chapters.stream().map(String::trim).filter(s -> !s.isBlank()).toList();
        return AlertConfig.DUNGEON_ENTRIES.get().stream().map(s -> "第一章节|" + s).toList();
    }

    private static String chapterOf(String raw) {
        int split = raw == null ? -1 : raw.indexOf('|');
        if (split < 0) return "第一章节";
        String chapter = raw.substring(0, split).trim();
        return chapter.isBlank() ? "第一章节" : chapter;
    }


    private record DungeonEntry(String name, ResourceLocation dimension, double x, double y, double z, boolean hasLocation) {
    }

    private static DungeonEntry parseEntry(String raw) {
        String value = raw == null ? "" : raw.trim();
        int chapterSplit = value.indexOf('|');
        if (chapterSplit >= 0) value = value.substring(chapterSplit + 1).trim();
        String name = value;
        ResourceLocation dimension = null;
        double x = 0.0D;
        double y = 0.0D;
        double z = 0.0D;
        boolean hasLocation = false;

        int at = value.indexOf('@');
        if (at >= 0) {
            name = value.substring(0, at).trim();
            String location = value.substring(at + 1).trim();
            // 维度本身也可能包含命名空间冒号，例如 minecraft:overworld:100 64 -200。
            // 坐标分隔符应取最后一个冒号，不能取第一个冒号。
            int colon = location.lastIndexOf(':');
            if (colon >= 0) {
                dimension = ResourceLocation.tryParse(location.substring(0, colon).trim());
                String[] parts = location.substring(colon + 1).trim().split("\\s+");
                if (dimension != null && parts.length == 3) {
                    try {
                        x = Double.parseDouble(parts[0]);
                        y = Double.parseDouble(parts[1]);
                        z = Double.parseDouble(parts[2]);
                        hasLocation = true;
                    } catch (NumberFormatException ignored) {
                        // 配置写错时只显示行动名，不改变玩家位置。
                    }
                }
            }
        }
        return new DungeonEntry(name.isBlank() ? value : name, dimension, x, y, z, hasLocation);
    }

    private static String teleportFailure(DungeonEntry entry, ServerPlayer player) {
        if (!entry.hasLocation() || entry.dimension() == null) {
            return "入口格式不对，请写成 行动名@minecraft:overworld:100 64 -200";
        }
        ServerLevel targetLevel = player.server.getLevel(ResourceKey.create(Registries.DIMENSION, entry.dimension()));
        if (targetLevel == null) {
            return "找不到维度 " + entry.dimension();
        }
        if (!targetLevel.isInWorldBounds(BlockPos.containing(entry.x(), entry.y(), entry.z()))) {
            return "入口坐标超出世界范围";
        }
        return null;
    }

    /** 行动全员传送成功后统一播放一次指挥部播报，再广播每位参与者的自动回复。 */
    public static void scheduleEntryDialogueForGroup(MinecraftServer server, List<UUID> participants) {
        if (!AlertConfig.ENTRY_DIALOGUE_ENABLED.get() || server == null || participants == null || participants.isEmpty()) return;
        List<UUID> ids = List.copyOf(participants);
        DelayedTasks.schedule(server, AlertConfig.ENTRY_COMMAND_DELAY_TICKS.get(), current -> {
            List<ServerPlayer> online = ids.stream().map(current.getPlayerList()::getPlayer)
                    .filter(java.util.Objects::nonNull).filter(ServerPlayer::isAlive).toList();
            if (online.isEmpty()) return;
            Component command = Component.literal(AlertConfig.ENTRY_COMMAND_SPEAKER.get())
                    .withStyle(ChatFormatting.BLUE)
                    .append(Component.literal(": " + AlertConfig.ENTRY_COMMAND_LINE.get())
                            .withStyle(ChatFormatting.WHITE));
            for (ServerPlayer recipient : online) recipient.sendSystemMessage(command);
            DelayedTasks.schedule(current, AlertConfig.ENTRY_PLAYER_DELAY_TICKS.get(), afterReply -> {
                List<ServerPlayer> recipients = ids.stream().map(afterReply.getPlayerList()::getPlayer)
                        .filter(java.util.Objects::nonNull).filter(ServerPlayer::isAlive).toList();
                List<ServerPlayer> speakers = List.copyOf(recipients);
                for (ServerPlayer speaker : speakers) {
                    Component reply = Component.literal(speaker.getGameProfile().getName())
                            .withStyle(ChatFormatting.BLUE)
                            .append(Component.literal(": " + AlertConfig.ENTRY_PLAYER_LINE.get())
                                    .withStyle(ChatFormatting.WHITE));
                    for (ServerPlayer recipient : recipients) recipient.sendSystemMessage(reply);
                }
            });
        });
    }

    private static boolean isDuplicateClick(ServerPlayer player, LivingEntity npc) {
        long now = player.level().getGameTime();
        String key = player.getUUID() + ":" + npc.getId();
        Long last = RECENT_USES.get(key);
        if (last != null && last == now) {
            return true;
        }
        RECENT_USES.put(key, now);
        if (RECENT_USES.size() > 256) {
            RECENT_USES.clear();
        }
        return false;
    }

    private static void hint(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(ChatFormatting.AQUA), true);
    }
}
