package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.ActionPreparationService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public final class ToggleReadyPacket {
    public static void encode(ToggleReadyPacket message, FriendlyByteBuf buffer) {}
    public static ToggleReadyPacket decode(FriendlyByteBuf buffer) { return new ToggleReadyPacket(); }
    public static void handle(ToggleReadyPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) ActionPreparationService.toggleReady(player);
        });
        context.setPacketHandled(true);
    }
}
