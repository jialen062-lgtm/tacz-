package cn.blockforge.generated.taczcnpcalert;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;
import java.util.UUID;

/** Respawn-time return teleport, delayed to coexist with taczgz's spectator handoff. */
public final class DeathReturnService {
    private DeathReturnService() {}

    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!AlertConfig.DEATH_RETURN_ENABLED.get() || !(event.getEntity() instanceof ServerPlayer player)) return;
        UUID id = player.getUUID();
        MinecraftServer server = player.server;
        // taczgz handles its death-to-spectator transition on the server executor. Wait one tick
        // so its region ownership can be queried before applying this independent return point.
        DelayedTasks.schedule(server, 1, current -> {
            ServerPlayer online = current.getPlayerList().getPlayer(id);
            if (online == null || !online.isAlive() || isTaczgzManaging(id, online)) return;
            ResourceLocation dimension = ResourceLocation.tryParse(AlertConfig.DEATH_RETURN_DIMENSION.get());
            if (dimension == null) {
                online.displayClientMessage(Component.literal("死亡返回点维度配置无效。").withStyle(ChatFormatting.RED), false);
                return;
            }
            ServerLevel target = current.getLevel(ResourceKey.create(Registries.DIMENSION, dimension));
            if (target == null) {
                online.displayClientMessage(Component.literal("找不到死亡返回点维度：" + dimension).withStyle(ChatFormatting.RED), false);
                return;
            }
            double x = AlertConfig.DEATH_RETURN_X.get();
            double y = AlertConfig.DEATH_RETURN_Y.get();
            double z = AlertConfig.DEATH_RETURN_Z.get();
            if (!target.isInWorldBounds(BlockPos.containing(x, y, z))) {
                online.displayClientMessage(Component.literal("死亡返回点坐标超出世界范围，请检查配置。").withStyle(ChatFormatting.RED), false);
                return;
            }
            try {
                online.stopRiding();
                online.teleportTo(target, x, y, z, online.getYRot(), online.getXRot());
            } catch (RuntimeException failure) {
                TaczCnpcAlertMod.LOGGER.warn("传送玩家 {} 到死亡返回点失败", online.getGameProfile().getName(), failure);
                online.displayClientMessage(Component.literal("死亡返回点传送失败，请联系管理员。").withStyle(ChatFormatting.RED), false);
            }
        });
    }

    private static boolean isTaczgzManaging(UUID id, ServerPlayer player) {
        if (player.gameMode.getGameModeForPlayer() == GameType.SPECTATOR) return true;
        if (!ModList.get().isLoaded("taczgz")) return false;
        try {
            Class<?> manager = Class.forName("com.taczgz.SpectatorManager");
            Method active = manager.getMethod("isManagedSpectator", UUID.class);
            Object result = active.invoke(null, id);
            if (Boolean.TRUE.equals(result)) return true;
            Method pending = manager.getMethod("isPendingSpectator", UUID.class);
            return Boolean.TRUE.equals(pending.invoke(null, id));
        } catch (ReflectiveOperationException ignored) {
            // Older taczgz builds do not expose the optional hook. Avoid overriding an active spectator.
            return player.gameMode.getGameModeForPlayer() == GameType.SPECTATOR;
        }
    }
}
