package cn.blockforge.generated.taczcnpcalert;

import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PreparationStatusPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

/** Server-authoritative preparation lobby. All online players participate. */
public final class ActionPreparationService {
    private static MinecraftServer activeServer;
    private static Action selectedAction;
    private static long countdownEnd = -1L;
    private static int lastAnnouncedSecond = -1;
    private static boolean teleporting;

    private record Action(String name, ResourceLocation dimension, double x, double y, double z) {}

    private ActionPreparationService() {}

    public static boolean begin(ServerPlayer initiator, String name, ResourceLocation dimension,
                                double x, double y, double z) {
        if (initiator == null || dimension == null) return false;
        MinecraftServer server = initiator.server;
        ServerLevel target = server.getLevel(ResourceKey.create(Registries.DIMENSION, dimension));
        if (target == null || !target.isInWorldBounds(net.minecraft.core.BlockPos.containing(x, y, z))) {
            hint(initiator, "行动入口无效：目标维度或坐标不存在。");
            return false;
        }
        Action requested = new Action(name, dimension, x, y, z);
        if (activeServer == server && selectedAction != null && !selectedAction.equals(requested)) {
            hint(initiator, "当前服务器已有行动准备大厅，请先完成或重启当前行动。");
            return false;
        }
        if (activeServer != server || selectedAction == null) {
            reset();
            activeServer = server;
            selectedAction = requested;
            announce(server, "行动「" + name + "」已建立准备大厅。所有在线玩家均需按 Y 准备。");
            publishStatus(server);
        }
        return true;
    }

    public static void toggleReady(ServerPlayer player) {
        if (player == null || activeServer != player.server || selectedAction == null || teleporting) {
            if (player != null) hint(player, "当前没有等待中的行动。");
            return;
        }
        UUID id = player.getUUID();
        if (readyState.contains(id)) readyState.remove(id); else readyState.add(id);
        if (countdownEnd >= 0 && !allReady()) cancelCountdown("有人取消准备");
        publishStatus(activeServer);
        if (allReady()) startCountdown();
    }

    private static final Set<UUID> readyState = new LinkedHashSet<>();

    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || activeServer != player.server || selectedAction == null) return;
        readyState.remove(player.getUUID());
        if (countdownEnd >= 0) cancelCountdown("有新玩家加入，等待其准备");
        MinecraftServer server = activeServer;
        DelayedTasks.schedule(server, 1, current -> {
            if (activeServer == current && selectedAction != null) publishStatus(current);
        });
    }

    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || activeServer != player.server || selectedAction == null) return;
        readyState.remove(player.getUUID());
        MinecraftServer server = activeServer;
        DelayedTasks.schedule(server, 1, current -> {
            if (activeServer != current || selectedAction == null) return;
            if (current.getPlayerList().getPlayers().isEmpty()) { reset(); return; }
            if (countdownEnd >= 0 && !allReady()) cancelCountdown("玩家离开后，仍有玩家未准备");
            if (countdownEnd < 0 && allReady()) startCountdown();
            publishStatus(current);
        });
    }

    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || activeServer == null || selectedAction == null) return;
        if (countdownEnd < 0 && allReady()) startCountdown();
        if (countdownEnd < 0) return;
        long remaining = countdownEnd - activeServer.getTickCount();
        int seconds = (int) Math.ceil(remaining / 20.0D);
        if (seconds != lastAnnouncedSecond && seconds > 0) {
            lastAnnouncedSecond = seconds;
            announce(activeServer, "行动将在 " + seconds + " 秒后开始。");
            sendPreparationPacket(activeServer);
        }
        if (remaining <= 0 && allReady() && !teleporting) launch();
        else if (remaining <= 0 && !allReady()) cancelCountdown("准备状态发生变化");
    }

    private static void startCountdown() {
        if (activeServer == null || selectedAction == null || countdownEnd >= 0 || teleporting || !allReady()) return;
        countdownEnd = activeServer.getTickCount() + 200L;
        lastAnnouncedSecond = 10;
        announce(activeServer, "全员准备完成，10 秒倒计时开始！");
        sendPreparationPacket(activeServer);
    }

    private static boolean allReady() {
        if (activeServer == null) return false;
        for (ServerPlayer player : activeServer.getPlayerList().getPlayers()) {
            if (!readyState.contains(player.getUUID())) return false;
        }
        return !activeServer.getPlayerList().getPlayers().isEmpty();
    }

    private static void cancelCountdown(String reason) {
        countdownEnd = -1L;
        lastAnnouncedSecond = -1;
        announce(activeServer, "倒计时已取消：" + reason + "。");
        sendPreparationPacket(activeServer);
    }

    private static void launch() {
        if (teleporting || activeServer == null || selectedAction == null || !allReady()) return;
        teleporting = true;
        Action action = selectedAction;
        ServerLevel target = activeServer.getLevel(ResourceKey.create(Registries.DIMENSION, action.dimension()));
        if (target == null || !target.isInWorldBounds(net.minecraft.core.BlockPos.containing(action.x(), action.y(), action.z()))) {
            announce(activeServer, "行动启动失败：目标维度或坐标已不存在。");
            for (ServerPlayer player : activeServer.getPlayerList().getPlayers()) {
                ModNetwork.sendToPlayer(PreparationStatusPacket.inactive(), player);
            }
            reset();
            return;
        }
        java.util.List<UUID> participants = new java.util.ArrayList<>();
        for (ServerPlayer player : java.util.List.copyOf(activeServer.getPlayerList().getPlayers())) {
            try {
                player.stopRiding();
                player.teleportTo(target, action.x(), action.y(), action.z(), player.getYRot(), player.getXRot());
                participants.add(player.getUUID());
            } catch (RuntimeException failure) {
                TaczCnpcAlertMod.LOGGER.warn("传送玩家 {} 到行动 {} 失败", player.getGameProfile().getName(), action.name(), failure);
                hint(player, "传送到行动地图失败，请联系管理员检查坐标。");
            }
        }
        SheriffService.scheduleEntryDialogueForGroup(activeServer, participants);
        announce(activeServer, "行动「" + action.name() + "」已开始！");
        for (ServerPlayer player : activeServer.getPlayerList().getPlayers()) {
            ModNetwork.sendToPlayer(PreparationStatusPacket.inactive(), player);
        }
        reset();
    }

    private static void sendPreparationPacket(MinecraftServer server) {
        if (server == null || selectedAction == null) return;
        java.util.List<PreparationStatusPacket.PlayerStatus> players = new java.util.ArrayList<>();
        int readyCount = 0;
        int total = 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            boolean isReady = readyState.contains(player.getUUID());
            if (isReady) readyCount++;
            total++;
            players.add(new PreparationStatusPacket.PlayerStatus(player.getGameProfile().getName(), isReady));
        }
        int seconds = countdownEnd < 0 ? -1 : (int) Math.ceil(Math.max(0L, countdownEnd - server.getTickCount()) / 20.0D);
        PreparationStatusPacket packet = new PreparationStatusPacket(true, selectedAction.name(),
                readyCount, total, seconds, players);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) ModNetwork.sendToPlayer(packet, player);
    }

    private static void publishStatus(MinecraftServer server) {
        if (server == null || selectedAction == null) return;
        sendPreparationPacket(server);
        int total = server.getPlayerList().getPlayers().size();
        int count = 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (readyState.contains(player.getUUID())) count++;
        }
        StringBuilder line = new StringBuilder("行动「" + selectedAction.name() + "」  " + count + "/" + total + " 已准备");
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            boolean isReady = readyState.contains(player.getUUID());
            line.append("\n").append(isReady ? "[已准备] " : "[未准备] ").append(player.getGameProfile().getName());
        }
        announce(server, line.toString());
    }

    private static void announce(MinecraftServer server, String message) {
        if (server == null) return;
        server.getPlayerList().broadcastSystemMessage(Component.literal(message).withStyle(ChatFormatting.AQUA), false);
    }

    private static void hint(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal(message).withStyle(ChatFormatting.YELLOW), false);
    }

    public static void onServerStopped(net.minecraftforge.event.server.ServerStoppedEvent event) {
        if (activeServer == event.getServer()) reset();
    }

    private static void reset() {
        activeServer = null;
        selectedAction = null;
        readyState.clear();
        countdownEnd = -1L;
        lastAnnouncedSecond = -1;
        teleporting = false;
    }
}
