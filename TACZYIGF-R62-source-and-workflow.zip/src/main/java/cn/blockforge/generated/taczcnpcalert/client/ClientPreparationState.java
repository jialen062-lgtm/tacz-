package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.net.PreparationStatusPacket;

import java.util.List;

/** Client cache for the latest server preparation lobby snapshot. */
public final class ClientPreparationState {
    public static boolean active;
    public static String actionName = "";
    public static int readyCount;
    public static int totalCount;
    public static int countdownSeconds = -1;
    public static List<PreparationStatusPacket.PlayerStatus> players = List.of();

    private ClientPreparationState() {}

    public static void apply(PreparationStatusPacket packet) {
        active = packet.active();
        actionName = packet.actionName();
        readyCount = packet.readyCount();
        totalCount = packet.totalCount();
        countdownSeconds = packet.countdownSeconds();
        players = packet.players();
    }
}
