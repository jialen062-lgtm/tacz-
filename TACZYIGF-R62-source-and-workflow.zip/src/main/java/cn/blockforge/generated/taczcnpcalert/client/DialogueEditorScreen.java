package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueStore;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.SaveDialogueEditorPacket;
import cn.blockforge.generated.taczcnpcalert.net.CloseDialogueEditorPacket;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Visual node editor. The underlying nodes/lines/options/target JSON remains backward compatible. */
public final class DialogueEditorScreen extends Screen {
    private final int npcId;
    private final String npcName;
    private JsonObject script;
    private int nodeIndex;
    private int selectedIndex = -1;
    private int itemScroll;
    private boolean optionMode;
    private boolean preview;
    private boolean explicitExit;
    private EditBox textBox;
    private EditBox targetBox;
    private int listTop;
    private int listBottom;
    private int panelLeft;
    private int panelRight;

    public DialogueEditorScreen(int npcId, String npcName, String json) {
        super(Component.literal("对话编辑 · " + npcName));
        this.npcId = npcId;
        this.npcName = npcName == null ? "NPC" : npcName;
        this.script = parseOrCreate(json);
        ensureNode();
        normalizeTargets();
    }

    private static JsonObject parseOrCreate(String json) {
        try {
            JsonElement parsed = JsonParser.parseString(json == null ? "" : json);
            if (parsed.isJsonObject() && parsed.getAsJsonObject().has("nodes")) return parsed.getAsJsonObject();
        } catch (Exception ignored) { }
        return DialogueStore.emptyScript();
    }

    private JsonArray nodes() {
        JsonElement value = script.get("nodes");
        if (value == null || !value.isJsonArray()) {
            JsonArray array = new JsonArray();
            script.add("nodes", array);
            return array;
        }
        return value.getAsJsonArray();
    }

    private JsonObject ensureNode() {
        JsonArray array = nodes();
        while (array.size() <= nodeIndex) array.add(newNode());
        JsonElement value = array.get(nodeIndex);
        if (!value.isJsonObject()) {
            JsonObject node = newNode(); array.set(nodeIndex, node); return node;
        }
        JsonObject node = value.getAsJsonObject();
        if (!node.has("lines") || !node.get("lines").isJsonArray()) node.add("lines", new JsonArray());
        if (!node.has("options") || !node.get("options").isJsonArray()) node.add("options", new JsonArray());
        return node;
    }

    private JsonObject newNode() {
        JsonObject node = new JsonObject();
        node.add("lines", new JsonArray());
        node.add("options", new JsonArray());
        return node;
    }

    private JsonArray currentItems() {
        JsonObject node = ensureNode();
        return node.getAsJsonArray(optionMode ? "options" : "lines");
    }

    private String itemText(JsonElement element) {
        if (optionMode && element != null && element.isJsonObject()) {
            JsonElement text = element.getAsJsonObject().get("text");
            return text != null && text.isJsonPrimitive() ? text.getAsString() : "";
        }
        return element != null && element.isJsonPrimitive() ? element.getAsString() : "";
    }

    private int itemTarget(JsonElement element) {
        try { return element.getAsJsonObject().get("target").getAsInt(); }
        catch (Exception ignored) { return 0; }
    }

    @Override
    protected void init() {
        clearWidgets();
        panelLeft = Math.max(8, width / 2 - 260);
        panelRight = Math.min(width - 8, panelLeft + 520);
        listTop = 108;
        listBottom = Math.max(listTop + 40, height - 112);
        int fieldW = panelRight - panelLeft - 32;
        textBox = new EditBox(font, panelLeft + 16, height - 91, fieldW, 20, Component.literal("文本内容"));
        textBox.setMaxLength(DialogueStore.MAX_TEXT);
        addRenderableWidget(textBox);
        targetBox = new EditBox(font, panelRight - 74, height - 65, 58, 20, Component.literal("目标节点"));
        targetBox.setMaxLength(3);
        targetBox.setValue("0");
        addRenderableWidget(targetBox);
        targetBox.visible = optionMode;

        addRenderableWidget(Button.builder(Component.literal("上一节点"), b -> changeNode(-1))
                .bounds(panelLeft + 104, 48, 58, 20).build());
        addRenderableWidget(Button.builder(Component.literal("下一节点"), b -> changeNode(1))
                .bounds(panelLeft + 166, 48, 58, 20).build());
        addRenderableWidget(Button.builder(Component.literal("新增节点"), b -> addNode())
                .bounds(panelLeft + 228, 48, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("删除节点"), b -> deleteNode())
                .bounds(panelLeft + 294, 48, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("清空脚本"), b -> clearScript())
                .bounds(panelLeft + 360, 48, 62, 20).build());

        int buttonY = height - 38;
        addRenderableWidget(Button.builder(Component.literal("新增"), b -> addItem())
                .bounds(panelLeft + 16, buttonY, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("修改"), b -> updateItem())
                .bounds(panelLeft + 82, buttonY, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("删除"), b -> deleteItem())
                .bounds(panelLeft + 148, buttonY, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("预览"), b -> preview = !preview)
                .bounds(panelLeft + 214, buttonY, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("保存"), b -> save())
                .bounds(panelRight - 148, buttonY, 62, 20).build());
        addRenderableWidget(Button.builder(Component.literal("退出"), b -> exitEditor())
                .bounds(panelRight - 82, buttonY, 62, 20).build());
        updateFieldsFromSelection();
    }

    private void addItem() {
        String text = textBox.getValue().trim();
        if (text.isEmpty() || currentItems().size() >= (optionMode ? 6 : 20)) return;
        if (optionMode) {
            JsonObject option = new JsonObject();
            int target = parseTarget();
            ensureNodeIndex(target);
            option.addProperty("text", text);
            option.addProperty("target", target);
            currentItems().add(option);
        } else currentItems().add(text);
        selectedIndex = currentItems().size() - 1;
        itemScroll = Math.max(0, currentItems().size() - Math.max(1, (listBottom - listTop) / 23));
        updateFieldsFromSelection();
    }

    private void updateItem() {
        if (selectedIndex < 0 || selectedIndex >= currentItems().size()) return;
        String text = textBox.getValue().trim();
        if (text.isEmpty()) return;
        if (optionMode) {
            JsonObject option;
            try { option = currentItems().get(selectedIndex).getAsJsonObject(); }
            catch (Exception ignored) { option = new JsonObject(); currentItems().set(selectedIndex, option); }
            int target = parseTarget();
            ensureNodeIndex(target);
            option.addProperty("text", text);
            option.addProperty("target", target);
        } else currentItems().set(selectedIndex, new com.google.gson.JsonPrimitive(text));
    }

    private void deleteItem() {
        if (selectedIndex < 0 || selectedIndex >= currentItems().size()) return;
        currentItems().remove(selectedIndex);
        selectedIndex = Math.min(selectedIndex, currentItems().size() - 1);
        itemScroll = Math.max(0, Math.min(itemScroll, Math.max(0, currentItems().size() - 1)));
        updateFieldsFromSelection();
    }

    private int parseTarget() {
        try { return Math.max(0, Math.min(DialogueStore.MAX_NODES - 1, Integer.parseInt(targetBox.getValue().trim()))); }
        catch (Exception ignored) { return 0; }
    }

    private void ensureNodeIndex(int index) {
        while (nodes().size() <= index && nodes().size() < DialogueStore.MAX_NODES) nodes().add(newNode());
    }

    private void normalizeTargets() {
        JsonArray all = nodes();
        int originalSize = all.size();
        for (int nodeIndex = 0; nodeIndex < originalSize; nodeIndex++) {
            JsonElement nodeElement = all.get(nodeIndex);
            if (!nodeElement.isJsonObject()) continue;
            JsonElement options = nodeElement.getAsJsonObject().get("options");
            if (options == null || !options.isJsonArray()) continue;
            for (JsonElement optionElement : options.getAsJsonArray()) {
                if (!optionElement.isJsonObject()) continue;
                JsonObject option = optionElement.getAsJsonObject();
                int target;
                try { target = option.get("target").getAsInt(); } catch (Exception ignored) { target = 0; }
                target = Math.max(0, Math.min(DialogueStore.MAX_NODES - 1, target));
                option.addProperty("target", target);
                ensureNodeIndex(target);
            }
        }
    }

    private void updateFieldsFromSelection() {
        JsonArray items = currentItems();
        if (selectedIndex >= 0 && selectedIndex < items.size()) {
            JsonElement item = items.get(selectedIndex);
            textBox.setValue(itemText(item));
            if (optionMode) targetBox.setValue(Integer.toString(itemTarget(item)));
        } else {
            textBox.setValue("");
            if (optionMode) targetBox.setValue("0");
        }
    }

    private void save() {
        ModNetwork.sendToServer(new SaveDialogueEditorPacket(npcId, script.toString()));
    }

    private void exitEditor() {
        ModNetwork.sendToServer(new SaveDialogueEditorPacket(npcId, script.toString()));
        ModNetwork.sendToServer(new CloseDialogueEditorPacket(npcId));
        explicitExit = true;
        onClose();
    }

    @Override
    public void onClose() {
        // Preserve an in-progress draft if the screen is closed with Escape or replaced by another screen.
        if (!explicitExit && script != null) {
            ModNetwork.sendToServer(new SaveDialogueEditorPacket(npcId, script.toString()));
        }
        super.onClose();
    }

    private void changeNode(int delta) {
        nodeIndex = Math.max(0, Math.min(DialogueStore.MAX_NODES - 1, nodeIndex + delta));
        ensureNode(); selectedIndex = -1; itemScroll = 0; updateFieldsFromSelection();
    }

    private void addNode() {
        if (nodes().size() >= DialogueStore.MAX_NODES) return;
        nodeIndex = nodes().size(); nodes().add(newNode()); selectedIndex = -1; itemScroll = 0; updateFieldsFromSelection();
    }

    private void deleteNode() {
        if (nodes().size() <= 1) {
            nodes().set(0, newNode()); nodeIndex = 0;
        } else {
            int removed = nodeIndex;
            nodes().remove(removed);
            for (JsonElement nodeElement : nodes()) {
                if (!nodeElement.isJsonObject()) continue;
                JsonElement optionsElement = nodeElement.getAsJsonObject().get("options");
                if (optionsElement == null || !optionsElement.isJsonArray()) continue;
                for (JsonElement optionElement : optionsElement.getAsJsonArray()) {
                    if (!optionElement.isJsonObject()) continue;
                    JsonObject option = optionElement.getAsJsonObject();
                    int target;
                    try { target = option.get("target").getAsInt(); } catch (Exception ignored) { continue; }
                    if (target == removed) option.addProperty("target", 0);
                    else if (target > removed) option.addProperty("target", target - 1);
                }
            }
            nodeIndex = Math.min(nodeIndex, nodes().size() - 1);
        }
        selectedIndex = -1; itemScroll = 0; ensureNode(); updateFieldsFromSelection();
    }

    private void clearScript() {
        script = DialogueStore.emptyScript(); nodeIndex = 0; selectedIndex = -1; itemScroll = 0; ensureNode(); updateFieldsFromSelection();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(panelLeft, 0, panelRight, height, 0xE0000000);
        g.drawCenteredString(font, "NPC 对话可视化编辑器", (panelLeft + panelRight) / 2, 12, 0xFFFFFFFF);
        g.drawCenteredString(font, npcName, (panelLeft + panelRight) / 2, 30, 0xFFFFD34D);
        g.drawString(font, "节点 " + (nodeIndex + 1) + " / " + nodes().size(), panelLeft + 16, 54, 0xFFFFFFFF);
        g.drawString(font, "NPC 台词", panelLeft + 16, 78, optionMode ? 0xFFAAAAAA : 0xFFFF6666);
        g.drawString(font, "玩家选项", panelLeft + 104, 78, optionMode ? 0xFF66CCFF : 0xFFAAAAAA);
        g.drawString(font, "选择条目以修改；选项可指定跳转节点", panelLeft + 16, 94, 0xFFBBBBBB);

        JsonArray items = currentItems();
        int y = listTop;
        for (int row = 0; row < items.size() && y + 20 < listBottom; row++) {
            int i = itemScroll + row;
            if (i >= items.size()) break;
            boolean hover = mx >= panelLeft + 14 && mx <= panelRight - 14 && my >= y && my < y + 20;
            int color = i == selectedIndex ? 0xAA315B88 : (hover ? 0x66555555 : 0x33222222);
            g.fill(panelLeft + 14, y, panelRight - 14, y + 19, color);
            String line = (i + 1) + ". " + itemText(items.get(i));
            if (optionMode) line += "  → 节点 " + itemTarget(items.get(i));
            g.drawString(font, font.plainSubstrByWidth(line, panelRight - panelLeft - 44), panelLeft + 22, y + 6, 0xFFEAEAEA, false);
            y += 23;
        }
        if (items.isEmpty()) g.drawCenteredString(font, optionMode ? "暂无玩家选项" : "暂无 NPC 台词", (panelLeft + panelRight) / 2, listTop + 14, 0xFF999999);

        if (preview) {
            int x = panelRight - 190;
            g.fill(x, 48, panelRight - 12, Math.min(height - 48, 48 + nodes().size() * 34), 0xEE111820);
            g.drawString(font, "脚本预览", x + 8, 54, 0xFFFFD34D);
            int py = 70;
            for (int n = 0; n < nodes().size() && py < height - 60; n++) {
                if (!nodes().get(n).isJsonObject()) continue;
                JsonObject node = nodes().get(n).getAsJsonObject();
                JsonArray ls = node.has("lines") && node.get("lines").isJsonArray() ? node.getAsJsonArray("lines") : new JsonArray();
                JsonArray os = node.has("options") && node.get("options").isJsonArray() ? node.getAsJsonArray("options") : new JsonArray();
                g.drawString(font, "节点 " + n, x + 8, py, 0xFFFFD34D); py += 13;
                for (JsonElement line : ls) {
                    if (py >= height - 60) break;
                    String value = line.isJsonPrimitive() ? line.getAsString() : "";
                    g.drawString(font, font.plainSubstrByWidth("说：" + value, 164), x + 8, py, 0xFFFFFFFF); py += 12;
                }
                for (JsonElement option : os) {
                    if (py >= height - 60) break;
                    if (!option.isJsonObject()) continue;
                    JsonObject optionObject = option.getAsJsonObject();
                    String value = optionObject.has("text") && optionObject.get("text").isJsonPrimitive()
                            ? optionObject.get("text").getAsString() : "";
                    int target = -1;
                    try { if (optionObject.has("target")) target = optionObject.get("target").getAsInt(); } catch (Exception ignored) { }
                    g.drawString(font, font.plainSubstrByWidth("选：" + value + " → " + target, 164), x + 8, py, 0xFF88CCFF); py += 12;
                }
            }
        }
        super.render(g, mx, my, pt);
        g.drawString(font, "内容", panelLeft + 16, height - 105, 0xFFDDDDDD);
        if (optionMode) g.drawString(font, "跳转节点", panelRight - 74, height - 78, 0xFFDDDDDD);
        g.drawString(font, "节点操作：← / → 切换；新增节点、删除节点、清空脚本", panelLeft + 16, height - 56, 0xFF999999);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && my >= listTop && my < listBottom && mx >= panelLeft + 14 && mx <= panelRight - 14) {
            int index = itemScroll + ((int) my - listTop) / 23;
            if (index >= 0 && index < currentItems().size()) { selectedIndex = index; updateFieldsFromSelection(); return true; }
        }
        if (button == 0 && my >= 72 && my <= 91) {
            if (mx < panelLeft + 96) { optionMode = false; targetBox.visible = false; selectedIndex = -1; itemScroll = 0; updateFieldsFromSelection(); return true; }
            if (mx < panelLeft + 190) { optionMode = true; targetBox.visible = true; selectedIndex = -1; itemScroll = 0; updateFieldsFromSelection(); return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx >= panelLeft && mx <= panelRight && my >= listTop && my <= listBottom) {
            int visible = Math.max(1, (listBottom - listTop) / 23);
            itemScroll = Math.max(0, Math.min(itemScroll - (int) Math.signum(delta), Math.max(0, currentItems().size() - visible)));
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((textBox != null && textBox.isFocused()) || (targetBox != null && targetBox.isFocused()))
            return super.keyPressed(keyCode, scanCode, modifiers);
        if (keyCode == 263) { changeNode(-1); return true; }
        if (keyCode == 262) { changeNode(1); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean isPauseScreen() { return false; }
}
