package cn.blockforge.generated.taczcnpcalert.net;

import java.util.List;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** 服务端 → 客户端：打开警长的行动选择面板。 */
public final class OpenDungeonPanelPacket {

    private final int npcId;
    private final List<String> dungeonNames;
    private final String selectedDungeon;

    public OpenDungeonPanelPacket(int npcId, List<String> dungeonNames, String selectedDungeon) {
        this.npcId = npcId;
        this.dungeonNames = List.copyOf(dungeonNames);
        this.selectedDungeon = selectedDungeon == null ? "" : selectedDungeon;
    }

    public int npcId() {
        return npcId;
    }

    public List<String> dungeonNames() {
        return dungeonNames;
    }

    public String selectedDungeon() {
        return selectedDungeon;
    }

    public static void encode(OpenDungeonPanelPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.npcId);
        buffer.writeCollection(message.dungeonNames, FriendlyByteBuf::writeUtf);
        buffer.writeUtf(message.selectedDungeon, 256);
    }

    public static OpenDungeonPanelPacket decode(FriendlyByteBuf buffer) {
        int npcId = buffer.readVarInt();
        List<String> names = buffer.readCollection(java.util.ArrayList::new, FriendlyByteBuf::readUtf);
        return new OpenDungeonPanelPacket(npcId, names, buffer.readUtf(256));
    }

    public static void handle(OpenDungeonPanelPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler.openDungeonPanel(
                        message.npcId, message.dungeonNames, message.selectedDungeon)));
        context.setPacketHandled(true);
    }
}
