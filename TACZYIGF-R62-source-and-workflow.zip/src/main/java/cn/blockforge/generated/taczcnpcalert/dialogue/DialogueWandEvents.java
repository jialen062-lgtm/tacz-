package cn.blockforge.generated.taczcnpcalert.dialogue;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.SheriffService;
import cn.blockforge.generated.taczcnpcalert.QuartermasterService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** NPC 对话入口：空手右键触发普通对话，持编辑魔杖右键打开编辑模式。 */
public final class DialogueWandEvents {
    private record ClickStamp(long tick, UUID npcId) {}
    private static final Map<UUID, ClickStamp> LAST_CLICK = new ConcurrentHashMap<>();

    private DialogueWandEvents() {}

    @net.minecraftforge.eventbus.api.SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        handle(event, event.getTarget());
    }

    @net.minecraftforge.eventbus.api.SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handle(event, event.getTarget());
    }

    private static void handle(PlayerInteractEvent event, Entity target) {
        Player player = event.getEntity();
        if (!(target instanceof LivingEntity npc) || !AlertService.isNpcType(npc)) return;
        ItemStack held = event.getItemStack();
        boolean editing = held.is(ModRegistry.DIALOGUE_EDIT_WAND.get());
        // Preserve the dedicated interactions of the sheriff and quartermaster NPCs.
        if (!editing && (SheriffService.isSheriff(npc) || QuartermasterService.isQuartermaster(npc))) return;
        boolean emptyHand = player.getMainHandItem().isEmpty() && player.getOffhandItem().isEmpty();
        if (!editing && !emptyHand) return;
        boolean clientSide = player.level().isClientSide();
        // Entity persistent data is server-owned and is not guaranteed to be synced to the client.
        // Let empty-hand interactions reach the server; it cancels only when a script actually exists.
        if (!editing && clientSide) return;
        // Do not steal another NPC mod's normal interaction when this NPC has no dialogue script.
        if (!editing && DialogueStore.parse(DialogueStore.read(npc)) == null) return;

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        // Only the server opens the editor/dialogue. The two Forge interaction events are deduplicated.
        if (!clientSide && player instanceof ServerPlayer serverPlayer) {
            long tick = player.level().getGameTime();
            ClickStamp previous = LAST_CLICK.put(player.getUUID(), new ClickStamp(tick, npc.getUUID()));
            if (previous != null && previous.tick() == tick && previous.npcId().equals(npc.getUUID())) return;
            use(serverPlayer, npc, editing);
        }
    }

    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        LAST_CLICK.remove(event.getEntity().getUUID());
    }

    public static void use(ServerPlayer player, LivingEntity npc, boolean editing) {
        if (editing) {
            DialogueEditService.toggle(player, npc);
            return;
        }
        String json = DialogueStore.read(npc);
        if (DialogueStore.parse(json) == null) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "这个 NPC 还没有对话脚本。请使用对话编辑魔杖编写。")
                    .withStyle(net.minecraft.ChatFormatting.YELLOW), false);
            return;
        }
        ModNetwork.sendToPlayer(new cn.blockforge.generated.taczcnpcalert.net.OpenDialoguePacket(
                npc.getId(), npc.getName().getString(), json), player);
    }
}
