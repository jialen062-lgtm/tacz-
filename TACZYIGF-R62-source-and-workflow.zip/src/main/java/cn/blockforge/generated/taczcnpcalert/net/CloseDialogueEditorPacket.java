package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueEditService;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Explicit Exit button only; closing the screen with Escape does not discard the server edit session. */
public final class CloseDialogueEditorPacket {
    private final int npcId;
    public CloseDialogueEditorPacket(int npcId) { this.npcId = npcId; }
    public static void encode(CloseDialogueEditorPacket packet, FriendlyByteBuf buffer) { buffer.writeVarInt(packet.npcId); }
    public static CloseDialogueEditorPacket decode(FriendlyByteBuf buffer) { return new CloseDialogueEditorPacket(buffer.readVarInt()); }
    public static void handle(CloseDialogueEditorPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) DialogueEditService.closeFromEditor(player, packet.npcId);
        });
        context.setPacketHandled(true);
    }
}
