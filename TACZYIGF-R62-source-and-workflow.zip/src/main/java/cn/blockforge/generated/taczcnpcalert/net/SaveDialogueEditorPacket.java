package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.dialogue.DialogueEditService;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** 客户端提交编辑器中的完整脚本；服务端负责校验和保存。 */
public final class SaveDialogueEditorPacket {
    private final int npcId;
    private final String json;
    public SaveDialogueEditorPacket(int npcId, String json) { this.npcId = npcId; this.json = json == null ? "" : json; }
    public static void encode(SaveDialogueEditorPacket m, FriendlyByteBuf b) { b.writeVarInt(m.npcId); b.writeUtf(m.json, 32767); }
    public static SaveDialogueEditorPacket decode(FriendlyByteBuf b) { return new SaveDialogueEditorPacket(b.readVarInt(), b.readUtf(32767)); }
    public static void handle(SaveDialogueEditorPacket m, Supplier<NetworkEvent.Context> c) {
        NetworkEvent.Context ctx = c.get();
        ctx.enqueueWork(() -> { ServerPlayer p = ctx.getSender(); if (p != null) DialogueEditService.saveFromEditor(p, m.npcId, m.json); });
        ctx.setPacketHandled(true);
    }
}
