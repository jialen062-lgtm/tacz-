package cn.blockforge.generated.taczcnpcalert.net;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** 服务端通知客户端打开 NPC 对话脚本编辑器。 */
public final class OpenDialogueEditorPacket {
    private final int npcId;
    private final String npcName;
    private final String json;
    public OpenDialogueEditorPacket(int npcId, String npcName, String json) {
        this.npcId = npcId; this.npcName = npcName == null ? "NPC" : npcName; this.json = json == null ? "" : json;
    }
    public static void encode(OpenDialogueEditorPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.npcId); b.writeUtf(m.npcName, 256); b.writeUtf(m.json, 32767);
    }
    public static OpenDialogueEditorPacket decode(FriendlyByteBuf b) {
        return new OpenDialogueEditorPacket(b.readVarInt(), b.readUtf(256), b.readUtf(32767));
    }
    public static void handle(OpenDialogueEditorPacket m, Supplier<NetworkEvent.Context> c) {
        NetworkEvent.Context ctx = c.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                cn.blockforge.generated.taczcnpcalert.client.ClientPanelHandler.openDialogueEditor(m.npcId, m.npcName, m.json)));
        ctx.setPacketHandled(true);
    }
}
