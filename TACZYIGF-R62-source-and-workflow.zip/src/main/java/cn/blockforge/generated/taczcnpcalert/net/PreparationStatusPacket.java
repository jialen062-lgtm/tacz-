package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.client.ClientPreparationState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Server-authoritative preparation lobby state sent to every online player. */
public final class PreparationStatusPacket {
    public record PlayerStatus(String name, boolean ready) {}
    private final boolean active;
    private final String actionName;
    private final int readyCount;
    private final int totalCount;
    private final int countdownSeconds;
    private final List<PlayerStatus> players;

    public PreparationStatusPacket(boolean active, String actionName, int readyCount, int totalCount,
                                   int countdownSeconds, List<PlayerStatus> players) {
        this.active = active;
        this.actionName = actionName == null ? "" : actionName.substring(0, Math.min(128, actionName.length()));
        this.readyCount = readyCount;
        this.totalCount = totalCount;
        this.countdownSeconds = countdownSeconds;
        this.players = players == null ? List.of() : List.copyOf(players);
    }

    public static PreparationStatusPacket inactive() {
        return new PreparationStatusPacket(false, "", 0, 0, -1, List.of());
    }

    public static void encode(PreparationStatusPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBoolean(packet.active);
        if (!packet.active) return;
        buffer.writeUtf(packet.actionName, 128);
        buffer.writeVarInt(packet.readyCount);
        buffer.writeVarInt(packet.totalCount);
        buffer.writeVarInt(packet.countdownSeconds);
        int count = Math.min(packet.players.size(), 128);
        buffer.writeVarInt(count);
        for (int i = 0; i < count; i++) {
            PlayerStatus player = packet.players.get(i);
            buffer.writeUtf(player.name(), 32);
            buffer.writeBoolean(player.ready());
        }
    }

    public static PreparationStatusPacket decode(FriendlyByteBuf buffer) {
        if (!buffer.readBoolean()) return inactive();
        String action = buffer.readUtf(128);
        int ready = Math.max(0, Math.min(128, buffer.readVarInt()));
        int total = Math.max(0, Math.min(128, buffer.readVarInt()));
        int countdown = buffer.readVarInt();
        int count = Math.max(0, Math.min(128, buffer.readVarInt()));
        List<PlayerStatus> players = new ArrayList<>(count);
        for (int i = 0; i < count; i++) players.add(new PlayerStatus(buffer.readUtf(32), buffer.readBoolean()));
        return new PreparationStatusPacket(true, action, ready, total, countdown, players);
    }

    public static void handle(PreparationStatusPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientPreparationState.apply(packet)));
        context.setPacketHandled(true);
    }

    public boolean active() { return active; }
    public String actionName() { return actionName; }
    public int readyCount() { return readyCount; }
    public int totalCount() { return totalCount; }
    public int countdownSeconds() { return countdownSeconds; }
    public List<PlayerStatus> players() { return players; }
}
