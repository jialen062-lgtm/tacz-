# 构建与验证状态

- Java 源码语法解析：通过，按 Java 17 语言级别解析；TACZYIGF 67 个 Java 文件、独立 taczgz 16 个 Java 文件，共 83 个。
- JSON 资源：两个项目合计 13 个文件解析通过。
- `mods.toml`：两个模组的 TOML 解析通过（TACZYIGF 文件先展开 ForgeGradle 占位符后解析）。
- Gradle `clean build`：未执行。当前工作环境没有 Gradle/Gradle Wrapper，也没有 Java 17（只有 Java 21）；不能把语法解析当成 Forge 编译通过。
- 专用服务器 / 多客户端联机测试：未执行。必须在 Forge 1.20.1 / Java 17 环境按 `R62_IN_PROGRESS_CN.md` 的验收步骤实测。

两个项目均附带 GitHub Actions 工作流，使用 Java 17 和 Gradle 8.8 进行实际构建；工作流成功后才会生成可安装 JAR。
