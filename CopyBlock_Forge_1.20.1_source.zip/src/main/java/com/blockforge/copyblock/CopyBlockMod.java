package com.blockforge.copyblock;

import com.blockforge.copyblock.registry.ModBlocks;
import com.blockforge.copyblock.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CopyBlockMod.MOD_ID)
public final class CopyBlockMod {
    public static final String MOD_ID = "copyblock";

    public CopyBlockMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
    }
}
