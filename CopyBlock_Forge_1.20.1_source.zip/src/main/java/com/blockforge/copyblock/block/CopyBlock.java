package com.blockforge.copyblock.block;

import com.blockforge.copyblock.data.CopySessionData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

public final class CopyBlock extends Block {
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");

    public CopyBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(ACTIVE, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        // 只允许主手空手操作。非空手必须 PASS，不能阻止放置样本方块。
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        ItemStack mainHand = player.getMainHandItem();
        if (!mainHand.isEmpty()) {
            return InteractionResult.PASS;
        }

        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.PASS;
        }

        MinecraftServer server = serverLevel.getServer();
        CopySessionData session = CopySessionData.get(server);

        // 第一次点击才读取顶部样本；第二次点击只负责确定终点。
        if (!session.hasBase()) {
            BlockState sample = serverLevel.getBlockState(pos.above());
            if (sample.isAir()) {
                player.displayClientMessage(Component.literal("未检测到样本方块"), true);
                return InteractionResult.CONSUME;
            }
            if (!sample.getFluidState().isEmpty()) {
                player.displayClientMessage(Component.literal("不能复制空气或流体"), true);
                return InteractionResult.CONSUME;
            }

            session.setBase(serverLevel.dimension().location().toString(), pos, sample);
            serverLevel.setBlock(pos, state.setValue(ACTIVE, true), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
            player.displayClientMessage(Component.literal("已设置复制基点，样本：" +
                    BuiltInRegistries.BLOCK.getKey(sample.getBlock()).toString()), true);
            return InteractionResult.CONSUME;
        }

        if (!session.dimension().equals(serverLevel.dimension().location().toString())) {
            player.displayClientMessage(Component.literal("两个复制器必须位于同一维度"), true);
            return InteractionResult.CONSUME;
        }

        BlockPos first = session.basePos();
        BlockState savedSample = session.sampleState();

        // 第二个复制器进入短暂激活状态；填充成功后会话数据统一清除。
        serverLevel.setBlock(pos, state.setValue(ACTIVE, true), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);

        int minX = Math.min(first.getX(), pos.getX());
        int minY = Math.min(first.getY(), pos.getY());
        int minZ = Math.min(first.getZ(), pos.getZ());
        int maxX = Math.max(first.getX(), pos.getX());
        int maxY = Math.max(first.getY(), pos.getY());
        int maxZ = Math.max(first.getZ(), pos.getZ());

        long changed = 0L;
        // 包含两个端点，严格填充由两个复制器构成的完整闭区间立方体。
        // 只同步客户端并保留已知形状，不触发每个方块的邻居更新级联。
        // 若目标位置已有与样本同状态的方块实体，先清空再放置，以免保留旧容器/命令数据。
        int updateFlags = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    BlockPos target = new BlockPos(x, y, z);
                    BlockState current = serverLevel.getBlockState(target);
                    if (current == savedSample) {
                        if (serverLevel.getBlockEntity(target) != null) {
                            serverLevel.setBlock(target, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), updateFlags);
                            if (serverLevel.setBlock(target, savedSample, updateFlags)) {
                                changed++;
                            }
                        }
                    } else if (serverLevel.setBlock(target, savedSample, updateFlags)) {
                        changed++;
                    }
                }
            }
        }

        session.clear();
        player.displayClientMessage(Component.literal("方块复制完成！填充位置数：" + changed), true);
        return InteractionResult.CONSUME;
    }
}
