package com.blockforge.copyblock.registry;

import com.blockforge.copyblock.CopyBlockMod;
import com.blockforge.copyblock.block.CopyBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, CopyBlockMod.MOD_ID);

    public static final RegistryObject<Block> COPY_BLOCK = BLOCKS.register(
            "copy_block",
            () -> new CopyBlock(BlockBehaviour.Properties.of()
                    .strength(3.5F)
                    .lightLevel(state -> state.getValue(CopyBlock.ACTIVE) ? 10 : 0)
                    .requiresCorrectToolForDrops())
    );

    private ModBlocks() {}
}
