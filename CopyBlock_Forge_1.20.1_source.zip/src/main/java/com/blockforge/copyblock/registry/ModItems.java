package com.blockforge.copyblock.registry;

import com.blockforge.copyblock.CopyBlockMod;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CopyBlockMod.MOD_ID);

    public static final RegistryObject<Item> COPY_BLOCK_ITEM = ITEMS.register(
            "copy_block",
            () -> new BlockItem(ModBlocks.COPY_BLOCK.get(), new Item.Properties())
    );

    private ModItems() {}
}
