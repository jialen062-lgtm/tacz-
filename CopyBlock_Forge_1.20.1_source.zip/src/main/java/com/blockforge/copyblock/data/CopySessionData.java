package com.blockforge.copyblock.data;

import com.blockforge.copyblock.CopyBlockMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;

public final class CopySessionData extends SavedData {
    private static final String DATA_NAME = CopyBlockMod.MOD_ID + "_session";

    private boolean hasBase;
    private String dimension = "";
    private BlockPos basePos = BlockPos.ZERO;
    private BlockState sampleState;

    public static CopySessionData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                CopySessionData::load,
                CopySessionData::new,
                DATA_NAME
        );
    }

    public static CopySessionData load(CompoundTag tag) {
        CopySessionData data = new CopySessionData();
        if (tag.getBoolean("HasBase") && tag.contains("Sample")) {
            data.hasBase = true;
            data.dimension = tag.getString("Dimension");
            data.basePos = BlockPos.of(tag.getLong("BasePos"));
            data.sampleState = NbtUtils.readBlockState(BuiltInRegistries.BLOCK, tag.getCompound("Sample"));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("HasBase", hasBase);
        if (hasBase && sampleState != null) {
            tag.putString("Dimension", dimension);
            tag.putLong("BasePos", basePos.asLong());
            tag.put("Sample", NbtUtils.writeBlockState(sampleState));
        }
        return tag;
    }

    public boolean hasBase() { return hasBase; }
    public String dimension() { return dimension; }
    public BlockPos basePos() { return basePos; }
    public BlockState sampleState() { return sampleState; }

    public void setBase(String dimension, BlockPos pos, BlockState sample) {
        this.hasBase = true;
        this.dimension = dimension;
        this.basePos = pos.immutable();
        this.sampleState = sample;
        setDirty();
    }

    public void clear() {
        hasBase = false;
        dimension = "";
        basePos = BlockPos.ZERO;
        sampleState = null;
        setDirty();
    }
}
