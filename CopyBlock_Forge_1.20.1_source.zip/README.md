# CopyBlock — Forge 1.20.1

- Minecraft 1.20.1 / Forge 47.4.10 / Java 17 / official Mojmap
- 唯一新增方块：`copyblock:copy_block`
- 主手空手右键：第一次记录基点和顶部样本；第二次记录终点并填充闭区间长方体。
- 非空手返回 `PASS`，因此可以正常在复制器顶部放置样本。
- 基点会以发光状态显示；填充完成后会话数据清空。
- 样本支持任意非空气、非流体 BlockState。

## 构建
使用 Gradle 8.8 和 JDK 17：
`gradle build`

产物：`build/libs/copyblock-1.0.0.jar`

## 重要说明
当前版本按需求复制 BlockState（方块类型及属性），不复制 BlockEntity 的附加 NBT
（例如箱子物品、命令方块指令）。区域包含两个端点，故两个复制器本身也会被样本方块覆盖。
大体积区域会同步执行，可能造成服务器卡顿；请先在测试世界验证目标区域大小。
