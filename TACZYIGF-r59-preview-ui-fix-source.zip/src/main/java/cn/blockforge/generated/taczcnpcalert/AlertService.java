package cn.blockforge.generated.taczcnpcalert;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 全模组的核心逻辑：判断谁听见了枪声、能不能喊、然后怎么反馈。
 *
 * <p>警觉规则是硬规则：范围内尚未发现玩家的 NPC 全部触发；已经把玩家当作目标的 NPC 零触发；
 * 同一个 NPC 在冷却时间（默认 1 分钟）内只喊一次。</p>
 */
public final class AlertService {

    private static final String TAG_LAST_COMBAT = "tacz_cnpc_alert.last_combat";
    private static final String TAG_LAST_ALERT = "tacz_cnpc_alert.last_alert";
    private static final String CNPC_ENTITY_CLASS = "noppes.npcs.entity.EntityNPCInterface";
    private static final String CNPC_IS_KILLED_METHOD = "isKilled";
    private static final String CNPC_RESET_METHOD = "reset";
    private static final ThreadLocal<Boolean> PLAYING_REACTION_SOUND = ThreadLocal.withInitial(() -> false);

    private AlertService() {
    }

    /** 这个实体是不是一声“枪响”（默认就是 TaCZ 的子弹实体）。 */
    public static boolean isGunshotEntity(Entity entity) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (id == null) {
            return false;
        }
        String key = id.toString();
        for (String candidate : AlertConfig.BULLET_ENTITY_IDS.get()) {
            if (key.equals(candidate)) {
                return true;
            }
        }
        return false;
    }

    /** 这个实体算不算“NPC”（默认 CustomNPCs 的生物）。 */
    public static boolean isNpc(Entity entity) {
        return entity instanceof LivingEntity && entity.isAlive() && isConfiguredNpcType(entity);
    }

    /** 只看类型、不看死活，给死亡事件用（死亡判定的那一刻实体已经不算“活着”了）。 */
    public static boolean isNpcType(Entity entity) {
        return entity instanceof LivingEntity && isConfiguredNpcType(entity);
    }

    private static boolean isConfiguredNpcType(Entity entity) {
        if (isCustomNpcType(entity)) {
            return true;
        }
        // 只认 CNPC / npc_namespaces 里的生物。原版友好生物（村民、牛、羊等）
        // 不参与枪声警告——它们不是"嫌疑人"，被它们触发警告是 bug。
        // ANY_MOB 仅允许有攻击性的生物，避免调试开关把友好生物也算进来。
        return AlertConfig.ANY_MOB.get() && entity instanceof Mob mob && mob.isAggressive();
    }

    private static boolean isCustomNpcType(Entity entity) {
        if (entity.getClass().getName().startsWith("noppes.npcs")) {
            return true;
        }
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (id == null) {
            return false;
        }
        String namespace = id.getNamespace().toLowerCase(Locale.ROOT);
        for (String candidate : AlertConfig.NPC_NAMESPACES.get()) {
            if (namespace.equals(candidate.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    /** 把某个 NPC 标记成“正在战斗”。 */
    public static void markCombat(LivingEntity npc) {
        npc.getPersistentData().putLong(TAG_LAST_COMBAT, npc.level().getGameTime());
    }

    /**
     * “已经发现玩家”只认 NPC 当前正在把玩家当作目标；没有当前目标的 NPC 仍然可以被惊动。
     *
     * <p>不能使用 {@code getLastHurtByMob()}：友好 NPC 被玩家误伤后可能只留下旧的受伤记录，
     * 但它并没有真正发现玩家。若把这条旧记录当成发现状态，友好 NPC 就会永远漏掉枪声警告。</p>
     */
    public static boolean hasDiscoveredPlayer(LivingEntity npc) {
        if (npc instanceof Mob mob) {
            LivingEntity target = mob.getTarget();
            return target instanceof Player && target.isAlive();
        }
        return false;
    }

    /** 当前是否正处于本模组播放喊声的调用栈中，避免喊声自己再次触发警觉。 */
    public static boolean isPlayingReactionSound() {
        return PLAYING_REACTION_SOUND.get();
    }

    public static void runWithReactionSoundGuard(Runnable action) {
        boolean previous = PLAYING_REACTION_SOUND.get();
        PLAYING_REACTION_SOUND.set(true);
        try {
            action.run();
        } finally {
            PLAYING_REACTION_SOUND.set(previous);
        }
    }

    /**
     * 让所有已加载、正在等待重生的 CNPC NPC 立即重生。
     *
     * <p>非官方 CNPC 的 NPC 会保留死亡实体，并通过公开的 {@code isKilled()} / {@code reset()}
     * 方法控制重生。因此这里只处理“已死亡但实体仍在世界里”的 NPC，不会重复重置活着的 NPC，
     * 也不会凭空生成已经被完全移除的 NPC。</p>
     *
     * @return 实际重生的 NPC 数量；-1 表示未检测到可用的 CNPC 接口
     */
    public static int respawnWaitingNpcs(net.minecraft.server.MinecraftServer server) {
        if (!isCustomNpcsLoaded()) {
            return -1;
        }

        int respawned = 0;
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof LivingEntity npc) || !isCustomNpcType(entity) || !isWaitingForRespawn(npc)) {
                    continue;
                }
                if (invokeNpcReset(npc)) {
                    respawned++;
                }
            }
        }
        return respawned;
    }

    private static boolean isCustomNpcsLoaded() {
        try {
            Class.forName(CNPC_ENTITY_CLASS, false, AlertService.class.getClassLoader());
            return true;
        } catch (ClassNotFoundException ignored) {
            return false;
        }
    }

    private static boolean isWaitingForRespawn(LivingEntity npc) {
        try {
            Method isKilled = npc.getClass().getMethod(CNPC_IS_KILLED_METHOD);
            Object result = isKilled.invoke(npc);
            return result instanceof Boolean killed && killed;
        } catch (ReflectiveOperationException | SecurityException ignored) {
            return false;
        }
    }

    private static boolean invokeNpcReset(LivingEntity npc) {
        try {
            Method reset = npc.getClass().getMethod(CNPC_RESET_METHOD);
            reset.invoke(npc);
            return true;
        } catch (ReflectiveOperationException | SecurityException exception) {
            TaczCnpcAlertMod.LOGGER.warn("无法重生 CNPC NPC（实体类型：{}）", npc.getType(), exception);
            return false;
        }
    }

    /**
     * 处理一声枪响。
     *
     * <p>同一个 NPC 在 {@code alert_cooldown_ticks} 之内最多被惊动一次（默认 1200 tick = 1 分钟），
     * 这样连发武器不会把聊天框刷爆。</p>
     *
     * @param shooter 开枪的人，可能为 null（比如子弹是从别的地方飞来的）
     */
    public static void handleGunshot(Level level, double x, double y, double z, Entity shooter) {
        handleNoise(level, x, y, z, shooter, false);
    }

    /** 调试指令 /taczcnpc alert 专用：忽略 1 分钟冷却，立刻让范围内的 NPC 警觉一次。 */
    public static void handleDebugGunshot(Level level, double x, double y, double z, Entity shooter) {
        handleNoise(level, x, y, z, shooter, true);
    }

    private static void handleNoise(Level level, double x, double y, double z, Entity shooter,
                                    boolean ignoreCooldown) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        double radius = AlertConfig.HEARING_RADIUS.get();
        if (radius <= 0.0D) {
            return;
        }

        Vec3 origin = new Vec3(x, y, z);
        AABB area = new AABB(origin, origin).inflate(radius);
        List<LivingEntity> nearby = serverLevel.getEntitiesOfClass(LivingEntity.class, area, AlertService::isNpc);
        if (nearby.isEmpty()) {
            return;
        }

        long now = serverLevel.getGameTime();
        double radiusSqr = radius * radius;
        long cooldown = ignoreCooldown ? 0L : AlertConfig.ALERT_COOLDOWN.get();

        List<LivingEntity> ready = new ArrayList<>();
        for (LivingEntity npc : nearby) {
            if (shooter != null && npc == shooter) {
                continue;
            }
            if (npc.distanceToSqr(origin) > radiusSqr) {
                continue;
            }
            // 这是本需求的硬规则：已经发现玩家的 NPC 零触发；其余 NPC 全部触发。
            if (hasDiscoveredPlayer(npc)) {
                continue;
            }
            long lastAlert = npc.getPersistentData().getLong(TAG_LAST_ALERT);
            if (cooldown > 0L && now - lastAlert < cooldown) {
                continue;
            }
            npc.getPersistentData().putLong(TAG_LAST_COMBAT, now);
            ready.add(npc);
        }

        ready.sort(Comparator.comparingDouble(npc -> npc.distanceToSqr(origin)));
        for (LivingEntity npc : ready) {
            react(serverLevel, npc, shooter);
        }
    }

    private static void react(ServerLevel level, LivingEntity npc, Entity shooter) {
        if (shooter != null && npc instanceof Mob mob) {
            if (AlertConfig.FACE_SHOOTER.get()) {
                mob.getLookControl().setLookAt(shooter, 30.0F, 30.0F);
            }
        }

        if (AlertConfig.ENABLE_PARTICLE.get()) {
            level.sendParticles(ModRegistry.EXCLAIM.get(),
                    npc.getX(),
                    npc.getY() + npc.getBbHeight() + 0.45D,
                    npc.getZ(),
                    1,
                    0.0D, 0.0D, 0.0D,
                    0.0D);
        }

        if (AlertConfig.ENABLE_SOUND.get()) {
            SoundEvent shout = resolveShoutSound();
            if (shout != null) {
                float pitch = 0.95F + level.getRandom().nextFloat() * 0.15F;
                runWithReactionSoundGuard(() -> level.playSound(null, npc.getX(), npc.getY(), npc.getZ(), shout,
                        SoundSource.HOSTILE, AlertConfig.SHOUT_VOLUME.get().floatValue(), pitch));
            }
        }

        broadcastLine(level, npc, pickLine(level));
        // 给 1 分钟冷却留时间戳。
        npc.getPersistentData().putLong(TAG_LAST_ALERT, level.getGameTime());
    }

    /** 在附近玩家的左下角聊天框里打出一句带红色前缀的喊话。 */
    private static void broadcastLine(ServerLevel level, LivingEntity npc, String line) {
        Component message = Component.literal(AlertConfig.SPEAKER_NAME.get()).withStyle(ChatFormatting.GOLD)
                .append(Component.literal(": " + line).withStyle(ChatFormatting.WHITE));
        broadcastNear(level, npc.position(), message);
    }

    /** 把一条消息发给同一维度、指定坐标一定距离内的所有玩家。 */
    private static void broadcastNear(ServerLevel level, Vec3 center, Component message) {
        broadcastNear(level, center, message, null);
    }

    /**
     * 把一条消息发给同一维度、指定坐标一定距离内的所有玩家，并可以额外跳过某个玩家
     * （用于“击杀播报”里已经单独收到消息的击杀者，避免重复刷两遍）。
     */
    private static void broadcastNear(ServerLevel level, Vec3 center, Component message, UUID skip) {
        double chatRadius = AlertConfig.CHAT_RADIUS.get();
        double chatRadiusSqr = chatRadius * chatRadius;
        for (ServerPlayer player : level.getServer().getPlayerList().getPlayers()) {
            if (player.level() != level) {
                continue;
            }
            if (skip != null && skip.equals(player.getUUID())) {
                continue;
            }
            if (player.distanceToSqr(center) > chatRadiusSqr) {
                continue;
            }
            player.sendSystemMessage(message);
        }
    }

    /**
     * 播报击杀无线电：击杀者本人无论离多远、在哪个维度都一定收到（他才是“报话”的人），
     * NPC 周围的玩家仍然按聊天距离 {@code chat_radius} 收到。
     */
    private static void broadcastKillRadio(ServerLevel level, Vec3 center, UUID killerId, Component message) {
        ServerPlayer killer = level.getServer().getPlayerList().getPlayer(killerId);
        if (killer != null) {
            killer.sendSystemMessage(message);
        }
        broadcastNear(level, center, message, killerId);
    }

    /**
     * 玩家干掉了一个 NPC：先播“玩家ID: 嫌疑人已清除!”，
     * 隔一段时间（默认 2 秒）再播“指挥部: 继续前进!”，两句都是蓝色。
     *
     * <p>这两句是击杀播报，不跟“听见枪声”的距离挂钩：无论玩家离 NPC 多远、NPC 之前有没有
     * 被枪声惊动，只要是他打死的，两条都会送到他面前。NPC 喊“谁在那!”的距离规则不受影响。</p>
     */
    public static void handleNpcDeath(LivingEntity npc, DamageSource source) {
        if (!(npc.level() instanceof ServerLevel level) || !AlertConfig.KILL_RADIO_ENABLED.get()) {
            return;
        }
        if (!isNpcType(npc) || source == null) {
            return;
        }
        Player player = resolveKiller(source);
        if (player == null) {
            return;
        }

        String playerName = player.getGameProfile().getName();
        Component first = Component.literal(playerName).withStyle(ChatFormatting.BLUE)
                .append(Component.literal(": " + AlertConfig.KILL_RADIO_FIRST_LINE.get())
                        .withStyle(ChatFormatting.WHITE));
        Component second = Component.literal(AlertConfig.KILL_RADIO_COMMAND_SPEAKER.get())
                .withStyle(ChatFormatting.GOLD)
                .append(Component.literal(": " + AlertConfig.KILL_RADIO_SECOND_LINE.get())
                        .withStyle(ChatFormatting.WHITE));

        Vec3 at = npc.position();
        UUID killerId = player.getUUID();
        broadcastKillRadio(level, at, killerId, first);
        DelayedTasks.schedule(level.getServer(), AlertConfig.KILL_RADIO_DELAY_TICKS.get(),
                server -> broadcastKillRadio(level, at, killerId, second));
    }

    /**
     * 找出“是谁打死的”。优先用伤害来源里的造成者；如果子弹/爆炸只带了一个弹体实体，
     * 就顺着弹体的主人往上找开枪的人。
     */
    private static Player resolveKiller(DamageSource source) {
        Entity causing = source.getEntity();
        if (causing instanceof Player player) {
            return player;
        }
        Entity direct = source.getDirectEntity();
        if (direct instanceof Projectile projectile && projectile.getOwner() instanceof Player owner) {
            return owner;
        }
        return null;
    }

    private static ChatFormatting parseColor(String name) {
        if (name != null) {
            ChatFormatting parsed = ChatFormatting.getByName(name);
            if (parsed != null && parsed.isColor()) {
                return parsed;
            }
        }
        return ChatFormatting.BLUE;
    }

    private static String pickLine(ServerLevel level) {
        List<? extends String> lines = AlertConfig.LINES.get();
        if (lines.isEmpty()) {
            return "...";
        }
        int index = level.getRandom().nextInt(lines.size());
        return lines.get(index);
    }

    private static SoundEvent resolveShoutSound() {
        ResourceLocation id = ResourceLocation.tryParse(AlertConfig.SHOUT_SOUND.get());
        if (id == null) {
            return null;
        }
        return ForgeRegistries.SOUND_EVENTS.getValue(id);
    }
}
