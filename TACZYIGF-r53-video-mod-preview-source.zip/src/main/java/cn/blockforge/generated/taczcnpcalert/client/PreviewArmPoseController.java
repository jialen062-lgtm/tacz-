package cn.blockforge.generated.taczcnpcalert.client;

/**
 * Controls the temporary arm pose used only while the inventory-style player preview is rendered.
 * ThreadLocal keeps the animation state isolated from normal world-player rendering.
 */
public final class PreviewArmPoseController {
    private static final ThreadLocal<Float> PROGRESS = ThreadLocal.withInitial(() -> 0.0F);

    private PreviewArmPoseController() { }

    public static void begin(float progress) {
        PROGRESS.set(Math.max(0.0F, Math.min(1.0F, progress)));
    }

    public static void end() {
        PROGRESS.remove();
    }

    public static float progress() {
        return PROGRESS.get();
    }
}
