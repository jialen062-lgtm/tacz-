package cn.blockforge.generated.taczcnpcalert.mixin;

import cn.blockforge.generated.taczcnpcalert.client.PreviewArmPoseController;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies a staged two-handed rifle presentation pose only during the GUI player preview render. */
@Mixin(PlayerModel.class)
public abstract class PlayerPreviewArmPoseMixin {

    @Inject(method = "setupAnim", at = @At("TAIL"), require = 1)
    private void taczyigf$applyPreviewWeaponPose(LivingEntity entity, float limbSwing, float limbSwingAmount,
                                                float ageInTicks, float netHeadYaw, float headPitch,
                                                CallbackInfo ci) {
        float progress = PreviewArmPoseController.progress();
        if (progress <= 0.001F) return;

        // The first phase raises the firing arm; the support arm follows slightly later.
        float firing = ease(Math.min(1.0F, progress / 0.72F));
        float support = ease(Math.max(0.0F, Math.min(1.0F, (progress - 0.16F) / 0.78F)));
        HumanoidModel<?> model = (HumanoidModel<?>) (Object) this;
        boolean rightHanded = entity.getMainArm() == HumanoidArm.RIGHT;

        // Vanilla model parts are the actual shoulder/arm bones used by the player renderer.
        // Negative X rotation brings the arms forward; Y/Z offsets create a natural two-hand hold.
        float firingArmX = lerp(0.18F, -1.18F, firing);
        float supportArmX = lerp(0.18F, -1.34F, support);
        float firingArmY = lerp(0.0F, rightHanded ? -0.22F : 0.22F, firing);
        float supportArmY = lerp(0.0F, rightHanded ? 0.42F : -0.42F, support);
        float firingArmZ = lerp(0.0F, rightHanded ? -0.10F : 0.10F, firing);
        float supportArmZ = lerp(0.0F, rightHanded ? 0.12F : -0.12F, support);

        if (rightHanded) {
            model.rightArm.xRot = firingArmX;
            model.rightArm.yRot = firingArmY;
            model.rightArm.zRot = firingArmZ;
            model.leftArm.xRot = supportArmX;
            model.leftArm.yRot = supportArmY;
            model.leftArm.zRot = supportArmZ;
        } else {
            model.leftArm.xRot = firingArmX;
            model.leftArm.yRot = firingArmY;
            model.leftArm.zRot = firingArmZ;
            model.rightArm.xRot = supportArmX;
            model.rightArm.yRot = supportArmY;
            model.rightArm.zRot = supportArmZ;
        }

        // Small torso/head follow-through makes the pose read as an intentional weapon presentation.
        model.body.yRot = lerp(model.body.yRot, rightHanded ? -0.055F : 0.055F, progress);
        model.head.yRot += (rightHanded ? -0.035F : 0.035F) * progress;
        model.head.xRot = lerp(model.head.xRot, model.head.xRot - 0.045F, progress);
    }

    private static float ease(float value) {
        float t = Math.max(0.0F, Math.min(1.0F, value));
        return t * t * (3.0F - 2.0F * t);
    }

    private static float lerp(float from, float to, float amount) {
        return from + (to - from) * amount;
    }
}
