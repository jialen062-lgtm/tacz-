package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.AlertConfig;
import cn.blockforge.generated.taczcnpcalert.MilitaryGearCatalog;
import cn.blockforge.generated.taczcnpcalert.LrtacticalCompat;
import cn.blockforge.generated.taczcnpcalert.PanelActionService;
import cn.blockforge.generated.taczcnpcalert.TaczCompat;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;
import com.mojang.math.Axis;
import com.mojang.blaze3d.vertex.PoseStack;
import org.joml.Vector3f;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 军需官 NPC 的配装面板。
 *
 * <p>六个页签：装备、枪械、子弹、投掷物、近战、改造。领取操作由服务端执行；
 * “改造”页会先列出背包里的枪，选中之后列出可用配件槽位，再选择配件安装，
 * 已经安装配件的槽位可执行卸载。</p>
 *
 * <p>“装备”页的东西是服务端从军事装备模组里认出来的（默认 Fracture Point），
 * 列表太长，所以上面还有一排分类按钮：全部 / 头部 / 躯干 / 腿脚 / 其它。</p>
 *
 * <p>界面本身不发物品，所有操作都通过 {@link PanelActionPacket} 交给服务端执行。</p>
 */
public class PanelScreen extends Screen {

    private static final int PANEL_WIDTH = 640;
    private static final int PANEL_HEIGHT = 380;
    private static final int COLS = 6;
    private static final int ROWS = 3; // 18 items per page so the next page is reachable with large gun packs.
    private static final int CELL = 32;
    private static final int PER_PAGE = COLS * ROWS;
    /** 左侧物品清单的顶部偏移；中央预览和右侧属性区独立绘制。 */
    private static final int GRID_Y = 76;
    private static final String[] TAB_NAMES = {"装备", "枪械", "子弹", "投掷物", "近战", "改造"};
    /** 装备页的分类筛选按钮，第 0 个是“全部”。 */
    private static final String[] FILTER_NAMES = {"全部", "头部", "躯干", "腿脚", "其它"};

    private static final int STAGE_PICK_GUN = 0;
    private static final int STAGE_PICK_SLOT = 1;
    private static final int STAGE_PICK_ATTACHMENT = 2;
    /** “改造”页的页签下标（前面加了投掷物、近战两页，它挪到了最后）。 */
    private static final int TAB_MODIFY = 5;

    /** 网格里的一格。 */
    private record Entry(String action, String id, ItemStack stack, String label, int data) {
    }

    private final int npcId;
    private final List<String> equipmentIds;
    private final List<String> gunIds;
    private final List<String> ammoIds;
    private final List<String> meleeIds;
    private final List<String> throwableIds;
    /** 槽位名 → 可用配件 ID（服务端算好的）。 */
    private final java.util.Map<String, List<String>> attachments;
    private int left;
    private int top;
    /** Scale the complete panel to the available GUI viewport, including widgets and hitboxes. */
    private float uiScale = 1.0F;
    private int tab;
    private int page;
    private int equipFilter;
    private List<Entry> entries = List.of();
    private Entry selectedEntry;
    private int stage = STAGE_PICK_GUN;
    private int selectedGunSlot = -1;
    private String pickingSlot;
    private float previewYaw = 0.0F;
    private float previewPitch = 0.0F;
    private float previewZoom = 11.5F;
    private boolean rotatingPreview;
    /** 枪械展示动作进度：0 为自然站姿，1 为进入持枪展示构图。 */
    private float gunPoseProgress = 1.0F;
    private ItemStack cachedPreviewPivotStack = ItemStack.EMPTY;
    private PreviewPivot cachedPreviewPivot;

    private Button prevButton;
    private Button nextButton;
    private Button backButton;
    private Button ammoFilterButton;
    private Button savePresetButton;
    private Button presetHistoryButton;
    private Button rotatePlayerLeftButton;
    private Button rotatePlayerRightButton;
    private Button graphicsConfigButton;
    /** 人物预览旋转角度；按钮每次转 90°，拖动可细调。 */
    private float playerPreviewYaw = 0.0F;
    private float playerPreviewPitch = 0.0F;
    private boolean filterAmmoForHeldGun;
    private final List<Button> filterButtons = new ArrayList<>();
    private int tickCounter;
    private int gearAnimationTicks = -1;
    private int gearAnimationCategory = 0;
    /** 当前保持放大的装备大类；-1 表示未放大。 */
    private int gearZoomCategory = -1;
    private String panelNotice = "";
    private int panelNoticeTicks = 0;

    public PanelScreen(int npcId, List<String> equipmentIds, List<String> gunIds, List<String> ammoIds,
                       List<String> meleeIds, List<String> throwableIds,
                       java.util.Map<String, List<String>> attachments) {
        super(Component.literal("军需官 · 装备补给"));
        this.npcId = npcId;
        this.equipmentIds = equipmentIds;
        this.gunIds = gunIds;
        this.ammoIds = ammoIds;
        this.meleeIds = meleeIds;
        this.throwableIds = throwableIds;
        this.attachments = attachments;
    }

    // ---------------------------------------------------------------- 初始化

    @Override
    protected void init() {
        PreviewGraphicsConfig.load();
        this.uiScale = Math.min(1.0F, Math.min(this.width / (float) PANEL_WIDTH,
                this.height / (float) PANEL_HEIGHT));
        this.uiScale = Math.max(0.35F, this.uiScale);
        int logicalWidth = (int) (this.width / this.uiScale);
        int logicalHeight = (int) (this.height / this.uiScale);
        this.left = (logicalWidth - PANEL_WIDTH) / 2;
        this.top = (logicalHeight - PANEL_HEIGHT) / 2;
        this.tickCounter = 0;

        int tabWidth = (PANEL_WIDTH - 16) / TAB_NAMES.length;
        for (int index = 0; index < TAB_NAMES.length; index++) {
            final int target = index;
            this.addRenderableWidget(Button.builder(Component.literal(TAB_NAMES[index]), button -> switchTab(target))
                    .bounds(this.left + 8 + index * tabWidth, this.top + 20, tabWidth - 2, 18)
                    .build());
        }

        this.filterButtons.clear();
        for (int index = 0; index < FILTER_NAMES.length; index++) {
            final int target = index;
            this.filterButtons.add(this.addRenderableWidget(
                    Button.builder(Component.literal(FILTER_NAMES[index]), button -> switchFilter(target))
                            .bounds(this.left + 14 + index * 40, this.top + 43, 38, 14)
                            .build()));
        }

        this.ammoFilterButton = this.addRenderableWidget(Button.builder(
                        Component.literal("适配当前枪械：关"), button -> toggleAmmoFilter())
                .bounds(this.left + 14, this.top + 43, 112, 14)
                .build());

        this.prevButton = this.addRenderableWidget(Button.builder(Component.literal("<"), button -> flipPage(-1))
                .bounds(this.left + 8, this.top + PANEL_HEIGHT - 24, 24, 18)
                .build());
        this.nextButton = this.addRenderableWidget(Button.builder(Component.literal(">"), button -> flipPage(1))
                .bounds(this.left + PANEL_WIDTH - 32, this.top + PANEL_HEIGHT - 24, 24, 18)
                .build());
        this.savePresetButton = this.addRenderableWidget(Button.builder(Component.literal("保存当前枪械预设"), button -> {
                    if (this.selectedGunSlot >= 0) ModNetwork.sendToServer(new PanelActionPacket(
                            PanelActionService.ACTION_PRESET_SAVE, "", this.selectedGunSlot));
                }).bounds(this.left + 14, this.top + 43, 104, 14).build());
        this.presetHistoryButton = this.addRenderableWidget(Button.builder(Component.literal("历史预设"), button ->
                        ModNetwork.sendToServer(new PanelActionPacket(PanelActionService.ACTION_PRESET_LIST, "", 0)))
                .bounds(this.left + 122, this.top + 43, 76, 14).build());

        int previewCenterX = this.left + 331;
        this.rotatePlayerLeftButton = this.addRenderableWidget(Button.builder(
                        Component.literal("向左旋转"), button -> rotatePlayer(-1))
                .bounds(previewCenterX - 78, this.top + 348, 74, 18).build());
        this.rotatePlayerRightButton = this.addRenderableWidget(Button.builder(
                        Component.literal("向右旋转"), button -> rotatePlayer(1))
                .bounds(previewCenterX + 4, this.top + 348, 74, 18).build());

        this.graphicsConfigButton = this.addRenderableWidget(Button.builder(Component.literal("图形设置"),
                        button -> this.minecraft.setScreen(new PreviewGraphicsConfigScreen(this)))
                .bounds(this.left + PANEL_WIDTH - 82, this.top + 3, 74, 14).build());

        this.backButton = this.addRenderableWidget(Button.builder(Component.literal("返回"), button -> goBack())
                .bounds(this.left + PANEL_WIDTH / 2 - 24, this.top + PANEL_HEIGHT - 24, 48, 18)
                .build());

        rebuildEntries();
        updateButtons();
    }

    private void rotatePlayer(int direction) {
        if ((this.tab != 0 && this.tab != 1 && this.tab != TAB_MODIFY) || direction == 0) return;
        this.playerPreviewYaw = wrapDegrees(this.playerPreviewYaw + direction * 90.0F);
        // Force a fresh render state; the player's world rotation is never modified.
        this.tickCounter++;
    }

    /** 从图形设置页刷新人物预览：回到正面并重置预览旋转状态，不修改玩家实际朝向。 */
    public void refreshPlayerPosePreview() {
        this.playerPreviewYaw = 0.0F;
        this.playerPreviewPitch = 0.0F;
        this.previewYaw = 0.0F;
        this.previewPitch = 0.0F;
        this.rotatingPreview = false;
        this.gearAnimationTicks = -1;
        if (this.minecraft != null && this.minecraft.player != null) {
            this.minecraft.player.refreshDimensions();
        }
    }

    private void switchTab(int newTab) {
        this.tab = newTab;
        this.selectedEntry = null;
        this.gunPoseProgress = (newTab == 1 || newTab == TAB_MODIFY) ? 0.0F : 1.0F;
        this.gearZoomCategory = -1;
        this.gearAnimationTicks = -1;
        this.page = 0;
        this.stage = STAGE_PICK_GUN;
        this.selectedGunSlot = -1;
        this.pickingSlot = null;
        rebuildEntries();
        updateButtons();
    }

    private void switchFilter(int newFilter) {
        this.equipFilter = newFilter;
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    private void goBack() {
        if (this.tab != TAB_MODIFY) {
            return;
        }
        if (this.stage == STAGE_PICK_ATTACHMENT) {
            this.stage = STAGE_PICK_SLOT;
            this.pickingSlot = null;
        } else if (this.stage == STAGE_PICK_SLOT) {
            this.stage = STAGE_PICK_GUN;
            this.selectedGunSlot = -1;
        }
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    private void flipPage(int delta) {
        int pages = totalPages();
        if (pages <= 1) {
            return;
        }
        this.page = Math.floorMod(this.page + delta, pages);
        this.selectedEntry = null;
    }

    private int totalPages() {
        return Math.max(1, (this.entries.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private void updateButtons() {
        int pages = totalPages();
        if (this.prevButton != null) {
            this.prevButton.visible = true;
            this.prevButton.active = pages > 1;
        }
        if (this.nextButton != null) {
            this.nextButton.visible = true;
            this.nextButton.active = pages > 1;
        }
        if (this.rotatePlayerLeftButton != null) {
            this.rotatePlayerLeftButton.visible = this.tab == 0 || this.tab == 1 || this.tab == TAB_MODIFY;
            this.rotatePlayerLeftButton.active = this.tab == 0 || this.tab == 1 || this.tab == TAB_MODIFY;
        }
        if (this.rotatePlayerRightButton != null) {
            this.rotatePlayerRightButton.visible = this.tab == 0 || this.tab == 1 || this.tab == TAB_MODIFY;
            this.rotatePlayerRightButton.active = this.tab == 0 || this.tab == 1 || this.tab == TAB_MODIFY;
        }
        if (this.backButton != null) {
            this.backButton.visible = this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN;
        }
        for (Button button : this.filterButtons) {
            button.visible = this.tab == 0;
        }
        if (this.ammoFilterButton != null) {
            this.ammoFilterButton.visible = this.tab == 2;
            this.ammoFilterButton.setMessage(Component.literal(
                    this.filterAmmoForHeldGun ? "适配当前枪械：开" : "适配当前枪械：关"));
        }
        if (this.savePresetButton != null) {
            this.savePresetButton.visible = this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN;
            this.savePresetButton.active = this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN;
        }
        if (this.presetHistoryButton != null) {
            this.presetHistoryButton.visible = this.tab == TAB_MODIFY;
        }
    }

    private void toggleAmmoFilter() {
        this.filterAmmoForHeldGun = !this.filterAmmoForHeldGun;
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    // ---------------------------------------------------------------- 数据

    private void rebuildEntries() {
        List<Entry> list = new ArrayList<>();
        switch (this.tab) {
            case 0 -> buildEquipment(list);
            case 1 -> buildGuns(list);
            case 2 -> buildAmmo(list);
            case 3 -> buildThrowables(list);
            case 4 -> buildMelee(list);
            case TAB_MODIFY -> buildModify(list);
            default -> {
            }
        }
        this.entries = list;
        // 筛选/刷新后，若原选中物品已不在列表中，立即清掉旧预览，避免“错误物品”残留。
        if (this.selectedEntry != null && !this.entries.contains(this.selectedEntry)) {
            this.selectedEntry = null;
        }
        if (this.page >= totalPages()) {
            this.page = Math.max(0, totalPages() - 1);
        }
    }

    private void buildEquipment(List<Entry> list) {
        java.util.Set<ResourceLocation> added = new java.util.HashSet<>();
        for (String raw : this.equipmentIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null || !added.add(id)) {
                continue;
            }
            // 第 0 个筛选按钮是“全部”，后面的依次对应 头部 / 躯干 / 腿脚 / 其它。
            if (this.equipFilter > 0 && MilitaryGearCatalog.categoryOf(id) != this.equipFilter - 1) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item == null || item == net.minecraft.world.item.Items.AIR
                    || item instanceof net.minecraft.world.item.BlockItem) {
                continue;
            }
            ItemStack stack = new ItemStack(item);
            if (stack.isEmpty()) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_EQUIP, id.toString(), stack, null, 0));
        }
    }

    private void buildGuns(List<Entry> list) {
        for (String raw : this.gunIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildGun(id);
            if (!stack.isEmpty()) {
                list.add(new Entry(PanelActionService.ACTION_GUN, raw, stack, null, 0));
            }
        }
    }

    private boolean hasHeldGunForAmmoFilter() {
        Player player = this.minecraft == null ? null : this.minecraft.player;
        return player != null && TaczCompat.isGun(player.getMainHandItem());
    }

    private void buildAmmo(List<Entry> list) {
        int size = Math.min(AlertConfig.AMMO_STACK_SIZE.get(), 64);
        Player player = this.minecraft == null ? null : this.minecraft.player;
        ItemStack heldGun = player == null ? ItemStack.EMPTY : player.getMainHandItem();
        boolean applyGunFilter = this.filterAmmoForHeldGun && TaczCompat.isGun(heldGun);
        for (String raw : this.ammoIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildAmmo(id, size);
            if (stack.isEmpty()) {
                continue;
            }
            if (applyGunFilter && !TaczCompat.isAmmoOfGun(heldGun, stack)) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_AMMO, raw, stack, null, 0));
        }
    }

    /** 投掷物页：绿葡萄等外部扩展包自动识别出来的真实投掷物。 */
    private void buildThrowables(List<Entry> list) {
        for (String raw : this.throwableIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            ItemStack stack = item == null ? ItemStack.EMPTY : new ItemStack(item);
            if (stack.isEmpty()) {
                stack = LrtacticalCompat.buildThrowable(id);
            }
            if (!stack.isEmpty() && !isUnknownPlaceholder(raw, stack)) {
                list.add(new Entry(PanelActionService.ACTION_THROWABLE, raw, stack, null, 0));
            }
        }
    }

    /** 近战页：TaCZ 近战武器 + 扩展包识别出来的冷兵器。 */
    private void buildMelee(List<Entry> list) {
        for (String raw : this.meleeIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            // 先兼容逐件注册的扩展物品；lrtactical 和 TaCZ 则分别通过各自索引构造通用物品。
            Item item = ForgeRegistries.ITEMS.getValue(id);
            ItemStack stack = item == null ? ItemStack.EMPTY : new ItemStack(item);
            if (stack.isEmpty()) {
                stack = LrtacticalCompat.buildMelee(id);
            }
            if (stack.isEmpty()) {
                stack = TaczCompat.buildMelee(id);
            }
            if (!stack.isEmpty() && !isUnknownPlaceholder(raw, stack)) {
                list.add(new Entry(PanelActionService.ACTION_MELEE, raw, stack, null, 0));
            }
        }
    }

    private static boolean isUnknownPlaceholder(String rawId, ItemStack stack) {
        String id = rawId == null ? "" : rawId.toLowerCase(java.util.Locale.ROOT);
        for (String part : id.split("[:/_-]")) {
            if (part.equals("unknown") || part.equals("unk") || part.equals("placeholder")
                    || part.equals("missing") || part.equals("invalid") || part.equals("null")) {
                return true;
            }
        }
        String name = stack == null || stack.isEmpty() ? "" : stack.getHoverName().getString().trim();
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        return name.equals("未知") || name.equals("未知物品") || name.equals("未识别")
                || lower.equals("unknown") || lower.equals("unknown item")
                || lower.equals("missing item") || lower.equals("invalid item")
                || lower.equals("placeholder");
    }

    private void buildPlainItems(List<Entry> list, List<String> ids, String action) {
        for (String raw : ids) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item != null) {
                list.add(new Entry(action, raw, new ItemStack(item), null, 0));
            }
        }
    }

    private void buildModify(List<Entry> list) {
        Player player = this.minecraft == null ? null : this.minecraft.player;
        if (player == null || !TaczCompat.isAvailable()) {
            return;
        }
        if (this.stage == STAGE_PICK_GUN) {
            for (int slot = 0; slot < 36; slot++) {
                ItemStack stack = player.getInventory().getItem(slot);
                if (TaczCompat.isGun(stack)) {
                    list.add(new Entry("select_gun", "", stack, null, slot));
                }
            }
            return;
        }

        ItemStack gun = gunInSlot(player, this.selectedGunSlot);
        if (gun.isEmpty()) {
            this.stage = STAGE_PICK_GUN;
            return;
        }

        if (this.stage == STAGE_PICK_SLOT) {
            for (String slot : TaczCompat.SLOTS) {
                if (!TaczCompat.allowsSlot(gun, slot)) {
                    continue;
                }
                ResourceLocation installed = TaczCompat.installedAttachmentId(gun, slot);
                ItemStack icon = installed == null ? ItemStack.EMPTY : TaczCompat.buildAttachment(installed);
                String slotHint = installed == null ? "空槽位" : "已安装 · 点击可更换";
                list.add(new Entry("pick_slot", slot, icon,
                        PanelActionService.slotName(slot) + " · " + slotHint, 0));
            }
            return;
        }

        List<String> available = this.attachments.getOrDefault(this.pickingSlot, List.of());
        for (String raw : available) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildAttachment(id);
            if (stack.isEmpty()) {
                continue;
            }
            if (!TaczCompat.allowsSlot(gun, this.pickingSlot)) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_INSTALL, raw, stack, null, 0));
        }
    }

    private static ItemStack gunInSlot(Player player, int slot) {
        if (player == null || slot < 0 || slot >= player.getInventory().getContainerSize()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = player.getInventory().getItem(slot);
        return TaczCompat.isGun(stack) ? stack : ItemStack.EMPTY;
    }

    // ---------------------------------------------------------------- 渲染

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.pose().pushPose();
        graphics.pose().scale(this.uiScale, this.uiScale, 1.0F);
        mouseX = (int) (mouseX / this.uiScale);
        mouseY = (int) (mouseY / this.uiScale);

        int x0 = this.left;
        int y0 = this.top;
        graphics.fill(x0, y0, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, 0xF9000000);
        // 新版基准：纯黑底、白色文字、橙色选中强调。
        int border = 0xFF5A3518;
        graphics.fill(x0, y0, x0 + PANEL_WIDTH, y0 + 2, border);
        graphics.fill(x0, y0 + PANEL_HEIGHT - 2, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, border);
        graphics.fill(x0, y0, x0 + 2, y0 + PANEL_HEIGHT, border);
        graphics.fill(x0 + PANEL_WIDTH - 2, y0, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, border);

        // 三个内容区：左侧清单、中间 3D/物品预览、右侧属性。
        graphics.fill(x0 + 10, y0 + 62, x0 + 222, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 230, y0 + 62, x0 + 432, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 440, y0 + 62, x0 + PANEL_WIDTH - 10, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 226, y0 + 62, x0 + 228, y0 + PANEL_HEIGHT - 34, 0xFF34200F);
        graphics.fill(x0 + 436, y0 + 62, x0 + 438, y0 + PANEL_HEIGHT - 34, 0xFF34200F);

        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, x0 + PANEL_WIDTH / 2, y0 + 7, 0xFFF2F2F2);
        String listTitle = this.tab == TAB_MODIFY ? (this.stage == STAGE_PICK_GUN ? "选择待改装枪械" : this.stage == STAGE_PICK_SLOT ? "枪械配件槽位" : "选择替换配件")
                : this.tab == 1 ? "选择枪械" : "物资清单";
        graphics.drawString(this.font, listTitle, x0 + 18, y0 + 64, 0xFFD8D8D8, false);
        graphics.drawCenteredString(this.font, "人物展示", x0 + 331, y0 + 64, 0xFFD8D8D8);
        graphics.drawString(this.font, "枪械信息", x0 + 452, y0 + 64, 0xFFD8D8D8, false);

        if (this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN) {
            Player player = this.minecraft == null ? null : this.minecraft.player;
            ItemStack gun = gunInSlot(player, this.selectedGunSlot);
            String gunName = gun.isEmpty() ? "未选择枪械" : TaczCompat.displayName(gun);
            graphics.drawCenteredString(this.font, Component.literal(gunName).withStyle(ChatFormatting.GOLD),
                    x0 + 331, y0 + 84, 0xFFD700);
        }

        Entry hovered = renderGrid(graphics, mouseX, mouseY);
        Entry detailEntry = hovered != null ? hovered : this.selectedEntry;
        renderPreview(graphics, detailEntry, mouseX, mouseY);
        renderDetails(graphics, detailEntry);
        // 人物实体可能被放大；把旋转按钮最后绘制，确保始终可见、可点击。
        if (this.tab == 0 || this.tab == 1 || this.tab == TAB_MODIFY) {
            if (this.rotatePlayerLeftButton != null) this.rotatePlayerLeftButton.render(graphics, mouseX, mouseY, partialTick);
            if (this.rotatePlayerRightButton != null) this.rotatePlayerRightButton.render(graphics, mouseX, mouseY, partialTick);
        }

        String hint = buildHint(hovered);
        graphics.drawCenteredString(this.font, Component.literal(hint).withStyle(ChatFormatting.GRAY),
                x0 + PANEL_WIDTH / 2, y0 + PANEL_HEIGHT - 47, 0xFFB0B0B0);

        int pages = totalPages();
        graphics.drawString(this.font, "第 " + (this.page + 1) + " / " + pages + " 页（每页 18 件）",
                this.left + 48, y0 + PANEL_HEIGHT - 18, 0xFFCCCCCC);

        if (hovered != null) {
            if (!hovered.stack().isEmpty()) {
                graphics.renderTooltip(this.font, hovered.stack(), mouseX, mouseY);
            } else if (hovered.label() != null) {
                graphics.renderTooltip(this.font, Component.literal(hovered.label()), mouseX, mouseY);
            }
        }

        // 操作结果提示最后绘制，确保位于面板、物品提示和其它 UI 内容之上。
        if (this.panelNoticeTicks > 0 && !this.panelNotice.isBlank()) {
            // 操作/聊天提示固定在屏幕底部中央，位于物品栏（快捷栏）上方。
            // 使用逻辑屏幕尺寸，确保 UI 缩放后位置仍然正确。
            int logicalWidth = (int) (this.width / this.uiScale);
            int logicalHeight = (int) (this.height / this.uiScale);
            int noticeY = Math.max(4, logicalHeight - 52);
            int noticeWidth = Math.min(logicalWidth - 24, this.font.width(this.panelNotice) + 24);
            int noticeLeft = (logicalWidth - noticeWidth) / 2;
            graphics.fill(noticeLeft, noticeY, noticeLeft + noticeWidth, noticeY + 18, 0xF0000000);
            graphics.fill(noticeLeft, noticeY, noticeLeft + noticeWidth, noticeY + 1, 0xFFFFA34A);
            graphics.fill(noticeLeft, noticeY + 17, noticeLeft + noticeWidth, noticeY + 18, 0xFFFFA34A);
            int alpha = this.panelNoticeTicks > 10 ? 255 : Math.max(0, this.panelNoticeTicks * 25);
            int color = (alpha << 24) | 0x00FFFFFF;
            graphics.drawCenteredString(this.font, this.panelNotice, logicalWidth / 2, noticeY + 5, color);
        }
        graphics.pose().popPose();
    }

    /** 服务端确认装备成功后触发；0头部、1躯干、2腿脚、3其它。 */
    public void playGearEquipAnimation(int category) {
        int nextCategory = Math.max(0, Math.min(3, category));
        // 同一装备大类内换具体物品（例如不同头盔）不重新播放动画，也不缩回去。
        if (this.gearZoomCategory == nextCategory) {
            return;
        }
        this.gearZoomCategory = nextCategory;
        this.gearAnimationCategory = nextCategory;
        this.gearAnimationTicks = 0;
    }

    /** 在面板最上方显示服务端确认的获得/装备结果。 */
    public void showPanelNotice(String message) {
        this.panelNotice = message == null ? "" : message;
        this.panelNoticeTicks = 60;
    }

    /** 中央预览限制在中间展示窗内，放大时只裁切展示窗，不会覆盖按钮或面板边缘。 */
    private void renderPreview(GuiGraphics graphics, Entry entry, int mouseX, int mouseY) {
        // The panel is drawn under an extra uiScale PoseStack transform. Scissor coordinates
        // must be supplied in the actual GUI coordinate space, not the panel's logical space.
        // Neutralize the panel transform while pushing the scissor rectangle, and pre-scale
        // the rectangle exactly once. This prevents a half-width clip on narrow/mobile screens.
        float scale = Math.max(0.01F, this.uiScale);
        int x1 = Math.max(0, (int) Math.floor((this.left + 230) * scale));
        int y1 = Math.max(0, (int) Math.floor((this.top + 62) * scale));
        int x2 = Math.min(this.width, (int) Math.ceil((this.left + 432) * scale));
        int y2 = Math.min(this.height, (int) Math.ceil((this.top + PANEL_HEIGHT - 34) * scale));

        graphics.pose().pushPose();
        graphics.pose().scale(1.0F / scale, 1.0F / scale, 1.0F);
        graphics.enableScissor(x1, y1, x2, y2);
        graphics.pose().popPose();
        try {
            renderPreviewContents(graphics, entry, mouseX, mouseY);
        } finally {
            graphics.disableScissor();
        }
    }

    /** 中央预览：人物装备聚焦，或显示枪械/弹药/投掷物/近战 3D 模型。 */
    private void renderPreviewContents(GuiGraphics graphics, Entry entry, int mouseX, int mouseY) {
        int centerX = this.left + 331;
        int bottomY = this.top + 292;
        Player player = this.minecraft == null ? null : this.minecraft.player;
        ItemStack preview = entry == null ? ItemStack.EMPTY : entry.stack();

        // 枪械选择与改装页始终展示人物：人物手中的枪就是当前选中/正在改装的枪。
        if (this.tab == TAB_MODIFY) {
            if (this.stage == STAGE_PICK_GUN) {
                preview = entry != null && TaczCompat.isGun(entry.stack()) ? entry.stack() : ItemStack.EMPTY;
            } else {
                preview = gunInSlot(player, this.selectedGunSlot);
            }
        }

        boolean gunCharacterPage = this.tab == 1 || this.tab == TAB_MODIFY;
        boolean showPlayer = player != null && (this.tab == 0 || gunCharacterPage
                || (entry == null && this.tab != 3 && this.tab != 4));
        // 投掷物与近战仍显示独立物品模型；枪械改装页不再切回孤立枪械模型。
        // 改枪阶段展示独立的完整枪械模型，便于观察配件安装位置；
        // 选枪阶段仍保留人物预览和持枪动画。
        boolean itemOnlyPreview = this.tab == 3 || this.tab == 4
                || (this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN);
        if (itemOnlyPreview) showPlayer = false;

        if (showPlayer) {
            ItemStack originalHand = player.getItemInHand(InteractionHand.MAIN_HAND).copy();
            boolean replaceHand = gunCharacterPage && !preview.isEmpty();
            try {
                if (replaceHand) player.setItemInHand(InteractionHand.MAIN_HAND, preview.copy());
                // 玩家模型固定朝向，不再把实时鼠标坐标传入渲染器，避免人物随鼠标乱晃。
                float zoom = 1.0F;
                float focusShift = 0.0F;
                if (this.gearAnimationTicks >= 0 && this.tab == 0) {
                    float progress = Math.min(1.0F, this.gearAnimationTicks / (float) PreviewGraphicsConfig.gearZoomDurationTicks());
                    // 只放大约 45%，再把对应身体部位移到预览窗中心；裁切区域外不会溢出。
                    float amount = progress * progress * (3.0F - 2.0F * progress);
                    zoom += 0.45F * amount;
                    focusShift = switch (this.gearAnimationCategory) {
                        case 0 -> 44.0F * amount; // 头盔：头部/上半身
                        case 1 -> 4.0F * amount;  // 胸甲：躯干中央
                        case 2 -> legOrFootFocusShift(player, entry) * amount;
                        default -> 0.0F;
                    };
                }
                float playerScale = (float) PreviewGraphicsConfig.playerPreviewScale;
                boolean gunPreview = gunCharacterPage && !preview.isEmpty();
                float pose = gunPreview ? smoothStep(this.gunPoseProgress) : 0.0F;
                float gunZoom = gunPreview ? (1.0F + pose * 1.0F) : 1.0F;
                int entityScale = Math.max(20, Math.round(150.0F * playerScale * zoom * gunZoom));
                // 进入枪械展示时，从全身自然站姿平滑推进到上半身持枪构图。
                float upperBodyShift = gunPreview ? -100.0F * pose : 0.0F;
                int entityBottom = bottomY + Math.round(focusShift * zoom + upperBodyShift);
                graphics.pose().pushPose();
                graphics.pose().translate(centerX + PreviewGraphicsConfig.playerPreviewOffsetX,
                        entityBottom + PreviewGraphicsConfig.playerPreviewOffsetY,
                        PreviewGraphicsConfig.playerPreviewOffsetZ);
                // 在预览窗口中心旋转整个实体（包括手持枪械），不修改游戏内玩家朝向。
                float drawTurn = gunPreview ? (1.0F - pose) * -10.0F : 0.0F;
                float drawTilt = gunPreview ? (1.0F - pose) * 3.0F : 0.0F;
                graphics.pose().mulPose(Axis.YP.rotationDegrees(this.playerPreviewYaw + drawTurn));
                graphics.pose().mulPose(Axis.XP.rotationDegrees(this.playerPreviewPitch + drawTilt));
                graphics.pose().translate(-centerX, -entityBottom, 0.0D);
                float drawLookY = gunPreview ? (1.0F - pose) * -16.0F : 0.0F;
                PreviewArmPoseController.begin(gunPreview ? pose : 0.0F);
                try {
                    InventoryScreen.renderEntityInInventoryFollowsAngle(graphics, centerX,
                            entityBottom, entityScale, 0.0F, drawLookY + this.playerPreviewPitch, player);
                } finally {
                    PreviewArmPoseController.end();
                }
                graphics.pose().popPose();
            } finally {
                PreviewArmPoseController.end();
                if (replaceHand) {
                    player.setItemInHand(InteractionHand.MAIN_HAND, originalHand);
                }
            }
            return;
        }

        if (!preview.isEmpty()) {
            // Use the FIXED item transform and the normal 3D item renderer rather than
            // GuiGraphics' flat GUI icon transform. TaCZ's registered item model/BewLR
            // is therefore allowed to provide its actual model for guns and attachments.
            graphics.pose().pushPose();
            graphics.pose().translate(centerX, this.top + 174, 80.0F);
            // 从当前物品模型的真实顶点计算包围盒中心；不同枪械/配件的模型原点
            // 不一定在几何中心，不能再统一假设枢轴是 (0.5, 0.5, 0.5)。
            PreviewPivot pivot = calculatePreviewPivot(preview);
            graphics.pose().translate(pivot.x(), pivot.y(), pivot.z());
            graphics.pose().mulPose(Axis.YP.rotationDegrees(this.previewYaw));
            graphics.pose().mulPose(Axis.XP.rotationDegrees(this.previewPitch));
            double configuredScale;
            if (this.tab == 2) {
                configuredScale = PreviewGraphicsConfig.ammoPreviewScale;
            } else {
                // 投掷物、近战和其他非弹药模型共用“枪械及其他模型大小”设置。
                configuredScale = PreviewGraphicsConfig.gunPreviewScale;
            }
            float modelScale = (float) (configuredScale * (this.previewZoom / 11.5F));
            graphics.pose().scale(modelScale, modelScale, modelScale);
            graphics.pose().translate(-pivot.x(), -pivot.y(), -pivot.z());
            MultiBufferSource.BufferSource buffers = this.minecraft.renderBuffers().bufferSource();
            // TaCZ 的枪械模型可能包含带 alpha 的部件；预览时启用标准透明混合并关闭面剔除，
            // 避免部分材质面因渲染状态/背面剔除而看起来透明或消失。
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            try {
                this.minecraft.getItemRenderer().renderStatic(preview, ItemDisplayContext.FIXED,
                        15728880, OverlayTexture.NO_OVERLAY, graphics.pose(), buffers,
                        this.minecraft.level, 0);
                buffers.endBatch();
            } finally {
                RenderSystem.enableCull();
                RenderSystem.disableBlend();
                graphics.pose().popPose();
            }
            graphics.drawCenteredString(this.font, preview.getHoverName(), centerX,
                    this.top + 226, 0xFFF0F0F0);
            graphics.drawCenteredString(this.font, "3D 模型 · 拖动旋转 · 滚轮缩放", centerX,
                    this.top + 240, 0xFFB8B8B8);
        } else if (player != null && !itemOnlyPreview) {
            InventoryScreen.renderEntityInInventoryFollowsAngle(graphics, centerX, bottomY,
                    Math.round(150.0F * (float) PreviewGraphicsConfig.playerPreviewScale),
                    this.playerPreviewYaw, this.playerPreviewPitch, player);
        } else {
            graphics.drawCenteredString(this.font, "选择一件物品查看", centerX,
                    this.top + 190, 0xFF999999);
        }
    }


    /** 模型局部坐标中的旋转中心（Minecraft 物品模型坐标通常为 0..1）。 */
    private record PreviewPivot(float x, float y, float z) {
    }

    /**
     * 汇总 BakedModel 所有朝向及 unculled quads 的顶点，按真实几何包围盒取中心。
     * 某些 TaCZ 模型原点明显偏离几何中心，因此固定使用 0.5 会造成绕空处旋转。
     */
    private PreviewPivot calculatePreviewPivot(ItemStack stack) {
        if (stack == null || stack.isEmpty() || this.minecraft == null) {
            return new PreviewPivot(0.5F, 0.5F, 0.5F);
        }
        if (this.cachedPreviewPivot != null
                && ItemStack.isSameItemSameTags(this.cachedPreviewPivotStack, stack)) {
            return this.cachedPreviewPivot;
        }
        PreviewPivot result = calculatePreviewPivotUncached(stack);
        this.cachedPreviewPivotStack = stack.copy();
        this.cachedPreviewPivot = result;
        return result;
    }

    private PreviewPivot calculatePreviewPivotUncached(ItemStack stack) {
        // TaCZ 枪械走 Bedrock 自定义渲染器，不会把枪体顶点暴露在普通 BakedModel 中。
        // 优先读取 TaCZ 模型声明的中心，并应用与 FIXED 预览完全相同的 GunItemTransforms。
        PreviewPivot taczPivot = calculateTaCZGunPivot(stack);
        if (taczPivot != null) {
            return taczPivot;
        }
        try {
            BakedModel model = this.minecraft.getItemRenderer().getModel(
                    stack, this.minecraft.level, null, 0);
            // 先应用 FIXED 展示变换，再统计顶点；否则模型自带的平移/缩放会让枢轴偏移。
            PoseStack displayTransform = new PoseStack();
            BakedModel transformedModel = model.applyTransform(
                    ItemDisplayContext.FIXED, displayTransform, false);
            // 与 ItemRenderer.renderStatic 的标准坐标归一化顺序一致。
            displayTransform.translate(-0.5F, -0.5F, -0.5F);
            org.joml.Matrix4f displayMatrix = displayTransform.last().pose();
            float minX = Float.POSITIVE_INFINITY;
            float minY = Float.POSITIVE_INFINITY;
            float minZ = Float.POSITIVE_INFINITY;
            float maxX = Float.NEGATIVE_INFINITY;
            float maxY = Float.NEGATIVE_INFINITY;
            float maxZ = Float.NEGATIVE_INFINITY;
            boolean found = false;

            // null 表示 unculled quads；六个方向覆盖普通方块/物品模型的面。
            Direction[] directions = Direction.values();
            for (int face = -1; face < directions.length; face++) {
                Direction direction = face < 0 ? null : directions[face];
                List<BakedQuad> quads = transformedModel.getQuads(
                        null, direction, RandomSource.create(0x51A7L));
                for (BakedQuad quad : quads) {
                    int[] vertices = quad.getVertices();
                    // DefaultVertexFormat.BLOCK 每个顶点 8 个 int，前三个是 XYZ 浮点位。
                    for (int offset = 0; offset + 2 < vertices.length; offset += 8) {
                        Vector3f point = new Vector3f(
                                Float.intBitsToFloat(vertices[offset]),
                                Float.intBitsToFloat(vertices[offset + 1]),
                                Float.intBitsToFloat(vertices[offset + 2]));
                        displayMatrix.transformPosition(point);
                        float x = point.x();
                        float y = point.y();
                        float z = point.z();
                        if (!Float.isFinite(x) || !Float.isFinite(y) || !Float.isFinite(z)) {
                            continue;
                        }
                        minX = Math.min(minX, x);
                        minY = Math.min(minY, y);
                        minZ = Math.min(minZ, z);
                        maxX = Math.max(maxX, x);
                        maxY = Math.max(maxY, y);
                        maxZ = Math.max(maxZ, z);
                        found = true;
                    }
                }
            }
            if (!found) {
                return new PreviewPivot(0.5F, 0.5F, 0.5F);
            }
            return new PreviewPivot((minX + maxX) * 0.5F,
                    (minY + maxY) * 0.5F, (minZ + maxZ) * 0.5F);
        } catch (RuntimeException exception) {
            // 遇到第三方自定义模型异常时，预览仍可显示，只回退到标准物品中心。
            return new PreviewPivot(0.5F, 0.5F, 0.5F);
        }
    }

    /** 通过反射读取 TaCZ BedrockGunModel 的中心，避免本模组对 TaCZ 形成硬编译依赖。 */
    private PreviewPivot calculateTaCZGunPivot(ItemStack stack) {
        try {
            ClassLoader loader = stack.getItem().getClass().getClassLoader();
            Class<?> apiClass = Class.forName("com.tacz.guns.api.TimelessAPI", false, loader);
            Object optionalObject = apiClass.getMethod("getGunDisplay", ItemStack.class).invoke(null, stack);
            if (!(optionalObject instanceof java.util.Optional<?> optional) || optional.isEmpty()) {
                return null;
            }
            Object display = optional.get();
            Object model = display.getClass().getMethod("getGunModel").invoke(display);
            if (model == null) {
                return null;
            }
            Object transform = display.getClass().getMethod("getTransform").invoke(display);
            Object scale = transform.getClass().getMethod("getScale").invoke(transform);
            Object offset = model.getClass().getMethod("getOffset").invoke(model);
            if (offset == null || scale == null) {
                return null;
            }

            PoseStack fixedTransform = new PoseStack();
            BakedModel itemModel = this.minecraft.getItemRenderer().getModel(
                    stack, this.minecraft.level, null, 0);
            itemModel.applyTransform(ItemDisplayContext.FIXED, fixedTransform, false);
            // ItemRenderer 在调用自定义 BEWLR 前会把物品模型原点移到 (-0.5,-0.5,-0.5)。
            fixedTransform.translate(-0.5F, -0.5F, -0.5F);
            Class<?> transformsClass = Class.forName(
                    "com.tacz.guns.client.renderer.item.GunItemTransforms", false, loader);
            boolean applied = false;
            for (Method method : transformsClass.getMethods()) {
                Class<?>[] parameters = method.getParameterTypes();
                if (method.getName().equals("apply") && parameters.length == 4
                        && parameters[0] == ItemDisplayContext.class
                        && parameters[1].isInstance(scale)
                        && parameters[2].isInstance(model)
                        && parameters[3].isAssignableFrom(PoseStack.class)) {
                    method.invoke(null, ItemDisplayContext.FIXED, scale, model, fixedTransform);
                    applied = true;
                    break;
                }
            }
            if (!applied) {
                return null;
            }

            double x = ((Number) offset.getClass().getMethod("x").invoke(offset)).doubleValue();
            double y = ((Number) offset.getClass().getMethod("y").invoke(offset)).doubleValue();
            double z = ((Number) offset.getClass().getMethod("z").invoke(offset)).doubleValue();
            Vector3f center = new Vector3f((float) x, (float) y, (float) z);
            fixedTransform.last().pose().transformPosition(center);
            if (!Float.isFinite(center.x()) || !Float.isFinite(center.y()) || !Float.isFinite(center.z())) {
                return null;
            }
            return new PreviewPivot(center.x(), center.y(), center.z());
        } catch (ReflectiveOperationException | LinkageError | ClassCastException exception) {
            // 没有安装 TaCZ、版本 API 不同或模型数据未就绪时，继续使用通用 BakedModel 算法。
            return null;
        }
    }

    /** 腿脚大类进一步按实际装备槽位取景：裤子略偏下，鞋子对准下半身。 */
    private static float legOrFootFocusShift(Player player, Entry entry) {
        if (entry != null && !entry.stack().isEmpty()) {
            net.minecraft.world.entity.EquipmentSlot actual =
                    net.minecraft.world.item.Equipable.get(entry.stack()) == null ? null
                            : net.minecraft.world.item.Equipable.get(entry.stack()).getEquipmentSlot();
            if (actual == net.minecraft.world.entity.EquipmentSlot.FEET) {
                return -44.0F;
            }
            if (actual == net.minecraft.world.entity.EquipmentSlot.LEGS) {
                return -24.0F;
            }
        }
        return -24.0F;
    }

    /** 读取物品自身 tooltip，避免凭空编造伤害、口径或穿透等数值。 */
    private void renderDetails(GuiGraphics graphics, Entry entry) {
        int x = this.left + 452;
        int y = this.top + 88;
        if (entry == null) {
            graphics.drawString(this.font, "选择左侧物品以查看详细信息。", x, y, 0xFFAAAAAA, false);
            return;
        }
        if (!entry.stack().isEmpty()) {
            graphics.drawString(this.font, entry.stack().getHoverName(), x, y, 0xFFF0F0F0, false);
            y += 18;
            if (TaczCompat.isGun(entry.stack())) {
                for (String stat : TaczCompat.gunStats(entry.stack())) {
                    if (y > this.top + PANEL_HEIGHT - 54) break;
                    for (FormattedCharSequence wrapped : this.font.split(Component.literal(stat), 174)) {
                        if (y > this.top + PANEL_HEIGHT - 54) break;
                        graphics.drawString(this.font, wrapped, x, y, 0xFFB8B8B8, false);
                        y += 12;
                    }
                }
            } else {
                Player player = this.minecraft == null ? null : this.minecraft.player;
                List<Component> lines = entry.stack().getTooltipLines(player, TooltipFlag.Default.NORMAL);
                int shown = 0;
                for (Component line : lines) {
                    if (shown >= 18 || y > this.top + PANEL_HEIGHT - 54) {
                        break;
                    }
                    for (FormattedCharSequence wrapped : this.font.split(line, 174)) {
                        if (shown >= 18 || y > this.top + PANEL_HEIGHT - 54) {
                            break;
                        }
                        graphics.drawString(this.font, wrapped, x, y,
                                shown == 0 ? 0xFFDADADA : 0xFFB8B8B8, false);
                        y += 11;
                        shown++;
                    }
                }
            }
        } else if (entry.label() != null) {
            graphics.drawString(this.font, entry.label(), x, y, 0xFFF0F0F0, false);
        }
        if (entry.id() != null && !entry.id().isBlank()) {
            graphics.drawString(this.font, "ID: " + entry.id(), x, this.top + PANEL_HEIGHT - 52,
                    0x76685B, false);
        }
    }

    /** 画网格，返回鼠标指着的那一格（没有就返回 null）。 */
    private Entry renderGrid(GuiGraphics graphics, int mouseX, int mouseY) {
        if (this.tab == 1 || this.tab == TAB_MODIFY) {
            int listX = this.left + 14;
            int listY = this.top + GRID_Y;
            int rowHeight = 15;
            int listWidth = 204;
            int start = this.page * PER_PAGE;
            Entry hovered = null;
            for (int index = 0; index < PER_PAGE; index++) {
                int entryIndex = start + index;
                int x = listX;
                int y = listY + index * rowHeight;
                Entry current = entryIndex < this.entries.size() ? this.entries.get(entryIndex) : null;
                boolean over = current != null && mouseX >= x && mouseX < x + listWidth
                        && mouseY >= y && mouseY < y + rowHeight - 1;
                boolean selected = current != null && current.equals(this.selectedEntry);
                int fill = over ? 0xD06B431E : selected ? 0xB85A3517 : 0x80505050;
                graphics.fill(x, y, x + listWidth, y + rowHeight - 1, fill);
                if (selected || over) {
                    graphics.fill(x, y, x + 2, y + rowHeight - 1, 0xFFFF982E);
                    graphics.fill(x, y + rowHeight - 2, x + listWidth, y + rowHeight - 1, 0xFF8C511F);
                }
                if (current != null) {
                    if (!current.stack().isEmpty()) {
                        graphics.renderItem(current.stack(), x + 3, y + 1);
                        String name = current.stack().getHoverName().getString();
                        if (name.length() > 25) name = name.substring(0, 24) + "…";
                        graphics.drawString(this.font, name, x + 23, y + 3,
                                selected ? 0xFFFFC078 : 0xFFE5E5E5, false);
                    } else {
                        String name = current.label() == null ? current.id() : current.label();
                        if (name == null) name = "未知槽位";
                        if (name.length() > 30) name = name.substring(0, 29) + "…";
                        graphics.drawString(this.font, name, x + 6, y + 3,
                                selected ? 0xFFFFC078 : 0xFFE5E5E5, false);
                    }
                    if (over) hovered = current;
                }
            }
            return hovered;
        }
        int gridX = this.left + 16;
        int gridY = this.top + GRID_Y;
        int start = this.page * PER_PAGE;
        Entry hovered = null;

        for (int index = 0; index < PER_PAGE; index++) {
            int entryIndex = start + index;
            int column = index % COLS;
            int row = index / COLS;
            int x = gridX + column * CELL;
            int y = gridY + row * CELL;
            boolean over = mouseX >= x && mouseX < x + CELL - 2 && mouseY >= y && mouseY < y + CELL - 2;
            Entry current = entryIndex < this.entries.size() ? this.entries.get(entryIndex) : null;
            boolean selected = current != null && current.equals(this.selectedEntry);
            graphics.fill(x, y, x + CELL - 3, y + CELL - 3,
                    over ? 0xA06A503A : selected ? 0x90513D2D : 0x50352A20);

            if (entryIndex < this.entries.size()) {
                Entry entry = this.entries.get(entryIndex);
                if (!entry.stack().isEmpty()) {
                    graphics.renderItem(entry.stack(), x + 8, y + 7);
                } else if (entry.label() != null) {
                    String text = entry.label().length() > 3 ? entry.label().substring(0, 3) : entry.label();
                    graphics.drawCenteredString(this.font, Component.literal(text),
                            x + (CELL - 3) / 2, y + (CELL - 3) / 2 - 4, 0xFFF2F2F2);
                }
                if (over) {
                    hovered = entry;
                }
            }
        }
        return hovered;
    }

    private String buildHint(Entry hovered) {
        if (this.tab == TAB_MODIFY) {
            return switch (this.stage) {
                case STAGE_PICK_GUN -> this.entries.isEmpty() && !TaczCompat.isAvailable()
                        ? "没有检测到 TaCZ，改造功能不可用"
                        : "选一把背包里的枪来改装";
                case STAGE_PICK_SLOT -> "选择配件槽位；已安装配件也可直接替换";
                default -> "选择配件安装；位置由实际安装规则决定";
            };
        }
        if (this.entries.isEmpty()) {
            if (this.tab == 0) {
                return "没有可领取的装备（检查配置里的 military_namespaces）";
            }
            if (this.tab == 3) {
                return "没有检测到外部投掷物（请确认已安装绿葡萄战术攻防）";
            }
            if (this.tab == 4) {
                return "没有可领取的近战武器（检查 TaCZ / 近战扩展包，或配置 melee_namespaces）";
            }
            return switch (this.tab) {
                case 2 -> this.filterAmmoForHeldGun && this.hasHeldGunForAmmoFilter()
                        ? "这把枪没有匹配弹药；可关闭适配筛选查看全部"
                        : "没有可领取的子弹（检查 TaCZ 是否装了枪包）";
                default -> "没有可领取的枪械（检查 TaCZ 是否装了枪包）";
            };
        }
        if (hovered != null) {
            if (this.tab == 2) {
                return this.filterAmmoForHeldGun && this.hasHeldGunForAmmoFilter()
                        ? "已按手持枪械筛选适配弹药；左键领取，Shift+点击批量"
                        : this.filterAmmoForHeldGun
                                ? "手持 TaCZ 枪械后自动筛选适配弹药；当前显示全部弹药"
                                : "左键领一组子弹，可反复点（Shift+点击批量）";
            }
            if (this.tab == 3) {
                return "点击领取外部真实投掷物：" + itemName(hovered);
            }
            String name = itemName(hovered);
            return "点击领取：" + name;
        }
        return switch (this.tab) {
            case 0 -> "点装备领取，上面可以按部位筛选";
            case 1 -> "点击领取枪械，弹匣已装满";
            case 2 -> "点击领取子弹，数量随点随给";
            case 3 -> "点击领取绿葡萄等外部真实投掷物";
            case 4 -> "点击领取近战武器";
            default -> "改造枪械";
        };
    }

    private static String itemName(Entry hovered) {
        return hovered.stack().isEmpty() ? shortId(hovered.id()) : hovered.stack().getHoverName().getString();
    }

    private static String shortId(String id) {
        if (id == null || id.isBlank()) {
            return "";
        }
        int colon = id.indexOf(':');
        return colon >= 0 ? id.substring(colon + 1) : id;
    }

    // ---------------------------------------------------------------- 交互

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        mouseX /= this.uiScale;
        mouseY /= this.uiScale;
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        boolean overPreview = mouseX >= this.left + 230 && mouseX <= this.left + 432
                && mouseY >= this.top + 62 && mouseY <= this.top + PANEL_HEIGHT - 34
                && (this.tab == 1 || this.tab == TAB_MODIFY || (this.tab != 0 && this.tab != 3 && this.tab != 4))
                && !(this.tab == TAB_MODIFY && this.stage == STAGE_PICK_GUN && this.entries.isEmpty());
        // 左键或右键拖动预览区域，都用于旋转当前预览对象。
        if (button == 1 && overPreview) {
            this.rotatingPreview = true;
            return true;
        }
        if (button != 0) {
            return false;
        }
        if (overPreview) {
            this.rotatingPreview = true;
            return true;
        }
        Entry entry = entryAt(mouseX, mouseY);
        if (entry == null) {
            if (this.tab == 0) {
                this.gearZoomCategory = -1;
                this.gearAnimationTicks = -1;
                return true;
            }
            return false;
        }
        this.selectedEntry = entry;
        if (this.tab == 1 && TaczCompat.isGun(entry.stack())) this.gunPoseProgress = 0.0F;
        activate(entry);
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        mouseX /= this.uiScale;
        mouseY /= this.uiScale;
        dragX /= this.uiScale;
        dragY /= this.uiScale;
        if (this.rotatingPreview && (button == 0 || button == 1)) {
            // 选枪阶段拖动人物；改枪阶段拖动枪械本体，俯仰与水平旋转独立处理。
            if (this.tab == 1 || (this.tab == TAB_MODIFY && this.stage == STAGE_PICK_GUN)) {
                this.playerPreviewYaw = wrapDegrees(this.playerPreviewYaw + (float) dragX * 0.8F);
                this.playerPreviewPitch = Math.max(-85.0F, Math.min(85.0F,
                        this.playerPreviewPitch + (float) dragY * 0.8F));
            } else {
                this.previewYaw = wrapDegrees(this.previewYaw + (float) dragX * 0.8F);
                this.previewPitch = Math.max(-85.0F, Math.min(85.0F,
                        this.previewPitch + (float) dragY * 0.8F));
            }
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    private static float smoothStep(float value) {
        float t = Math.max(0.0F, Math.min(1.0F, value));
        return t * t * (3.0F - 2.0F * t);
    }

    private static float wrapDegrees(float angle) {
        angle %= 360.0F;
        if (angle >= 180.0F) angle -= 360.0F;
        if (angle < -180.0F) angle += 360.0F;
        return angle;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        mouseX /= this.uiScale;
        mouseY /= this.uiScale;
        if (this.rotatingPreview && (button == 0 || button == 1)) {
            this.rotatingPreview = false;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        mouseX /= this.uiScale;
        mouseY /= this.uiScale;
        int listBottom = (this.tab == 1 || this.tab == TAB_MODIFY)
                ? this.top + PANEL_HEIGHT - 34 : this.top + GRID_Y + ROWS * CELL;
        if (mouseX >= this.left + 8 && mouseX <= this.left + 220
                && mouseY >= this.top + GRID_Y && mouseY <= listBottom) {
            if (delta != 0 && totalPages() > 1) {
                flipPage(delta > 0 ? -1 : 1);
                return true;
            }
        }
        if (mouseX >= this.left + 230 && mouseX <= this.left + 432
                && mouseY >= this.top + 62 && mouseY <= this.top + PANEL_HEIGHT - 34
                && this.tab != 0 && !(this.tab == TAB_MODIFY && this.stage == STAGE_PICK_GUN)
                ) {
            this.previewZoom = Math.max(8.0F, Math.min(17.0F, this.previewZoom + (delta > 0 ? 0.65F : -0.65F)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    private Entry entryAt(double mouseX, double mouseY) {
        if (this.tab == 1 || this.tab == TAB_MODIFY) {
            int listX = this.left + 14;
            int listY = this.top + GRID_Y;
            int rowHeight = 15;
            int start = this.page * PER_PAGE;
            if (mouseX < listX || mouseX >= listX + 204 || mouseY < listY) return null;
            int row = (int) ((mouseY - listY) / rowHeight);
            if (row < 0 || row >= PER_PAGE || mouseY >= listY + PER_PAGE * rowHeight) return null;
            int index = start + row;
            return index >= 0 && index < this.entries.size() ? this.entries.get(index) : null;
        }
        int gridX = this.left + 16;
        int gridY = this.top + GRID_Y;
        int start = this.page * PER_PAGE;
        for (int index = 0; index < PER_PAGE; index++) {
            int entryIndex = start + index;
            if (entryIndex >= this.entries.size()) {
                continue;
            }
            int column = index % COLS;
            int row = index / COLS;
            int x = gridX + column * CELL;
            int y = gridY + row * CELL;
            if (mouseX >= x && mouseX < x + CELL - 2 && mouseY >= y && mouseY < y + CELL - 2) {
                return this.entries.get(entryIndex);
            }
        }
        return null;
    }

    private void activate(Entry entry) {
        switch (entry.action()) {
            case "select_gun" -> {
                this.selectedGunSlot = entry.data();
                this.gunPoseProgress = 0.0F;
                this.stage = STAGE_PICK_SLOT;
                this.page = 0;
                rebuildEntries();
                updateButtons();
            }
            case "pick_slot" -> {
                // 配件槽统一进入选择列表，不再提供“更改位置”模式。
                // 若槽位已有配件，后续安装操作会由服务端先卸下旧配件再安装新配件。
                this.pickingSlot = entry.id();
                this.stage = STAGE_PICK_ATTACHMENT;
                this.page = 0;
                rebuildEntries();
                updateButtons();
            }
            case PanelActionService.ACTION_INSTALL -> {
                ModNetwork.sendToServer(new PanelActionPacket(
                        PanelActionService.ACTION_INSTALL, entry.id(), this.selectedGunSlot));
                this.stage = STAGE_PICK_SLOT;
                this.pickingSlot = null;
                this.page = 0;
                rebuildEntries();
                updateButtons();
            }
            case PanelActionService.ACTION_AMMO -> {
                if (hasShiftDown()) {
                    ModNetwork.sendToServer(new PanelActionPacket(
                            PanelActionService.ACTION_AMMO_BULK, entry.id(), 0));
                } else {
                    ModNetwork.sendToServer(new PanelActionPacket(
                            PanelActionService.ACTION_AMMO, entry.id(), 0));
                }
            }
            default -> ModNetwork.sendToServer(new PanelActionPacket(entry.action(), entry.id(), 0));
        }
    }


    @Override
    public void tick() {
        this.tickCounter++;
        if (this.gunPoseProgress < 1.0F) this.gunPoseProgress = Math.min(1.0F, this.gunPoseProgress + 0.075F);
        if (this.panelNoticeTicks > 0) this.panelNoticeTicks--;
        if (this.gearAnimationTicks >= 0 && this.gearAnimationTicks < PreviewGraphicsConfig.gearZoomDurationTicks()) {
            this.gearAnimationTicks++;
        }
        // 改造页的数据来自玩家背包，隔几 tick 刷一下，免得刚装好的配件图标不更新。
        if ((this.tab == TAB_MODIFY || (this.tab == 2 && this.filterAmmoForHeldGun))
                && this.tickCounter % 10 == 0) {
            rebuildEntries();
            updateButtons();
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    public int npcId() {
        return npcId;
    }
}
