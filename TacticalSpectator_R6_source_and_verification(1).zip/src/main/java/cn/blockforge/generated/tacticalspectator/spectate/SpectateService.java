package cn.blockforge.generated.tacticalspectator.spectate;

import cn.blockforge.generated.tacticalspectator.ModItems;
import cn.blockforge.generated.tacticalspectator.net.ModNetwork;
import cn.blockforge.generated.tacticalspectator.net.packet.S2CSpectateModePacket;
import cn.blockforge.generated.tacticalspectator.region.Region;
import cn.blockforge.generated.tacticalspectator.region.RegionStore;
import cn.blockforge.generated.tacticalspectator.round.Participant;
import cn.blockforge.generated.tacticalspectator.round.Round;
import cn.blockforge.generated.tacticalspectator.round.RoundService;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetCameraPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 战术平板观战（服务端权威）。
 *
 * 为什么不再“只对客户端已跟踪的实体才切镜头”：
 *   原版 ClientboundSetCameraPacket 只有在客户端已经拥有该实体（并且加载了周围区块）时才生效。
 *   原实现因此把“目标是否已被跟踪”当成观战资格，远距离目标永远无法选中。
 *   现在的做法与原版旁观者一致：观战期间把观战者“本体”锚定到目标身边（旁观模式，不可被攻击、
 *   不拾取、不触发机关），客户端因此自然收到目标实体与周围区块；服务端在目标被跟踪（StartTracking）
 *   之后再下发镜头包，并在观战期间周期性重发镜头包自愈，避免“切换成功但画面停留在旧目标”。
 *   观战开始前保存观战者的原位置 / 维度 / 游戏模式，退出、断线、回合结束、服务器关闭时恢复；
 *   原点同时写进玩家持久数据，服务器崩溃后下次登录也会恢复。
 *
 * 资格校验始终在服务端：目标必须是同一回合名单里、在线、存活、仍在该区域范围内的玩家。
 */
public final class SpectateService {
    public static final String ORIGIN_KEY = "tactical_spectator_origin";

    private static final double FOLLOW_DISTANCE_SQR = 24.0 * 24.0;
    private static final int ASSERT_FAST_INTERVAL = 5;
    private static final int ASSERT_SLOW_INTERVAL = 20;
    /** 超过这个时间仍没等到 StartTracking，就当作已就绪，降为慢速重发（不据此切换目标，避免事件记录漂移造成误判） */
    private static final int ASSUME_READY_AFTER = 100;
    private static final int TOGGLE_COOLDOWN = 10;
    private static final int CYCLE_COOLDOWN = 3;

    private static final class Session {
        final long regionId;
        UUID target;
        boolean confirmed;
        boolean selfMoving;
        int extraAsserts;
        int selectedAt;
        int lastAssert;
        final ResourceKey<Level> originDim;
        final double ox;
        final double oy;
        final double oz;
        final float oyRot;
        final float oxRot;
        final GameType originMode;

        Session(long regionId, ServerPlayer p) {
            this.regionId = regionId;
            this.originDim = p.level().dimension();
            this.ox = p.getX();
            this.oy = p.getY();
            this.oz = p.getZ();
            this.oyRot = p.getYRot();
            this.oxRot = p.getXRot();
            this.originMode = p.gameMode.getGameModeForPlayer();
        }
    }

    private static final Map<UUID, Session> ACTIVE = new HashMap<>();
    /** 观战者 -> 已开始跟踪的玩家。只用来决定“何时下发镜头包”，不再作为观战资格 */
    private static final Map<UUID, Set<UUID>> TRACKED = new HashMap<>();
    private static final Map<UUID, Integer> LAST_TOGGLE = new HashMap<>();
    private static final Map<UUID, Integer> LAST_CYCLE = new HashMap<>();

    // ---------- 入口 ----------

    public static boolean isHoldingTablet(ServerPlayer player) {
        return player.getMainHandItem().is(ModItems.TACTICAL_TABLET.get())
                || player.getOffhandItem().is(ModItems.TACTICAL_TABLET.get());
    }

    /** 手持平板右键：未观战 -> 进入观战；观战中 -> 退出观战 */
    public static boolean toggle(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return false;
        }
        UUID id = player.getUUID();
        int now = server.getTickCount();
        Integer last = LAST_TOGGLE.get(id);
        if (last != null && now - last < TOGGLE_COOLDOWN) {
            return false;
        }
        LAST_TOGGLE.put(id, now);
        if (ACTIVE.containsKey(id)) {
            stopFor(player, "ts.spectate.stopped");
            return true;
        }
        if (!isHoldingTablet(player)) {
            tell(player, "ts.spectate.notholding");
            return false;
        }
        if (!player.isAlive() || player.isSpectator()) {
            tell(player, "ts.spectate.none");
            return false;
        }
        Round round = RoundService.firstRoundOf(id);
        Participant me = round == null ? null : round.get(id);
        if (me == null || me.alive) {
            tell(player, "ts.spectate.none");
            return false;
        }
        List<ServerPlayer> targets = targets(player, round);
        if (targets.isEmpty()) {
            tell(player, "ts.spectate.unavailable");
            return false;
        }
        Session session = new Session(round.regionId, player);
        ACTIVE.put(id, session);
        saveOrigin(player, session);
        player.setGameMode(GameType.SPECTATOR);
        if (!player.isSpectator()) {
            // 别的模组取消了游戏模式切换：不能让一个普通模式的本体跟着目标走，整体回滚
            ACTIVE.remove(id);
            clearOrigin(player);
            tell(player, "ts.spectate.unavailable");
            return false;
        }
        select(player, session, targets.get(ThreadLocalRandom.current().nextInt(targets.size())));
        RoundService.sync(server, round);
        return true;
    }

    /** A(-1) / D(+1)：按名单顺序循环切换 */
    public static void cycle(ServerPlayer player, int direction) {
        Session session = ACTIVE.get(player.getUUID());
        MinecraftServer server = player.getServer();
        if (session == null || server == null || direction == 0) {
            return;
        }
        int now = server.getTickCount();
        Integer last = LAST_CYCLE.get(player.getUUID());
        if (last != null && now - last < CYCLE_COOLDOWN) {
            return;
        }
        LAST_CYCLE.put(player.getUUID(), now);
        List<ServerPlayer> targets = targets(player, RoundService.byRegion(session.regionId));
        if (targets.isEmpty()) {
            stopFor(player, "ts.spectate.unavailable");
            return;
        }
        int current = indexOf(targets, session.target);
        int dir = Integer.signum(direction);
        int next = current < 0 ? (dir > 0 ? 0 : targets.size() - 1)
                : Math.floorMod(current + dir, targets.size());
        ServerPlayer target = targets.get(next);
        if (target.getUUID().equals(session.target)) {
            assertCamera(player, session, target);
            return;
        }
        select(player, session, target);
    }

    // ---------- 周期校验 ----------

    public static void validate(MinecraftServer server) {
        int now = server.getTickCount();
        for (Map.Entry<UUID, Session> entry : new ArrayList<>(ACTIVE.entrySet())) {
            UUID id = entry.getKey();
            Session session = entry.getValue();
            ServerPlayer viewer = server.getPlayerList().getPlayer(id);
            if (viewer == null) {
                ACTIVE.remove(id);
                TRACKED.remove(id);
                continue;
            }
            if (!viewer.isAlive()) {
                stopFor(viewer, null, false);
                continue;
            }
            if (!viewer.isSpectator()) {
                // 游戏模式被其他模组 / 指令改掉：视为外部终止，不再强行恢复位置
                stopFor(viewer, "ts.spectate.stopped", false);
                continue;
            }
            Round round = RoundService.byRegion(session.regionId);
            Participant me = round == null ? null : round.get(id);
            if (round == null || me == null || me.alive) {
                stopFor(viewer, "ts.spectate.ended");
                continue;
            }
            List<ServerPlayer> targets = targets(viewer, round);
            if (targets.isEmpty()) {
                stopFor(viewer, "ts.spectate.unavailable");
                continue;
            }
            ServerPlayer current = find(targets, session.target);
            if (current == null) {
                // 当前目标死亡 / 掉线 / 离开区域：自动切到名单里的下一位
                select(viewer, session, nextAfter(round, session.target, targets));
                continue;
            }
            if (viewer.level() != current.level() || viewer.distanceToSqr(current) > FOLLOW_DISTANCE_SQR) {
                follow(viewer, session, current);
                assertCamera(viewer, session, current);
            }
            int age = now - session.selectedAt;
            int sinceAssert = now - session.lastAssert;
            if (!session.confirmed) {
                if (age >= ASSUME_READY_AFTER) {
                    session.confirmed = true;
                } else if (sinceAssert >= ASSERT_FAST_INTERVAL) {
                    assertCamera(viewer, session, current);
                }
            } else if (session.extraAsserts > 0) {
                session.extraAsserts--;
                assertCamera(viewer, session, current);
            } else if (sinceAssert >= ASSERT_SLOW_INTERVAL) {
                assertCamera(viewer, session, current);
            }
        }
    }

    // ---------- 目标集合（服务端资格校验） ----------

    private static List<ServerPlayer> targets(ServerPlayer viewer, Round round) {
        List<ServerPlayer> result = new ArrayList<>();
        MinecraftServer server = viewer.getServer();
        if (round == null || server == null) {
            return result;
        }
        Participant me = round.get(viewer.getUUID());
        if (me == null || me.alive || !viewer.isAlive()) {
            return result;
        }
        Region region = RegionStore.get(server).byId(round.regionId);
        if (region == null) {
            return result;
        }
        for (Participant participant : round.orderedList()) {
            if (!participant.alive) {
                continue;
            }
            ServerPlayer target = server.getPlayerList().getPlayer(participant.uuid);
            if (target == null || target == viewer || !target.isAlive() || target.isSpectator()) {
                continue;
            }
            if (!region.contains(target.level().dimension().location(), target.blockPosition())) {
                continue;
            }
            result.add(target);
        }
        return result;
    }

    private static int indexOf(List<ServerPlayer> targets, UUID id) {
        for (int i = 0; i < targets.size(); i++) {
            if (targets.get(i).getUUID().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private static ServerPlayer find(List<ServerPlayer> targets, UUID id) {
        int index = indexOf(targets, id);
        return index < 0 ? null : targets.get(index);
    }

    /** 名单顺序里排在旧目标之后的第一个可观战玩家；旧目标不在名单里则从头开始 */
    private static ServerPlayer nextAfter(Round round, UUID oldTarget, List<ServerPlayer> targets) {
        List<Participant> order = round.orderedList();
        int start = -1;
        for (int i = 0; i < order.size(); i++) {
            if (order.get(i).uuid.equals(oldTarget)) {
                start = i;
                break;
            }
        }
        for (int step = 1; step <= order.size(); step++) {
            Participant p = order.get(Math.floorMod(start + step, order.size()));
            ServerPlayer candidate = find(targets, p.uuid);
            if (candidate != null) {
                return candidate;
            }
        }
        return targets.get(0);
    }

    // ---------- 镜头同步 ----------

    private static void select(ServerPlayer viewer, Session session, ServerPlayer target) {
        MinecraftServer server = viewer.getServer();
        if (server == null) {
            return;
        }
        session.target = target.getUUID();
        session.confirmed = false;
        session.extraAsserts = 0;
        session.selectedAt = server.getTickCount();
        follow(viewer, session, target);
        if (isTracked(viewer, target)) {
            confirm(viewer, session, target);
        }
        ModNetwork.sendTo(viewer, new S2CSpectateModePacket(true, session.regionId,
                target.getUUID(), target.getGameProfile().getName()));
    }

    /** 把观战者本体带到目标身边（跨维度也可以），并让服务端把镜头指向目标 */
    private static void follow(ServerPlayer viewer, Session session, ServerPlayer target) {
        session.selfMoving = true;
        try {
            ServerLevel level = target.serverLevel();
            if (viewer.serverLevel() != level || viewer.distanceToSqr(target) > FOLLOW_DISTANCE_SQR) {
                viewer.teleportTo(level, target.getX(), target.getY(), target.getZ(),
                        target.getYRot(), target.getXRot());
            }
            viewer.setCamera(target);
        } finally {
            session.selfMoving = false;
        }
    }

    private static void assertCamera(ServerPlayer viewer, Session session, ServerPlayer target) {
        viewer.connection.send(new ClientboundSetCameraPacket(target));
        MinecraftServer server = viewer.getServer();
        if (server != null) {
            session.lastAssert = server.getTickCount();
        }
    }

    private static void confirm(ServerPlayer viewer, Session session, ServerPlayer target) {
        assertCamera(viewer, session, target);
        session.confirmed = true;
        session.extraAsserts = 2;
    }

    private static boolean isTracked(ServerPlayer viewer, ServerPlayer target) {
        Set<UUID> set = TRACKED.get(viewer.getUUID());
        return set != null && set.contains(target.getUUID());
    }

    /** Forge StartTracking / StopTracking：客户端拿到目标实体之后才下发镜头包 */
    public static void onTracking(ServerPlayer viewer, ServerPlayer target, boolean start) {
        if (start) {
            TRACKED.computeIfAbsent(viewer.getUUID(), k -> new HashSet<>()).add(target.getUUID());
            Session session = ACTIVE.get(viewer.getUUID());
            if (session != null && target.getUUID().equals(session.target) && !session.confirmed) {
                confirm(viewer, session, target);
            }
        } else {
            Set<UUID> set = TRACKED.get(viewer.getUUID());
            if (set != null) {
                set.remove(target.getUUID());
            }
        }
    }

    // ---------- 结束 / 清理 ----------

    public static boolean isActive(ServerPlayer player) {
        return ACTIVE.containsKey(player.getUUID());
    }

    /** 观战者的本体正在被本模组自己移动（用来区分“我们传送的”与“外部传送的”维度切换） */
    public static boolean isSelfMoving(ServerPlayer player) {
        Session session = ACTIVE.get(player.getUUID());
        return session != null && session.selfMoving;
    }

    public static void stopFor(ServerPlayer player, String messageKey) {
        stopFor(player, messageKey, true);
    }

    /** 退出观战：恢复本人视角、游戏模式；restorePosition 为 true 时回到观战前的位置 */
    public static void stopFor(ServerPlayer player, String messageKey, boolean restorePosition) {
        Session session = ACTIVE.remove(player.getUUID());
        if (session == null) {
            return;
        }
        session.selfMoving = true;
        try {
            boolean ours = player.isSpectator();
            player.setCamera(player);
            if (restorePosition) {
                restoreOrigin(player, session.originDim, session.ox, session.oy, session.oz,
                        session.oyRot, session.oxRot);
            }
            if (ours && session.originMode != GameType.SPECTATOR) {
                player.setGameMode(session.originMode);
            }
        } finally {
            session.selfMoving = false;
        }
        clearOrigin(player);
        player.connection.send(new ClientboundSetCameraPacket(player));
        ModNetwork.sendTo(player, new S2CSpectateModePacket(false, 0L, null, ""));
        if (messageKey != null) {
            tell(player, messageKey);
        }
    }

    private static void restoreOrigin(ServerPlayer player, ResourceKey<Level> dim,
                                      double x, double y, double z, float yRot, float xRot) {
        MinecraftServer server = player.getServer();
        ServerLevel level = server == null ? null : server.getLevel(dim);
        if (level == null) {
            return;
        }
        player.teleportTo(level, x, y, z, yRot, xRot);
        player.fallDistance = 0.0F;
        player.setDeltaMovement(Vec3.ZERO);
    }

    /** 观战者自己死亡（例如被 /kill）：结束观战，游戏模式随复活恢复，不再传送 */
    public static void onViewerDeath(ServerPlayer player) {
        stopFor(player, null, false);
    }

    public static void onViewerRespawn(ServerPlayer player) {
        stopFor(player, null, false);
    }

    /** 外部（非本模组）造成的维度切换：观战者本体被别的模组传走了，观战随之结束 */
    public static void onDimensionChanged(ServerPlayer player) {
        if (isActive(player) && !isSelfMoving(player)) {
            stopFor(player, "ts.spectate.stopped", false);
        }
    }

    /** 下线：先恢复位置与游戏模式再保存玩家数据；名单身份保留 */
    public static void onLogout(ServerPlayer player) {
        UUID id = player.getUUID();
        stopFor(player, null, true);
        ACTIVE.remove(id);
        TRACKED.remove(id);
        TRACKED.values().forEach(targets -> targets.remove(id));
        LAST_TOGGLE.remove(id);
        LAST_CYCLE.remove(id);
    }

    /** 上线：若上次因崩溃等原因没能恢复原位置 / 游戏模式，这里补上；并重置客户端观战状态 */
    public static void onLogin(ServerPlayer player) {
        UUID id = player.getUUID();
        if (!ACTIVE.containsKey(id)) {
            CompoundTag data = player.getPersistentData();
            if (data.contains(ORIGIN_KEY, Tag.TAG_COMPOUND)) {
                restoreFromTag(player, data.getCompound(ORIGIN_KEY));
                data.remove(ORIGIN_KEY);
            }
        }
        ModNetwork.sendTo(player, new S2CSpectateModePacket(false, 0L, null, ""));
    }

    private static void restoreFromTag(ServerPlayer player, CompoundTag tag) {
        try {
            ResourceLocation loc = ResourceLocation.tryParse(tag.getString("dim"));
            if (loc != null) {
                restoreOrigin(player, ResourceKey.create(Registries.DIMENSION, loc),
                        tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"),
                        tag.getFloat("yRot"), tag.getFloat("xRot"));
            }
            GameType mode = GameType.byId(tag.getInt("mode"));
            if (player.isSpectator() && mode != GameType.SPECTATOR) {
                player.setGameMode(mode);
            }
        } catch (RuntimeException ignored) {
            // 原点数据损坏时放弃恢复，不影响登录
        }
    }

    private static void saveOrigin(ServerPlayer player, Session s) {
        CompoundTag tag = new CompoundTag();
        tag.putString("dim", s.originDim.location().toString());
        tag.putDouble("x", s.ox);
        tag.putDouble("y", s.oy);
        tag.putDouble("z", s.oz);
        tag.putFloat("yRot", s.oyRot);
        tag.putFloat("xRot", s.oxRot);
        tag.putInt("mode", s.originMode.getId());
        player.getPersistentData().put(ORIGIN_KEY, tag);
    }

    private static void clearOrigin(ServerPlayer player) {
        player.getPersistentData().remove(ORIGIN_KEY);
    }

    public static void onRoundEnd(MinecraftServer server, long regionId) {
        for (ServerPlayer spectator : spectatorsOf(server, regionId)) {
            stopFor(spectator, "ts.spectate.ended");
        }
    }

    public static List<ServerPlayer> spectatorsOf(MinecraftServer server, long regionId) {
        List<ServerPlayer> result = new ArrayList<>();
        ACTIVE.forEach((id, session) -> {
            if (session.regionId == regionId) {
                ServerPlayer spectator = server.getPlayerList().getPlayer(id);
                if (spectator != null) {
                    result.add(spectator);
                }
            }
        });
        return result;
    }

    /** 服务器关闭前：把所有观战者放回原位置 / 原游戏模式，避免以“锚定状态”保存玩家数据 */
    public static void stopAll(MinecraftServer server) {
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            if (ACTIVE.containsKey(p.getUUID())) {
                stopFor(p, null, true);
            }
        }
        clear();
    }

    public static void clear() {
        ACTIVE.clear();
        TRACKED.clear();
        LAST_TOGGLE.clear();
        LAST_CYCLE.clear();
    }

    private static void tell(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private SpectateService() {}
}
