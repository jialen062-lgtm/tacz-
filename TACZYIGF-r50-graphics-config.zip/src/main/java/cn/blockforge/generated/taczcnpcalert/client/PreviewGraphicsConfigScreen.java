package cn.blockforge.generated.taczcnpcalert.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/** 游戏内图形设置页：只提供枪械/弹药预览大小、装备放大速度和人物姿态刷新。 */
public final class PreviewGraphicsConfigScreen extends Screen {
    private final Screen parent;

    public PreviewGraphicsConfigScreen(Screen parent) {
        super(Component.literal("图形设置"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        PreviewGraphicsConfig.load();
        int center = this.width / 2;
        int top = Math.max(4, (this.height - 220) / 2);
        int sliderWidth = Math.min(280, this.width - 40);
        int sliderX = center - sliderWidth / 2;

        this.addRenderableWidget(new ValueSlider(sliderX, top + 34, sliderWidth, 20,
                "枪械 3D 预览模型大小", PreviewGraphicsConfig.gunPreviewScale, 5.0D, 30.0D,
                value -> PreviewGraphicsConfig.gunPreviewScale = value, value -> String.format(java.util.Locale.ROOT, "%.1f", value)));
        this.addRenderableWidget(new ValueSlider(sliderX, top + 74, sliderWidth, 20,
                "弹药 3D 预览模型大小", PreviewGraphicsConfig.ammoPreviewScale, 5.0D, 30.0D,
                value -> PreviewGraphicsConfig.ammoPreviewScale = value, value -> String.format(java.util.Locale.ROOT, "%.1f", value)));
        this.addRenderableWidget(new ValueSlider(sliderX, top + 114, sliderWidth, 20,
                "选中装备时的放大速度", PreviewGraphicsConfig.gearZoomSpeed, 0.25D, 3.0D,
                value -> PreviewGraphicsConfig.gearZoomSpeed = value, value -> String.format(java.util.Locale.ROOT, "%.2f 倍", value)));

        this.addRenderableWidget(Button.builder(Component.literal("刷新人物姿态"), button -> refreshPlayerPose())
                .bounds(center - 100, top + 154, 200, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("保存并返回"), button -> {
                    PreviewGraphicsConfig.save();
                    this.minecraft.setScreen(this.parent);
                }).bounds(center - 100, top + 184, 200, 20).build());
    }

    private void refreshPlayerPose() {
        if (this.parent instanceof PanelScreen panel) {
            panel.refreshPlayerPosePreview();
        } else if (this.minecraft != null && this.minecraft.player != null) {
            Player player = this.minecraft.player;
            player.refreshDimensions();
        }
    }

    @Override
    public void onClose() {
        PreviewGraphicsConfig.save();
        this.minecraft.setScreen(this.parent);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int panelWidth = Math.min(360, this.width - 20);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(4, (this.height - 220) / 2);
        int bottom = Math.min(this.height - 4, top + 220);
        graphics.fill(left, top, left + panelWidth, bottom, 0xF9000000);
        graphics.fill(left, top, left + panelWidth, top + 2, 0xFFFFA34A);
        graphics.fill(left, bottom - 2, left + panelWidth, bottom, 0xFFFFA34A);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, top + 13, 0xFFFFFFFF);
        graphics.drawCenteredString(this.font, "仅调整本模组的预览显示，不改变游戏内物品属性", this.width / 2,
                bottom - 15, 0xFFB8B8B8);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @FunctionalInterface
    private interface DoubleSetter { void set(double value); }
    @FunctionalInterface
    private interface ValueFormatter { String format(double value); }

    private static final class ValueSlider extends AbstractSliderButton {
        private final String label;
        private final double min;
        private final double max;
        private final DoubleSetter setter;
        private final ValueFormatter formatter;

        private ValueSlider(int x, int y, int width, int height, String label, double initial,
                            double min, double max, DoubleSetter setter, ValueFormatter formatter) {
            super(x, y, width, height, Component.empty(), (initial - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.formatter = formatter;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            double value = this.min + this.value * (this.max - this.min);
            this.setMessage(Component.literal(this.label + "：" + this.formatter.format(value)));
        }

        @Override
        protected void applyValue() {
            this.setter.set(this.min + this.value * (this.max - this.min));
        }
    }
}
