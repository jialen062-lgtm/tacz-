package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.AlertConfig;
import cn.blockforge.generated.taczcnpcalert.AttachmentMovementRules;
import cn.blockforge.generated.taczcnpcalert.AttachmentPositionData;
import cn.blockforge.generated.taczcnpcalert.MilitaryGearCatalog;
import cn.blockforge.generated.taczcnpcalert.LrtacticalCompat;
import cn.blockforge.generated.taczcnpcalert.PanelActionService;
import cn.blockforge.generated.taczcnpcalert.TaczCompat;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * 军需官 NPC 的配装面板。
 *
 * <p>六个页签：装备、枪械、子弹、投掷物、近战、改造。领取操作由服务端执行；
 * “改造”页会先列出背包里的枪，选中之后列出可用配件槽位，再选择配件安装，
 * 已经安装配件的槽位可执行卸载。</p>
 *
 * <p>“装备”页的东西是服务端从军事装备模组里认出来的（默认 Fracture Point），
 * 列表太长，所以上面还有一排分类按钮：全部 / 头部 / 躯干 / 腿脚 / 其它。</p>
 *
 * <p>界面本身不发物品，所有操作都通过 {@link PanelActionPacket} 交给服务端执行。</p>
 */
public class PanelScreen extends Screen {

    private static final int PANEL_WIDTH = 640;
    private static final int PANEL_HEIGHT = 380;
    private static final int COLS = 6;
    private static final int ROWS = 5;
    private static final int CELL = 32;
    private static final int PER_PAGE = COLS * ROWS;
    /** 左侧物品清单的顶部偏移；中央预览和右侧属性区独立绘制。 */
    private static final int GRID_Y = 76;
    private static final String[] TAB_NAMES = {"装备", "枪械", "子弹", "投掷物", "近战", "改造"};
    /** 装备页的分类筛选按钮，第 0 个是“全部”。 */
    private static final String[] FILTER_NAMES = {"全部", "头部", "躯干", "腿脚", "其它"};

    private static final int STAGE_PICK_GUN = 0;
    private static final int STAGE_PICK_SLOT = 1;
    private static final int STAGE_PICK_ATTACHMENT = 2;
    private static final int STAGE_EDIT_POSITION = 3;
    /** “改造”页的页签下标（前面加了投掷物、近战两页，它挪到了最后）。 */
    private static final int TAB_MODIFY = 5;

    /** 网格里的一格。 */
    private record Entry(String action, String id, ItemStack stack, String label, int data) {
    }

    private final int npcId;
    private final List<String> equipmentIds;
    private final List<String> gunIds;
    private final List<String> ammoIds;
    private final List<String> meleeIds;
    private final List<String> throwableIds;
    /** 槽位名 → 可用配件 ID（服务端算好的）。 */
    private final java.util.Map<String, List<String>> attachments;
    private int left;
    private int top;
    private int tab;
    private int page;
    private int equipFilter;
    private List<Entry> entries = List.of();
    private Entry selectedEntry;
    private int stage = STAGE_PICK_GUN;
    private int selectedGunSlot = -1;
    private String pickingSlot;
    private boolean draggingAttachmentOffset;
    private double dragStartMouseX;
    private double dragStartMouseY;
    private AttachmentPositionData.Offset dragStartOffset = new AttachmentPositionData.Offset(0, 0, 0);
    private AttachmentPositionData.Offset currentOffset = new AttachmentPositionData.Offset(0, 0, 0);

    private Button prevButton;
    private Button nextButton;
    private Button backButton;
    private Button ammoFilterButton;
    private boolean filterAmmoForHeldGun;
    private final List<Button> filterButtons = new ArrayList<>();
    private int tickCounter;

    public PanelScreen(int npcId, List<String> equipmentIds, List<String> gunIds, List<String> ammoIds,
                       List<String> meleeIds, List<String> throwableIds,
                       java.util.Map<String, List<String>> attachments) {
        super(Component.literal("军需官 · 装备补给"));
        this.npcId = npcId;
        this.equipmentIds = equipmentIds;
        this.gunIds = gunIds;
        this.ammoIds = ammoIds;
        this.meleeIds = meleeIds;
        this.throwableIds = throwableIds;
        this.attachments = attachments;
    }

    // ---------------------------------------------------------------- 初始化

    @Override
    protected void init() {
        this.left = (this.width - PANEL_WIDTH) / 2;
        this.top = (this.height - PANEL_HEIGHT) / 2;
        this.tickCounter = 0;

        int tabWidth = (PANEL_WIDTH - 16) / TAB_NAMES.length;
        for (int index = 0; index < TAB_NAMES.length; index++) {
            final int target = index;
            this.addRenderableWidget(Button.builder(Component.literal(TAB_NAMES[index]), button -> switchTab(target))
                    .bounds(this.left + 8 + index * tabWidth, this.top + 20, tabWidth - 2, 18)
                    .build());
        }

        this.filterButtons.clear();
        for (int index = 0; index < FILTER_NAMES.length; index++) {
            final int target = index;
            this.filterButtons.add(this.addRenderableWidget(
                    Button.builder(Component.literal(FILTER_NAMES[index]), button -> switchFilter(target))
                            .bounds(this.left + 14 + index * 40, this.top + 43, 38, 14)
                            .build()));
        }

        this.ammoFilterButton = this.addRenderableWidget(Button.builder(
                        Component.literal("适配当前枪械：关"), button -> toggleAmmoFilter())
                .bounds(this.left + 14, this.top + 43, 112, 14)
                .build());

        this.prevButton = this.addRenderableWidget(Button.builder(Component.literal("<"), button -> flipPage(-1))
                .bounds(this.left + 8, this.top + PANEL_HEIGHT - 24, 24, 18)
                .build());
        this.nextButton = this.addRenderableWidget(Button.builder(Component.literal(">"), button -> flipPage(1))
                .bounds(this.left + PANEL_WIDTH - 32, this.top + PANEL_HEIGHT - 24, 24, 18)
                .build());
        this.backButton = this.addRenderableWidget(Button.builder(Component.literal("返回"), button -> goBack())
                .bounds(this.left + PANEL_WIDTH / 2 - 24, this.top + PANEL_HEIGHT - 24, 48, 18)
                .build());

        rebuildEntries();
        updateButtons();
    }

    private void switchTab(int newTab) {
        this.tab = newTab;
        this.selectedEntry = null;
        this.page = 0;
        this.stage = STAGE_PICK_GUN;
        this.selectedGunSlot = -1;
        this.pickingSlot = null;
        rebuildEntries();
        updateButtons();
    }

    private void switchFilter(int newFilter) {
        this.equipFilter = newFilter;
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    private void goBack() {
        if (this.tab != TAB_MODIFY) {
            return;
        }
        if (this.stage == STAGE_EDIT_POSITION || this.stage == STAGE_PICK_ATTACHMENT) {
            this.stage = STAGE_PICK_SLOT;
            this.pickingSlot = null;
        } else if (this.stage == STAGE_PICK_SLOT) {
            this.stage = STAGE_PICK_GUN;
            this.selectedGunSlot = -1;
        }
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    private void flipPage(int delta) {
        int pages = totalPages();
        if (pages <= 1) {
            return;
        }
        this.page = Math.floorMod(this.page + delta, pages);
    }

    private int totalPages() {
        return Math.max(1, (this.entries.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private void updateButtons() {
        int pages = totalPages();
        if (this.prevButton != null) {
            this.prevButton.visible = pages > 1;
        }
        if (this.nextButton != null) {
            this.nextButton.visible = pages > 1;
        }
        if (this.backButton != null) {
            this.backButton.visible = this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN;
        }
        for (Button button : this.filterButtons) {
            button.visible = this.tab == 0;
        }
        if (this.ammoFilterButton != null) {
            this.ammoFilterButton.visible = this.tab == 2;
            this.ammoFilterButton.setMessage(Component.literal(
                    this.filterAmmoForHeldGun ? "适配当前枪械：开" : "适配当前枪械：关"));
        }
    }

    private void toggleAmmoFilter() {
        this.filterAmmoForHeldGun = !this.filterAmmoForHeldGun;
        this.selectedEntry = null;
        this.page = 0;
        rebuildEntries();
        updateButtons();
    }

    // ---------------------------------------------------------------- 数据

    private void rebuildEntries() {
        List<Entry> list = new ArrayList<>();
        switch (this.tab) {
            case 0 -> buildEquipment(list);
            case 1 -> buildGuns(list);
            case 2 -> buildAmmo(list);
            case 3 -> buildThrowables(list);
            case 4 -> buildMelee(list);
            case TAB_MODIFY -> buildModify(list);
            default -> {
            }
        }
        this.entries = list;
        if (this.page >= totalPages()) {
            this.page = Math.max(0, totalPages() - 1);
        }
    }

    private void buildEquipment(List<Entry> list) {
        for (String raw : this.equipmentIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            // 第 0 个筛选按钮是“全部”，后面的依次对应 头部 / 躯干 / 腿脚 / 其它。
            if (this.equipFilter > 0 && MilitaryGearCatalog.categoryOf(id) != this.equipFilter - 1) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item == null) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_EQUIP, id.toString(), new ItemStack(item), null, 0));
        }
    }

    private void buildGuns(List<Entry> list) {
        for (String raw : this.gunIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildGun(id);
            if (!stack.isEmpty()) {
                list.add(new Entry(PanelActionService.ACTION_GUN, raw, stack, null, 0));
            }
        }
    }

    private boolean hasHeldGunForAmmoFilter() {
        Player player = this.minecraft == null ? null : this.minecraft.player;
        return player != null && TaczCompat.isGun(player.getMainHandItem());
    }

    private void buildAmmo(List<Entry> list) {
        int size = Math.min(AlertConfig.AMMO_STACK_SIZE.get(), 64);
        Player player = this.minecraft == null ? null : this.minecraft.player;
        ItemStack heldGun = player == null ? ItemStack.EMPTY : player.getMainHandItem();
        boolean applyGunFilter = this.filterAmmoForHeldGun && TaczCompat.isGun(heldGun);
        for (String raw : this.ammoIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildAmmo(id, size);
            if (stack.isEmpty()) {
                continue;
            }
            if (applyGunFilter && !TaczCompat.isAmmoOfGun(heldGun, stack)) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_AMMO, raw, stack, null, 0));
        }
    }

    /** 投掷物页：绿葡萄等外部扩展包自动识别出来的真实投掷物。 */
    private void buildThrowables(List<Entry> list) {
        for (String raw : this.throwableIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            ItemStack stack = item == null ? ItemStack.EMPTY : new ItemStack(item);
            if (stack.isEmpty()) {
                stack = LrtacticalCompat.buildThrowable(id);
            }
            if (!stack.isEmpty()) {
                list.add(new Entry(PanelActionService.ACTION_THROWABLE, raw, stack, null, 0));
            }
        }
    }

    /** 近战页：TaCZ 近战武器 + 扩展包识别出来的冷兵器。 */
    private void buildMelee(List<Entry> list) {
        for (String raw : this.meleeIds) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            // 先兼容逐件注册的扩展物品；lrtactical 和 TaCZ 则分别通过各自索引构造通用物品。
            Item item = ForgeRegistries.ITEMS.getValue(id);
            ItemStack stack = item == null ? ItemStack.EMPTY : new ItemStack(item);
            if (stack.isEmpty()) {
                stack = LrtacticalCompat.buildMelee(id);
            }
            if (stack.isEmpty()) {
                stack = TaczCompat.buildMelee(id);
            }
            if (!stack.isEmpty()) {
                list.add(new Entry(PanelActionService.ACTION_MELEE, raw, stack, null, 0));
            }
        }
    }

    private void buildPlainItems(List<Entry> list, List<String> ids, String action) {
        for (String raw : ids) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            if (id == null) {
                continue;
            }
            Item item = ForgeRegistries.ITEMS.getValue(id);
            if (item != null) {
                list.add(new Entry(action, raw, new ItemStack(item), null, 0));
            }
        }
    }

    private void buildModify(List<Entry> list) {
        Player player = this.minecraft == null ? null : this.minecraft.player;
        if (player == null || !TaczCompat.isAvailable()) {
            return;
        }
        if (this.stage == STAGE_PICK_GUN) {
            for (int slot = 0; slot < 36; slot++) {
                ItemStack stack = player.getInventory().getItem(slot);
                if (TaczCompat.isGun(stack)) {
                    list.add(new Entry("select_gun", "", stack, null, slot));
                }
            }
            return;
        }

        ItemStack gun = gunInSlot(player, this.selectedGunSlot);
        if (gun.isEmpty()) {
            this.stage = STAGE_PICK_GUN;
            return;
        }

        if (this.stage == STAGE_EDIT_POSITION) {
            ResourceLocation installed = TaczCompat.installedAttachmentId(gun, this.pickingSlot);
            if (installed != null) {
                ItemStack attachment = TaczCompat.buildAttachment(installed);
                list.add(new Entry("editing_attachment", installed.toString(), attachment, "拖动中央枪械预览调整配件位置", 0));
            }
            return;
        }

        if (this.stage == STAGE_PICK_SLOT) {
            for (String slot : TaczCompat.SLOTS) {
                if (!TaczCompat.allowsSlot(gun, slot)) {
                    continue;
                }
                ResourceLocation installed = TaczCompat.installedAttachmentId(gun, slot);
                ItemStack icon = installed == null ? ItemStack.EMPTY : TaczCompat.buildAttachment(installed);
                String movementHint = installed == null ? "空槽位"
                        : switch (cn.blockforge.generated.taczcnpcalert.AttachmentMovementRules.classify(
                                slot, installed.toString())) {
                            case FIXED -> "固定位置";
                            case CONDITIONAL -> "握把：按型号判断";
                            case RAIL_DEPENDENT -> "导轨可移动范围尚未确认";
                            case UNKNOWN -> "位置规则未确认";
                        };
                list.add(new Entry("pick_slot", slot, icon,
                        PanelActionService.slotName(slot) + " · " + movementHint + " · 当前仅安装/卸载", 0));
            }
            return;
        }

        List<String> available = this.attachments.getOrDefault(this.pickingSlot, List.of());
        for (String raw : available) {
            ResourceLocation id = ResourceLocation.tryParse(raw);
            ItemStack stack = id == null ? ItemStack.EMPTY : TaczCompat.buildAttachment(id);
            if (stack.isEmpty()) {
                continue;
            }
            if (!TaczCompat.allowsSlot(gun, this.pickingSlot)) {
                continue;
            }
            list.add(new Entry(PanelActionService.ACTION_INSTALL, raw, stack, null, 0));
        }
    }

    private static ItemStack gunInSlot(Player player, int slot) {
        if (player == null || slot < 0 || slot >= player.getInventory().getContainerSize()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = player.getInventory().getItem(slot);
        return TaczCompat.isGun(stack) ? stack : ItemStack.EMPTY;
    }

    // ---------------------------------------------------------------- 渲染

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);

        int x0 = this.left;
        int y0 = this.top;
        graphics.fill(x0, y0, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, 0xF9000000);
        // 新版基准：纯黑底、白色文字、橙色选中强调。
        int border = 0xFF5A3518;
        graphics.fill(x0, y0, x0 + PANEL_WIDTH, y0 + 2, border);
        graphics.fill(x0, y0 + PANEL_HEIGHT - 2, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, border);
        graphics.fill(x0, y0, x0 + 2, y0 + PANEL_HEIGHT, border);
        graphics.fill(x0 + PANEL_WIDTH - 2, y0, x0 + PANEL_WIDTH, y0 + PANEL_HEIGHT, border);

        // 三个内容区：左侧清单、中间 3D/物品预览、右侧属性。
        graphics.fill(x0 + 10, y0 + 62, x0 + 222, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 230, y0 + 62, x0 + 432, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 440, y0 + 62, x0 + PANEL_WIDTH - 10, y0 + PANEL_HEIGHT - 34, 0xE8080808);
        graphics.fill(x0 + 226, y0 + 62, x0 + 228, y0 + PANEL_HEIGHT - 34, 0xFF34200F);
        graphics.fill(x0 + 436, y0 + 62, x0 + 438, y0 + PANEL_HEIGHT - 34, 0xFF34200F);

        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, x0 + PANEL_WIDTH / 2, y0 + 7, 0xFFF2F2F2);
        graphics.drawString(this.font, "物资清单", x0 + 18, y0 + 64, 0xFFD8D8D8, false);
        graphics.drawCenteredString(this.font, "展示", x0 + 331, y0 + 64, 0xFFD8D8D8);
        graphics.drawString(this.font, "物品信息", x0 + 452, y0 + 64, 0xFFD8D8D8, false);

        if (this.tab == TAB_MODIFY && this.stage != STAGE_PICK_GUN) {
            Player player = this.minecraft == null ? null : this.minecraft.player;
            ItemStack gun = gunInSlot(player, this.selectedGunSlot);
            String gunName = gun.isEmpty() ? "未选择枪械" : TaczCompat.displayName(gun);
            graphics.drawCenteredString(this.font, Component.literal(gunName).withStyle(ChatFormatting.GOLD),
                    x0 + 331, y0 + 84, 0xFFD700);
        }

        Entry hovered = renderGrid(graphics, mouseX, mouseY);
        Entry detailEntry = hovered != null ? hovered : this.selectedEntry;
        renderPreview(graphics, detailEntry, mouseX, mouseY);
        if (this.tab == TAB_MODIFY && this.stage == STAGE_EDIT_POSITION) {
            graphics.drawCenteredString(this.font, String.format(java.util.Locale.ROOT,
                    "X %.2f   Y %.2f   Z %.2f", this.currentOffset.x(), this.currentOffset.y(), this.currentOffset.z()),
                    x0 + 331, y0 + PANEL_HEIGHT - 36, 0xFFFFA34A);
        }
        renderDetails(graphics, detailEntry);

        String hint = buildHint(hovered);
        graphics.drawCenteredString(this.font, Component.literal(hint).withStyle(ChatFormatting.GRAY),
                x0 + PANEL_WIDTH / 2, y0 + PANEL_HEIGHT - 47, 0xFFB0B0B0);

        int pages = totalPages();
        if (pages > 1) {
            graphics.drawString(this.font, "第 " + (this.page + 1) + " / " + pages + " 页",
                    this.left + 48, y0 + PANEL_HEIGHT - 18, 0xFFCCCCCC);
        }

        if (hovered != null) {
            if (!hovered.stack().isEmpty()) {
                graphics.renderTooltip(this.font, hovered.stack(), mouseX, mouseY);
            } else if (hovered.label() != null) {
                graphics.renderTooltip(this.font, Component.literal(hovered.label()), mouseX, mouseY);
            }
        }
    }

    /** 中央预览：装备页展示当前玩家皮肤模型，其它页展示当前选中物品。 */
    private void renderPreview(GuiGraphics graphics, Entry entry, int mouseX, int mouseY) {
        int centerX = this.left + 331;
        int bottomY = this.top + PANEL_HEIGHT - 56;
        Player player = this.minecraft == null ? null : this.minecraft.player;
        ItemStack preview = entry == null ? ItemStack.EMPTY : entry.stack();
        if (this.tab == TAB_MODIFY && this.stage == STAGE_EDIT_POSITION) {
            preview = gunInSlot(player, this.selectedGunSlot);
        }
        if (player != null && (this.tab == 0 || !preview.isEmpty())) {
            // 与 Locknar 展示一致：角色位于中央。武器页临时让预览角色手持所选物品，
            // 由 Minecraft/物品自身的客户端渲染器绘制；TaCZ 枪械会走它注册的自定义模型渲染器，
            // 投掷物和近战物品则走各自物品模型。finally 确保不会污染玩家真实背包。
            ItemStack originalHand = player.getItemInHand(InteractionHand.MAIN_HAND).copy();
            boolean replaceHand = this.tab != 0 && !preview.isEmpty();
            try {
                if (replaceHand) {
                    player.setItemInHand(InteractionHand.MAIN_HAND, preview.copy());
                }
                InventoryScreen.renderEntityInInventoryFollowsAngle(graphics, centerX, bottomY,
                        this.tab == 0 ? 112 : 132, 0.0F, 0.0F, player);
            } finally {
                if (replaceHand) {
                    player.setItemInHand(InteractionHand.MAIN_HAND, originalHand);
                }
            }
            if (this.tab != 0 && !preview.isEmpty()) {
                graphics.drawCenteredString(this.font, preview.getHoverName(), centerX,
                        this.top + PANEL_HEIGHT - 48, 0xFFF0F0F0);
            }
            return;
        }
        if (!preview.isEmpty()) {
            graphics.pose().pushPose();
            graphics.pose().translate(centerX - 32, this.top + 142, 0.0F);
            graphics.pose().scale(4.0F, 4.0F, 1.0F);
            graphics.renderItem(preview, 0, 0);
            graphics.pose().popPose();
            graphics.drawCenteredString(this.font, preview.getHoverName(), centerX,
                    this.top + 226, 0xFFF0F0F0);
        } else {
            graphics.drawCenteredString(this.font, "选择一件物品查看", centerX,
                    this.top + 190, 0xFF999999);
        }
    }

    /** 读取物品自身 tooltip，避免凭空编造伤害、口径或穿透等数值。 */
    private void renderDetails(GuiGraphics graphics, Entry entry) {
        int x = this.left + 452;
        int y = this.top + 88;
        if (entry == null) {
            graphics.drawString(this.font, "选择左侧物品以查看详细信息。", x, y, 0xFFAAAAAA, false);
            return;
        }
        if (!entry.stack().isEmpty()) {
            graphics.drawString(this.font, entry.stack().getHoverName(), x, y, 0xFFF0F0F0, false);
            y += 18;
            Player player = this.minecraft == null ? null : this.minecraft.player;
            List<Component> lines = entry.stack().getTooltipLines(player, TooltipFlag.Default.NORMAL);
            int shown = 0;
            for (Component line : lines) {
                if (shown >= 18 || y > this.top + PANEL_HEIGHT - 54) {
                    break;
                }
                for (FormattedCharSequence wrapped : this.font.split(line, 174)) {
                    if (shown >= 18 || y > this.top + PANEL_HEIGHT - 54) {
                        break;
                    }
                    graphics.drawString(this.font, wrapped, x, y, shown == 0 ? 0xFFDADADA : 0xFFB8B8B8, false);
                    y += 11;
                    shown++;
                }
            }
        } else if (entry.label() != null) {
            graphics.drawString(this.font, entry.label(), x, y, 0xFFF0F0F0, false);
        }
        if (entry.id() != null && !entry.id().isBlank()) {
            graphics.drawString(this.font, "ID: " + entry.id(), x, this.top + PANEL_HEIGHT - 52,
                    0x76685B, false);
        }
    }

    /** 画网格，返回鼠标指着的那一格（没有就返回 null）。 */
    private Entry renderGrid(GuiGraphics graphics, int mouseX, int mouseY) {
        int gridX = this.left + 16;
        int gridY = this.top + GRID_Y;
        int start = this.page * PER_PAGE;
        Entry hovered = null;

        for (int index = 0; index < PER_PAGE; index++) {
            int entryIndex = start + index;
            int column = index % COLS;
            int row = index / COLS;
            int x = gridX + column * CELL;
            int y = gridY + row * CELL;
            boolean over = mouseX >= x && mouseX < x + CELL - 2 && mouseY >= y && mouseY < y + CELL - 2;
            Entry current = entryIndex < this.entries.size() ? this.entries.get(entryIndex) : null;
            boolean selected = current != null && current.equals(this.selectedEntry);
            graphics.fill(x, y, x + CELL - 3, y + CELL - 3,
                    over ? 0xA06A503A : selected ? 0x90513D2D : 0x50352A20);

            if (entryIndex < this.entries.size()) {
                Entry entry = this.entries.get(entryIndex);
                if (!entry.stack().isEmpty()) {
                    graphics.renderItem(entry.stack(), x + 8, y + 7);
                } else if (entry.label() != null) {
                    String text = entry.label().length() > 3 ? entry.label().substring(0, 3) : entry.label();
                    graphics.drawCenteredString(this.font, Component.literal(text),
                            x + (CELL - 3) / 2, y + (CELL - 3) / 2 - 4, 0xFFF2F2F2);
                }
                if (over) {
                    hovered = entry;
                }
            }
        }
        return hovered;
    }

    private String buildHint(Entry hovered) {
        if (this.tab == TAB_MODIFY) {
            return switch (this.stage) {
                case STAGE_PICK_GUN -> this.entries.isEmpty() && !TaczCompat.isAvailable()
                        ? "没有检测到 TaCZ，改造功能不可用"
                        : "选一把背包里的枪来改装";
                case STAGE_PICK_SLOT -> "选择槽位；可移动配件会进入位置编辑";
                case STAGE_EDIT_POSITION -> "在中央枪械预览上拖动：左右调整 X，上下调整 Y；滚轮调整 Z";
                default -> "选择配件安装；位置由实际安装规则决定";
            };
        }
        if (this.entries.isEmpty()) {
            if (this.tab == 0) {
                return "没有可领取的装备（检查配置里的 military_namespaces）";
            }
            if (this.tab == 3) {
                return "没有检测到外部投掷物（请确认已安装绿葡萄战术攻防）";
            }
            if (this.tab == 4) {
                return "没有可领取的近战武器（检查 TaCZ / 近战扩展包，或配置 melee_namespaces）";
            }
            return switch (this.tab) {
                case 2 -> this.filterAmmoForHeldGun && this.hasHeldGunForAmmoFilter()
                        ? "这把枪没有匹配弹药；可关闭适配筛选查看全部"
                        : "没有可领取的子弹（检查 TaCZ 是否装了枪包）";
                default -> "没有可领取的枪械（检查 TaCZ 是否装了枪包）";
            };
        }
        if (hovered != null) {
            if (this.tab == 2) {
                return this.filterAmmoForHeldGun && this.hasHeldGunForAmmoFilter()
                        ? "已按手持枪械筛选适配弹药；左键领取，Shift+点击批量"
                        : this.filterAmmoForHeldGun
                                ? "手持 TaCZ 枪械后自动筛选适配弹药；当前显示全部弹药"
                                : "左键领一组子弹，可反复点（Shift+点击批量）";
            }
            if (this.tab == 3) {
                return "点击领取外部真实投掷物：" + itemName(hovered);
            }
            String name = itemName(hovered);
            return "点击领取：" + name;
        }
        return switch (this.tab) {
            case 0 -> "点装备领取，上面可以按部位筛选";
            case 1 -> "点击领取枪械，弹匣已装满";
            case 2 -> "点击领取子弹，数量随点随给";
            case 3 -> "点击领取绿葡萄等外部真实投掷物";
            case 4 -> "点击领取近战武器";
            default -> "改造枪械";
        };
    }

    private static String itemName(Entry hovered) {
        return hovered.stack().isEmpty() ? shortId(hovered.id()) : hovered.stack().getHoverName().getString();
    }

    private static String shortId(String id) {
        if (id == null || id.isBlank()) {
            return "";
        }
        int colon = id.indexOf(':');
        return colon >= 0 ? id.substring(colon + 1) : id;
    }

    // ---------------------------------------------------------------- 交互

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (button != 0) {
            return false;
        }
        Entry entry = entryAt(mouseX, mouseY);
        if (entry == null) {
            return false;
        }
        this.selectedEntry = entry;
        activate(entry);
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (this.tab == TAB_MODIFY && this.stage == STAGE_EDIT_POSITION && button == 0
                && mouseX >= this.left + 230 && mouseX <= this.left + 432
                && mouseY >= this.top + 62 && mouseY <= this.top + PANEL_HEIGHT - 34) {
            if (!this.draggingAttachmentOffset) {
                this.draggingAttachmentOffset = true;
                this.dragStartMouseX = mouseX;
                this.dragStartMouseY = mouseY;
                this.dragStartOffset = this.currentOffset;
            }
            double dx = (mouseX - this.dragStartMouseX) * 0.005D;
            double dy = (this.dragStartMouseY - mouseY) * 0.005D;
            this.currentOffset = new AttachmentPositionData.Offset(
                    this.dragStartOffset.x() + dx, this.dragStartOffset.y() + dy, this.currentOffset.z());
            applyClientPreviewOffset();
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.draggingAttachmentOffset && button == 0) {
            this.draggingAttachmentOffset = false;
            ResourceLocation installed = installedEditingAttachment();
            sendOffsetToServer();
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (this.tab == TAB_MODIFY && this.stage == STAGE_EDIT_POSITION
                && mouseX >= this.left + 230 && mouseX <= this.left + 432
                && mouseY >= this.top + 62 && mouseY <= this.top + PANEL_HEIGHT - 34) {
            this.currentOffset = new AttachmentPositionData.Offset(this.currentOffset.x(), this.currentOffset.y(),
                    this.currentOffset.z() + (delta > 0 ? 0.01D : -0.01D));
            applyClientPreviewOffset();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    private ResourceLocation installedEditingAttachment() {
        ItemStack gun = gunInSlot(this.minecraft == null ? null : this.minecraft.player, this.selectedGunSlot);
        return gun.isEmpty() || this.pickingSlot == null ? null
                : TaczCompat.installedAttachmentId(gun, this.pickingSlot);
    }


    private void sendOffsetToServer() {
        ResourceLocation installed = installedEditingAttachment();
        if (installed != null && this.pickingSlot != null) {
            ModNetwork.sendToServer(new PanelActionPacket(PanelActionService.ACTION_SET_ATTACHMENT_OFFSET,
                    installed.toString(), this.selectedGunSlot, -1,
                    this.currentOffset.x(), this.currentOffset.y(), this.currentOffset.z()));
        }
    }

    private void applyClientPreviewOffset() {
        ItemStack gun = gunInSlot(this.minecraft == null ? null : this.minecraft.player, this.selectedGunSlot);
        ResourceLocation installed = installedEditingAttachment();
        if (!gun.isEmpty() && installed != null && this.pickingSlot != null) {
            AttachmentPositionData.set(gun, this.pickingSlot, TaczCompat.buildAttachment(installed),
                    this.currentOffset.x(), this.currentOffset.y(), this.currentOffset.z());
        }
    }

    private Entry entryAt(double mouseX, double mouseY) {
        int gridX = this.left + 16;
        int gridY = this.top + GRID_Y;
        int start = this.page * PER_PAGE;
        for (int index = 0; index < PER_PAGE; index++) {
            int entryIndex = start + index;
            if (entryIndex >= this.entries.size()) {
                continue;
            }
            int column = index % COLS;
            int row = index / COLS;
            int x = gridX + column * CELL;
            int y = gridY + row * CELL;
            if (mouseX >= x && mouseX < x + CELL - 2 && mouseY >= y && mouseY < y + CELL - 2) {
                return this.entries.get(entryIndex);
            }
        }
        return null;
    }

    private void activate(Entry entry) {
        switch (entry.action()) {
            case "select_gun" -> {
                this.selectedGunSlot = entry.data();
                this.stage = STAGE_PICK_SLOT;
                this.page = 0;
                rebuildEntries();
                updateButtons();
            }
            case "pick_slot" -> {
                ItemStack selectedGun = gunInSlot(this.minecraft == null ? null : this.minecraft.player, this.selectedGunSlot);
                ResourceLocation installed = TaczCompat.installedAttachmentId(selectedGun, entry.id());
                if (installed != null) {
                    if (AttachmentMovementRules.canDrag(entry.id(), installed.toString(), true)) {
                        this.pickingSlot = entry.id();
                        this.currentOffset = AttachmentPositionData.get(selectedGun, entry.id(), TaczCompat.buildAttachment(installed));
                        this.stage = STAGE_EDIT_POSITION;
                        this.page = 0;
                        rebuildEntries();
                        updateButtons();
                    } else {
                        ModNetwork.sendToServer(new PanelActionPacket(
                                PanelActionService.ACTION_UNINSTALL, entry.id(), this.selectedGunSlot));
                    }
                } else {
                    this.pickingSlot = entry.id();
                    this.stage = STAGE_PICK_ATTACHMENT;
                    this.page = 0;
                    rebuildEntries();
                    updateButtons();
                }
            }
            case PanelActionService.ACTION_INSTALL -> {
                ModNetwork.sendToServer(new PanelActionPacket(
                        PanelActionService.ACTION_INSTALL, entry.id(), this.selectedGunSlot));
                this.stage = STAGE_PICK_SLOT;
                this.pickingSlot = null;
                this.page = 0;
                rebuildEntries();
                updateButtons();
            }
            case PanelActionService.ACTION_AMMO -> {
                if (hasShiftDown()) {
                    ModNetwork.sendToServer(new PanelActionPacket(
                            PanelActionService.ACTION_AMMO_BULK, entry.id(), 0));
                } else {
                    ModNetwork.sendToServer(new PanelActionPacket(
                            PanelActionService.ACTION_AMMO, entry.id(), 0));
                }
            }
            default -> ModNetwork.sendToServer(new PanelActionPacket(entry.action(), entry.id(), 0));
        }
    }


    @Override
    public void tick() {
        this.tickCounter++;
        // 改造页的数据来自玩家背包，隔几 tick 刷一下，免得刚装好的配件图标不更新。
        if ((this.tab == TAB_MODIFY || (this.tab == 2 && this.filterAmmoForHeldGun))
                && this.tickCounter % 10 == 0) {
            rebuildEntries();
            updateButtons();
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    public int npcId() {
        return npcId;
    }
}
