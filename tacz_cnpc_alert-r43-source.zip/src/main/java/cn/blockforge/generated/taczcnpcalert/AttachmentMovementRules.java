package cn.blockforge.generated.taczcnpcalert;

import java.util.Locale;
import java.util.Set;

/**
 * TACZYIGF 配件位置调整规则。
 *
 * <p>注意：TaCZ 原生槽位安装/卸载不等于模型位置编辑。此类只负责判定
 * 哪些配件在设计上允许进入“位置调整”流程；真正改变模型变换还需要
 * 对应枪械/配件提供可写的位置数据，不能仅靠拖动 UI 假装完成。</p>
 */
public final class AttachmentMovementRules {
    public enum Movement { FIXED, CONDITIONAL, RAIL_DEPENDENT, UNKNOWN }

    private static final Set<String> KNOWN_ADJUSTABLE_GRIP_TOKENS = Set.of(
            "vertical", "angled", "foregrip", "handstop", "bipod_grip"
    );

    private AttachmentMovementRules() {
    }

    /** 返回指定槽位/配件的现实逻辑分类。未知配件默认不开放拖动。 */
    public static Movement classify(String slot, String attachmentId) {
        String normalizedSlot = slot == null ? "" : slot.toUpperCase(Locale.ROOT);
        String id = attachmentId == null ? "" : attachmentId.toLowerCase(Locale.ROOT);
        return switch (normalizedSlot) {
            case "STOCK", "MUZZLE", "EXTENDED_MAG" -> Movement.FIXED;
            case "GRIP" -> containsAny(id, KNOWN_ADJUSTABLE_GRIP_TOKENS)
                    ? Movement.CONDITIONAL : Movement.FIXED;
            // 瞄具和激光器只有在枪械确实存在连续导轨/可调安装位时才可调整。
            case "SCOPE", "LASER" -> Movement.RAIL_DEPENDENT;
            // TaCZ 当前槽位表未描述具体安装接口，不能猜测可移动。
            default -> Movement.UNKNOWN;
        };
    }

    /** 只有已确认可调整且当前枪械提供位置编辑接口时才允许实际拖动。 */
    public static boolean canDrag(String slot, String attachmentId, boolean hasPositionEditor) {
        if (!hasPositionEditor) {
            return false;
        }
        Movement movement = classify(slot, attachmentId);
        // 导轨槽位存在不等于配件可沿导轨移动；尚未读取具体枪械导轨范围前不开放拖动。
        return movement == Movement.CONDITIONAL;
    }

    private static boolean containsAny(String value, Set<String> tokens) {
        for (String token : tokens) {
            if (value.contains(token)) {
                return true;
            }
        }
        return false;
    }
}
