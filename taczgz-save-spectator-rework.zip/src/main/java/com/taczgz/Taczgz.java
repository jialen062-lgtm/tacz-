package com.taczgz;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(Taczgz.MODID)
public class Taczgz {
    public static final String MODID = "taczgz";
    public static final Logger LOGGER = LogUtils.getLogger();
    public Taczgz() { NetworkHandler.register(); }
}
