package com.taczgz;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = Taczgz.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientHud {
    private static boolean confirmOpen = false;

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("spectator_info", (gui, pose, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null || !mc.player.isSpectator()) return;
            int buttonX = 8, buttonY = height - 29, buttonW = 104, buttonH = 20;
            gui.fill(buttonX, buttonY, buttonX + buttonW, buttonY + buttonH, 0xC0000000);
            gui.drawString(mc.font, Component.literal("取消观战"), buttonX + 8, buttonY + 6, 0xFFFFFF, true);
            var camera = mc.getCameraEntity();
            String target = camera == null || camera == mc.player ? "等待存活玩家" : camera.getName().getString();
            gui.drawString(mc.font, Component.literal("观战目标：" + target), 8, 8, 0xFFFFFF, true);
            if (confirmOpen) {
                int left = width / 2 - 100, top = height / 2 - 42;
                gui.fill(left, top, left + 200, top + 84, 0xE0000000);
                gui.drawCenteredString(mc.font, Component.literal("确定要取消观战并重生吗？"), width / 2, top + 12, 0xFFFFFF);
                gui.fill(width / 2 - 90, top + 42, width / 2 - 4, top + 66, 0xFF287A35);
                gui.fill(width / 2 + 4, top + 42, width / 2 + 90, top + 66, 0xFF555555);
                gui.drawCenteredString(mc.font, Component.literal("确认"), width / 2 - 47, top + 50, 0xFFFFFF);
                gui.drawCenteredString(mc.font, Component.literal("继续观战"), width / 2 + 47, top + 50, 0xFFFFFF);
            }
        });
    }

    @Mod.EventBusSubscriber(modid = Taczgz.MODID, value = Dist.CLIENT)
    public static class MouseHandler {
        @SubscribeEvent
        public static void click(InputEvent.MouseButton.Pre event) {
            if (event.getButton() != GLFW.GLFW_MOUSE_BUTTON_LEFT || event.getAction() != GLFW.GLFW_PRESS) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || !mc.player.isSpectator()) return;
            double scaleX = mc.getWindow().getGuiScaledWidth() / (double) mc.getWindow().getScreenWidth();
            double scaleY = mc.getWindow().getGuiScaledHeight() / (double) mc.getWindow().getScreenHeight();
            int x = (int) (mc.mouseHandler.xpos() * scaleX);
            int y = (int) (mc.mouseHandler.ypos() * scaleY);
            int width = mc.getWindow().getGuiScaledWidth(), height = mc.getWindow().getGuiScaledHeight();
            if (!confirmOpen && x >= 8 && x <= 112 && y >= height - 29 && y <= height - 9) {
                confirmOpen = true; event.setCanceled(true); return;
            }
            if (confirmOpen) {
                int left = width / 2 - 90, top = height / 2 + 0;
                if (x >= left && x <= left + 180 && y >= top && y <= top + 24) {
                    boolean confirm = x < width / 2;
                    confirmOpen = false;
                    if (confirm) NetworkHandler.CHANNEL.sendToServer(new SpectatorActionPacket(SpectatorActionPacket.CONFIRM_CANCEL));
                    event.setCanceled(true);
                }
            }
        }
    }
}
