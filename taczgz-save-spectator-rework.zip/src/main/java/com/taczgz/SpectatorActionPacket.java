package com.taczgz;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class SpectatorActionPacket {
    public static final int CONFIRM_CANCEL = 1;
    private final int action;
    public SpectatorActionPacket(int action) { this.action = action; }
    public static void encode(SpectatorActionPacket packet, FriendlyByteBuf buf) { buf.writeVarInt(packet.action); }
    public static SpectatorActionPacket decode(FriendlyByteBuf buf) { return new SpectatorActionPacket(buf.readVarInt()); }
    public static void handle(SpectatorActionPacket packet, Supplier<NetworkEvent.Context> context) {
        ServerPlayer player = context.get().getSender();
        if (player != null && packet.action == CONFIRM_CANCEL) SpectatorManager.cancelForPlayer(player);
        context.get().setPacketHandled(true);
    }
}
