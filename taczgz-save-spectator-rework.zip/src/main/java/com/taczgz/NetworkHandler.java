package com.taczgz;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class NetworkHandler {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Taczgz.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static int id = 0;
    private NetworkHandler() {}
    public static void register() {
        CHANNEL.messageBuilder(SpectatorActionPacket.class, id++)
                .encoder(SpectatorActionPacket::encode).decoder(SpectatorActionPacket::decode)
                .consumerMainThread(SpectatorActionPacket::handle).add();
    }
}
