package com.taczgz;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import java.util.*;

public final class SpectatorManager {
    private static final Set<UUID> waitingForRespawn = new HashSet<>();
    private static final Set<UUID> modSpectators = new HashSet<>();
    private static final Map<UUID, UUID> targets = new HashMap<>();
    private static final Map<UUID, GameType> previousModes = new HashMap<>();
    private SpectatorManager() {}

    public static void onDeath(ServerPlayer dead) {
        MinecraftServer server = dead.getServer();
        if (server == null) return;
        waitingForRespawn.add(dead.getUUID());
        server.execute(() -> {
            List<ServerPlayer> participants = server.getPlayerList().getPlayers();
            boolean anyoneAlive = participants.stream().anyMatch(p -> p != dead && p.isAlive()
                    && !modSpectators.contains(p.getUUID()) && p.gameMode.getGameModeForPlayer() != GameType.SPECTATOR);
            if (!anyoneAlive) {
                respawnEveryone(server);
            } else {
                // Ask the vanilla server to perform the normal respawn, then switch the player to spectator.
                dead.connection.handleClientCommand(new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.PERFORM_RESPAWN));
            }
        });
    }

    public static void onRespawn(ServerPlayer player) {
        if (!waitingForRespawn.remove(player.getUUID())) return;
        MinecraftServer server = player.getServer();
        if (server == null) return;
        previousModes.putIfAbsent(player.getUUID(), GameType.SURVIVAL);
        modSpectators.add(player.getUUID());
        player.setGameMode(GameType.SPECTATOR);
        chooseRandomTarget(player);
    }

    private static void respawnEveryone(MinecraftServer server) {
        for (ServerPlayer player : new ArrayList<>(server.getPlayerList().getPlayers())) {
            UUID id = player.getUUID();
            if (waitingForRespawn.contains(id)) {
                waitingForRespawn.remove(id);
                player.connection.handleClientCommand(new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.PERFORM_RESPAWN));
            }
            if (modSpectators.remove(id)) {
                targets.remove(id);
                player.setCamera(player);
                player.setGameMode(previousModes.getOrDefault(id, GameType.SURVIVAL));
                previousModes.remove(id);
                player.sendSystemMessage(Component.literal("所有参与玩家均已阵亡，已自动重生。").withStyle(ChatFormatting.GREEN));
            }
        }
    }

    private static List<ServerPlayer> alivePlayers(ServerPlayer viewer) {
        List<ServerPlayer> result = new ArrayList<>();
        for (ServerPlayer candidate : viewer.getServer().getPlayerList().getPlayers()) {
            if (!candidate.getUUID().equals(viewer.getUUID()) && candidate.isAlive()
                    && !modSpectators.contains(candidate.getUUID())
                    && candidate.gameMode.getGameModeForPlayer() != GameType.SPECTATOR) result.add(candidate);
        }
        result.sort(Comparator.comparing(p -> p.getUUID().toString()));
        return result;
    }

    private static void chooseRandomTarget(ServerPlayer viewer) {
        List<ServerPlayer> candidates = alivePlayers(viewer);
        if (candidates.isEmpty()) {
            targets.remove(viewer.getUUID());
            viewer.setCamera(viewer);
            return;
        }
        ServerPlayer target = candidates.get(viewer.getRandom().nextInt(candidates.size()));
        targets.put(viewer.getUUID(), target.getUUID());
        viewer.setCamera(target);
    }

    public static void tick(ServerPlayer viewer) {
        if (!modSpectators.contains(viewer.getUUID())) return;
        UUID current = targets.get(viewer.getUUID());
        boolean valid = current != null && alivePlayers(viewer).stream().anyMatch(p -> p.getUUID().equals(current));
        if (!valid) chooseRandomTarget(viewer);
    }

    public static String targetName(ServerPlayer viewer) {
        UUID id = targets.get(viewer.getUUID());
        if (id == null || viewer.getServer() == null) return "等待存活玩家";
        ServerPlayer target = viewer.getServer().getPlayerList().getPlayer(id);
        return target == null ? "等待存活玩家" : target.getGameProfile().getName();
    }

    public static boolean isModSpectator(UUID id) { return modSpectators.contains(id); }

    public static void cancelForPlayer(ServerPlayer player) {
        if (!modSpectators.remove(player.getUUID())) return;
        targets.remove(player.getUUID());
        waitingForRespawn.remove(player.getUUID());
        player.setCamera(player);
        player.setGameMode(previousModes.getOrDefault(player.getUUID(), GameType.SURVIVAL));
        previousModes.remove(player.getUUID());
        player.sendSystemMessage(Component.literal("已取消观战并重生。").withStyle(ChatFormatting.GREEN));
    }
}
