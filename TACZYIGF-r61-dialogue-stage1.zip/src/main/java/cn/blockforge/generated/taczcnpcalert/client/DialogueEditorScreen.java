package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.SaveDialogueEditorPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** NPC 对话脚本 UI 编辑器。以完整 JSON 编辑，旧脚本格式保持兼容。 */
public final class DialogueEditorScreen extends Screen {
    private final int npcId;
    private final String npcName;
    private final String initialJson;
    private EditBox jsonBox;
    public DialogueEditorScreen(int npcId, String npcName, String json) {
        super(Component.literal("对话编辑 · " + npcName)); this.npcId = npcId; this.npcName = npcName; this.initialJson = json == null || json.isBlank() ? "{\"nodes\":[{\"lines\":[],\"options\":[]}] }" : json;
    }
    @Override protected void init() {
        int w = Math.min(500, width - 30);
        jsonBox = new EditBox(font, (width-w)/2, height/2-35, w, 22, Component.literal("JSON"));
        jsonBox.setMaxLength(32767); jsonBox.setValue(initialJson); addRenderableWidget(jsonBox);
        addRenderableWidget(Button.builder(Component.literal("保存"), b -> {
            ModNetwork.sendToServer(new SaveDialogueEditorPacket(npcId, jsonBox.getValue())); onClose();
        }).bounds(width/2-105, height/2+12, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("退出"), b -> onClose())
                .bounds(width/2+5, height/2+12, 100, 20).build());
    }
    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g); g.drawCenteredString(font, "NPC 对话脚本编辑器", width/2, height/2-78, 0xFFFFFFFF);
        g.drawCenteredString(font, npcName + " · 编辑 JSON 脚本", width/2, height/2-58, 0xFFFFD34D);
        g.drawCenteredString(font, "保留 nodes / lines / options / target 数据结构", width/2, height/2-7, 0xFFBBBBBB);
        super.render(g,mx,my,pt);
    }
    @Override public boolean isPauseScreen() { return false; }
}
