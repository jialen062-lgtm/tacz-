package cn.blockforge.generated.taczcnpcalert.dialogue;

import cn.blockforge.generated.taczcnpcalert.AlertService;
import cn.blockforge.generated.taczcnpcalert.ModRegistry;
import cn.blockforge.generated.taczcnpcalert.net.DialogueWandInteractPacket;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;

/** NPC 对话入口：空手右键触发普通对话，持编辑魔杖右键打开编辑模式。 */
public final class DialogueWandEvents {
    private DialogueWandEvents() {}

    @net.minecraftforge.eventbus.api.SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        handle(event, event.getTarget());
    }

    @net.minecraftforge.eventbus.api.SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        handle(event, event.getTarget());
    }

    private static void handle(PlayerInteractEvent event, Entity target) {
        Player player = event.getEntity();
        if (!(target instanceof LivingEntity npc) || !AlertService.isNpcType(npc)) return;
        ItemStack held = event.getItemStack();
        boolean editing = held.is(ModRegistry.DIALOGUE_EDIT_WAND.get());
        boolean emptyHand = player.getMainHandItem().isEmpty() && player.getOffhandItem().isEmpty();
        if (!editing && !emptyHand) return;

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (player.level().isClientSide()) {
            if (editing) ModNetwork.sendToServer(new DialogueWandInteractPacket(target.getId(), true));
        } else if (player instanceof ServerPlayer serverPlayer) {
            use(serverPlayer, npc, editing);
        }
    }

    public static void use(ServerPlayer player, LivingEntity npc, boolean editing) {
        if (editing) {
            DialogueEditService.toggle(player, npc);
            return;
        }
        String json = DialogueStore.read(npc);
        if (DialogueStore.parse(json) == null) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "这个 NPC 还没有对话脚本。请使用对话编辑魔杖编写。")
                    .withStyle(net.minecraft.ChatFormatting.YELLOW), false);
            return;
        }
        ModNetwork.sendToPlayer(new cn.blockforge.generated.taczcnpcalert.net.OpenDialoguePacket(
                npc.getId(), npc.getName().getString(), json), player);
    }
}
