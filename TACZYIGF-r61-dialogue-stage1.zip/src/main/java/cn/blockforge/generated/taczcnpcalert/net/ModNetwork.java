package cn.blockforge.generated.taczcnpcalert.net;

import cn.blockforge.generated.taczcnpcalert.TaczCnpcAlertMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * 模组的网络通道。一共三个包，各管一件事：
 * <ul>
 *   <li>{@link WandInteractPacket}：拿着界面魔杖右键了 NPC（客户端 → 服务端）</li>
 *   <li>{@link MapWandInteractPacket}：拿着地图魔杖右键了 NPC（客户端 → 服务端）</li>
 *   <li>{@link OpenPanelPacket}：打开军需官面板（服务端 → 客户端）</li>
 *   <li>{@link OpenDungeonPanelPacket}：打开警长副本面板（服务端 → 客户端）</li>
 *   <li>{@link PanelActionPacket}：在面板里点了领取/改造/选择副本（客户端 → 服务端）</li>
 * </ul>
 */
public final class ModNetwork {

    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ResourceLocation.fromNamespaceAndPath(TaczCnpcAlertMod.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(WandInteractPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(WandInteractPacket::encode)
                .decoder(WandInteractPacket::decode)
                .consumerMainThread(WandInteractPacket::handle)
                .add();

        CHANNEL.messageBuilder(MapWandInteractPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(MapWandInteractPacket::encode)
                .decoder(MapWandInteractPacket::decode)
                .consumerMainThread(MapWandInteractPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenPanelPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenPanelPacket::encode)
                .decoder(OpenPanelPacket::decode)
                .consumerMainThread(OpenPanelPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDungeonPanelPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDungeonPanelPacket::encode)
                .decoder(OpenDungeonPanelPacket::decode)
                .consumerMainThread(OpenDungeonPanelPacket::handle)
                .add();

        CHANNEL.messageBuilder(PanelActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(PanelActionPacket::encode)
                .decoder(PanelActionPacket::decode)
                .consumerMainThread(PanelActionPacket::handle)
                .add();

        CHANNEL.messageBuilder(DialogueWandInteractPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(DialogueWandInteractPacket::encode)
                .decoder(DialogueWandInteractPacket::decode)
                .consumerMainThread(DialogueWandInteractPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDialoguePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDialoguePacket::encode)
                .decoder(OpenDialoguePacket::decode)
                .consumerMainThread(OpenDialoguePacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenDialogueEditorPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenDialogueEditorPacket::encode)
                .decoder(OpenDialogueEditorPacket::decode)
                .consumerMainThread(OpenDialogueEditorPacket::handle)
                .add();

        CHANNEL.messageBuilder(SaveDialogueEditorPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SaveDialogueEditorPacket::encode)
                .decoder(SaveDialogueEditorPacket::decode)
                .consumerMainThread(SaveDialogueEditorPacket::handle)
                .add();

        CHANNEL.messageBuilder(GearEquipAnimationPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(GearEquipAnimationPacket::encode)
                .decoder(GearEquipAnimationPacket::decode)
                .consumerMainThread(GearEquipAnimationPacket::handle)
                .add();

        CHANNEL.messageBuilder(PanelNoticePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(PanelNoticePacket::encode)
                .decoder(PanelNoticePacket::decode)
                .consumerMainThread(PanelNoticePacket::handle)
                .add();

        CHANNEL.messageBuilder(WeaponPresetListPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(WeaponPresetListPacket::encode)
                .decoder(WeaponPresetListPacket::decode)
                .consumerMainThread(WeaponPresetListPacket::handle)
                .add();
    }

    public static void sendToServer(Object message) {
        CHANNEL.sendToServer(message);
    }

    public static void sendToPlayer(Object message, ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }
}
