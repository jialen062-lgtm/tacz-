# 区域任务管理器 (zonetaskmanager) — 作者 Niejiale
Minecraft 1.20.1 / Forge 47.3.0 / 依赖 CustomNPCs Unofficial (modId `customnpcs`)

## 构建
1. 无需 CNPC jar（编译用 src/main/java/noppes（编译桩，不进 jar） 桩类，不进产物）
2. 用 IDE 导入 Gradle 项目（或自行 `gradle wrapper` 后 `./gradlew build`），产物在 `build/libs/`
3. 运行/服务器需同时安装 CNPC 非官方版

## 项目结构
```
build.gradle / settings.gradle / gradle.properties
libs/                                   放 CNPC jar
src/main/resources/
  META-INF/mods.toml                    声明对 customnpcs 的强依赖
  assets/zonetaskmanager/models/item/zone_divider.json   复用 minecraft:item/stick 贴图
  assets/zonetaskmanager/lang/{zh_cn,en_us}.json         「地图区域划分器」等名称
src/main/java/com/niejiale/zonetask/
  ZoneTaskMod.java        入口：注册物品、网络、配置
  ModItems.java           zone_divider
  config/ZoneConfig.java  config/zonetaskmanager-common.toml：撤离 x/y/z/dimension
  zone/Zone.java          长方体区域
  zone/ZoneStorage.java   JSON 持久化：<世界>/zonetaskmanager/<维度>.json
  zone/SelectionManager   服务端 A/B 选点
  command/PyCommand.java  /py <名字>、/py sc <名字>（需要权限等级 2）
  task/SuspectChecker     CNPC API：嫌疑人判定 + 区域内重新扫描
  task/EvacuationManager  阶段二：P 键投票、广播、传送结算
  task/TaskEvents         LivingDeathEvent、玩家登录/换维度同步、服务端拦截
  network/*               SimpleChannel 与 5 个数据包
  client/*                ClientState、渲染线框、P 键(ClientTickEvent)、点选
```

## CNPC API（已对照 jar 核实）
- 该 jar 中**没有 `INpc`**，对应接口是 `noppes.npcs.api.entity.ICustomNpc`。
- `直接 instanceof noppes.npcs.entity.EntityNPCInterface，getFaction() 取阵营
- `ICustomNpc#getFaction()` → `IFaction`。
- **Aggressive 判定：`IFaction#playerStatus(IPlayer)`，返回 `-1` 即 Aggressive**
  （字节码：点数 ≥ friendlyPoints → 1；< neutralPoints → -1；否则 0）。
  不用 `Faction#isAggressiveToPlayer`，因为它对创造模式玩家恒为 false。
- CNPC 的“敌对”是相对玩家声望而言：口径为“任意在线玩家对该阵营为 Aggressive，则该 NPC 计为嫌疑人”。

## LivingDeathEvent
`TaskEvents#onLivingDeath`：服务端、`EventPriority.LOWEST`（不接收已取消事件）→ `SuspectChecker.isSuspect(dead)` →
遍历当前维度包含死者坐标的区域 → `countAlive(...)` 重新扫描（排除死者）→ 为 0 则 `EvacuationManager.start`。

## SimpleChannel 同步
| 包 | 方向 | 作用 |
|---|---|---|
| SelectPointPacket | C2S | 左/右键点选，服务端校验手持物与距离 |
| EvacReadyPacket | C2S | 按 P，服务端标记并广播“还剩 X 人” |
| SyncZonesPacket | S2C | 当前维度已保存区域（登录/换维度/重生/增删时发送） |
| SyncSelectionPacket | S2C | 当前 A/B（用于选区预览线框） |
| EvacStatePacket | S2C | 撤离阶段开/关 |
渲染完全在客户端：`RenderLevelStageEvent`（AFTER_TRANSLUCENT_BLOCKS）+ `LevelRenderer.renderLineBox`，仅在主手持划分器时绘制。

## 已知限制 / 说明
- 只统计已加载区块内的实体。
- P 键默认与原版“社交屏幕”冲突，可在控制设置中改键。
- 坐标缺失时：全员按 P 后广播红字“坐标不存在！”，保持撤离阶段，改好配置后可重按 P。
- 区域名不能以 `sc ` 开头（会被解析为删除子命令）。
