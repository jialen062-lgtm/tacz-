package noppes.npcs.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import noppes.npcs.controllers.data.Faction;

/** 仅编译用桩类（签名与 CNPC 1.20.1 GBPort 20260711 一致，已从 jar 核实）。build.gradle 中 jar 会排除 noppes/**。 */
public abstract class EntityNPCInterface extends PathfinderMob {
    protected EntityNPCInterface(EntityType<? extends PathfinderMob> type, Level level) { super(type, level); }
    public Faction getFaction() { throw new UnsupportedOperationException("stub"); }
}
