package noppes.npcs.controllers.data;

/** 编译用桩类 */
public class Faction {
    public int id;
    public int neutralPoints;
    public int friendlyPoints;
}
