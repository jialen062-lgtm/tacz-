package noppes.npcs.controllers.data;

import net.minecraft.world.entity.player.Player;

/** 编译用桩类 */
public class PlayerData {
    public PlayerFactionData factionData;
    public static PlayerData get(Player player) { throw new UnsupportedOperationException("stub"); }
}
