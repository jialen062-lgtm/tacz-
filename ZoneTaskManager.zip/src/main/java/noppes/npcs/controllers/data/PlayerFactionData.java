package noppes.npcs.controllers.data;

import net.minecraft.world.entity.player.Player;

/** 编译用桩类 */
public class PlayerFactionData {
    public int getFactionPoints(Player player, int factionId) { throw new UnsupportedOperationException("stub"); }
}
