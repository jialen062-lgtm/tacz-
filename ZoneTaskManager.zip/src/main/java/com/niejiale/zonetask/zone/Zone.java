package com.niejiale.zonetask.zone;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 长方体区域（方块坐标，含两端）。字段 public 以便 Gson 直接序列化。 */
public class Zone {
    public String name;
    public int minX, minY, minZ, maxX, maxY, maxZ;

    public Zone() {}

    public Zone(String name, BlockPos a, BlockPos b) {
        this.name = name;
        minX = Math.min(a.getX(), b.getX()); maxX = Math.max(a.getX(), b.getX());
        minY = Math.min(a.getY(), b.getY()); maxY = Math.max(a.getY(), b.getY());
        minZ = Math.min(a.getZ(), b.getZ()); maxZ = Math.max(a.getZ(), b.getZ());
    }

    public AABB aabb() {
        return new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
    }

    public boolean contains(Vec3 pos) {
        return aabb().contains(pos);
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeUtf(name);
        buf.writeInt(minX); buf.writeInt(minY); buf.writeInt(minZ);
        buf.writeInt(maxX); buf.writeInt(maxY); buf.writeInt(maxZ);
    }

    public static Zone read(FriendlyByteBuf buf) {
        Zone z = new Zone();
        z.name = buf.readUtf();
        z.minX = buf.readInt(); z.minY = buf.readInt(); z.minZ = buf.readInt();
        z.maxX = buf.readInt(); z.maxY = buf.readInt(); z.maxZ = buf.readInt();
        return z;
    }
}
