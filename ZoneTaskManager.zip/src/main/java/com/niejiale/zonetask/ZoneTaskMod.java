package com.niejiale.zonetask;

import com.niejiale.zonetask.config.ZoneConfig;
import com.niejiale.zonetask.network.ZoneNetwork;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** 区域任务管理器 - 作者: Niejiale */
@Mod(ZoneTaskMod.MODID)
public class ZoneTaskMod {
    public static final String MODID = "zonetaskmanager";

    public ZoneTaskMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(ZoneNetwork::register));
        bus.addListener((BuildCreativeModeTabContentsEvent e) -> {
            if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) e.accept(ModItems.ZONE_DIVIDER);
        });
        // 生成 config/zonetaskmanager-common.toml
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ZoneConfig.SPEC);
    }
}
