package com.niejiale.zonetask.network;

import com.niejiale.zonetask.ZoneTaskMod;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * SimpleChannel：
 *  C2S  SelectPointPacket   客户端点击方块 -> 服务端记录 A/B
 *  C2S  EvacReadyPacket     客户端按 P     -> 服务端标记“已准备撤离”
 *  S2C  SyncZonesPacket     服务端 -> 客户端：当前维度已保存区域（用于渲染线框）
 *  S2C  SyncSelectionPacket 服务端 -> 客户端：当前 A/B 选点（用于渲染预览）
 *  S2C  EvacStatePacket     服务端 -> 客户端：撤离阶段开/关
 */
public final class ZoneNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ZoneTaskMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, SelectPointPacket.class, SelectPointPacket::encode, SelectPointPacket::decode,
                SelectPointPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, EvacReadyPacket.class, EvacReadyPacket::encode, EvacReadyPacket::decode,
                EvacReadyPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, SyncZonesPacket.class, SyncZonesPacket::encode, SyncZonesPacket::decode,
                SyncZonesPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, SyncSelectionPacket.class, SyncSelectionPacket::encode, SyncSelectionPacket::decode,
                SyncSelectionPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, EvacStatePacket.class, EvacStatePacket::encode, EvacStatePacket::decode,
                EvacStatePacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    /** 把玩家所在维度的区域发给该玩家 */
    public static void syncZones(ServerPlayer p) {
        ResourceLocation dim = p.level().dimension().location();
        List<Zone> list = new ArrayList<>(ZoneStorage.zones(dim).values());
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new SyncZonesPacket(dim, list));
    }

    /** 区域增删后，通知该维度所有玩家 */
    public static void broadcastZones(MinecraftServer server, ResourceLocation dim) {
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            if (p.level().dimension().location().equals(dim)) syncZones(p);
        }
    }

    private ZoneNetwork() {}
}
