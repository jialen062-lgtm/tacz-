package com.niejiale.zonetask.network;

import com.niejiale.zonetask.task.EvacuationManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** C2S：玩家按下 P 键，标记“已准备撤离”。 */
public record EvacReadyPacket() {
    public void encode(FriendlyByteBuf buf) {}
    public static EvacReadyPacket decode(FriendlyByteBuf buf) { return new EvacReadyPacket(); }

    public static void handle(EvacReadyPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) EvacuationManager.onReady(p);
        });
        ctx.get().setPacketHandled(true);
    }
}
