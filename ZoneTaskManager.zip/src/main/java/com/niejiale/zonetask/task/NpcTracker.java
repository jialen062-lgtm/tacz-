package com.niejiale.zonetask.task;

import net.minecraft.resources.ResourceLocation;
import noppes.npcs.entity.EntityNPCInterface;

import java.util.*;

/**
 * 按维度登记所有已加载的 CNPC NPC（EntityJoinLevelEvent 加入 / EntityLeaveLevelEvent 移除）。
 * 区域扫描只遍历这份名单，开销与 NPC 数量成正比，与区域体积大小无关
 * （以前用 getEntitiesOfClass(AABB) 会遍历整个区域覆盖的所有区块分段）。
 * 只在服务端主线程访问。
 */
public final class NpcTracker {
    private static final Map<ResourceLocation, Set<EntityNPCInterface>> BY_DIM = new HashMap<>();

    public static void add(ResourceLocation dim, EntityNPCInterface npc) {
        BY_DIM.computeIfAbsent(dim, k -> Collections.newSetFromMap(new IdentityHashMap<>())).add(npc);
    }

    public static void remove(ResourceLocation dim, EntityNPCInterface npc) {
        Set<EntityNPCInterface> s = BY_DIM.get(dim);
        if (s != null) s.remove(npc);
    }

    public static Collection<EntityNPCInterface> get(ResourceLocation dim) {
        Set<EntityNPCInterface> s = BY_DIM.get(dim);
        return s == null ? List.of() : s;
    }

    public static void clear() { BY_DIM.clear(); }

    private NpcTracker() {}
}
