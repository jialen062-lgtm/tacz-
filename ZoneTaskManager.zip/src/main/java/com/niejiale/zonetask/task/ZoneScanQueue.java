package com.niejiale.zonetask.task;

import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.server.level.ServerLevel;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 延迟合并扫描：嫌疑人死亡时只把区域标记为“待扫描”，
 * 等 DELAY_TICKS 个 tick 后统一扫一次。
 * 手雷/连发/群体击杀在同一时刻死掉几十个 NPC 时，只会扫描一次而不是几十次（O(N²) -> O(N)）。
 */
public final class ZoneScanQueue {
    private static final int DELAY_TICKS = 5;   // 0.25 秒，玩家几乎无感

    private static final Map<Zone, ServerLevel> PENDING = new LinkedHashMap<>();
    private static int cooldown = 0;

    public static void mark(ServerLevel level, Zone zone) {
        if (PENDING.isEmpty()) cooldown = DELAY_TICKS;
        PENDING.put(zone, level);
    }

    /** 每个服务端 tick 结束时调用，空队列时只有一次 isEmpty 判断 */
    public static void onServerTick() {
        if (PENDING.isEmpty() || --cooldown > 0) return;
        Map<Zone, ServerLevel> batch = new LinkedHashMap<>(PENDING);
        PENDING.clear();
        if (EvacuationManager.isActive()) return;

        Map<ServerLevel, SuspectChecker.Session> sessions = new IdentityHashMap<>();   // 同批共享阵营缓存
        for (Map.Entry<Zone, ServerLevel> en : batch.entrySet()) {
            Zone zone = en.getKey();
            ServerLevel level = en.getValue();
            // 区域在等待期间被删除/覆盖则跳过
            if (ZoneStorage.zones(level.dimension().location()).get(zone.name) != zone) continue;
            SuspectChecker.Session s = sessions.computeIfAbsent(level, SuspectChecker.Session::new);
            if (!SuspectChecker.hasAliveSuspect(level, zone, null, s)) {
                EvacuationManager.start(level.getServer(), zone);
                return;
            }
        }
    }

    public static void clear() { PENDING.clear(); cooldown = 0; }

    private ZoneScanQueue() {}
}
