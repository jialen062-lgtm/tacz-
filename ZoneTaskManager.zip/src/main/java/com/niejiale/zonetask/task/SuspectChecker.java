package com.niejiale.zonetask.task;

import com.niejiale.zonetask.zone.Zone;
import noppes.npcs.api.NpcAPI;
import noppes.npcs.api.entity.ICustomNpc;
import noppes.npcs.api.entity.IPlayer;
import noppes.npcs.api.handler.data.IFaction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * 嫌疑人判定（全部走 CNPC 公开 API，已对照 jar 核实签名）：
 *
 *  1. NpcAPI.Instance().getIEntity(Entity)  -> IEntity 包装；CNPC 的 NPC 会被包装成 ICustomNpc
 *     （注意：该 jar 中不存在名为 INpc 的接口，对应的就是 noppes.npcs.api.entity.ICustomNpc）
 *  2. ICustomNpc#getFaction()               -> IFaction（该 NPC 所属阵营）
 *  3. IFaction#playerStatus(IPlayer)        -> int：
 *        >= friendlyPoints -> 1  (Friendly)
 *        <  neutralPoints  -> -1 (Aggressive，即“不友好/敌对”)
 *        其余              -> 0  (Neutral)
 *     （由 Faction.class 字节码反汇编确认；比 Faction#isAggressiveToPlayer 更合适，
 *      因为后者对创造模式玩家恒返回 false）
 *
 *  CNPC 的阵营“敌对”是相对于玩家声望(阵营点数)而言的，所以这里的口径是：
 *  只要有任意一名在线玩家对该阵营处于 Aggressive 状态，该 NPC 就算嫌疑人。
 */
public final class SuspectChecker {
    /** IFaction#playerStatus 返回 -1 = Aggressive */
    public static final int AGGRESSIVE = -1;

    public static boolean isSuspect(Entity entity, ServerLevel level) {
        if (entity instanceof Player || !(entity instanceof LivingEntity)) return false;
        Object wrapped = NpcAPI.Instance().getIEntity(entity);
        if (!(wrapped instanceof ICustomNpc<?> npc)) return false;     // 不是 CNPC 的 NPC
        IFaction faction = npc.getFaction();
        if (faction == null) return false;
        for (ServerPlayer sp : level.getServer().getPlayerList().getPlayers()) {
            Object pw = NpcAPI.Instance().getIEntity(sp);
            if (pw instanceof IPlayer<?> ip && faction.playerStatus(ip) == AGGRESSIVE) return true;
        }
        return false;
    }

    /** 重新扫描区域内仍存活的嫌疑人数量（exclude = 刚死亡、需排除的实体） */
    public static int countAlive(ServerLevel level, Zone zone, Entity exclude) {
        return level.getEntitiesOfClass(LivingEntity.class, zone.aabb(),
                e -> e != exclude && e.isAlive() && isSuspect(e, level)).size();
    }

    private SuspectChecker() {}
}
