package com.niejiale.zonetask.task;

import com.niejiale.zonetask.zone.Zone;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import noppes.npcs.controllers.data.Faction;
import noppes.npcs.controllers.data.PlayerData;
import noppes.npcs.entity.EntityNPCInterface;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * 嫌疑人判定（直接使用 CNPC 实体类，已对照 GBPort-Unofficial-1.20.1.20260711 字节码核实）：
 *  1. entity instanceof noppes.npcs.entity.EntityNPCInterface
 *  2. EntityNPCInterface#getFaction() -> Faction
 *  3. PlayerData.get(Player).factionData.getFactionPoints(Player, faction.id) < faction.neutralPoints => Aggressive
 *     （等价于 Faction#playerStatus == -1，且对创造模式玩家同样有效）
 * 口径：任意在线玩家对该阵营处于 Aggressive，则该 NPC 计为嫌疑人。任何异常都视为“不是嫌疑人”。
 *
 * 大区域 / 大量 NPC 的性能设计：
 *  - 遍历 NpcTracker 的 NPC 名单，而不是扫描区域体积
 *  - “见证者”缓存：记住每个区域上一个确认存活的嫌疑人，下次先查他，命中即 O(1) 返回
 *  - Session：同一批扫描内，每个阵营的敌对结果只算一次，玩家列表只取一次
 *  - 找到第一个存活嫌疑人即返回
 */
public final class SuspectChecker {
    private static boolean warned = false;
    private static final Map<Zone, WeakReference<EntityNPCInterface>> WITNESS = new WeakHashMap<>();

    /** 一批扫描共享的上下文 */
    public static final class Session {
        final List<ServerPlayer> players;
        final Map<Integer, Boolean> cache = new HashMap<>();
        public Session(ServerLevel level) { this.players = level.getServer().getPlayerList().getPlayers(); }
    }

    /** 单个实体判定（LivingDeathEvent 用） */
    public static boolean isSuspect(Entity entity, ServerLevel level) {
        try {
            if (!(entity instanceof EntityNPCInterface npc)) return false;
            return aggressive(npc, new Session(level));
        } catch (Throwable t) {
            warn(t);
            return false;
        }
    }

    /** 区域内是否还有存活的嫌疑人（exclude 可为 null） */
    public static boolean hasAliveSuspect(ServerLevel level, Zone zone, Entity exclude, Session s) {
        try {
            // 1) 见证者快速通道
            WeakReference<EntityNPCInterface> ref = WITNESS.get(zone);
            EntityNPCInterface w = ref == null ? null : ref.get();
            if (w != null && w != exclude && valid(w, level, zone) && aggressive(w, s)) return true;

            // 2) 遍历该维度已登记的 NPC，先做便宜的存活/坐标判断，最后才查阵营
            for (EntityNPCInterface npc : NpcTracker.get(level.dimension().location())) {
                if (npc == exclude || !valid(npc, level, zone)) continue;
                if (aggressive(npc, s)) {
                    WITNESS.put(zone, new WeakReference<>(npc));
                    return true;
                }
            }
            WITNESS.remove(zone);
            return false;
        } catch (Throwable t) {
            warn(t);
            return true;   // 出错时保守处理：认为还有嫌疑人，避免误触发撤离
        }
    }

    private static boolean valid(EntityNPCInterface npc, ServerLevel level, Zone zone) {
        return npc.isAlive() && npc.level() == level && zone.contains(npc.position());
    }

    private static boolean aggressive(EntityNPCInterface npc, Session s) {
        Faction faction = npc.getFaction();
        if (faction == null) return false;
        Boolean c = s.cache.get(faction.id);
        if (c != null) return c;
        boolean result = false;
        for (ServerPlayer sp : s.players) {
            PlayerData data = PlayerData.get(sp);
            if (data == null || data.factionData == null) continue;
            if (data.factionData.getFactionPoints(sp, faction.id) < faction.neutralPoints) { result = true; break; }
        }
        s.cache.put(faction.id, result);
        return result;
    }

    public static void clear() { WITNESS.clear(); }

    private static void warn(Throwable t) {
        if (!warned) {
            warned = true;
            System.err.println("[ZoneTaskManager] 嫌疑人判定失败（已忽略，仅提示一次）: " + t);
        }
    }

    private SuspectChecker() {}
}
