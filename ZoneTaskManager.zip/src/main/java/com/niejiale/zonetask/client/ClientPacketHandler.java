package com.niejiale.zonetask.client;

import com.niejiale.zonetask.network.EvacStatePacket;
import com.niejiale.zonetask.network.SyncSelectionPacket;
import com.niejiale.zonetask.network.SyncZonesPacket;

/** 仅在客户端被调用（通过 DistExecutor），避免服务端加载客户端类。 */
public final class ClientPacketHandler {
    public static void onZones(SyncZonesPacket m) { ClientState.zonesDim = m.dim(); ClientState.zones = m.zones(); }

    public static void onSelection(SyncSelectionPacket m) { ClientState.selDim = m.dim(); ClientState.selA = m.a(); ClientState.selB = m.b(); }

    public static void onEvac(EvacStatePacket m) { ClientState.evacActive = m.active(); }

    private ClientPacketHandler() {}
}
