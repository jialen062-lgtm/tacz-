package com.niejiale.zonetask.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.niejiale.zonetask.ZoneTaskMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** MOD 总线（客户端）：注册 P 键。注意原版“社交屏幕”默认也是 P，可在控制设置里改键。 */
@Mod.EventBusSubscriber(modid = ZoneTaskMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    public static final KeyMapping EVAC_KEY = new KeyMapping("key.zonetaskmanager.evacuate",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, "key.categories.zonetaskmanager");

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent e) { e.register(EVAC_KEY); }

    private ClientModEvents() {}
}
