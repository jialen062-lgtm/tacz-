package com.niejiale.zonetask.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.niejiale.zonetask.ModItems;
import com.niejiale.zonetask.ZoneTaskMod;
import com.niejiale.zonetask.network.EvacReadyPacket;
import com.niejiale.zonetask.network.SelectPointPacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.zone.Zone;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** FORGE 总线（客户端）：点选、线框渲染、P 键。 */
@Mod.EventBusSubscriber(modid = ZoneTaskMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static BlockPos lastA;
    private static long lastATime;

    private static boolean holding(Player p) {
        return p != null && p.getMainHandItem().is(ModItems.ZONE_DIVIDER.get());
    }

    // ---------- 点选：客户端事件 -> C2S 数据包 ----------
    // 客户端取消事件后原版不会再把“右键方块”发给服务端，所以必须自己发 SelectPointPacket。
    @SubscribeEvent
    public static void onLeftClick(PlayerInteractEvent.LeftClickBlock e) {
        if (!e.getLevel().isClientSide() || !holding(e.getEntity())) return;
        e.setCanceled(true);                                                // 不破坏方块
        if (e.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START) return;
        long now = e.getLevel().getGameTime();
        if (e.getPos().equals(lastA) && now - lastATime < 10) return;      // 按住不放时节流
        lastA = e.getPos().immutable();
        lastATime = now;
        ZoneNetwork.CHANNEL.sendToServer(new SelectPointPacket(true, e.getPos()));
    }

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock e) {
        if (!e.getLevel().isClientSide() || !holding(e.getEntity())) return;
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        ZoneNetwork.CHANNEL.sendToServer(new SelectPointPacket(false, e.getPos()));
    }

    // ---------- 渲染：只在手持划分器时绘制 ----------
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !holding(p)) return;
        var dim = mc.level.dimension().location();

        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.lines());

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);

        if (dim.equals(ClientState.zonesDim)) {
            for (Zone z : ClientState.zones) {                              // 已保存区域：橙色
                LevelRenderer.renderLineBox(ps, vc, z.minX, z.minY, z.minZ, z.maxX + 1, z.maxY + 1, z.maxZ + 1,
                        1.0F, 0.55F, 0.1F, 1.0F);
            }
        }
        if (dim.equals(ClientState.selDim)) {                               // 当前选区预览
            BlockPos a = ClientState.selA, b = ClientState.selB;
            if (a != null) box(ps, vc, a, a, 0.2F, 1.0F, 0.2F);              // A：绿
            if (b != null) box(ps, vc, b, b, 0.3F, 0.6F, 1.0F);              // B：蓝
            if (a != null && b != null) box(ps, vc, a, b, 1.0F, 1.0F, 0.2F); // 选区：黄
        }
        ps.popPose();
        buf.endBatch(RenderType.lines());
    }

    private static void box(PoseStack ps, VertexConsumer vc, BlockPos a, BlockPos b, float r, float g, float bl) {
        LevelRenderer.renderLineBox(ps, vc,
                Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()),
                Math.max(a.getX(), b.getX()) + 1, Math.max(a.getY(), b.getY()) + 1, Math.max(a.getZ(), b.getZ()) + 1,
                r, g, bl, 1.0F);
    }

    // ---------- P 键：ClientTickEvent ----------
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (ClientModEvents.EVAC_KEY.consumeClick()) {
            if (mc.player == null) continue;
            if (ClientState.evacActive) {
                ZoneNetwork.CHANNEL.sendToServer(new EvacReadyPacket());
            } else {
                mc.player.displayClientMessage(Component.literal("当前没有可撤离的任务"), true);
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) { ClientState.reset(); }

    private ClientEvents() {}
}
