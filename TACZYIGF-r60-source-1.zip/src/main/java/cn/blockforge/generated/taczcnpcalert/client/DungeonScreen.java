package cn.blockforge.generated.taczcnpcalert.client;

import cn.blockforge.generated.taczcnpcalert.SheriffService;
import cn.blockforge.generated.taczcnpcalert.net.ModNetwork;
import cn.blockforge.generated.taczcnpcalert.net.PanelActionPacket;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** 左侧纵向副本列表；副本名称仍由服务端配置下发。 */
public final class DungeonScreen extends Screen {
    private static final int PANEL_WIDTH = 250;
    private static final int ROW_HEIGHT = 28;
    private final int npcId;
    private final List<String> dungeonNames;
    private final String selectedDungeon;
    private int scroll;
    private int listTop;
    private int listBottom;

    public DungeonScreen(int npcId, List<String> dungeonNames, String selectedDungeon) {
        super(Component.literal("警长 · 副本选择"));
        this.npcId = npcId;
        this.dungeonNames = List.copyOf(dungeonNames);
        this.selectedDungeon = selectedDungeon == null ? "" : selectedDungeon;
    }

    @Override
    protected void init() {
        listTop = 76;
        listBottom = this.height - 58;
        clampScroll();
    }

    private int visibleRows() { return Math.max(1, (listBottom - listTop) / ROW_HEIGHT); }
    private void clampScroll() { scroll = Math.max(0, Math.min(scroll, Math.max(0, dungeonNames.size() - visibleRows()))); }

    private void select(int index) {
        if (index < 0 || index >= dungeonNames.size()) return;
        ModNetwork.sendToServer(new PanelActionPacket(SheriffService.ACTION_DUNGEON, Integer.toString(index), 0, npcId));
        onClose();
    }

    private void clearSelection() {
        ModNetwork.sendToServer(new PanelActionPacket(SheriffService.ACTION_CLEAR_DUNGEON, "-1", 0, npcId));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        int panelRight = Math.min(PANEL_WIDTH, width - 70);
        g.fill(0, 0, panelRight, height, 0xB9000000);
        g.fill(panelRight - 2, 0, panelRight, height, 0x40FFFFFF);
        g.drawString(font, "警长 · 副本选择", 25, 24, 0xFFFFFFFF, false);
        g.fill(24, 51, panelRight - 24, 52, 0x66FFFFFF);
        String selected = selectedDungeon.isBlank() ? "当前未选择副本" : "当前选择：" + selectedDungeon;
        g.drawString(font, selected, 25, 60, 0xFFFFD34D, false);

        int rows = visibleRows();
        for (int row = 0; row < rows; row++) {
            int index = scroll + row;
            if (index >= dungeonNames.size()) break;
            int y = listTop + row * ROW_HEIGHT;
            boolean hover = mouseX >= 18 && mouseX <= panelRight - 18 && mouseY >= y && mouseY < y + 23;
            g.fill(18, y, panelRight - 18, y + 23, hover ? 0x55FFFFFF : 0x22000000);
            g.drawString(font, dungeonNames.get(index), 30, y + 7, hover ? 0xFFFFFF55 : 0xFFEDEDED, false);
        }
        if (dungeonNames.isEmpty()) {
            g.drawString(font, "没有可玩的副本，请检查配置", 25, listTop + 12, 0xFFFF7777, false);
        }
        if (dungeonNames.size() > rows) {
            g.drawString(font, "滚轮浏览  " + (scroll + 1) + " / " + dungeonNames.size(), 25, listBottom + 7, 0xFFAAAAAA, false);
        }
        g.drawString(font, "清除选择", 25, height - 35, 0xFFE5E5E5, false);
        g.drawString(font, "关闭", panelRight - 65, height - 35, 0xFFE5E5E5, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int panelRight = Math.min(PANEL_WIDTH, width - 70);
        if (mouseY >= listTop && mouseY < listBottom && mouseX >= 18 && mouseX <= panelRight - 18) {
            int row = ((int) mouseY - listTop) / ROW_HEIGHT;
            select(scroll + row);
            return true;
        }
        if (mouseY >= height - 45 && mouseX < 115) { clearSelection(); return true; }
        if (mouseY >= height - 45 && mouseX >= panelRight - 85 && mouseX <= panelRight) { onClose(); return true; }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (mouseX <= PANEL_WIDTH && mouseY >= listTop && mouseY <= listBottom) {
            scroll -= (int)Math.signum(delta);
            clampScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
