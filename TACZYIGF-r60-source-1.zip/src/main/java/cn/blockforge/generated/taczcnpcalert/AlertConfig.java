package cn.blockforge.generated.taczcnpcalert;

import java.util.List;
import java.util.function.Predicate;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * 模组的配置文件，游戏里生成在 config/tacz_cnpc_alert-common.toml。
 * 每一条都写了中文注释，改完保存、重启游戏（或 /reload）后生效。
 *
 * <p>文件里只有 {@code alert} 一段：枪声惊动 NPC 的台词、范围和表现，以及击杀后的无线电播报。</p>
 */
public final class AlertConfig {

    public static final ForgeConfigSpec SPEC;

    /** 听觉半径：枪声离 NPC 多少格之内算“听见了”。 */
    public static final ForgeConfigSpec.DoubleValue HEARING_RADIUS;
    /** 聊天距离：多少格之内的玩家能看到这句喊话。 */
    public static final ForgeConfigSpec.DoubleValue CHAT_RADIUS;
    /** 聊天框里那个红色的前缀。 */
    public static final ForgeConfigSpec.ConfigValue<String> SPEAKER_NAME;
    /** 台词池，随机挑一句，默认两句各 50%。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> LINES;
    /** 哪些实体的出现算“一声枪响”，默认 TaCZ 的子弹实体。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> BULLET_ENTITY_IDS;
    /** 只看注册名时，NPC 必须属于哪些 mod 命名空间，默认 customnpcs。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> NPC_NAMESPACES;
    /** 调试用：拉开后任何生物都会对枪声有反应（没装 CNPC 时也能看效果）。 */
    public static final ForgeConfigSpec.BooleanValue ANY_MOB;
    /** 是否在 NPC 头顶弹感叹号粒子。 */
    public static final ForgeConfigSpec.BooleanValue ENABLE_PARTICLE;
    /** 是否播喊声。 */
    public static final ForgeConfigSpec.BooleanValue ENABLE_SOUND;
    /** 喊声音效的注册名。 */
    public static final ForgeConfigSpec.ConfigValue<String> SHOUT_SOUND;
    /** 喊声音量。 */
    public static final ForgeConfigSpec.DoubleValue SHOUT_VOLUME;
    /** 喊话时 NPC 是否转头看向开枪的人。 */
    public static final ForgeConfigSpec.BooleanValue FACE_SHOOTER;
    /** NPC 挨打时是否也算“进入战斗”。 */
    public static final ForgeConfigSpec.BooleanValue HURT_COUNTS_AS_COMBAT;
    /** 同一个 NPC 两次警觉的最短间隔；默认 1200 tick = 1 分钟。 */
    public static final ForgeConfigSpec.IntValue ALERT_COOLDOWN;

    /** 玩家打死 NPC 后，是否播报“嫌疑人已清除 / 继续前进”。 */
    public static final ForgeConfigSpec.BooleanValue KILL_RADIO_ENABLED;
    /** 第一句的说话人是玩家的 ID，这句话的内容。 */
    public static final ForgeConfigSpec.ConfigValue<String> KILL_RADIO_FIRST_LINE;
    /** 隔几 tick 播第二句，40 tick = 2 秒。 */
    public static final ForgeConfigSpec.IntValue KILL_RADIO_DELAY_TICKS;
    /** 第二句的说话人，默认“指挥部”。 */
    public static final ForgeConfigSpec.ConfigValue<String> KILL_RADIO_COMMAND_SPEAKER;
    /** 第二句的内容。 */
    public static final ForgeConfigSpec.ConfigValue<String> KILL_RADIO_SECOND_LINE;
    /** 玩家名称颜色，r60 固定为红色；指挥部名称固定为金色。 */
    public static final ForgeConfigSpec.ConfigValue<String> KILL_RADIO_COLOR;

    /** 手动往“装备”页里加的物品（一般留空，装备会自动从军事装备模组里认出来）。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EQUIPMENT_EXTRA;
    /** 军事装备模组的命名空间（modid），装备页会把这些 mod 里的护甲类装备自动列出来。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> MILITARY_NAMESPACES;
    /** 一个军事装备都没认出来时的备用清单（默认一套铁装加盾牌）。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FALLBACK_EQUIPMENT;
    /** 军需官面板“子弹”页点一次给多少发。 */
    public static final ForgeConfigSpec.IntValue AMMO_STACK_SIZE;

    // ---- 近战 / 投掷识别 ----
    /** 近战武器页扫描的命名空间。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> MELEE_NAMESPACES;
    /** 手动往“近战”页加的物品注册名。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> MELEE_EXTRA;
    /** 投掷物页扫描的命名空间（投掷类爆炸同时受“禁止破坏方块”保护）。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> THROWABLE_NAMESPACES;
    /** 手动往“投掷物”页加的物品注册名。 */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> THROWABLE_EXTRA;
    /** 外部投掷物的雷类爆炸是否禁止破坏方块。 */
    public static final ForgeConfigSpec.BooleanValue PROTECT_TERRAIN;

    // ---- NPC 战场投掷与烟雾 ----
    /** 是否允许 NPC 远程投掷。 */
    public static final ForgeConfigSpec.BooleanValue NPC_THROW_ENABLED;
    /** NPC 是否优先扔 TaCZ 扩展包（绿葡萄战术攻防等）里的投掷物。 */
    public static final ForgeConfigSpec.BooleanValue NPC_USE_EXTERNAL_THROWABLES;
    /** 别的 mod / 玩家扔的烟雾弹是否也遮挡 NPC 的视线。 */
    public static final ForgeConfigSpec.BooleanValue EXTERNAL_SMOKE_BLINDS;
    /** NPC 两次投掷之间的冷却 tick。 */
    public static final ForgeConfigSpec.IntValue NPC_THROW_COOLDOWN;
    /** 每次检查时投掷的概率（百分比）。 */
    public static final ForgeConfigSpec.IntValue NPC_THROW_CHANCE;
    /** 投出的雷里烟雾弹占比（百分比）。 */
    public static final ForgeConfigSpec.IntValue NPC_SMOKE_CHANCE;
    /** 少于这个距离不投（免得糊脸）。 */
    public static final ForgeConfigSpec.DoubleValue NPC_THROW_MIN_DISTANCE;
    /** 超过这个距离不投。 */
    public static final ForgeConfigSpec.DoubleValue NPC_THROW_MAX_DISTANCE;
    /** 烟雾区半径（格）。 */
    public static final ForgeConfigSpec.DoubleValue SMOKE_RADIUS;
    /** 烟雾区持续 tick（20 tick = 1 秒）。 */
    public static final ForgeConfigSpec.IntValue SMOKE_DURATION;
    /** 被烟雾挡住后“找不到人”的时长 tick。 */
    public static final ForgeConfigSpec.IntValue SMOKE_BLIND_TICKS;

    /**
     * 警长面板里的副本入口。
     *
     * <p>格式：{@code 副本名@维度:x y z}。没有维度或坐标时只显示名称，不传送。</p>
     */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> DUNGEON_ENTRIES;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.comment("TACZ × CNPC：枪声惊动 NPC 的设置").push("alert");

        HEARING_RADIUS = builder
                .comment("听觉半径（格）。枪声在这个距离内的 NPC 才会警觉，默认 7 格。")
                .defineInRange("hearing_radius", 7.0D, 1.0D, 64.0D);

        CHAT_RADIUS = builder
                .comment("聊天可见距离（格）。只有这个范围内的玩家能在左下角聊天框看到喊话。")
                .defineInRange("chat_radius", 32.0D, 1.0D, 256.0D);

        SPEAKER_NAME = builder
                .comment("聊天框里那个红色前缀（喊话者名字）。")
                .define("speaker_name", "嫌疑人");

        LINES = builder
                .comment("台词池。每次喊话随机挑一句，两条时各 50% 概率。")
                .defineList("lines", List.of("谁在那!", "给我出来!"), nonBlankString());

        BULLET_ENTITY_IDS = builder
                .comment("哪些实体的出现算“一声枪响”。默认 TaCZ 开枪时生成的子弹实体 tacz:bullet。")
                .defineList("bullet_entity_ids", List.of("tacz:bullet"), nonBlankString());

        NPC_NAMESPACES = builder
                .comment("哪些 mod 命名空间下的生物算 NPC。默认 CustomNPCs 的 customnpcs。")
                .comment("如果你用的是别的 NPC 模组，把它的命名空间加进来即可，例如 \"customnpcplus\"。")
                .defineList("npc_namespaces", List.of("customnpcs"), nonBlankString());

        ANY_MOB = builder
                .comment("调试开关：开启后任何生物（僵尸、牛、村民……）都会对枪声有反应。")
                .comment("还没装 CustomNPCs、只想先看看效果时打开它；正式地图请保持 false，")
                .comment("否则原版动物和村民也会被枪声惊动、被打死时还会播\u201c嫌疑人已清除\u201d。")
                .define("any_mob", false);

        ENABLE_PARTICLE = builder
                .comment("是否在 NPC 头顶弹出感叹号粒子。")
                .define("enable_particle", true);

        ENABLE_SOUND = builder
                .comment("是否播放短促喊声。")
                .define("enable_sound", true);

        SHOUT_SOUND = builder
                .comment("喊声音效的注册名，默认是掠夺者的短促叫声。可换成任意原版音效。")
                .define("shout_sound", "minecraft:entity.pillager.ambient");

        SHOUT_VOLUME = builder
                .comment("喊声音量，默认 0.9。")
                .defineInRange("shout_volume", 0.9D, 0.0D, 4.0D);

        FACE_SHOOTER = builder
                .comment("喊话时 NPC 是否转头看向开枪的人（只影响朝向，不改 NPC 自己的 AI）。")
                .define("face_shooter", true);

        HURT_COUNTS_AS_COMBAT = builder
                .comment("NPC 被打时是否也算进入战斗。")
                .define("hurt_counts_as_combat", true);

        ALERT_COOLDOWN = builder
                .comment("同一个 NPC 两次警觉之间最短隔多少 tick。20 tick = 1 秒，默认 1200 tick = 1 分钟。")
                .comment("也就是说同一个 NPC 在 1 分钟之内最多只喊一次；填 0 表示不限制。")
                .defineInRange("alert_cooldown_ticks", 1200, 0, 24000);

        builder.comment("玩家打死 NPC 后，聊天框里的无线电播报").push("kill_radio");

        KILL_RADIO_ENABLED = builder
                .comment("是否播报“玩家ID: 嫌疑人已清除!”，2 秒后再播“指挥部: 继续前进!”。")
                .comment("这两句只认“谁打死的”：击杀者离 NPC 多远、在哪个维度都会收到，")
                .comment("NPC 周围的玩家按下面的 chat_radius 收到。NPC 喊“谁在那!”的距离不受影响。")
                .define("enabled", true);

        KILL_RADIO_FIRST_LINE = builder
                .comment("第一句的内容，说话人自动用玩家的游戏 ID。")
                .define("first_line", "嫌疑人已清除!");

        KILL_RADIO_DELAY_TICKS = builder
                .comment("两句之间隔多少 tick，20 tick = 1 秒，默认 40 tick = 2 秒。")
                .defineInRange("delay_ticks", 40, 0, 200);

        KILL_RADIO_COMMAND_SPEAKER = builder
                .comment("第二句的说话人。")
                .define("command_speaker", "指挥部");

        KILL_RADIO_SECOND_LINE = builder
                .comment("第二句的内容。")
                .define("second_line", "继续前进!");

        KILL_RADIO_COLOR = builder
                .comment("播报颜色（英文色名）：blue 蓝、aqua 青、red 红、gold 金、white 白、yellow 黄。")
                .define("color", "red");

        builder.pop();

        builder.comment("军需官 NPC（用魔杖点过的 NPC）提供的补给设置").push("supply");

        EQUIPMENT_EXTRA = builder
                .comment("手动往“装备”页里补东西，写物品注册名，一行一个。一般留空就够用。")
                .comment("装备页主要靠 military_namespaces 自动认出军事装备，这里只放自动认不出来的额外物品。")
                .defineList("equipment_extra", List.<String>of(), nonBlankString());

        MILITARY_NAMESPACES = builder
                .comment("军事装备模组的 modid（命名空间），装备页会自动把这个 mod 里的")
                .comment("头盔、防弹衣、护腿、靴子、制服、肩甲、背包、面罩、夜视仪、防弹插板列出来。")
                .comment("默认 fracturepoint，也就是 Fracture Point（军事装备模组）。")
                .comment("换成别的装备 mod 时，写它的 modid 即可，例如 \"somearmormod\"。")
                .defineList("military_namespaces", List.of("fracturepoint"), nonBlankString());

        FALLBACK_EQUIPMENT = builder
                .comment("一个军事装备都没认出来的时候（多半是没装那个模组），装备页改用这份备用清单。")
                .defineList("fallback_equipment", List.of(
                        "minecraft:iron_helmet",
                        "minecraft:iron_chestplate",
                        "minecraft:iron_leggings",
                        "minecraft:iron_boots"), nonBlankString());

        AMMO_STACK_SIZE = builder
                .comment("子弹页点一次给多少发。默认 64，一次点满一组；“批量领取”会给这么多组各一份。")
                .defineInRange("ammo_stack_size", 64, 1, 4096);

        builder.pop();

        builder.comment("军需官面板：近战武器与投掷物").push("weapons");

        MELEE_NAMESPACES = builder
                .comment("“近战”页会自动列出这些 mod（命名空间）里名字带 knife/melee/bayonet 等的物品。")
                .defineList("melee_namespaces", List.of("tacz", "lrtactical", "fracturepoint"), nonBlankString());

        MELEE_EXTRA = builder
                .comment("手动往“近战”页加的物品注册名，自动认不出来时用。")
                .defineList("melee_extra", List.<String>of(), nonBlankString());

        THROWABLE_NAMESPACES = builder
                .comment("“投掷物”页扫描的命名空间；默认包含绿葡萄战术攻防 lrtactical。这里的雷类弹体爆炸也会自动禁止破坏方块。")
                .defineList("throwable_namespaces", List.of("lrtactical", "tacz", "fracturepoint"), nonBlankString());

        THROWABLE_EXTRA = builder
                .comment("手动往“投掷物”页加的物品注册名。")
                .defineList("throwable_extra", List.<String>of(), nonBlankString());

        PROTECT_TERRAIN = builder
                .comment("雷类投掷物的爆炸是否禁止破坏方块（伤害保留）。默认开。")
                .define("throwables_do_not_break_blocks", true);

        builder.pop();

        builder.comment("NPC 战场投掷与烟雾致盲").push("combat");

        NPC_THROW_ENABLED = builder
                .comment("是否允许 NPC 在有目标时远程投掷手雷/烟雾弹。")
                .define("npc_throw_enabled", true);

        NPC_USE_EXTERNAL_THROWABLES = builder
                .comment("NPC 投掷时使用 TaCZ 扩展包（绿葡萄战术攻防等）里的真实投掷物。",
                        "认不出来或扔不出去时不会生成本模组自制替代品。")
                .define("npc_use_tacz_throwables", true);

        EXTERNAL_SMOKE_BLINDS = builder
                .comment("别的模组或玩家扔的烟雾弹，是否也让 NPC 看不见人（在落点补一片致盲烟雾区）。")
                .define("external_smoke_blinds", true);

        NPC_THROW_COOLDOWN = builder
                .comment("同一个 NPC 两次投掷的最短间隔 tick。20 tick = 1 秒，默认 120 = 6 秒。")
                .defineInRange("npc_throw_cooldown_ticks", 120, 20, 1200);

        NPC_THROW_CHANCE = builder
                .comment("NPC 每次检查时投掷的概率（百分比），默认 50。")
                .defineInRange("npc_throw_chance_percent", 50, 0, 100);

        NPC_SMOKE_CHANCE = builder
                .comment("NPC 投出的雷里烟雾弹占的比例（百分比），默认 20。")
                .defineInRange("npc_smoke_chance_percent", 20, 0, 100);

        NPC_THROW_MIN_DISTANCE = builder
                .comment("目标离 NPC 少于此格数不投雷（免得糊脸自伤）。")
                .defineInRange("npc_throw_min_distance", 6.0D, 2.0D, 20.0D);

        NPC_THROW_MAX_DISTANCE = builder
                .comment("目标离 NPC 超过此格数不投雷。")
                .defineInRange("npc_throw_max_distance", 26.0D, 8.0D, 64.0D);

        SMOKE_RADIUS = builder
                .comment("烟雾区半径（格）。")
                .defineInRange("smoke_radius", 4.5D, 1.0D, 12.0D);

        SMOKE_DURATION = builder
                .comment("烟雾区持续 tick，20 tick = 1 秒，默认 300 = 15 秒。")
                .defineInRange("smoke_duration_ticks", 300, 40, 1200);

        SMOKE_BLIND_TICKS = builder
                .comment("视线被烟雾挡住后，NPC “找不到人”的时长 tick，默认 100 = 5 秒。")
                .defineInRange("smoke_blind_ticks", 100, 20, 600);

        builder.pop();

        builder.comment("警长 NPC 的副本选择").push("dungeon");

        DUNGEON_ENTRIES = builder
                .comment("警长面板显示的副本。格式：副本名@维度:x y z，例如 废弃工厂@minecraft:overworld:100 64 -200。")
                .comment("不写维度或坐标时只显示副本名、不传送。列表顺序就是面板顺序。")
                .defineList("entries", List.of("训练场", "废弃工厂", "地下研究所"), nonBlankString());

        builder.pop();
        builder.pop();

        SPEC = builder.build();
    }

    private static Predicate<Object> nonBlankString() {
        return object -> object instanceof String text && !text.isBlank();
    }

    private AlertConfig() {
    }
}
